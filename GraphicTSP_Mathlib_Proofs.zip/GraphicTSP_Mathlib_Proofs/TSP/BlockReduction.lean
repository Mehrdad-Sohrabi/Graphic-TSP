import TSP.TourGluing
import TSP.SmallGraphs

/-! Exact reduction of universal tour bounds to two-vertex-connected graphs.
The block-case premise is a generic reduction input, not a final approximation theorem. -/
namespace TSP.Graph
open Chapter06
open Classical

/-- Finite articulation recursion proves the general graph bound from the block bound.
No running-time statement is asserted here. -/
theorem tour_bound_of_two_vertex_connected (C : ℝ) (hC : 1 ≤ C)
    (hblock : ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), G.IsSimple → IsTwoVertexConnected G →
        ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP) :
    ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), G.IsSimple → G.Connected →
        ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP := by
  have claim : ∀ n : ℕ, ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), Fintype.card V = n → G.IsSimple → G.Connected →
        ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro V E _ _ _ _ G hn hs hc
      by_cases hsmall : Fintype.card V ≤ 2
      · exact small_graph_tour_bound G hs hc hsmall C hC
      · by_cases htwo : IsTwoVertexConnected G
        · exact hblock V E G hs htwo
        · obtain ⟨r, A, hA, _, hltA, _, hltB⟩ := exists_articulation_split G hc (by omega) htwo
          obtain ⟨x, hx, _⟩ := exists_optimal_subtour G hc
          have hleft := ih A.card (by omega) A (G.insideEdges A) (G.inducedSubgraph A)
            (by simp) (induced_simple G hs A) (attached_connected G A r hA hx)
          have hright := ih (otherPiece A r).card (by omega)
            (otherPiece A r) (G.insideEdges (otherPiece A r)) (G.inducedSubgraph (otherPiece A r))
            (by simp) (induced_simple G hs _) (attached_connected G _ r (otherPiece_attached G A r hA) hx)
          exact articulation_tour_bound G hs hc A r hA C hleft hright
  intro V E _ _ _ _ G hs hc
  exact claim (Fintype.card V) V E G rfl hs hc
end TSP.Graph
