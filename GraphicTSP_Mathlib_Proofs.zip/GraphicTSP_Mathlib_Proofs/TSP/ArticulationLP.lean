import TSP.ArticulationSplit
import TSP.InducedOptimization

/-! Exact additive LP accounting at a one-vertex separation. -/
namespace TSP.Graph
open scoped BigOperators
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem induced_objective (G : Graph V E) (A : Finset V) (x : E → ℝ) :
    edgeSum (restrictEdgeVector (G.insideEdges A) x) Finset.univ = edgeSum x (G.insideEdges A) := by
  rw [restrictEdgeVector_edgeSum, includeEdges_univ]

theorem piece_objectives_add (G : Graph V E) (hsimple : G.IsSimple)
    (A : Finset V) (r : V) (hA : G.AttachedAt A r) (x : E → ℝ) :
    edgeSum (restrictEdgeVector (G.insideEdges A) x) Finset.univ +
      edgeSum (restrictEdgeVector (G.insideEdges (otherPiece A r)) x) Finset.univ =
        edgeSum x Finset.univ := by
  rw [induced_objective G A x, induced_objective G (otherPiece A r) x]
  unfold edgeSum
  rw [← Finset.sum_union (piece_edges_disjoint G hsimple A r), piece_edges_union G A r hA]

/-- The two attached pieces have LP values summing to the original LP optimum. -/
theorem articulation_subtourLP_add (G : Graph V E) (hsimple : G.IsSimple) (hconn : G.Connected)
    (A : Finset V) (r : V) (hA : G.AttachedAt A r) :
    (G.inducedSubgraph A).subtourLP + (G.inducedSubgraph (otherPiece A r)).subtourLP = G.subtourLP := by
  obtain ⟨x, hx, ho⟩ := exists_optimal_subtour G hconn
  rw [← attached_restriction_optimal G A r hA hx ho,
    ← attached_restriction_optimal G (otherPiece A r) r (otherPiece_attached G A r hA) hx ho,
    piece_objectives_add G hsimple A r hA x, ho]

/-- An actual optimal extreme vector induces optimal extreme vectors on both pieces. -/
theorem articulation_optimal_extreme_restrictions (G : Graph V E)
    (A : Finset V) (r : V) (hA : G.AttachedAt A r) {x : E → ℝ}
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (ho : edgeSum x Finset.univ = G.subtourLP) :
    (restrictEdgeVector (G.insideEdges A) x ∈ (G.inducedSubgraph A).subtourPolytope.extremePoints ℝ ∧
      edgeSum (restrictEdgeVector (G.insideEdges A) x) Finset.univ = (G.inducedSubgraph A).subtourLP) ∧
    (restrictEdgeVector (G.insideEdges (otherPiece A r)) x ∈
      (G.inducedSubgraph (otherPiece A r)).subtourPolytope.extremePoints ℝ ∧
      edgeSum (restrictEdgeVector (G.insideEdges (otherPiece A r)) x) Finset.univ =
        (G.inducedSubgraph (otherPiece A r)).subtourLP) := by
  exact ⟨⟨attached_restriction_extreme G A r hA hx, attached_restriction_optimal G A r hA hx.1 ho⟩,
    attached_restriction_extreme G (otherPiece A r) r (otherPiece_attached G A r hA) hx,
    attached_restriction_optimal G (otherPiece A r) r (otherPiece_attached G A r hA) hx.1 ho⟩
end TSP.Graph
