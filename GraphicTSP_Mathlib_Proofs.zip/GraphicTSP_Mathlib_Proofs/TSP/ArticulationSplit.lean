import TSP.VertexInduced

/-! Construct an actual smaller one-vertex separation when vertex connectivity fails. -/
namespace TSP.Graph
open Chapter06
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def otherPiece (A : Finset V) (r : V) : Finset V := insert r Aᶜ

theorem otherPiece_attached (G : Graph V E) (A : Finset V) (r : V) (hA : G.AttachedAt A r) :
    G.AttachedAt (otherPiece A r) r := by
  refine ⟨Finset.mem_insert_self _ _, ?_⟩
  intro e
  constructor
  · intro hs hsr
    have hsn : G.src e ∉ A := by simpa [otherPiece, hsr] using hs
    by_cases htr : G.dst e = r
    · simp [otherPiece, htr]
    · apply Finset.mem_insert_of_mem
      apply Finset.mem_compl.mpr
      intro ht
      exact hsn ((hA.2 e).2 ht htr)
  · intro ht htr
    have htn : G.dst e ∉ A := by simpa [otherPiece, htr] using ht
    by_cases hsr : G.src e = r
    · simp [otherPiece, hsr]
    · apply Finset.mem_insert_of_mem
      apply Finset.mem_compl.mpr
      intro hs
      exact htn ((hA.2 e).1 hs hsr)

theorem pieces_union (A : Finset V) (r : V) : A ∪ otherPiece A r = Finset.univ := by
  ext v
  simp [otherPiece]

theorem pieces_inter (A : Finset V) (r : V) (hr : r ∈ A) : A ∩ otherPiece A r = {r} := by
  ext v
  simp only [otherPiece, Finset.mem_inter, Finset.mem_insert, Finset.mem_compl, Finset.mem_singleton]
  constructor
  · rintro ⟨hv, h | h⟩
    · exact h
    · exact (h hv).elim
  · intro h
    subst v
    exact ⟨hr, Or.inl rfl⟩

theorem piece_edges_disjoint (G : Graph V E) (hsimple : G.IsSimple)
    (A : Finset V) (r : V) : Disjoint (G.insideEdges A) (G.insideEdges (otherPiece A r)) := by
  apply Finset.disjoint_left.mpr
  intro e he hf
  have ha := (Finset.mem_filter.mp he).2
  have hb := (Finset.mem_filter.mp hf).2
  have hs : G.src e = r := by simpa [otherPiece, ha.1] using hb.1
  have ht : G.dst e = r := by simpa [otherPiece, ha.2] using hb.2
  exact hsimple.1 e (hs.trans ht.symm)

theorem piece_edges_union (G : Graph V E) (A : Finset V) (r : V) (hA : G.AttachedAt A r) :
    G.insideEdges A ∪ G.insideEdges (otherPiece A r) = Finset.univ := by
  apply Finset.eq_univ_of_forall
  intro e
  by_cases hs : G.src e ∈ A
  · by_cases ht : G.dst e ∈ A
    · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hs, ht⟩)
    · have hsr : G.src e = r := by by_contra h; exact ht ((hA.2 e).1 hs h)
      exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,
        by simp [otherPiece, hsr], by simp [otherPiece, ht]⟩)
  · by_cases ht : G.dst e ∈ A
    · have htr : G.dst e = r := by by_contra h; exact hs ((hA.2 e).2 ht h)
      exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,
        by simp [otherPiece, hs], by simp [otherPiece, htr]⟩)
    · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,
        by simp [otherPiece, hs], by simp [otherPiece, ht]⟩)

noncomputable def reachableAway (G : Graph V E) (r u : V) : Finset V :=
  Finset.univ.filter (fun v => v ≠ r ∧ Relation.ReflTransGen
    (G.AdjOn (Finset.univ.filter (fun e => G.src e ≠ r ∧ G.dst e ≠ r))) u v)

theorem reachable_piece_attached (G : Graph V E) (r u : V) :
    G.AttachedAt (insert r (G.reachableAway r u)) r := by
  refine ⟨Finset.mem_insert_self _ _, ?_⟩
  intro e
  constructor
  · intro hs hsr
    have hp := (Finset.mem_filter.mp (Finset.mem_of_mem_insert_of_ne hs hsr)).2.2
    by_cases htr : G.dst e = r
    · exact Finset.mem_insert.mpr (Or.inl htr)
    · apply Finset.mem_insert_of_mem
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, htr, ?_⟩
      exact hp.tail ⟨e, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hsr, htr⟩, Or.inl ⟨rfl, rfl⟩⟩
  · intro ht htr
    have hp := (Finset.mem_filter.mp (Finset.mem_of_mem_insert_of_ne ht htr)).2.2
    by_cases hsr : G.src e = r
    · exact Finset.mem_insert.mpr (Or.inl hsr)
    · apply Finset.mem_insert_of_mem
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, hsr, ?_⟩
      exact hp.tail ⟨e, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hsr, htr⟩, Or.inr ⟨rfl, rfl⟩⟩

/-- A connected graph of order at least three that is not two-vertex-connected
has two proper induced pieces, each attached to the rest at the same vertex. -/
theorem exists_articulation_split (G : Graph V E) (hconn : G.Connected)
    (hn : 3 ≤ Fintype.card V) (hnot : ¬IsTwoVertexConnected G) :
    ∃ (r : V) (A : Finset V), G.AttachedAt A r ∧
      2 ≤ A.card ∧ A.card < Fintype.card V ∧
      2 ≤ (otherPiece A r).card ∧ (otherPiece A r).card < Fintype.card V := by
  have hf : ¬∀ r u v : V, u ≠ r → v ≠ r → Relation.ReflTransGen
      (G.AdjOn (Finset.univ.filter (fun e => G.src e ≠ r ∧ G.dst e ≠ r))) u v :=
    fun h => hnot ⟨hn, hconn, h⟩
  push_neg at hf
  obtain ⟨r, u, v, hur, hvr, hpath⟩ := hf
  let A := insert r (G.reachableAway r u)
  have hr : r ∈ A := Finset.mem_insert_self _ _
  have hu : u ∈ A := Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hur, .refl⟩)
  have hv : v ∉ A := by
    intro hh
    rcases Finset.mem_insert.mp hh with h | h
    · exact hvr h
    · exact hpath (Finset.mem_filter.mp h).2.2
  have hcardA : 2 ≤ A.card := by
    have hsub : ({r, u} : Finset V) ⊆ A := by simp only [Finset.insert_subset_iff, Finset.singleton_subset_iff]; exact ⟨hr, hu⟩
    simpa [Ne.symm hur] using Finset.card_le_card hsub
  have hltA : A.card < Fintype.card V := by
    have he : A ≠ Finset.univ := fun heq => hv (heq ▸ Finset.mem_univ v)
    simpa using Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_univ _, he⟩)
  have hvC : v ∈ otherPiece A r := by simp [otherPiece, hv]
  have hrC : r ∈ otherPiece A r := Finset.mem_insert_self _ _
  have huC : u ∉ otherPiece A r := by simp [otherPiece, hur, hu]
  have hcardC : 2 ≤ (otherPiece A r).card := by
    have hsub : ({r, v} : Finset V) ⊆ otherPiece A r := by simp only [Finset.insert_subset_iff, Finset.singleton_subset_iff]; exact ⟨hrC, hvC⟩
    simpa [Ne.symm hvr] using Finset.card_le_card hsub
  have hltC : (otherPiece A r).card < Fintype.card V := by
    have he : otherPiece A r ≠ Finset.univ := fun heq => huC (heq ▸ Finset.mem_univ u)
    simpa using Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_univ _, he⟩)
  exact ⟨r, A, reachable_piece_attached G r u, hcardA, hltA, hcardC, hltC⟩
end TSP.Graph
