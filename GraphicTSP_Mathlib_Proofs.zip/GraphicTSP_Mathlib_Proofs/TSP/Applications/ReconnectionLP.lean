import TSP.Manuscript20261020.RepairLP

/-!
The notation of the 2026-11-05 manuscript, Section 4 and Appendix C.
These are explicit definitions and equivalence proofs, not new mathematical
assumptions. The legacy implementation names remain available for reuse.
-/
namespace TSP.Manuscript20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter08
open scoped BigOperators
variable {V E I : Type} [Fintype V] [Fintype E] [Fintype I]
  [DecidableEq V] [DecidableEq E] [DecidableEq I]

/-- P_R: exactly the box, auxiliary degree, and blossom inequalities (22). -/
def ReconnectionLP (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I) : Set (RewardEdge E I → ℝ) :=
  {x | (∀ a, 0 ≤ x a ∧ x a ≤ 1) ∧
    (∀ i, edgeSum (withoutRewardLoops x) (starRepresentatives stars i) +
      x (Sum.inl (Sum.inr i)) + 2 * x (Sum.inr i) ≤ (stars i).card + 1) ∧
    CutBlossomConstraints (rewardGraph G center owner) x}

/-- P^circ: the bounded odd-join polytope described in (26). -/
def NonloopReconnectionLP (G : Graph V E) (center : I → V)
    (owner : E → Option I) : Set ((E ⊕ I) → ℝ) :=
  {y | BoxConstraints y ∧ CutBlossomConstraints (auxiliaryGraph G center owner) y}

/-- Phi_H, including the cost of two for every unselected reward loop. -/
noncomputable def reconnectionCost (stars : I → Finset E)
    (x : RewardEdge E I → ℝ) : ℝ :=
  Fintype.card E - edgeSum (withoutRewardLoops x) (removableRepresentatives stars) +
    edgeSum (withoutRewardLoops x) (nonremovableRepresentatives stars) +
      2 * ∑ i, (1 - x (Sum.inr i))

/-- Phi_(G,S), the exact general-system expression (27).
The leading term becomes n-1 only for the particular DFS system. -/
noncomputable def nonloopReconnectionCost (stars : I → Finset E)
    (y : (E ⊕ I) → ℝ) : ℝ :=
  Fintype.card E - (∑ i, ((stars i).card - 1 : ℝ)) +
    edgeSum y (nonremovableRepresentatives stars) +
      ∑ i, max (y (Sum.inr i)) ((stars i).card - 1 - edgeSum y (starRepresentatives stars i))

/-- The minimization in (23); attainment is proved below. -/
noncomputable def ReconnectionLPOpt (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I) : ℝ :=
  sInf (reconnectionCost stars '' ReconnectionLP G stars center owner)

theorem reconnectionLP_eq_frameworkTwo (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hsimple : G.IsSimple) (hsys : IsRemovableSystem G stars center)
    (howner : ValidOwner stars owner) :
    ReconnectionLP G stars center owner = frameworkTwoPolytope G center owner := by
  ext x
  exact (frameworkTwo_description_iff edmondsJohnson_proved G stars center owner
    hsimple hsys howner x).symm

theorem reconnectionCost_eq_certificate (stars : I → Finset E)
    (x : RewardEdge E I → ℝ) : reconnectionCost stars x = certificate stars x := by
  simp only [reconnectionCost, certificate, frameworkTwoObjective, frameworkOneObjective,
    Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one]
  ring

theorem nonloopReconnectionCost_eq_repairCost (stars : I → Finset E)
    (y : E ⊕ I → ℝ) :
    nonloopReconnectionCost stars y = Manuscript20261020.repairCost stars y := rfl

/-- Equation (26) defines exactly the actual projection, with no extra bounds. -/
theorem nonloopReconnectionLP_eq_projection (G : Graph V E)
    (center : I → V) (owner : E → Option I) :
    NonloopReconnectionLP G center owner = projectedFrameworkTwo G center owner := by
  rw [projectedFrameworkTwo_eq_oddJoinPolytope]
  ext y
  constructor
  · intro hy
    exact Chapter08.odd_join_polytope_of_cut_blossom edmondsJohnson_proved
      (auxiliaryGraph G center owner) y hy.1 hy.2
  · intro hy
    exact oddJoinPolytope_necessary _ _ hy

theorem reconnectionOpt_eq_legacyRepair (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hsimple : G.IsSimple) (hsys : IsRemovableSystem G stars center)
    (howner : ValidOwner stars owner) :
    ReconnectionLPOpt G stars center owner = Manuscript20261020.Repair G stars center owner := by
  obtain ⟨K, hK, hopt, hmax⟩ := frameworkTwo_integral_optimum G stars center owner
  have heq : reconnectionCost stars (incidence K) =
      Manuscript20261020.Repair G stars center owner := by
    rw [reconnectionCost_eq_certificate]
    change _ - frameworkTwoObjective stars (incidence K) = _
    rw [hopt]
    rfl
  have hleast : IsLeast (reconnectionCost stars '' ReconnectionLP G stars center owner)
      (Manuscript20261020.Repair G stars center owner) := by
    refine ⟨⟨incidence K, ?_, heq⟩, ?_⟩
    · rwa [reconnectionLP_eq_frameworkTwo G stars center owner hsimple hsys howner]
    · rintro _ ⟨x, hx, rfl⟩
      rw [reconnectionLP_eq_frameworkTwo G stars center owner hsimple hsys howner] at hx
      rw [reconnectionCost_eq_certificate]
      exact Manuscript20261020.repair_le_certificate G stars center owner hx
  exact hleast.csInf_eq

/-- C.1, the minimum is attained by an integral point and bounds a real tour. -/
theorem reconnectionLP_integral_minimum (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hsimple : G.IsSimple) (hsys : IsRemovableSystem G stars center)
    (howner : ValidOwner stars owner) :
    ∃ K : Finset (RewardEdge E I), incidence K ∈ ReconnectionLP G stars center owner ∧
      reconnectionCost stars (incidence K) = ReconnectionLPOpt G stars center owner ∧
      (G.tsp : ℝ) ≤ ReconnectionLPOpt G stars center owner := by
  rw [reconnectionLP_eq_frameworkTwo G stars center owner hsimple hsys howner,
    reconnectionOpt_eq_legacyRepair G stars center owner hsimple hsys howner]
  obtain ⟨K, hK, hopt, _⟩ := frameworkTwo_integral_optimum G stars center owner
  refine ⟨K, hK, ?_, Manuscript20261020.tsp_le_repair G stars center owner hsimple hsys howner⟩
  rw [reconnectionCost_eq_certificate]
  change _ - frameworkTwoObjective stars (incidence K) = _
  rw [hopt]
  rfl

/-- C.1, the entire finite distribution statement, not only its mean bound. -/
theorem reconnection_tour_distribution (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hsimple : G.IsSimple) (hsys : IsRemovableSystem G stars center)
    (howner : ValidOwner stars owner) {x : RewardEdge E I → ℝ}
    (hx : x ∈ ReconnectionLP G stars center owner) :
    ∃ (ι : Type) (_ : Fintype ι) (w : ι → ℝ) (c : ι → E → ℕ),
      (∀ i, 0 ≤ w i) ∧ (∑ i, w i = 1) ∧ (∀ i, G.IsTour (c i)) ∧
      (∑ i, w i * (tourLength (c i) : ℝ)) ≤ reconnectionCost stars x := by
  rw [reconnectionCost_eq_certificate]
  rw [reconnectionLP_eq_frameworkTwo G stars center owner hsimple hsys howner] at hx
  exact frameworkTwo_tour_distribution G stars center owner hsimple hsys howner hx

/-- Corollary C.2, including attainment and equality of the two minima. -/
theorem nonloop_reconnection_minimum (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hsimple : G.IsSimple) (hsys : IsRemovableSystem G stars center)
    (howner : ValidOwner stars owner) :
    IsLeast (nonloopReconnectionCost stars '' NonloopReconnectionLP G center owner)
      (ReconnectionLPOpt G stars center owner) := by
  rw [nonloopReconnectionLP_eq_projection,
    reconnectionOpt_eq_legacyRepair G stars center owner hsimple hsys howner]
  exact Manuscript20261020.repair_nonloop_minimum G stars center owner hsimple hsys howner

/-- Theorem 4.1 without its excluded complexity assertion. -/
theorem nonloop_reconnection_tour_bound (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hsimple : G.IsSimple) (hsys : IsRemovableSystem G stars center)
    (howner : ValidOwner stars owner) {y : (E ⊕ I) → ℝ}
    (hy : y ∈ NonloopReconnectionLP G center owner) :
    (G.tsp : ℝ) ≤ nonloopReconnectionCost stars y := by
  have hlo := Manuscript20261020.tsp_le_repair G stars center owner hsimple hsys howner
  rw [← reconnectionOpt_eq_legacyRepair G stars center owner hsimple hsys howner] at hlo
  exact hlo.trans ((nonloop_reconnection_minimum G stars center owner hsimple hsys howner).2
    ⟨y, hy, rfl⟩)

end TSP.Manuscript20261105
