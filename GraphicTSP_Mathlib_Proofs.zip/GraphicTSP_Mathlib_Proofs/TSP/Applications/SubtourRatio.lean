import TSP.MainResults

/-! Explicit graph and denominator facts for the final ratio statements.
The transfer lemmas have a named `hbound` premise; they are not substitutes
for constructing a tour with the proposed improved length. -/
namespace TSP.Manuscript20261105
open Graph Chapter06
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem subtourLP_positive (G : Graph V E) (hconn : G.Connected)
    (hn : 2 ≤ Fintype.card V) : 0 < G.subtourLP := by
  have hcard : (0 : ℝ) < Fintype.card V := by exact_mod_cast (show 0 < Fintype.card V by omega)
  exact hcard.trans_le (subtourLP_ge_card G hconn hn)

/-- In the quartic class, the graphic subtour optimum is exactly n.
The upper-bound witness is the actual edge vector x_e = 1/2. -/
theorem quartic_subtourLP_eq_card (G : Graph V E) (hsimple : G.IsSimple)
    (h4 : ∀ v, G.intDegree Finset.univ v = 4) (hconn4 : G.IsKVertexConnected 4) :
    G.subtourLP = (Fintype.card V : ℝ) := by
  have htwo := kVertexConnected_two G (by decide) hconn4
  have hn : 2 ≤ Fintype.card V := by have := htwo.1; omega
  apply le_antisymm ?_ (subtourLP_ge_card G htwo.2.1 hn)
  have hhalf : G.SubtourFeasible (fun _ => (1 / 2 : ℝ)) := by
    refine ⟨by intro e; norm_num, ?_⟩
    intro U hU hUc
    obtain ⟨u, hu⟩ := hU
    obtain ⟨v, hv⟩ := hUc
    have hc := mixed_cut_card_ge G hsimple hconn4 ∅ U u v hu (by simp)
      (Finset.mem_compl.mp hv) (by simp)
    simp only [Finset.card_empty, liveEdges_empty, Finset.inter_univ, zero_add] at hc
    have hr : (4 : ℝ) ≤ (G.cut U).card := by exact_mod_cast hc
    simp only [edgeSum, Finset.sum_const, nsmul_eq_mul]
    linarith
  have hcard : 2 * Fintype.card E = 4 * Fintype.card V := by
    have hh := sum_intDegree G Finset.univ
    simp only [h4, Finset.sum_const, Finset.card_univ, smul_eq_mul] at hh
    omega
  have hcardR : 2 * (Fintype.card E : ℝ) = 4 * (Fintype.card V : ℝ) := by exact_mod_cast hcard
  have h := subtourLP_le G hhalf
  simp only [edgeSum, Finset.sum_const, Finset.card_univ, nsmul_eq_mul] at h
  linarith

theorem ratio_lt_of_affine_tsp_bound (G : Graph V E) (hconn : G.Connected)
    (hn : 2 ≤ Fintype.card V) {r saving : ℝ} (hsaving : 0 < saving)
    (hbound : (G.tsp : ℝ) ≤ r * G.subtourLP - saving) :
    (G.tsp : ℝ) / G.subtourLP < r := by
  apply (div_lt_iff₀ (subtourLP_positive G hconn hn)).mpr
  linarith

theorem ratio_lt_of_affine_tour_bound (G : Graph V E) (hconn : G.Connected)
    (hn : 2 ≤ Fintype.card V) {r saving : ℝ} (hsaving : 0 < saving)
    (hbound : ∃ c : E → ℕ, G.IsTour c ∧
      (tourLength c : ℝ) ≤ r * G.subtourLP - saving) :
    (G.tsp : ℝ) / G.subtourLP < r := by
  obtain ⟨c, hc, hlen⟩ := hbound
  exact ratio_lt_of_affine_tsp_bound G hconn hn hsaving
    ((Nat.cast_le.mpr (tsp_le_tour G hc)).trans hlen)

/-- The exact quartic implication required by the new extension.
Its tour-construction premise is explicit and still has to be supplied. -/
theorem quartic_ratio_lt_of_nine_sevenths_tour (G : Graph V E)
    (hconn4 : G.IsKVertexConnected 4)
    (hbound : ∃ c : E → ℕ, G.IsTour c ∧
      (tourLength c : ℝ) ≤ (9 * (Fintype.card V : ℝ) - 3) / 7) :
    (G.tsp : ℝ) / G.subtourLP < (9 / 7 : ℝ) := by
  have htwo := kVertexConnected_two G (by decide) hconn4
  have hn : 2 ≤ Fintype.card V := by have := htwo.1; omega
  obtain ⟨c, hc, hlen⟩ := hbound
  apply ratio_lt_of_affine_tour_bound G htwo.2.1 hn (r := 9 / 7) (saving := 3 / 7) (by norm_num)
  refine ⟨c, hc, ?_⟩
  have hlp := subtourLP_ge_card G htwo.2.1 hn
  linarith

/-- The exact general-graph implication required by the new extension.
No scalar or graph certificate is silently assumed by the final project. -/
theorem general_ratio_lt_of_improved_tour (G : Graph V E) (hconn : G.Connected)
    (hn : 2 ≤ Fintype.card V)
    (hbound : ∃ c : E → ℕ, G.IsTour c ∧
      (tourLength c : ℝ) ≤ (14524 * G.subtourLP - 8086) / 10481) :
    (G.tsp : ℝ) / G.subtourLP < (14524 / 10481 : ℝ) := by
  apply ratio_lt_of_affine_tour_bound G hconn hn
    (r := 14524 / 10481) (saving := 8086 / 10481) (by norm_num)
  obtain ⟨c, hc, hlen⟩ := hbound
  exact ⟨c, hc, by linarith⟩

/-- The quartic guarantee actually present in the updated PDF, in strict ratio form. -/
theorem manuscript_quartic_ratio_lt (G : Graph V E) (hsimple : G.IsSimple)
    (h4 : ∀ v, G.intDegree Finset.univ v = 4) (hconn4 : G.IsKVertexConnected 4) :
    (G.tsp : ℝ) / G.subtourLP < (13 / 10 : ℝ) := by
  have htwo := kVertexConnected_two G (by decide) hconn4
  have hn : 2 ≤ Fintype.card V := by have := htwo.1; omega
  obtain ⟨c, hc, hlen⟩ := MainResults.quartic_tour_bound G hsimple h4 hconn4
  apply ratio_lt_of_affine_tour_bound G htwo.2.1 hn
    (r := 13 / 10) (saving := 3 / 5) (by norm_num)
  refine ⟨c, hc, ?_⟩
  rw [quartic_subtourLP_eq_card G hsimple h4 hconn4]
  exact hlen

end TSP.Manuscript20261105
