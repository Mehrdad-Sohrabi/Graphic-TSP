import TSP.Improvements20261105.UnmatchedResidualBoundary
import TSP.Improvements20261105.SelectedHighQFamilyOwnership
import TSP.Improvements20261105.PositiveResidualSourceLinks

/-! The family before auxiliary ordinary-head payments is closed under
unmatched residual recipients. Every residual leaving it enters a matching
source, never a paid leaf, high-q group, root or matching target. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem residual_nonsource_receiver_not_high_q (hs : G.IsSimple) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (a : GatedDrops d)
    (H : Finset d.StarIndex) (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ couponResidualStarPairs d x z H)
    (hu : p.1.1 ∉ C.matching)
    (hnot : p.1 ∉ a.selectedHighQHeads d x z C) :
    p.2 ∉ a.selectedHighQHeads d x z C := by
  intro hj
  obtain ⟨w,hw,hjw⟩ := Finset.mem_biUnion.mp hj
  have howner := (Finset.mem_filter.mp hw).2.1
  have hparent := (Finset.mem_filter.mp hp).2.2.2
  have hunary := couponResidualStarPairs_source_unary d hs x z H p hp
  rcases (mem_highQGroupChildren d x z C w.1 p.2.1).mp (Finset.mem_filter.mp hjw).2 with he | he | ⟨hm,he⟩
  · have hbranch := howner.1
    rw [he] at hparent
    rw [hparent,hunary] at hbranch
    omega
  · rw [he,projectionLinks_parent d x w.1 howner.2.1] at hparent
    have heq : p.1=w := Subtype.ext (Subtype.ext hparent.symm)
    apply hnot
    rw [heq]
    apply Finset.mem_biUnion.mpr
    refine ⟨w,hw,Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩⟩
    exact (mem_highQGroupChildren d x z C w.1 w.1).mpr (Or.inl rfl)
  · rw [he,projectionLinks_parent d x (unaryNext d w.1) (C.link_subset hm)] at hparent
    have heq : unaryNext d w.1=p.1.1 := Subtype.ext hparent
    apply hu
    exact heq ▸ hm

theorem residual_nonsource_receiver_not_matching_target (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (H : Finset d.StarIndex) (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ couponResidualStarPairs d x z H)
    (hu : p.1.1 ∉ C.matching) : p.2.1 ∉ C.matching.image (unaryNext d) := by
  intro ht
  obtain ⟨s,hs,he⟩ := Finset.mem_image.mp ht
  have hparent := projectionLinks_parent d x s (C.link_subset hs)
  rw [he,(Finset.mem_filter.mp hp).2.2.2] at hparent
  have hsame : p.1.1=s := Subtype.ext hparent
  exact hu (hsame ▸ hs)

theorem residual_nonsource_receiver_classification
    (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (H : Finset d.StarIndex) (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ couponResidualStarPairs d x z H)
    (hsource : p.1.1 ∉ C.matching)
    (hnot : p.1 ∉ a.selectedHighQHeads d x z C)
    (hsel : a.head p.1.1=1) :
    p.2 ∈ a.internalUnmatchedHeads d P x z C ∨
      (p.2.1 ∈ C.matching ∧ p.2 ∉ a.allocatedLeafHeads d P x z C ∧
        p.2 ∉ a.selectedHighQHeads d x z C) := by
  have hnH := residual_nonsource_receiver_not_high_q d hs x z C a H p hp hsource hnot
  have hnL := residual_selected_receiver_not_leaf d hs hc x z hx hn hcap hm C P hP t ht f hf hb a ha hcan H p hp hsel
  have hnT := residual_nonsource_receiver_not_matching_target d x z C H p hp hsource
  have hnr := (couponResidualStarPairs_receiver_shape d hs x z H p hp).1
  by_cases hmj : p.2.1 ∈ matchingEndpoints id (unaryNext d) C.matching
  · right
    have hsrc : p.2.1 ∈ C.matching := by
      rcases Finset.mem_union.mp hmj with hh | hh
      · simpa using hh
      · exact (hnT hh).elim
    exact ⟨hsrc,hnL,hnH⟩
  · left
    exact Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun hh =>
      (Finset.mem_union.mp hh).elim hnL hnH⟩,hnr,hmj⟩

end TSP.Improvements20261105
