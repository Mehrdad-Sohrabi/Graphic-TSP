import TSP.Improvements20261105.ClassifiedPointAssembly
import TSP.Improvements20261105.TreeIntervals

/-! Simultaneous free increases, with their actual receiver pair
distributions and all classified connector marginals fixed at half
capacity. Increases ending at an unclassified major need no local reserve. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter05 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem exists_free_receiver_pairs {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (htop : ∀ v, t v ≤ 1 - x (d.treeEdge v))
    (hsource : ∀ v, t v ≠ 0 → SurvivingPositive d x v)
    (hfree : ∀ v : d.tree.Child, ClassifiedCenter d x v →
      t v ≤ edgeSum x (minorBoundary d x v) - x (d.treeEdge v))
    (u : V) :
    ∃ (w : PairOutcome E → ℝ) (P : PairOutcome E → Finset E),
      (∀ j, 0 ≤ w j) ∧ (∑ j, w j = 1) ∧
      (∀ j, P j ⊆ minorBoundary d x u) ∧
      (∀ j, (P j ∩ internalResourceEdges d x).card ≤ 1) ∧
      (∀ e, e ∈ minorBoundary d x u →
        ∑ j, w j * incidence (P j) e = treeIntervalValue d x t e) ∧
      (∀ i : ClassifiedStarIndex d x, partialCenter d x i = u →
        (∑ j, w j * (if Odd (P j ∩ anchorIncidences G (partialStars d x)
          (partialCenter d x) (partialMain d hx hn hcap) i).card then 1 else 0)) =
          classifiedCapacity d hx hn hcap (Sum.inr i) / 2) := by
  have hcanonical (hbase : ∀ e, e ∈ minorBoundary d x u → treeIntervalValue d x t e = x e / 2) :
      ∃ (w : PairOutcome E → ℝ) (P : PairOutcome E → Finset E),
        (∀ j, 0 ≤ w j) ∧ (∑ j, w j = 1) ∧
        (∀ j, P j ⊆ minorBoundary d x u) ∧
        (∀ j, (P j ∩ internalResourceEdges d x).card ≤ 1) ∧
        (∀ e, e ∈ minorBoundary d x u →
          ∑ j, w j * incidence (P j) e = treeIntervalValue d x t e) ∧
        (∀ i : ClassifiedStarIndex d x, partialCenter d x i = u →
          (∑ j, w j * (if Odd (P j ∩ anchorIncidences G (partialStars d x)
            (partialCenter d x) (partialMain d hx hn hcap) i).card then 1 else 0)) =
            classifiedCapacity d hx hn hcap (Sum.inr i) / 2) := by
    refine ⟨canonicalPairWeight (minorBoundary d x u) x, canonicalPairSet (minorBoundary d x u),
      canonicalPairWeight_nonneg _ x hx.1 (by
        have hh := minorBoundary_mass_lt_one d hsimple x u; linarith),
      canonicalPairWeight_sum _ x, canonicalPairSet_subset _, ?_, ?_, ?_⟩
    · intro j
      exact (Finset.card_le_card Finset.inter_subset_left).trans (canonicalPairSet_card _ j)
    · intro e he
      rw [canonicalPair_incidence_marginal, if_pos he, hbase e he]
    · intro i hi
      rw [classified_anchor_capacity_eq_mass d hsimple hx hn hcap i]
      apply canonicalPair_parity_marginal
      simpa only [hi] using classified_anchor_incidences_subset d hsimple hx hn hcap i
  by_cases hu : ClassifiedCenter d x u
  · by_cases hzero : ∀ v : d.tree.Child, (v : V) = u → t v = 0
    · exact hcanonical (fun e he => treeIntervalValue_boundary_unraised d hsimple hx hn t hsource u hzero e he)
    · push_neg at hzero
      obtain ⟨r, hru, htr⟩ := hzero
      subst u
      have hp := incoming_in_minorBoundary d hsimple x r hu
      obtain ⟨w, hw, hsum, hsub, hone, hm, hmain, hlight⟩ :=
        exists_interval_pair_distribution (minorBoundary d x r) (d.treeEdge r) hp x hx.1
          (minorBoundary_mass_lt_one d hsimple x r).le (t r) (ht r) (htop r)
      refine ⟨w, externalPairSet (minorBoundary d x r) (d.treeEdge r), hw, hsum, hsub,
        hone _ (surviving_representative_not_internal d hsimple hx hn r (hsource r htr)), ?_, ?_⟩
      · intro e he
        rw [hm, if_pos he]
        exact (treeIntervalValue_boundary d hsimple hx hn t hsource r e he).symm
      · intro i hi
        rw [classified_anchor_capacity_eq_mass d hsimple hx hn hcap i,
          classified_anchor_incidences d hx hn hcap i]
        split_ifs with hmi
        · rw [hi]
          have hsets : ∀ j, externalPairSet (minorBoundary d x r) (d.treeEdge r) j ∩
              minorBoundary d x r = externalPairSet (minorBoundary d x r) (d.treeEdge r) j :=
            fun j => Finset.inter_eq_left.mpr (hsub j)
          simp_rw [hsets]
          rw [hmain, max_eq_right (by linarith [hfree r hu]), add_zero]
        · apply hlight
          · simpa only [hi] using
              light_group_subset_minorBoundary d hsimple x (partialCenter d x i) i.2 i.1.1 rfl
                (fun hh => hmi ((partialMain_head d hx hn hcap i).mpr hh))
          · exact incoming_not_in_receiver_star d r i.1.1 hi
  · apply hcanonical
    intro e he
    simp [minorBoundary, hu] at he

theorem exists_free_classified_point {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (T : Finset (V ⊕ ClassifiedStarIndex d x))
    (hT : T ⊆ classifiedMajorSet d hx hn hcap) (hTeven : Even T.card)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (htop : ∀ v, t v ≤ 1 - x (d.treeEdge v))
    (hsource : ∀ v, t v ≠ 0 → SurvivingPositive d x v)
    (hfree : ∀ v : d.tree.Child, ClassifiedCenter d x v →
      t v ≤ edgeSum x (minorBoundary d x v) - x (d.treeEdge v)) :
    ∃ M : (E ⊕ ClassifiedStarIndex d x) → ℝ,
      BlossomConstraints (classifiedExpansion d x) (targetParity T) M ∧
      (∀ e, classifiedCapacity d hx hn hcap e / 2 ≤ M e ∧ M e ≤ 1 - classifiedCapacity d hx hn hcap e / 2) ∧
      (∀ e, M (Sum.inl e) = treeIntervalValue d x t e) ∧
      (∀ i, M (Sum.inr i) = classifiedCapacity d hx hn hcap (Sum.inr i) / 2) := by
  have hpairs := exists_free_receiver_pairs d hsimple hx hn hcap t ht htop hsource hfree
  choose w P hw hs hsub hone hm ha using hpairs
  have hanc : ∀ i, localAnchorMarginal d hx hn hcap w P i =
      classifiedCapacity d hx hn hcap (Sum.inr i) / 2 := fun i => ha _ i rfl
  obtain ⟨M, hM, hbox, hrep, hanchor⟩ := exists_classified_point_of_local_pairs d hsimple hx hn hcap T hT hTeven
    (treeIntervalValue d x t) (treeIntervalValue_box d x hcap t ht htop)
    (treeIntervalValue_internal d hsimple hx hn t hsource) w P hw hs hsub hone hm
    (fun i => by
      rw [hanc]
      have hh := (classified_anchor_capacity_bounds d hsimple hx hn hcap i).2
      exact ⟨le_rfl, by linarith⟩)
  exact ⟨M, hM, hbox, hrep, fun i => (hanchor i).trans (hanc i)⟩

end TSP.Improvements20261105
