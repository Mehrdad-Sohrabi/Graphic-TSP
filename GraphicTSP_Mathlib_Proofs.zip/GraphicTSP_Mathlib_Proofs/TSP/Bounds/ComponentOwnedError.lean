import TSP.Improvements20261105.ZeroLeafGlobalBudget

/-! One shared geometric error account, indexed by actual components.
Internal centers and entering connectors are the original graph owners. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.componentOwnedError (P : GatePlan d) (a : GatedDrops d)
    (x : E → ℝ) (r : FlowVertex d) : ℝ :=
  24*(∑ v ∈ a.originalComponentVertices d P r, degreeExcess G x v)+12*componentEntryError d x r

theorem componentEntryError_nonnegative (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (r : FlowVertex d) : 0 ≤ componentEntryError d x r := by
  cases r with
  | inl v => exact le_rfl
  | inr c =>
    unfold componentEntryError
    apply add_nonneg (le_max_right _ _)
    split_ifs
    · exact degreeExcess_nonnegative G hx hn _
    · exact le_rfl

theorem GatedDrops.componentOwnedError_nonnegative (P : GatePlan d) (a : GatedDrops d)
    (x : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (r : FlowVertex d) :
    0 ≤ a.componentOwnedError d P x r := by
  unfold componentOwnedError
  exact add_nonneg (mul_nonneg (by norm_num) (Finset.sum_nonneg
    (fun v _ => degreeExcess_nonnegative G hx hn v)))
    (mul_nonneg (by norm_num) (componentEntryError_nonnegative d x hx hn r))

theorem GatedDrops.internal_center_error_owned (P : GatePlan d) (a : GatedDrops d)
    (x : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (r : FlowVertex d) (v : V) (hv : a.component d P (.inl v) = r) :
    24*degreeExcess G x v ≤ a.componentOwnedError d P x r := by
  have hsum := Finset.single_le_sum (f := degreeExcess G x)
    (fun u (_hu : u ∈ a.originalComponentVertices d P r) => degreeExcess_nonnegative G hx hn u)
    (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hv⟩ : v ∈ a.originalComponentVertices d P r)
  have he := componentEntryError_nonnegative d x hx hn r
  unfold componentOwnedError
  linarith

theorem GatedDrops.entering_star_error_owned (P : GatePlan d) (a : GatedDrops d)
    (x : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (c : d.tree.Child) :
    12*enteringStarDeficit d x c ≤ a.componentOwnedError d P x (.inr c) := by
  have hsum : 0 ≤ ∑ v ∈ a.originalComponentVertices d P (.inr c), degreeExcess G x v :=
    Finset.sum_nonneg (fun v _ => degreeExcess_nonnegative G hx hn v)
  have he : enteringStarDeficit d x c ≤ componentEntryError d x (.inr c) := by
    simp only [componentEntryError]
    split_ifs
    · linarith [degreeExcess_nonnegative G hx hn (d.tree.parent c)]
    · simp only [add_zero,le_refl]
  unfold componentOwnedError
  linarith

theorem GatedDrops.componentOwnedError_family_bound (hs : G.IsSimple)
    (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (L : Finset (FlowVertex d))
    (hL : ∀ r ∈ L, r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P))
    (hleaf : ∀ r ∈ L, a.componentOutgoingCuts d P r = ∅) :
    (∑ r ∈ L, a.componentOwnedError d P x r) ≤
      48*(edgeSum x Finset.univ-(Fintype.card V : ℝ)) := by
  simpa only [componentOwnedError,Finset.sum_add_distrib,← Finset.mul_sum] using
    a.leaf_total_error_budget d hs P x hx hn L hL hleaf

theorem GatedDrops.outside_head_center_entry (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (c : d.tree.Child) (hc : a.component d P (.inr c) = r)
    (hcenter : a.component d P (.inl (d.tree.parent c)) ≠ r) : r = .inr c := by
  have hcut : expandedConnectorChild d c ∈ a.trueCuts d P := by
    by_contra h
    have he := (expandedTree d).cutComponentRoot_uncut (a.trueCuts d P) (expandedConnectorChild d c) h
    change a.component d P (.inr c) = a.component d P (.inl (d.tree.parent c)) at he
    exact hcenter (he.symm.trans hc)
  have he := (expandedTree d).cutComponentRoot_cut (a.trueCuts d P) (expandedConnectorChild d c) hcut
  change a.component d P (.inr c) = .inr c at he
  exact hc.symm.trans he

end TSP.Improvements20261105
