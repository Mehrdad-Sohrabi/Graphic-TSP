import TSP.Improvements20261105.GreedyHeadPacking
import TSP.Improvements20261105.ScoredSuccessorPacking

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem refined_fixed_incidence_le_noncritical (x z : E → ℝ)
    (eligible R : Finset d.tree.Child) (s : d.tree.Child) :
    refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) R s ≤ noncriticalIncidence d z s := by
  unfold refinedIncidenceCharge
  split_ifs with hc hr
  · exact (le_max_left _ _).trans (Finset.mem_filter.mp hc).2
  · exact (Finset.mem_filter.mp hc).2
  · exact le_rfl

theorem high_q_noncritical_load (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : 1/2 ≤ q) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hzq : ∀ e ∈ d.backGroup s, z e ≤ q)
    (hpack : edgeSum z (d.backGroup s)+q ≤ 2) :
    24*(edgeSum z (d.backGroup s)-1)+noncriticalIncidence d z s ≤ 48+240/361 := by
  have ho := greedy_ramp_mass_bound (d.backGroup s) z q (by linarith) hz hzq hpack
  have hn := greedy_signed_ramp_mass_bound (d.backGroup s) z q (by linarith) hz hzq hpack
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h3 := min_le_right (((d.backGroup s).card : ℝ)-1)
    (ScoredParameters.massSlope*edgeSum z (d.backGroup s)-1)
  unfold noncriticalIncidence
  rw [add_max]
  apply max_le
  · unfold oldIncidence
    unfold starIncidenceRamp edgeSum at h1 ⊢
    linarith
  · unfold mixedNoncriticalIncidence
    simp only [signedStarIncidence, starIncidenceRamp, edgeSum, ScoredParameters.massSlope] at h2 h3 hpack ⊢
    norm_num only at h2 h3 ⊢
    linarith

theorem small_receiver_noncritical_load (z : E → ℝ) (s : d.tree.Child) (q h : ℝ)
    (hq : 0 ≤ q) (hh : h ≤ 1/2) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hzq : ∀ e ∈ d.backGroup s, z e ≤ q)
    (hm : 1 ≤ edgeSum z (d.backGroup s))
    (hpack : q+(edgeSum z (d.backGroup s)-1) ≤ h) :
    24*(edgeSum z (d.backGroup s)-1)+noncriticalIncidence d z s ≤ 48*h+2064/361 := by
  have hqhalf : q ≤ 1/2 := by linarith
  have hprod : 0 ≤ (1-2*q)*(edgeSum z (d.backGroup s)-1) :=
    mul_nonneg (by linarith) (by linarith)
  have hquad := Finset.sum_le_sum (s := d.backGroup s)
    (fun e he => greedy_ramp_quadratic (z e) q (hz e he) (hzq e he))
  simp only [← Finset.mul_sum] at hquad
  have ho : edgeSum z (d.backGroup s)-1+
      (∑ e ∈ d.backGroup s, incidenceRamp (1/2) (z e)) ≤ 2*h := by
    unfold edgeSum at *
    nlinarith
  have hconvex := Finset.sum_le_sum (s := d.backGroup s)
    (fun e he => signed_ramp_convex (z e) (hz e he))
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum] at hconvex
  have hn : edgeSum z (d.backGroup s)-1+
      ((∑ e ∈ d.backGroup s, incidenceRamp (9/20) (z e))-1/10) ≤ 2*h := by
    unfold edgeSum at *
    linarith
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h3 := min_le_right (((d.backGroup s).card : ℝ)-1)
    (ScoredParameters.massSlope*edgeSum z (d.backGroup s)-1)
  unfold noncriticalIncidence
  rw [add_max]
  apply max_le
  · unfold oldIncidence
    unfold starIncidenceRamp edgeSum at h1 ho ⊢
    linarith
  · unfold mixedNoncriticalIncidence
    simp only [signedStarIncidence, starIncidenceRamp, edgeSum, ScoredParameters.massSlope] at h2 h3 hn hpack ⊢
    norm_num only at h2 h3 ⊢
    linarith

theorem scoredDFS_high_q_greedy (G : Graph V E) (x : E → ℝ)
    (hs : G.IsSimple) (hc : G.Connected) (root : V)
    (s : (scoredDFS G x hs hc root).tree.Child)
    (hq : 1/2 ≤ x ((scoredDFS G x hs hc root).treeEdge s))
    (e : E) (he : e ∈ (scoredDFS G x hs hc root).backGroup s) :
    x e ≤ x ((scoredDFS G x hs hc root).treeEdge s) := by
  apply scoredDFS_not_scored_greedy G x hs hc root s _ e he
  intro hsc
  let d := scoredDFS G x hs hc root
  have hm : d.treeEdge s ∈ d.group s := (d.mem_group s _).mpr (d.anchor_treeEdge s)
  have hmax : x (d.treeEdge s) ≤ starMaximum d x s := le_finiteMaximum x hm
  have hu := hsc.2.2.2.2.2.trans (ScoredParameters.upper_bounds _).2
  linarith

theorem scoredDFS_high_parent_greedy (G : Graph V E) (x : E → ℝ)
    (hs : G.IsSimple) (hc : G.Connected) (root : V)
    (s v : (scoredDFS G x hs hc root).tree.Child)
    (hp : (scoredDFS G x hs hc root).tree.parent s = (v : V))
    (hq : 1/2 ≤ x ((scoredDFS G x hs hc root).treeEdge v))
    (e : E) (he : e ∈ (scoredDFS G x hs hc root).backGroup s) :
    x e ≤ x ((scoredDFS G x hs hc root).treeEdge s) := by
  apply scoredDFS_not_scored_greedy G x hs hc root s _ e he
  intro hsc
  have hin := (scored_successor_incoming_bound _ x s v hp hsc).1
  linarith

end TSP.Improvements20261105
