import TSP.Improvements20261105.GeneralContextLocalPayment
import TSP.Improvements20261105.SelectedSpecialAllZeroTargets

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem GeneralPairPaymentContext.zero_target_payment
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (p : (d).StarIndex × (d).StarIndex)
    (hp : p ∈ K.a.internalMatchingPairs d (fixedGatePlan d x) x z K.C)
    (hsi : K.a.head p.1.1=1) (hsj : K.a.head p.2.1=1)
    (ht : 5 ≤ ((d).backGroup p.1.1).card) (hr : 2 ≤ ((d).backGroup p.2.1).card)
    (hzero : edgeSum z ((d).backGroup p.2.1) ≤ 1) :
    K.PairPayment G x₀ x z hs hconnected root p := by
  have hn : 2 ≤ Fintype.card V := by have hh:=K.hc.1; omega
  have hd := K.local_pair_data G x₀ x z hs hconnected root p hp
  have hh := scoredDFS_selected_large_source_zero_target_payment G x z hs hconnected root
    K.hx hn K.hcap K.hz K.hzx K.htree K.hprojection K.C K.owner K.ho K.rootStar K.hrootStar
    K.Q K.R (K.Q_connector_values G x₀ x z hs hconnected root hn) K.hconn K.hrep K.hbacks
    K.hloss K.hterminal K.hguarded (generalEligibleHeads d x) (generalRawCriticalHeads d x z K.a)
    (fun s hs => Finset.mem_filter.mpr ⟨Finset.mem_univ s,hs⟩)
    K.a.head p.1 p.2 hd.source hd.target hsi hsj ht hr
    (originalMatchingBadLabel d x₀ p.1.1) hd.bad_le_one (fun _ => hd.good_parts) hzero
    (K.pairDebt G x₀ x z hs hconnected root p) hd.debt_nonneg hd.debt_cap
  have ht3 : 3 ≤ ((d).backGroup p.1.1).card := by omega
  have hid : (if 3 ≤ ((d).backGroup p.2.1).card then (162/19 : ℝ) else 0)=
      (162/19)*(matchingPairCreditIndicator d K.a.head p : ℝ) := by
    unfold matchingPairCreditIndicator
    simp only [hsi,hsj,ht3,true_and]
    split_ifs <;> norm_num
  unfold PairPayment
  dsimp only [pairDebt] at hh
  linarith only [hh,hid]

end TSP.Improvements20261105
