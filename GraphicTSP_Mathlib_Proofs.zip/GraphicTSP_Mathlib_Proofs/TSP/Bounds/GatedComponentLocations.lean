import TSP.Improvements20261105.GatedCutPaths
import TSP.Improvements20261105.GatedTrueCutCount

/-! Locate heads and gate owners in the actual components of the expanded
tree after deleting the true cuts. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.component (P : GatePlan d) (a : GatedDrops d) (w : FlowVertex d) : FlowVertex d :=
  (expandedTree d).cutComponentRoot (a.trueCuts d P) w

@[simp] theorem GatedDrops.trueCutWeight_connector (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.trueCutWeight d P (expandedConnectorChild d v) = a.trueRoleWeight d P (.inl v) := rfl
@[simp] theorem GatedDrops.trueCutWeight_representative (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.trueCutWeight d P (expandedRepresentativeChild d v) = a.trueRoleWeight d P (.inr v) := rfl

theorem GatedDrops.component_uncut_connector (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child)
    (hv : a.trueRoleWeight d P (.inl v) = 0) :
    a.component d P (.inr v) = a.component d P (.inl (d.tree.parent v)) := by
  have hn : expandedConnectorChild d v ∉ a.trueCuts d P := by simp [trueCuts, hv]
  exact (expandedTree d).cutComponentRoot_uncut (a.trueCuts d P) (expandedConnectorChild d v) hn

theorem GatedDrops.component_uncut_representative (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child)
    (hv : a.trueRoleWeight d P (.inr v) = 0) :
    a.component d P (.inl (v : V)) = a.component d P (.inr v) := by
  have hn : expandedRepresentativeChild d v ∉ a.trueCuts d P := by simp [trueCuts, hv]
  have hh := (expandedTree d).cutComponentRoot_uncut (a.trueCuts d P) (expandedRepresentativeChild d v) hn
  simpa only [component, expandedTree, expandedParent, expandedRepresentativeChild,
    Sum.elim_inl, dif_neg v.2] using hh

theorem GatedDrops.component_back_path_zero (P : GatePlan d) (a : GatedDrops d) (b : BackEdge d)
    (hz : a.backPathCuts d P b = ∅) :
    a.component d P (.inr (d.anchor b.1)) = a.component d P (.inl (d.lower b.1)) :=
  (expandedTree d).cutsOnPath_empty_same (a.trueCuts d P)
    (expanded_auxiliary_ancestor d _ (d.anchor_spec b.1).2) hz

theorem GatedDrops.component_back_path_middle (P : GatePlan d) (a : GatedDrops d) (b : BackEdge d)
    (hz : a.backPathCuts d P b = ∅) (w : FlowVertex d)
    (hw : (expandedTree d).OnPath (.inr (d.anchor b.1)) (.inl (d.lower b.1)) w) :
    a.component d P (.inr (d.anchor b.1)) = a.component d P w := by
  have hsub := (expandedTree d).cutsOnPath_prefix_subset (a.trueCuts d P) (a := .inr (d.anchor b.1)) hw.2
  have hemp : (expandedTree d).cutsOnPath (a.trueCuts d P) (.inr (d.anchor b.1)) w = ∅ := by
    apply Finset.eq_empty_iff_forall_not_mem.mpr
    intro c hc
    have hh := hsub hc
    change c ∈ a.backPathCuts d P b at hh
    rw [hz] at hh
    exact Finset.not_mem_empty c hh
  exact (expandedTree d).cutsOnPath_empty_same (a.trueCuts d P) hw.1 hemp

theorem canonical_selected_rep_zero (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) : a.representative s = 0 := by
  by_cases hactive : (d.backGroup s).Nonempty
  · simpa only [GatedDrops.potential_representative] using
      gated_optimal_active_representative_zero d P t ht f hf hb (a.potential d P)
        hcan.1.1 hcan.1.2 s hactive
  · have hz := gated_optimal_inactive_head_zero d P hP t ht f hf hb (a.potential d P)
      hcan.1.1 hcan.1.2 s hactive
    simp [hsel] at hz

theorem canonical_selected_center_same_head (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) :
    a.component d P (.inl (s : V)) = a.component d P (.inr s) := by
  apply a.component_uncut_representative d P s
  have hz := canonical_selected_rep_zero d P hP t ht f hf hb a hcan s hsel
  simp [GatedDrops.trueRoleWeight, hz]

theorem canonical_gate_same_component (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (huse : P.UsesGate d s) (hpref : 0 < a.pref (P.receiver s)) :
    a.head s = 1 ∧ a.head (P.receiver s) = 1 ∧
      a.component d P (.inr s) = a.component d P (.inr (P.receiver s)) := by
  have hr : P.IsReceiver d (P.receiver s) := ⟨s, huse, rfl⟩
  have hpref' : 0 < gatedPrefixDrop d (a.potential d P) (P.receiver s) := by simpa using hpref
  have howner := canonical_gate_owner_selected d hs hc P hP t f hf hb (a.potential d P) hcan s huse hpref'
  have hreceiver := canonical_gate_receiver_selected d hs hc P hP t f hf hb (a.potential d P) hcan (P.receiver s) hr hpref'
  simp only [GatedDrops.potential_headSelector] at howner hreceiver
  have hsuf : a.suffix (P.receiver s) = 0 := by
    have hh := ha.paid (P.receiver s)
    rw [hreceiver, if_pos hr] at hh
    have hn := ha.suffix_nonneg (P.receiver s)
    omega
  have hconn : a.trueRoleWeight d P (.inl (P.receiver s)) = 0 := by
    simp [GatedDrops.trueRoleWeight, hr, hsuf]
  have hsame := canonical_selected_center_same_head d P hP t ht f hf hb a hcan s howner
  have hrec := a.component_uncut_connector d P (P.receiver s) hconn
  rw [hP s huse] at hrec
  exact ⟨howner, hreceiver, hsame.symm.trans hrec.symm⟩

end TSP.Improvements20261105
