import TSP.Improvements20261105.IntegralDualObjective
import TSP.Improvements20261105.BoundedCirculationMixture

/-! Exact bounded-circulation dual, weak duality, complementary slackness,
and integral potential rounding for real capacities. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem weighted_arcSum (endpoint : E → V) (f : E → ℝ) (p : V → ℝ) :
    (∑ v, p v * arcSum endpoint f v) = ∑ e, f e * p (endpoint e) := by
  simp only [arcSum, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  simp [mul_comm]

theorem balanced_potential_sum (N : Graph V E) (f : E → ℝ)
    (hf : Balanced N f) (p : V → ℝ) :
    (∑ e, f e * (p (N.dst e) - p (N.src e))) = 0 := by
  simp only [mul_sub, Finset.sum_sub_distrib]
  have hh : (∑ v, p v * arcSum N.dst f v) = ∑ v, p v * arcSum N.src f v := by
    apply Finset.sum_congr rfl
    intro v _
    rw [hf v]
  rw [weighted_arcSum, weighted_arcSum] at hh
  exact sub_eq_zero.mpr hh

noncomputable def circulationDualValue (N : Graph V E) (c : E → ℤ)
    (lower upper : E → ℝ) (p : V → ℝ) : ℝ :=
  ∑ e, (lower e * ((c e : ℝ) - (p (N.dst e) - p (N.src e))) -
    (upper e - lower e) * max (p (N.dst e) - p (N.src e) - c e) 0)

theorem dual_edge_bound (c l u x δ : ℝ) (hl : l ≤ x) (hu : x ≤ u) :
    l * (c - δ) - (u - l) * max (δ - c) 0 ≤ x * (c - δ) := by
  by_cases h : δ ≤ c
  · rw [max_eq_right (by linarith : δ - c ≤ 0), mul_zero, sub_zero]
    exact mul_le_mul_of_nonneg_right hl (by linarith)
  · rw [max_eq_left (by linarith : 0 ≤ δ - c)]
    have hh := mul_le_mul_of_nonpos_right hu (by linarith : c - δ ≤ 0)
    nlinarith

theorem circulation_weak_duality (N : Graph V E) (c : E → ℤ)
    (lower upper f : E → ℝ) (hf : Balanced N f)
    (hbox : ∀ e, lower e ≤ f e ∧ f e ≤ upper e) (p : V → ℝ) :
    circulationDualValue N c lower upper p ≤ ∑ e, (c e : ℝ) * f e := by
  have he := Finset.sum_le_sum (s := Finset.univ) (fun e _ =>
    dual_edge_bound (c e) (lower e) (upper e) (f e) (p (N.dst e) - p (N.src e))
      (hbox e).1 (hbox e).2)
  have hc := balanced_potential_sum N f hf p
  have hs : (∑ e, f e * ((c e : ℝ) - (p (N.dst e) - p (N.src e)))) =
      (∑ e, (c e : ℝ) * f e) - ∑ e, f e * (p (N.dst e) - p (N.src e)) := by
    simp [mul_sub, Finset.sum_sub_distrib, mul_comm]
  change circulationDualValue N c lower upper p ≤ _ at he
  rw [hs, hc, sub_zero] at he
  exact he

theorem dual_edge_equality (c l u x δ : ℝ) (hl : l ≤ x) (hu : x ≤ u)
    (hforward : x < u → δ ≤ c) (hbackward : l < x → c ≤ δ) :
    l * (c - δ) - (u - l) * max (δ - c) 0 = x * (c - δ) := by
  by_cases h : δ ≤ c
  · rw [max_eq_right (by linarith : δ - c ≤ 0), mul_zero, sub_zero]
    by_cases he : δ = c
    · rw [he]; ring
    · have hx : x = l := by
        by_contra hx
        have hh := hbackward (lt_of_le_of_ne hl (Ne.symm hx))
        exact he (le_antisymm h hh)
      rw [hx]
  · have hx : x = u := by
      by_contra hx
      exact h (hforward (lt_of_le_of_ne hu hx))
    rw [max_eq_left (by linarith : 0 ≤ δ - c), hx]
    ring

theorem circulation_complementary_slackness (N : Graph V E) (c : E → ℤ)
    (lower upper f : E → ℝ) (hf : Balanced N f)
    (hbox : ∀ e, lower e ≤ f e ∧ f e ≤ upper e) (p : V → ℝ)
    (hforward : ∀ e, f e < upper e → p (N.dst e) - p (N.src e) ≤ (c e : ℝ))
    (hbackward : ∀ e, lower e < f e → (c e : ℝ) ≤ p (N.dst e) - p (N.src e)) :
    circulationDualValue N c lower upper p = ∑ e, (c e : ℝ) * f e := by
  unfold circulationDualValue
  rw [Finset.sum_congr rfl (fun e _ => dual_edge_equality (c e) (lower e) (upper e) (f e)
    (p (N.dst e) - p (N.src e)) (hbox e).1 (hbox e).2 (hforward e) (hbackward e))]
  have hc := balanced_potential_sum N f hf p
  simp only [mul_sub, Finset.sum_sub_distrib] at hc ⊢
  simp only [mul_comm] at hc ⊢
  linarith

theorem circulationDualValue_as_differenceObjective (N : Graph V E) (c : E → ℤ)
    (lower upper : E → ℝ) (p : V → ℝ) :
    circulationDualValue N c lower upper p = (∑ e, lower e * (c e : ℝ)) +
      differenceObjective N (fun v => arcSum N.src lower v - arcSum N.dst lower v)
        (fun e => -(upper e - lower e)) c p := by
  unfold circulationDualValue differenceObjective
  simp only [sub_mul, mul_sub, neg_mul, Finset.sum_sub_distrib, Finset.sum_neg_distrib]
  have hs : (∑ v, arcSum N.src lower v * p v) = ∑ e, lower e * p (N.src e) := by
    simpa only [mul_comm] using weighted_arcSum N.src lower p
  have hd : (∑ v, arcSum N.dst lower v * p v) = ∑ e, lower e * p (N.dst e) := by
    simpa only [mul_comm] using weighted_arcSum N.dst lower p
  linarith

theorem circulation_dual_integral_no_smaller (N : Graph V E) (c : E → ℤ)
    (lower upper : E → ℝ) (p : V → ℝ) :
    ∃ P : V → ℤ,
      circulationDualValue N c lower upper p ≤
        circulationDualValue N c lower upper (fun v => (P v : ℝ)) := by
  obtain ⟨P, _, hp⟩ := exists_integral_potential_no_smaller N
    (fun v => arcSum N.src lower v - arcSum N.dst lower v)
    (fun e => -(upper e - lower e)) c p
  refine ⟨P, ?_⟩
  rw [circulationDualValue_as_differenceObjective, circulationDualValue_as_differenceObjective]
  linarith

end TSP.Improvements20261105
