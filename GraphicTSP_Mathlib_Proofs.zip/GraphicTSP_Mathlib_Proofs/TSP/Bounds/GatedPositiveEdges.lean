import TSP.Improvements20261105.GatedPorts
import TSP.Improvements20261105.GatedFeasibility

/-! Positive network flow supplies actual original back edges. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedPositiveBacks (f : GatedArc d → ℝ) : Finset E :=
  d.backEdges.filter (fun b => 0 < gatedBackVector d f b)

theorem gatedPositiveBacks_subset (f : GatedArc d → ℝ) : gatedPositiveBacks d f ⊆ d.backEdges :=
  Finset.filter_subset _ _

theorem finite_sum_positive_witness {A : Type} [Fintype A] (x : A → ℝ)
    (hx : 0 < ∑ a, x a) : ∃ a, 0 < x a := by
  by_contra hn
  push_neg at hn
  exact (not_lt_of_ge (Finset.sum_nonpos (fun a _ => hn a))) hx

theorem gated_subset_positive_witness (f : GatedArc d → ℝ)
    (S : Finset E) (hS : S ⊆ d.backEdges)
    (hp : 0 < ∑ b ∈ S, gatedBackVector d f b) : (gatedPositiveBacks d f ∩ S).Nonempty := by
  by_contra hn
  have hh : ∀ b ∈ S, gatedBackVector d f b ≤ 0 := by
    intro b hb
    by_contra hneg
    exact hn ⟨b, Finset.mem_inter.mpr
      ⟨Finset.mem_filter.mpr ⟨hS hb, lt_of_not_ge hneg⟩, hb⟩⟩
  exact (not_lt_of_ge (Finset.sum_nonpos hh)) hp

theorem gated_tail_term_le (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    (if P.kind v = .disabled ∨ P.kind v = .outgoing then f (gatedBypassArc d v) else 0) +
      f (gatedExitTailArc d v) ≤ gatedTailInput d P f v := by
  have hn : ∀ a, 0 ≤ f a := gated_nonnegative d P f hb
  unfold gatedTailInput
  have hh := Finset.single_le_sum (s := Finset.univ) (a := v)
    (f := fun s : d.tree.Child => if (s : V) = v then
      (if P.kind s = .disabled ∨ P.kind s = .outgoing then f (gatedBypassArc d s) else 0) +
        f (gatedExitTailArc d s) else 0)
    (by intro s _; dsimp only; split_ifs <;> first | exact add_nonneg (hn _) (hn _) | simpa using hn (gatedExitTailArc d s) | exact le_rfl)
    (Finset.mem_univ v)
  simpa using hh

theorem gated_gate_term_le (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    (if P.kind v = .outsideGate then f (gatedBypassArc d v) else 0) +
      (if P.kind v = .sharedGate then f (gatedExitGateArc d v) else 0) ≤
      gatedGateInput d P f (P.receiver v) := by
  have hn : ∀ a, 0 ≤ f a := gated_nonnegative d P f hb
  unfold gatedGateInput
  have hh := Finset.single_le_sum (s := Finset.univ) (a := v)
    (f := fun s : d.tree.Child => if P.receiver s = P.receiver v then
      (if P.kind s = .outsideGate then f (gatedBypassArc d s) else 0) +
        (if P.kind s = .sharedGate then f (gatedExitGateArc d s) else 0) else 0)
    (by intro s _; dsimp only; split_ifs <;> first | exact add_nonneg (hn _) (hn _) | simpa using hn (gatedBypassArc d s) | simpa using hn (gatedExitGateArc d s) | norm_num)
    (Finset.mem_univ v)
  simpa using hh

theorem gated_positive_tail_input (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : V) (hp : 0 < gatedTailInput d P f v) :
    ∃ b ∈ gatedPositiveBacks d f, d.lower b = v := by
  have hh := gated_balance_tail d P f hf v
  have ht := gated_nonnegative d P f hb (gatedTailArc d v)
  have hs : 0 < ∑ b : BackEdge d, if d.lower b.1 = v then f (gatedBackArc d b) else 0 := by linarith
  obtain ⟨b, hbpos⟩ := finite_sum_positive_witness _ hs
  by_cases he : d.lower b.1 = v
  · have hbpos' : 0 < f (gatedBackArc d b) := by simpa [he] using hbpos
    exact ⟨b.1, Finset.mem_filter.mpr ⟨b.2, by simpa using hbpos'⟩, he⟩
  · simp [he] at hbpos

theorem gated_positive_receiver_input (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.IsReceiver d v) (hp : 0 < gatedGateInput d P f v) :
    SelectedForeignCover d (gatedPositiveBacks d f) v :=
  gated_subset_positive_witness d f _ (deletedSubtreeCut_back d v)
    (hp.trans_le (gated_gate_input_le_foreign d P hP f hf hb v hv))

theorem gated_positive_outside_back (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.kind v = .outsideGate) (hp : 0 < f (gatedBypassArc d v)) :
    ∃ b ∈ gatedPositiveBacks d f, b ∈ d.backGroup v ∧
      ¬d.tree.Ancestor (P.receiver v) (d.lower b) := by
  have hh := gated_balance_outside d P f hf v
  rw [if_pos hv] at hh
  have hn := gated_nonnegative d P f hb (gatedFeedArc d v)
  have hs : 0 < gatedOutsideInput d P f v := by linarith
  obtain ⟨b, hbp⟩ := finite_sum_positive_witness _ hs
  change 0 < (if d.anchor b.1 = v ∧ P.OutsideBack d b then f (gatedBackArc d b) else 0) at hbp
  by_cases he : d.anchor b.1 = v ∧ P.OutsideBack d b
  · have hpos : 0 < f (gatedBackArc d b) := by simpa [he] using hbp
    have hout := he.2.2
    rw [he.1] at hout
    exact ⟨b.1, Finset.mem_filter.mpr ⟨b.2, by simpa using hpos⟩,
      (back_anchor_iff_group d b v).mp he.1, hout⟩
  · simp [he] at hbp

theorem gated_nonremovable_selected_cover (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : ¬(d.backGroup v).Nonempty) :
    SelectedTreeCover d (gatedPositiveBacks d f) v := by
  have hc := gated_nonremovable_coverage d P hP f hf hb v hv
  obtain ⟨b, hb⟩ := gated_subset_positive_witness d f _ Finset.inter_subset_right (by linarith)
  exact ⟨b, Finset.mem_inter.mpr ⟨(Finset.mem_inter.mp hb).1,
    (Finset.mem_inter.mp (Finset.mem_inter.mp hb).2).1⟩⟩

end TSP.Improvements20261105
