import TSP.Improvements20261105.GreedySourceCount2Continuous
import TSP.Improvements20261105.GreedySourceCount3Continuous
import TSP.Improvements20261105.GreedySourceCount4Continuous
import TSP.Improvements20261105.GreedySourceCount5Continuous
import TSP.Improvements20261105.GreedySourceCount6Continuous
import TSP.Improvements20261105.GreedySourceCount7Continuous
import TSP.Improvements20261105.GreedySourceCount8Continuous
import TSP.Improvements20261105.GreedySourceCount9Continuous
import TSP.Improvements20261105.GreedySourceCount10Continuous
import TSP.Improvements20261105.GreedySourceCount11Continuous
import TSP.Improvements20261105.GreedySourceCount12Continuous
import TSP.Improvements20261105.GreedySourceCount13Continuous
import TSP.Improvements20261105.GreedySourceCount14Continuous
import TSP.Improvements20261105.GreedySourceCount15Continuous
import TSP.Improvements20261105.GreedySourceCount16Continuous
import TSP.Improvements20261105.GreedySourceCount17Continuous
import TSP.Improvements20261105.GreedySourceCount18Continuous
import TSP.Improvements20261105.GreedySourceCount19Continuous

/-! Continuous greedy source rows, with exhaustive finite count coverage. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 8000000

theorem greedy_source_finite_continuous (t k bad : ℕ) (ht0 : 2 ≤ t) (ht1 : t ≤ 19)
    (hk : k < t) (hbad : bad ≤ 1) (q a I g : ℝ) (hq0 : 0 ≤ q) (hq1 : q ≤ 1)
    (ha : 1 ≤ a) (hcount : a ≤ (t : ℝ)*q) (hpack : a+q ≤ 2)
    (hka : (k : ℝ)*q ≤ a) (hak : a ≤ ((k : ℝ)+1)*q)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hggap : g+q+a ≤ 2)
    (hgood : t%2=0 → bad=0 → a+q-1 ≤ ((t : ℝ)/2)*q)
    (hgate : 4 ≤ t → t ≤ 25 → q ≤ ScoredParameters.lower t ∨
      ScoredParameters.upper t ≤ q ∨ q+a ≤ 2-ScoredParameters.incomingThreshold t)
    (hN : I ≤ max (24*greedyOldEnvelope q a k)
      ((360/19)*packedSignedMu q a k+(96/19)*((100/57)*a-1))) :
    (415/2)*(a-1)-(704/5)+24*(a-1+g)+I ≤ 4*((t : ℝ)+1)+2*(bad : ℝ) := by
  interval_cases t
  · have hh := greedy_source_2_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_3_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_4_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_5_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_6_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_7_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_8_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_9_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_10_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_11_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_12_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_13_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_14_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_15_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_16_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_17_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]
  · have hh := greedy_source_18_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num
  · have hh := greedy_source_19_continuous k hk q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg bad
    norm_num only [Nat.cast_ofNat] at *
    linarith only [hh,hb]

end TSP.Improvements20261105
