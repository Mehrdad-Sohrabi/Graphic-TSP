import TSP.Improvements20261105.ScoredSuccessorPacking
import TSP.Improvements20261105.LowQSourceCoupon

/-! The actual winning DFS score gives a lower bound on outgoing mass.
Both its own Q repair and its enlarged coupon retain that lower bound. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_outgoing_mass_lower (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (s : (d).tree.Child) (hsc : ScoredStar d x s) :
    (starMaximum d x s-x ((d).treeEdge s))/ScoredParameters.coefficient ((d).backGroup s).card ≤
      outgoingBackMass d x s := by
  have hw := scoredDFS_maximum_le_benchmark G x hs hc root hx.1 hcap s hsc
  have hh := hw.trans (ScoredParameters.benchmark_le_uncapped)
  apply (div_le_iff₀ (ScoredParameters.coefficient_bounds _).1).mpr
  linarith only [hh]

theorem scoredDFS_enlarged_coupon_lower (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (s : (d).tree.Child) (hsc : ScoredStar d x s) (hpos : 1 < edgeSum z ((d).backGroup s)) :
    max (x ((d).treeEdge s))
      (min (edgeSum z ((d).backGroup s)/2)
        ((starMaximum d x s-x ((d).treeEdge s))/ScoredParameters.coefficient ((d).backGroup s).card)) ≤
      projectedOutgoingCoupon d x z s := by
  have hM : x ((d).treeEdge s) ≤ starMaximum d x s :=
    le_finiteMaximum x ((d).mem_group s _ |>.mpr ((d).anchor_treeEdge s))
  have hU := hsc.2.2.2.2.2.trans (ScoredParameters.upper_bounds _).2
  have hb := projectedOutgoingCoupon_positive_base d x z s hpos
  rw [min_eq_left (by linarith)] at hb
  have ho := scoredDFS_outgoing_mass_lower G x hs hc root hx hcap s hsc
  rw [projectedOutgoingCoupon,if_pos hpos,hb]
  exact max_le_max le_rfl (min_le_min le_rfl ho)

theorem scoredDFS_preliminary_Q_lower (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (s : (d).tree.Child) (hsc : ScoredStar d x s) (hpos : 1 < edgeSum z ((d).backGroup s)) :
    min (edgeSum z ((d).backGroup s)-1)
      ((starMaximum d x s-x ((d).treeEdge s))/ScoredParameters.coefficient ((d).backGroup s).card) ≤
      preliminaryQIncrease d x s := by
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have ho := scoredDFS_outgoing_mass_lower G x hs hc root hx hcap s hsc
  rw [preliminaryQIncrease,if_neg hsc.1,← he]
  exact min_le_min le_rfl ho

theorem scoredDFS_enlarged_canonical_load (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (S T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hsc : ScoredStar d x s) (hpos : 1 < edgeSum z ((d).backGroup s)) :
    canonicalHeadLoad d (fixedGatePlan d x) x z S T (projectedOutgoingCoupon d x z) s ≤
      24*(edgeSum z ((d).backGroup s)-1)+refinedIncidenceCharge d x z S T s-
      24*max (x ((d).treeEdge s))
        (min (edgeSum z ((d).backGroup s)/2)
          ((starMaximum d x s-x ((d).treeEdge s))/ScoredParameters.coefficient ((d).backGroup s).card))+
      24*couponResidual d (fixedGatePlan d x) (fun e => x e.1) (projectedOutgoingCoupon d x z) s := by
  have hk : (fixedGatePlan d x).kind s ≠ .disabled := by
    simp only [fixedGatePlan,fixedBypassKind,if_neg hsc.1]
    split_ifs <;> decide
  have hb := scoredDFS_enlarged_coupon_lower G x z hs hc root hx hcap s hsc hpos
  unfold canonicalHeadLoad
  simp only [gatedFreeBase,if_neg hsc.1,Nat.cast_one,accountedCoupon,if_neg hk]
  linarith only [hb]

end TSP.Improvements20261105
