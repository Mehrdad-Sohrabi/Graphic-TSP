import TSP.Improvements20261105.RetainedLinkEdges

/-! Actual selected consecutive links inject into the retained induced
edges, component by component. Each source edge is counted once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_selected_headComponent_internal (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) : a.headComponent d P s ∈ a.internalComponents d P := by
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_univ _, ?_⟩
  apply (canonical_occupied_iff_internal d hs hc P hP t ht f hf hb a ha hcan _).mp
  exact ⟨s, (a.mem_componentHeads d P _ s).mpr ⟨hsel, rfl⟩⟩

theorem canonical_global_link_credit (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (z : E → ℝ) (hz : ∀ e, 0 ≤ z e) (hz1 : ∀ e, z e ≤ 1) (C : Finset d.tree.Child)
    (q : d.tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, (d.backGroup s).card ≤ 3 → ∀ e ∈ d.backGroup s, z e ≤ q s)
    (M : Finset d.tree.Child) (next : d.tree.Child → d.tree.Child)
    (hM : ∀ s ∈ M, d.tree.parent (next s) = (s : V) ∧ a.head s = 1 ∧ a.head (next s) = 1 ∧
      3 ≤ (d.backGroup s).card ∧ 3 ≤ (d.backGroup (next s)).card) :
    M.card ≤ ∑ r ∈ a.internalComponents d P, a.incidenceEdgeCount d P z C r := by
  let fiber (r : a.Component d P) : Finset d.tree.Child := M.filter (fun s => a.headComponent d P s = r)
  have hlocal (r : a.Component d P) : (fiber r).card ≤ a.incidenceEdgeCount d P z C r := by
    apply link_edge_card_bound d (fiber r) (retainedIncidenceHeads d z (a.componentHeads d P r) C) next
    intro s hsM
    have hmem := (Finset.mem_filter.mp hsM).1
    have hcomp := (Finset.mem_filter.mp hsM).2
    have h := hM s hmem
    have hsame := canonical_selected_link_same_component d P hP t ht f hf hb a ha hcan
      s (next s) h.1 h.2.1 h.2.2.1
    have hmS : s ∈ a.componentHeads d P r := by
      rw [← hcomp]
      exact (a.mem_componentHeads d P _ s).mpr ⟨h.2.1, rfl⟩
    have hmU : next s ∈ a.componentHeads d P r := by
      rw [← hcomp, hsame]
      exact (a.mem_componentHeads d P _ (next s)).mpr ⟨h.2.2.1, rfl⟩
    have hret (v : d.tree.Child) (hv : v ∈ a.componentHeads d P r) (htv : 3 ≤ (d.backGroup v).card) :
        v ∈ retainedIncidenceHeads d z (a.componentHeads d P r) C :=
      retainedIncidenceHeads_large d z hz hz1 _ C q (fun s _ => hq s) (fun s _ => hpack s)
        (fun s _ => hsmall s) (canonical_component_head_size d P hP t ht f hf hb a ha hcan r) v hv htv
    exact ⟨hret s hmS h.2.2.2.1, hret (next s) hmU h.2.2.2.2, h.1⟩
  have hsum : (∑ r ∈ a.internalComponents d P, (fiber r).card) = M.card := by
    simp only [fiber, Finset.card_filter]
    rw [Finset.sum_comm]
    calc
      _ = ∑ _s ∈ M, (1 : ℕ) := by
        apply Finset.sum_congr rfl
        intro s hsM
        have hr := canonical_selected_headComponent_internal d hs hc P hP t ht f hf hb a ha hcan
          s (hM s hsM).2.1
        simp [hr]
      _ = _ := by simp
  rw [← hsum]
  exact Finset.sum_le_sum (fun r _ => hlocal r)

end TSP.Improvements20261105
