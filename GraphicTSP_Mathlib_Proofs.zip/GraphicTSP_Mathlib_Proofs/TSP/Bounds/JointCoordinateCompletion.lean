import TSP.Improvements20261105.CanonicalJointCompletion
import TSP.Improvements20261105.CanonicalDropCoordinates

/-! The same feasible joint point is paired with the canonical coordinate
dual used in the component arguments; its objective is exactly preserved. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.value_shift (P : GatePlan d) (t : d.tree.Child → ℝ) (a : GatedDrops d) :
    a.value d P t = a.value d P (fun _ => 0) - ∑ v : d.tree.Child, t v * (a.head v : ℝ) := by
  simp only [GatedDrops.value, Finset.sum_sub_distrib, add_zero, add_mul, Finset.sum_add_distrib]
  ring

theorem canonical_coordinates_original_value (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : CanonicalGatedFor d P t f p) :
    (gatedDropsOf d p).value d P (fun _ => 0) =
      optionalDualValue (gatedNetwork d P) (fun e => (gatedCost d e : ℤ))
        (gatedLower d P) (gatedUpper d P) (fun v => (p v : ℝ)) := by
  have ha := gatedDropsOf_admissible d hp.1.1
  have hcan := gatedDropsOf_rebuild_canonical d P hP t f hf hb p hp
  have hvalue := (gatedDropsOf d p).potential_value d P hP t ha
  rw [hcan.1.2] at hvalue
  have hshift := gated_augmented_dual_selector_shift d P t p hp.1.1
  rw [hp.1.2] at hshift
  have hcoord := (gatedDropsOf d p).value_shift d P t
  change (gatedDropsOf d p).value d P t = (gatedDropsOf d p).value d P (fun _ => 0) -
    ∑ v : d.tree.Child, t v * (gatedHeadSelector d p v : ℝ) at hcoord
  linarith

theorem exists_joint_coordinate_completion (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.ValidGadgets d)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (C A : d.StarIndex → ℝ) (D : ℝ) (hD : 0 < D) :
    ∃ (Z : (E ⊕ d.StarIndex) → ℝ) (a : GatedDrops d),
      Z ∈ projectedFrameworkTwo G d.centers owner ∧ a.Admissible d P ∧
      (∃ f : GatedArc d → ℝ,
        Chapter06.Balanced (gatedNetwork d P) f ∧
        RealFlowBounds (gatedLower d P)
          (gatedAugmentedUpper d P (extendStarValue d (fun i => (max (C i) (A i) - A i) / (2 * D)))) f ∧
        CanonicalGatedFor d P (extendStarValue d (fun i => (max (C i) (A i) - A i) / (2 * D))) f (a.potential d P)) ∧
      edgeSum Z (nonremovableRepresentatives d.stars) =
        ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 ∧
      (∑ i : d.StarIndex,
        max (C i + 3 * D * (Z (Sum.inr i) - gatedArmBase d i.1))
          (A i + 3 * D * ((d.stars i).card - 1 -
            edgeSum Z (starRepresentatives d.stars i) - gatedArmBase d i.1))) ≤
      (∑ i : d.StarIndex, jointHeadTerm (C i) (A i) (a.head i.1 : ℝ)) +
        2 * D * a.value d P (fun _ => 0) := by
  obtain ⟨Z, p, hZ, ⟨f, hf, hb, hp⟩, _, _, hn, hbound⟩ :=
    exists_joint_canonical_completion d hs hc P hP owner ho C A D hD
  let t := extendStarValue d (fun i => (max (C i) (A i) - A i) / (2 * D))
  have hcan := gatedDropsOf_rebuild_canonical d P hP.tree t f hf hb p hp
  have hvalue := canonical_coordinates_original_value d P hP.tree t f hf hb p hp
  refine ⟨Z, gatedDropsOf d p, hZ, gatedDropsOf_admissible d hp.1.1,
    ⟨f, hf, hb, hcan⟩, hn, ?_⟩
  rw [hvalue]
  exact hbound

end TSP.Improvements20261105
