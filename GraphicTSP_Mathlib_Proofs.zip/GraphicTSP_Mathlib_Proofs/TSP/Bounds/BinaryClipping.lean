import TSP.Improvements20261105.BinaryCoordinates

/-! Capping positive integral back flows at one preserves all nonzero
coverage tests. Resetting bypasses at heads with at most one selected own
back cannot increase head-overflow or connector-deficiency payments. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def positiveBackSet {G : Graph V E} (d : DFSData G) (z : E → ℕ) : Finset E :=
  d.backEdges.filter (fun b => 0 < z b)

theorem positiveBackSet_subset {G : Graph V E} (d : DFSData G) (z : E → ℕ) :
    positiveBackSet d z ⊆ d.backEdges := Finset.filter_subset _ _

theorem positiveBackSet_mass {G : Graph V E} (d : DFSData G) (z : E → ℕ)
    (S : Finset E) : (positiveBackSet d z ∩ S).card ≤ ∑ b ∈ S, z b := by
  have h₁ : (positiveBackSet d z ∩ S).card ≤ ∑ b ∈ positiveBackSet d z ∩ S, z b := by
    calc
      _ = ∑ _b ∈ positiveBackSet d z ∩ S, 1 := by simp
      _ ≤ _ := Finset.sum_le_sum (fun b hb => by
        have hh := (Finset.mem_filter.mp (Finset.mem_inter.mp hb).1).2
        omega)
  exact h₁.trans (Finset.sum_le_sum_of_subset_of_nonneg Finset.inter_subset_right
    (fun b _ _ => Nat.zero_le (z b)))

theorem positiveBackSet_cover_iff {G : Graph V E} (d : DFSData G) (z : E → ℕ)
    (S : Finset E) (hS : S ⊆ d.backEdges) :
    (positiveBackSet d z ∩ S).Nonempty ↔ 0 < ∑ b ∈ S, z b := by
  constructor
  · rintro ⟨b, hb⟩
    have hz := (Finset.mem_filter.mp (Finset.mem_inter.mp hb).1).2
    exact hz.trans_le (Finset.single_le_sum (fun c _ => Nat.zero_le (z c)) (Finset.mem_inter.mp hb).2)
  · intro hp
    by_contra hn
    have hz : ∀ b ∈ S, z b = 0 := by
      intro b hb
      by_contra hne
      exact hn ⟨b, Finset.mem_inter.mpr ⟨Finset.mem_filter.mpr ⟨hS hb, by omega⟩, hb⟩⟩
    have hh := Finset.sum_eq_zero hz
    omega

theorem clipped_head_overflow_le (a k : ℕ) (r : ℝ) (hka : k ≤ a) :
    max ((k : ℝ) - (if 2 ≤ k then r else 0) - 1) 0 ≤
      max ((a : ℝ) - r - 1) 0 := by
  by_cases hk : 2 ≤ k
  · rw [if_pos hk]
    apply max_le_max _ le_rfl
    have hh : (k : ℝ) ≤ a := by exact_mod_cast hka
    linarith
  · rw [if_neg hk]
    have hkone : (k : ℝ) ≤ 1 := by exact_mod_cast (show k ≤ 1 by omega)
    have hz : max ((k : ℝ) - 0 - 1) 0 = 0 := max_eq_right (by linarith)
    rw [hz]
    exact le_max_right _ _

theorem clipped_connector_deficiency_le (a : ℕ) :
    (if 0 < a then (0 : ℝ) else 1) ≤ max (1 - (a : ℝ)) 0 := by
  by_cases ha : 0 < a
  · rw [if_pos ha]
    exact le_max_right _ _
  · have hz : a = 0 := by omega
    subst a
    norm_num

theorem clipped_actual_head_overflow {G : Graph V E} (d : DFSData G)
    (z : E → ℕ) (v : d.tree.Child) (r : ℝ) :
    max (((positiveBackSet d z ∩ d.backGroup v).card : ℝ) -
      (if 2 ≤ (positiveBackSet d z ∩ d.backGroup v).card then r else 0) - 1) 0 ≤
      max ((∑ b ∈ d.backGroup v, (z b : ℝ)) - r - 1) 0 := by
  have hh := clipped_head_overflow_le (∑ b ∈ d.backGroup v, z b)
    (positiveBackSet d z ∩ d.backGroup v).card r (positiveBackSet_mass d z _ )
  simpa only [Nat.cast_sum] using hh

theorem clipped_actual_connector_deficiency {G : Graph V E} (d : DFSData G)
    (z : E → ℕ) (v : d.tree.Child) :
    (if SelectedForeignCover d (positiveBackSet d z) v then (0 : ℝ) else 1) ≤
      max (1 - ∑ b ∈ deletedSubtreeCut d v, (z b : ℝ)) 0 := by
  have hi := positiveBackSet_cover_iff d z (deletedSubtreeCut d v) (deletedSubtreeCut_back d v)
  have hh := clipped_connector_deficiency_le (∑ b ∈ deletedSubtreeCut d v, z b)
  simpa only [SelectedForeignCover, hi, Nat.cast_sum] using hh

end TSP.Improvements20261105
