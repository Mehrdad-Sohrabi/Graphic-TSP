import TSP.Improvements20261105.FiniteEventThinning

/-! Keep all good-event mass and thin only the marked bad part. This
proves the precise lost-mass bound used by controlled zero-head guards. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Classical
open scoped BigOperators
variable {I : Type} [Fintype I] [DecidableEq I]

 theorem controlled_event_thinning (w : I → ℝ) (A B : Finset I) (hBA : B ⊆ A)
    (hw : ∀ i, 0 ≤ w i) (q k : ℝ) (hk : 0 ≤ k)
    (hbad : (∑ i ∈ B, w i) ≤ q/2) :
    ∃ r : I → ℝ,
      (∀ i, 0 ≤ r i ∧ r i ≤ w i) ∧
      (∀ i ∉ A, r i = 0) ∧
      (∀ i ∈ A \ B, r i = w i) ∧
      (∑ i ∈ B, r i) ≤ k/2 ∧
      (∑ i ∈ A, w i) - max (q-k) 0/2 ≤ ∑ i, r i := by
  let b := ∑ i ∈ B, w i
  have hb0 : 0 ≤ b := Finset.sum_nonneg (fun i _ => hw i)
  have hmass0 : 0 ≤ min b (k/2) := le_min hb0 (by linarith)
  obtain ⟨s, hs, hoff, hsum⟩ := finite_event_thinning w B (min b (k/2)) hw hmass0 (min_le_left _ _)
  let r := fun i => if i ∈ A \ B then w i else s i
  have hrB (i : I) (hi : i ∈ B) : r i = s i := by simp [r, hi]
  have hrAB (i : I) (hi : i ∈ A \ B) : r i = w i := if_pos hi
  have hsr : (∑ i ∈ B, s i) = min b (k/2) := by
    rw [← hsum]
    exact Finset.sum_subset (Finset.subset_univ _) (fun i _ hi => hoff i hi)
  have htotal : (∑ i, r i) = (∑ i ∈ A \ B, w i) + min b (k/2) := by
    have heq (i : I) : r i = (if i ∈ A \ B then w i else 0) + s i := by
      by_cases hi : i ∈ A \ B
      · rw [hrAB i hi, if_pos hi, hoff i (Finset.mem_sdiff.mp hi).2, add_zero]
      · simp only [r, if_neg hi, zero_add]
    simp_rw [heq]
    rw [Finset.sum_add_distrib, hsum]
    rw [← Finset.sum_filter]
    simp only [Finset.filter_mem_eq_inter, Finset.univ_inter]
  have hsplit := Finset.sum_sdiff hBA (f := w)
  have hloss : b-min b (k/2) ≤ max (q-k) 0/2 := by
    by_cases hbk : b ≤ k/2
    · rw [min_eq_left hbk, sub_self]
      positivity
    · rw [min_eq_right (le_of_not_ge hbk)]
      have hm := le_max_left (q-k) (0 : ℝ)
      change b ≤ q/2 at hbad
      linarith
  refine ⟨r, ?_, ?_, hrAB, ?_, ?_⟩
  · intro i
    by_cases hi : i ∈ A \ B
    · rw [hrAB i hi]; exact ⟨hw i, le_rfl⟩
    · simpa only [r, if_neg hi] using hs i
  · intro i hi
    have hnB : i ∉ B := fun h => hi (hBA h)
    simp [r, hi, hoff i hnB]
  · rw [Finset.sum_congr rfl hrB, hsr]
    exact min_le_right _ _
  · rw [htotal]
    change (∑ i ∈ A \ B, w i) + b = _ at hsplit
    linarith

end TSP.Improvements20261105
