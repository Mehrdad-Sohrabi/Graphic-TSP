import TSP.Improvements20261105.FixedQIncreases

/-! Normalize the actual classified Q connector by its original star mass.
The favorable center-excess term is kept explicitly. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem classified_main_mass_sum (hs : G.IsSimple) (x : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : ClassifiedStarIndex d x)
    (hi : partialMain d hx hn hcap (partialCenter d x i) = some i) :
    classifiedCapacity d hx hn hcap (.inr i) + edgeSum x (d.stars i.1) =
      2 + degreeExcess G x (d.centers i.1) := by
  rw [classified_anchor_capacity d hs hx hn hcap i, if_pos hi,
    minorBoundary_mass d hs x (partialCenter d x i) i.2]
  have hh := (partialMain_head d hx hn hcap i).mp hi
  rw [← hh]
  change (edgeSum x (G.cut {d.centers i.1}) - edgeSum x (d.stars i.1)) +
    edgeSum x (d.stars i.1) = _
  unfold degreeExcess
  ring

theorem classified_connector_normalized (hs : G.IsSimple) (x : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : ClassifiedStarIndex d x) (y : ℝ)
    (hy : y = if partialMain d hx hn hcap (partialCenter d x i) ≠ some i ∨
      Even (G.intDegree d.treeEdges (partialCenter d x i))
      then classifiedCapacity d hx hn hcap (.inr i) / 2
      else 1 - classifiedCapacity d hx hn hcap (.inr i) / 2) :
    y - edgeSum x (d.stars i.1) / 2 =
      if partialMain d hx hn hcap (partialCenter d x i) = some i then
        if Even (G.intDegree d.treeEdges (d.centers i.1)) then
          1 + degreeExcess G x (d.centers i.1) / 2 - edgeSum x (d.stars i.1)
        else -degreeExcess G x (d.centers i.1) / 2
      else 0 := by
  by_cases hm : partialMain d hx hn hcap (partialCenter d x i) = some i
  · rw [if_pos hm]
    have hmass := classified_main_mass_sum d hs x hx hn hcap i hm
    by_cases he : Even (G.intDegree d.treeEdges (d.centers i.1))
    · have hy' : y = classifiedCapacity d hx hn hcap (.inr i) / 2 := by
        rw [hy]
        split_ifs with h
        · rfl
        · exact (h (Or.inr he)).elim
      rw [if_pos he, hy']
      linarith
    · have hy' : y = 1 - classifiedCapacity d hx hn hcap (.inr i) / 2 := by
        rw [hy]
        split_ifs with h
        · rcases h with h | h
          · exact (h hm).elim
          · exact (he h).elim
        · rfl
      rw [if_neg he, hy']
      linarith
  · rw [if_neg hm]
    rw [hy, if_pos (Or.inl hm), classified_anchor_capacity d hs hx hn hcap i, if_neg hm]
    simp only [partialStars, sub_self]

theorem classified_connector_nonpositive (hs : G.IsSimple) (x : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : ClassifiedStarIndex d x) (y : ℝ)
    (hy : y = if partialMain d hx hn hcap (partialCenter d x i) ≠ some i ∨
      Even (G.intDegree d.treeEdges (partialCenter d x i))
      then classifiedCapacity d hx hn hcap (.inr i) / 2
      else 1 - classifiedCapacity d hx hn hcap (.inr i) / 2) :
    y - edgeSum x (d.stars i.1) / 2 ≤ 0 := by
  rw [classified_connector_normalized d hs x hx hn hcap i y hy]
  have hxi := degreeExcess_nonnegative G hx hn (d.centers i.1)
  split_ifs with hm he
  · have hmass := classified_main_mass_sum d hs x hx hn hcap i hm
    have hsmall := (classified_anchor_capacity_bounds d hs hx hn hcap i).2
    linarith
  · linarith
  · exact le_rfl

end TSP.Improvements20261105
