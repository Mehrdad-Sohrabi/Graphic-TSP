import TSP.Improvements20261105.DesignatedLeafPayment

/-! Fixed per-back score/mass choices. All benchmarks come from the
actual DFS comparison; the critical set may be fixed arbitrarily among
scored heads before the circulation dual is selected. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 ScoredParameters Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

structure ScoreComparisons (x : E → ℝ) (C : Finset d.tree.Child) : Prop where
  maximum_le : ∀ s ∈ C, starMaximum d x s ≤ upper (d.backGroup s).card
  dominates : ∀ s ∈ C, ∀ e ∈ d.backGroup s,
    benchmark (d.backGroup s).card (starMaximum d x s) (x e)
      (ancestorOutgoing d x (d.tree.parent s) (d.lower e)) ≤ winningBenchmark d x s

theorem scoredDFS_comparisons (G : Graph V E) (x : E → ℝ) (hs : G.IsSimple)
    (hc : G.Connected) (root : V) (C : Finset (scoredDFS G x hs hc root).tree.Child)
    (hC : ∀ s ∈ C, ScoredStar (scoredDFS G x hs hc root) x s) :
    ScoreComparisons (scoredDFS G x hs hc root) x C where
  maximum_le := fun s hsC => (hC s hsC).2.2.2.2.2
  dominates := fun s hsC e he => scoredDFS_benchmark_comparison G x hs hc root s
    (hC s hsC) e (Finset.mem_sdiff.mp he).1

noncomputable def scoreArm (x z : E → ℝ) (e : E) : ℝ :=
  (localMassSlope (d.backGroup (d.anchor e)).card / coefficient (d.backGroup (d.anchor e)).card) *
    (winningBenchmark d x (d.anchor e) - z e)

noncomputable def fixedBackPayment (x z : E → ℝ) (C : Finset d.tree.Child) (e : E) : ℝ :=
  if d.anchor e ∈ C then min (scoreArm d x z e) (massSlope * z e) else massSlope * z e

noncomputable def scorePaidBacks (x z : E → ℝ) (C : Finset d.tree.Child) (B : Finset E) : Finset E :=
  B.filter (fun e => d.anchor e ∈ C ∧ scoreArm d x z e ≤ massSlope * z e)

theorem score_comparison_back_le {x : E → ℝ} (hx : ∀ e, 0 ≤ x e) {C : Finset d.tree.Child}
    (hC : ScoreComparisons d x C) (e : E) (he : e ∈ d.backEdges) (hs : d.anchor e ∈ C) :
    x e ≤ winningBenchmark d x (d.anchor e) := by
  have hown : e ∈ d.backGroup (d.anchor e) := (back_anchor_iff_group d ⟨e, he⟩ _).mp rfl
  have hm : starMaximum d x (d.anchor e) ≤ 1 :=
    (hC.maximum_le _ hs).trans ((upper_bounds _).2.trans (by norm_num))
  have hg := benchmark_ge_value (t := (d.backGroup (d.anchor e)).card) (q := x e) hm
    (ancestorOutgoing_nonneg d hx (d.tree.parent (d.anchor e)) (d.lower e))
  exact hg.trans (hC.dominates _ hs e hown)

theorem fixedBackPayment_nonneg (x z : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e) (C : Finset d.tree.Child)
    (hC : ScoreComparisons d x C) (e : E) (he : e ∈ d.backEdges) :
    0 ≤ fixedBackPayment d x z C e := by
  unfold fixedBackPayment
  split_ifs with hs
  · apply le_min
    · apply mul_nonneg
      · exact div_nonneg (localMassSlope_bounds _).1.le (coefficient_bounds _).1.le
      · exact sub_nonneg.mpr ((hzx e).trans (score_comparison_back_le d hx hC e he hs))
    · exact mul_nonneg (by norm_num [massSlope]) (hz e)
  · exact mul_nonneg (by norm_num [massSlope]) (hz e)

theorem fixedBackPayment_score (x z : E → ℝ) (C : Finset d.tree.Child) (B : Finset E)
    (e : E) (he : e ∈ scorePaidBacks d x z C B) : fixedBackPayment d x z C e = scoreArm d x z e := by
  have hm := (Finset.mem_filter.mp he).2
  simp [fixedBackPayment, hm.1, min_eq_left hm.2]

theorem fixedBackPayment_mass (x z : E → ℝ) (C : Finset d.tree.Child) (B : Finset E)
    (e : E) (he : e ∈ B) (hn : e ∉ scorePaidBacks d x z C B) :
    fixedBackPayment d x z C e = massSlope * z e := by
  by_cases hs : d.anchor e ∈ C
  · have hlt : massSlope * z e < scoreArm d x z e := by
      by_contra hg
      exact hn (Finset.mem_filter.mpr ⟨he, hs, le_of_not_gt hg⟩)
    simp [fixedBackPayment, hs, min_eq_right hlt.le]
  · simp [fixedBackPayment, hs]

theorem fixed_leaf_payment (hs : G.IsSimple) (x z : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e) (C : Finset d.tree.Child)
    (hC : ScoreComparisons d x C) (v : V)
    (hmass : 1 ≤ edgeSum x (d.backEdges.filter (fun e => d.lower e = v))) :
    1 ≤ edgeSum (fixedBackPayment d x z C) (d.backEdges.filter (fun e => d.lower e = v)) +
      massSlope * leafProjectionLoss d x z v := by
  let B := d.backEdges.filter (fun e => d.lower e = v)
  let S := scorePaidBacks d x z C B
  have hSB : S ⊆ B := Finset.filter_subset _ _
  have hBE : B ⊆ d.backEdges := Finset.filter_subset _ _
  have hp : ∀ e ∈ B, 0 ≤ fixedBackPayment d x z C e :=
    fun e he => fixedBackPayment_nonneg d x z hx hz hzx C hC e (hBE he)
  have hdelta : edgeSum (fun e => x e - z e) B = leafProjectionLoss d x z v := by
    simp only [B, edgeSum, Finset.sum_filter, leafProjectionLoss]
  rw [← hdelta]
  by_cases hS : S.Nonempty
  · obtain ⟨b, hb, hmax⟩ := Finset.exists_max_image S (fun e => d.tree.depth (d.upper e)) hS
    have hsC := (Finset.mem_filter.mp hb).2.1
    have hbB := hSB hb
    have hbE := hBE hbB
    have hown : b ∈ d.backGroup (d.anchor b) := (back_anchor_iff_group d ⟨b, hbE⟩ _).mp rfl
    have htail : ∀ e ∈ S, d.lower e = d.lower b := by
      intro e he
      exact (Finset.mem_filter.mp (hSB he)).2.trans (Finset.mem_filter.mp hbB).2.symm
    have hA := last_designated_mass_le_score d hs S b hb htail hmax x hx
    have hcmp := hC.dominates _ hsC b hown
    rw [(d.anchor_spec b).1] at hcmp
    have hdef : coefficient (d.backGroup (d.anchor b)).card *
        min (edgeSum x (S.erase b)) (1 - starMaximum d x (d.anchor b)) ≤
          winningBenchmark d x (d.anchor b) - x b := by
      have hm := mul_le_mul_of_nonneg_left (min_le_min_right (1 - starMaximum d x (d.anchor b)) hA)
        (coefficient_bounds (d.backGroup (d.anchor b)).card).1.le
      unfold benchmark at hcmp
      linarith
    have hpaid : (localMassSlope (d.backGroup (d.anchor b)).card / coefficient (d.backGroup (d.anchor b)).card) *
        (winningBenchmark d x (d.anchor b) - z b) ≤ fixedBackPayment d x z C b := by
      rw [fixedBackPayment_score d x z C B b hb]
      exact le_rfl
    exact designated_leaf_payment B S hSB b hb x z (fixedBackPayment d x z C) hx hzx hp hmass
      (d.backGroup (d.anchor b)).card (winningBenchmark d x (d.anchor b)) (starMaximum d x (d.anchor b))
      (hC.maximum_le _ hsC) (le_finiteMaximum x (Finset.mem_sdiff.mp hown).1) hdef hpaid
      (fun e he => fixedBackPayment_mass d x z C B e (Finset.mem_sdiff.mp he).1 (Finset.mem_sdiff.mp he).2)
  · apply mass_pool_payment B x z (fixedBackPayment d x z C) hmass
    intro e he
    apply fixedBackPayment_mass d x z C B e he
    intro hm
    exact hS ⟨e, hm⟩

end TSP.Improvements20261105
