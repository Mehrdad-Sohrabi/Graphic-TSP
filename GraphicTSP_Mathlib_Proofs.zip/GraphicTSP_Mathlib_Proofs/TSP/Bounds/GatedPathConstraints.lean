import TSP.Improvements20261105.GatedBinaryCuts

/-! The exact constraint along every actual original back edge. Its tree
part is derived by telescoping around the elementary DFS circulation cycle. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def gatedTailDrop (p : GatedVertex d → ℤ) (v : V) : ℤ :=
  p (gatedCenter d v) - p (gatedTail d v)

def gatedOutsideDrop (p : GatedVertex d → ℤ) (v : d.tree.Child) : ℤ :=
  p (gatedOutside d v) - p (gatedHead d v)

noncomputable def gatedTreePathCost (p : GatedVertex d → ℤ) (b : BackEdge d) : ℝ :=
  ∑ v : d.tree.Child, (backCycle d b (.inl (.inl v)) * (gatedConnectorDrop d p v : ℝ) +
    backCycle d b (.inl (.inr v)) * (gatedRepresentativeDrop d p v : ℝ))

theorem gated_tree_path_telescope (p : GatedVertex d → ℤ) (b : BackEdge d) :
    gatedTreePathCost d p b = (p (gatedAux d (d.anchor b.1)) : ℝ) - p (gatedCenter d (d.lower b.1)) := by
  have hf : Chapter06.Balanced (ordinaryFlowNetwork d) (backCycle d b) :=
    backCycle_conservation d b
  have hh := balanced_potential_sum (ordinaryFlowNetwork d) (backCycle d b) hf
    (fun w => (p (.inl w) : ℝ))
  have hback : (∑ e : BackEdge d, backCycle d b (.inr e) *
      ((p (gatedAux d (d.anchor e.1)) : ℝ) - p (gatedCenter d (d.lower e.1)))) =
      (p (gatedAux d (d.anchor b.1)) : ℝ) - p (gatedCenter d (d.lower b.1)) := by
    simp [backCycle]
  simp only [Fintype.sum_sum_type, ordinaryFlowNetwork, flowSrc, flowDst,
    Sum.elim_inl, Sum.elim_inr] at hh
  rw [hback] at hh
  unfold gatedTreePathCost gatedConnectorDrop gatedRepresentativeDrop
  push_cast
  simp only [mul_sub, Finset.sum_add_distrib, Finset.sum_sub_distrib] at hh ⊢
  linarith

theorem gated_path_parts_nonnegative {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (b : BackEdge d) :
    0 ≤ gatedTreePathCost d p b ∧ 0 ≤ gatedTailDrop d p (d.lower b.1) ∧
      0 ≤ gatedOutsideDrop d p (d.anchor b.1) := by
  have ht := gated_dual_tail d hp (d.lower b.1)
  have ho := gated_dual_outside d hp (d.anchor b.1)
  refine ⟨?_, by unfold gatedTailDrop; omega, by unfold gatedOutsideDrop; omega⟩
  apply Finset.sum_nonneg
  intro v _
  have hpref := gated_dual_prefix d hp v
  have hsuff := gated_dual_suffix d hp v
  have hrep := gated_dual_representative d hp v
  have hc : (0 : ℝ) ≤ gatedConnectorDrop d p v := by
    have hh : 0 ≤ gatedConnectorDrop d p v := by unfold gatedConnectorDrop; omega
    exact_mod_cast hh
  have hr : (0 : ℝ) ≤ gatedRepresentativeDrop d p v := by
    have hh : 0 ≤ gatedRepresentativeDrop d p v := by unfold gatedRepresentativeDrop; omega
    exact_mod_cast hh
  exact add_nonneg (mul_nonneg (backCycle_nonneg d b _) hc) (mul_nonneg (backCycle_nonneg d b _) hr)

theorem gated_back_path_constraint {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (b : BackEdge d) :
    gatedTreePathCost d p b + (gatedTailDrop d p (d.lower b.1) : ℝ) +
      (if P.OutsideBack d b then (gatedOutsideDrop d p (d.anchor b.1) : ℝ) else 0) ≤
      (gatedHeadSelector d p (d.anchor b.1) : ℝ) := by
  have hh := hp (gatedBackArc d b) (by simp [gatedUpper])
  rw [gated_tree_path_telescope]
  unfold gatedTailDrop gatedOutsideDrop gatedHeadSelector
  push_cast
  by_cases ho : P.OutsideBack d b
  · rw [if_pos ho]
    have hhi : p (gatedOutside d (d.anchor b.1)) ≤ p (gatedTail d (d.lower b.1)) := by
      simpa [gatedNetwork, gatedCost, ho, sub_nonpos] using hh
    have hhr : (p (gatedOutside d (d.anchor b.1)) : ℝ) ≤ p (gatedTail d (d.lower b.1)) := by
      exact_mod_cast hhi
    linarith
  · rw [if_neg ho]
    have hhi : p (gatedHead d (d.anchor b.1)) ≤ p (gatedTail d (d.lower b.1)) := by
      simpa [gatedNetwork, gatedCost, ho, sub_nonpos] using hh
    have hhr : (p (gatedHead d (d.anchor b.1)) : ℝ) ≤ p (gatedTail d (d.lower b.1)) := by
      exact_mod_cast hhi
    linarith

theorem gated_back_path_budget_one {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (b : BackEdge d) :
    gatedTreePathCost d p b + (gatedTailDrop d p (d.lower b.1) : ℝ) +
      (if P.OutsideBack d b then (gatedOutsideDrop d p (d.anchor b.1) : ℝ) else 0) ≤ 1 := by
  have hh := gated_back_path_constraint d hp b
  have hbin := gated_head_selector_binary d P p hp (d.anchor b.1)
  have hn : (gatedHeadSelector d p (d.anchor b.1) : ℝ) ≤ 1 := by
    exact_mod_cast (show gatedHeadSelector d p (d.anchor b.1) ≤ 1 by omega)
  exact hh.trans hn

end TSP.Improvements20261105
