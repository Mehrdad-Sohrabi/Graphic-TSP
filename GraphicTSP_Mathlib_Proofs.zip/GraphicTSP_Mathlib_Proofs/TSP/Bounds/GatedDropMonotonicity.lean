import TSP.Improvements20261105.GatedDropObjective

/-! Quantitative control of changing dual coordinates. Every possible
increase of a bypass loss is charged to its own tail or its unique gate. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.pathCost_mono (a b : GatedDrops d)
    (hp : ∀ v, b.pref v ≤ a.pref v) (hs : ∀ v, b.suffix v ≤ a.suffix v)
    (hr : ∀ v, b.representative v ≤ a.representative v) (e : BackEdge d) :
    b.pathCost d e ≤ a.pathCost d e := by
  apply Finset.sum_le_sum
  intro v _
  apply add_le_add
  · apply mul_le_mul_of_nonneg_left _ (backCycle_nonneg d e _)
    exact_mod_cast add_le_add (hp v) (hs v)
  · apply mul_le_mul_of_nonneg_left _ (backCycle_nonneg d e _)
    exact_mod_cast hr v

theorem GatedDrops.penalty_nonneg (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    0 ≤ a.penalty d P v := by
  cases hk : P.kind v <;> simp [GatedDrops.penalty, hk]

theorem GatedDrops.penalty_zero_of_head_zero {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (v : d.tree.Child) (hv : a.head v = 0) : a.penalty d P v = 0 := by
  have hr := ha.representative_nonneg v
  have ht := ha.tail_nonneg v
  have hp := ha.pref_nonneg (P.receiver v)
  have ho := ha.outside_nonneg v
  cases hk : P.kind v <;> simp only [GatedDrops.penalty, hk] <;> omega

noncomputable def GatedDrops.penaltyBudget (P : GatePlan d) (a b : GatedDrops d)
    (v : d.tree.Child) : ℤ :=
  (if P.UsesGate d v then a.pref (P.receiver v) - b.pref (P.receiver v) else 0) +
  (if P.kind v = .outgoing ∨ P.kind v = .sharedGate then a.tail v - b.tail v else 0)

theorem GatedDrops.penalty_change_bound {P : GatePlan d} {a b : GatedDrops d}
    (ha : a.Admissible d P) (hb : b.Admissible d P)
    (hp : ∀ v, b.pref v ≤ a.pref v) (ht : ∀ v, b.tail v ≤ a.tail v)
    (hh : ∀ v, b.head v ≤ a.head v)
    (hr : ∀ v, b.head v ≠ 0 → a.representative v ≤ b.representative v)
    (ho : ∀ v, b.head v ≠ 0 → a.outside v ≤ b.outside v)
    (v : d.tree.Child) :
    b.penalty d P v ≤ a.penalty d P v + a.penaltyBudget d P b v := by
  have hpd := hp (P.receiver v)
  have htd := ht v
  have hhd := hh v
  by_cases hz : b.head v = 0
  · rw [b.penalty_zero_of_head_zero d hb v hz]
    have hpa := a.penalty_nonneg d P v
    unfold GatedDrops.penaltyBudget
    split_ifs <;> omega
  · have hrd := hr v hz
    have hod := ho v hz
    cases hk : P.kind v <;>
      simp only [GatedDrops.penalty, GatedDrops.penaltyBudget, GatePlan.UsesGate,
        hk, reduceCtorEq, or_false, false_or, or_true, true_or, if_false, if_true] <;> omega

theorem gate_receiver_sum (P : GatePlan d) (hP : P.RespectsTree d) (w : d.tree.Child → ℝ) :
    (∑ v : d.tree.Child, if P.UsesGate d v then w (P.receiver v) else 0) =
      ∑ v : d.tree.Child, if P.IsReceiver d v then w v else 0 := by
  let S := Finset.univ.filter (P.UsesGate d)
  have hinj : Set.InjOn P.receiver (S : Set d.tree.Child) := by
    intro s hs t ht he
    exact gate_receiver_unique d P hP s t (Finset.mem_filter.mp hs).2 (Finset.mem_filter.mp ht).2 he
  have himg : S.image P.receiver = Finset.univ.filter (P.IsReceiver d) := by
    ext v
    simp only [S, Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and, GatePlan.IsReceiver]
  rw [← Finset.sum_filter, ← Finset.sum_filter]
  change (∑ v ∈ S, w (P.receiver v)) = _
  rw [← Finset.sum_image hinj, himg]

theorem child_sum_le_vertex_sum (w : V → ℝ) (hw : ∀ v, 0 ≤ w v) :
    (∑ v : d.tree.Child, w v) ≤ ∑ v : V, w v := by
  have he : (∑ v : d.tree.Child, w v) = ∑ v ∈ Finset.univ.filter (fun v => v ≠ d.tree.root), w v := by
    exact (Finset.sum_subtype (Finset.univ.filter (fun v => v ≠ d.tree.root))
      (by intro v; simp) w).symm
  rw [he]
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
    (fun v _ _ => hw v)

theorem GatedDrops.penaltyBudget_sum_le (P : GatePlan d) (hP : P.RespectsTree d)
    (a b : GatedDrops d) (ht : ∀ v, b.tail v ≤ a.tail v) :
    (∑ v : d.tree.Child, (a.penaltyBudget d P b v : ℝ)) ≤
      (∑ v : d.tree.Child, if P.IsReceiver d v then ((a.pref v - b.pref v : ℤ) : ℝ) else 0) +
      ∑ v : V, ((a.tail v - b.tail v : ℤ) : ℝ) := by
  simp only [GatedDrops.penaltyBudget, Int.cast_add, Int.cast_ite, Int.cast_zero, Finset.sum_add_distrib]
  rw [gate_receiver_sum d P hP (fun v => ((a.pref v - b.pref v : ℤ) : ℝ))]
  apply add_le_add_left
  calc
    _ ≤ ∑ v : d.tree.Child, ((a.tail v - b.tail v : ℤ) : ℝ) := by
      apply Finset.sum_le_sum
      intro v _
      split_ifs
      · exact le_rfl
      · exact_mod_cast sub_nonneg.mpr (ht v)
    _ ≤ _ := child_sum_le_vertex_sum d (fun v => ((a.tail v - b.tail v : ℤ) : ℝ))
      (fun v => by dsimp only; exact_mod_cast sub_nonneg.mpr (ht v))

end TSP.Improvements20261105
