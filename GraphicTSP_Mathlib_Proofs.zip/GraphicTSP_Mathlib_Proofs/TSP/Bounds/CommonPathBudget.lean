import TSP.Improvements20261105.GatedComponentMass
import TSP.Improvements20261105.GatedCutDependencies

/-! A common true cut consumes the entire unit path budget of every
back using it. All other path terms and that back's tail drop are zero. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.common_cut_saturates {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child)
    (hw : w ∈ a.backPathCuts d P b) :
    a.physicalPathTerm d b w = 1 ∧ a.pathCost d b = 1 ∧ a.tail (d.lower b.1) = 0 := by
  have h1 := a.backPathCut_indicator_le d ha b w
  rw [if_pos hw] at h1
  have h2 : a.physicalPathTerm d b w ≤ a.pathCost d b := by
    rw [← a.physicalPathTerm_sum d b]
    exact Finset.single_le_sum (fun v _ => a.physicalPathTerm_nonneg d ha b v) (Finset.mem_univ w)
  have h3 := a.pathCost_le_one d ha b
  have hpath : a.pathCost d b = 1 := by linarith
  have ht := ha.back b
  have htail : (0 : ℝ) ≤ a.tail (d.lower b.1) := by exact_mod_cast ha.tail_nonneg _
  have ho : (0 : ℝ) ≤ if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0 := by
    split_ifs
    · exact_mod_cast ha.outside_nonneg _
    · exact le_rfl
  have hh : (a.head (d.anchor b.1) : ℝ) ≤ 1 := by
    have hb := a.head_binary d ha (d.anchor b.1)
    exact_mod_cast (show a.head (d.anchor b.1) ≤ 1 by omega)
  have hz : (a.tail (d.lower b.1) : ℝ) = 0 := by linarith
  exact ⟨by linarith, hpath, by exact_mod_cast hz⟩

theorem GatedDrops.common_cut_other_term_zero {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child)
    (hw : w ∈ a.backPathCuts d P b) (v : (expandedTree d).Child) (hne : v ≠ w) :
    a.physicalPathTerm d b v = 0 := by
  have hsat := a.common_cut_saturates d ha b w hw
  have hsum : a.physicalPathTerm d b v + a.physicalPathTerm d b w ≤ a.pathCost d b := by
    have h := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ ({v, w} : Finset (expandedTree d).Child))
      (fun u _ _ => a.physicalPathTerm_nonneg d ha b u)
    rw [Finset.sum_insert (by simpa using hne), Finset.sum_singleton, a.physicalPathTerm_sum d b] at h
    exact h
  have hn := a.physicalPathTerm_nonneg d ha b v
  linarith

noncomputable def GatedDrops.erasedPathTerm (a : GatedDrops d) (B : Finset (BackEdge d))
    (w : (expandedTree d).Child) : ℝ :=
  if ∃ b ∈ B, onExpandedBackPath d b w then (a.physicalRoleWeight d ((expandedTreeRoles d).symm w) : ℝ) else 0

theorem GatedDrops.erasedPathTerm_sum (a : GatedDrops d) (B : Finset (BackEdge d)) :
    (∑ w : (expandedTree d).Child, a.erasedPathTerm d B w) =
      ∑ v : d.tree.Child,
        ((if backsCoverConnector d B v then ((a.pref v + a.suffix v : ℤ) : ℝ) else 0) +
        (if backsCoverRepresentative d B v then (a.representative v : ℝ) else 0)) := by
  rw [← (expandedTreeRoles d).sum_comp, Fintype.sum_sum_type, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro v _
  simp only [erasedPathTerm, Equiv.symm_apply_apply]
  simp only [expandedTreeRoles, Equiv.coe_fn_mk,
    Sum.elim_inl, Sum.elim_inr, physicalRoleWeight, onExpandedBackPath,
    expanded_connector_back_path, expanded_representative_back_path, backsCoverConnector, backsCoverRepresentative]
  split_ifs <;> rfl

theorem GatedDrops.common_cut_deletion_cost {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (B : Finset (BackEdge d)) (S : Finset d.tree.Child)
    (hB : B.Nonempty) (w : (expandedTree d).Child)
    (hw : ∀ b ∈ B, w ∈ a.backPathCuts d P b) :
    a.deletionCost d (a.eraseBackDependencies d B S) = 1 := by
  obtain ⟨b₀, hb₀⟩ := hB
  have hterms : (∑ v : (expandedTree d).Child, a.erasedPathTerm d B v) = 1 := by
    rw [Finset.sum_eq_single w]
    · have hp : onExpandedBackPath d b₀ w := (Finset.mem_filter.mp (hw b₀ hb₀)).2
      have he : a.erasedPathTerm d B w = a.physicalPathTerm d b₀ w := by
        simp [erasedPathTerm, physicalPathTerm, hp, show ∃ b ∈ B, onExpandedBackPath d b w from ⟨b₀, hb₀, hp⟩]
      rw [he]
      exact (a.common_cut_saturates d ha b₀ w (hw b₀ hb₀)).1
    · intro v _ hne
      by_cases he : ∃ b ∈ B, onExpandedBackPath d b v
      · obtain ⟨b, hb, hp⟩ := he
        have hz := a.common_cut_other_term_zero d ha b w (hw b hb) v hne
        simpa only [erasedPathTerm, if_pos (show ∃ b ∈ B, onExpandedBackPath d b v from ⟨b, hb, hp⟩),
          physicalPathTerm, if_pos hp] using hz
      · simp [erasedPathTerm, he]
    · simp
  have htail : (∑ v : V, if backsUseTail d B v then (a.tail v : ℝ) else 0) = 0 := by
    apply Finset.sum_eq_zero
    intro v _
    by_cases hv : backsUseTail d B v
    · obtain ⟨b, hb, he⟩ := hv
      have hz := (a.common_cut_saturates d ha b w (hw b hb)).2.2
      rw [he] at hz
      simp [hz]
    · simp [hv]
  rw [a.eraseBackDependencies_cost, ← a.erasedPathTerm_sum, hterms, htail, add_zero]

end TSP.Improvements20261105
