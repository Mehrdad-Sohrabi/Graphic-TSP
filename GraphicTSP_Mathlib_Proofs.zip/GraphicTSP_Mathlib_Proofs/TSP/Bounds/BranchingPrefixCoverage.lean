import TSP.Improvements20261105.SourcePrefixCoverage

/-! If every actual leaf head lies in one child direction, another
child direction supplies external cut mass. The error is the original
center excess, owned by this leaf. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.branching_prefix_coverage (hs : G.IsSimple) (x : E → ℝ)
    (hx : G.SubtourFeasible x) (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (hr : r ≠ .inl d.tree.root)
    (hmarker : r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P))
    (hout : a.componentOutgoingCuts d P r = ∅)
    (w : d.tree.Child) (hcenter : a.component d P (.inl (d.tree.parent w)) = r)
    (hbranch : 2 ≤ childCount d (d.tree.parent w))
    (hheads : ∀ i ∈ a.actualComponentStars d P r, d.tree.Ancestor w i.1) :
    x (d.treeEdge w)+edgeSum x (d.backGroup w)-degreeExcess G x (d.tree.parent w) ≤
      componentEntryCoverage d x r := by
  classical
  obtain ⟨c,hc,hcw⟩ : ∃ c ∈ childSet d (d.tree.parent w), c ≠ w := by
    by_contra hn
    have hsub : childSet d (d.tree.parent w) ⊆ {w} := by
      intro c hc
      apply Finset.mem_singleton.mpr
      by_contra hne
      exact hn ⟨c,hc,hne⟩
    have hcard := Finset.card_le_card hsub
    rw [Finset.card_singleton] at hcard
    change 2 ≤ (childSet d (d.tree.parent w)).card at hbranch
    omega
  have hcp := (Finset.mem_filter.mp hc).2
  have hw : w ∈ childSet d (d.tree.parent w) := Finset.mem_filter.mpr ⟨Finset.mem_univ _,rfl⟩
  have hdis := child_subtrees_disjoint d (d.tree.parent w) hc hw hcw
  have hccomp : a.component d P (.inl (c : V)) = r := by
    apply a.leaf_descendant_same d P r hout (.inl (d.tree.parent w)) (.inl (c : V)) hcenter
    apply expanded_original_ancestor d
    rw [← hcp]
    exact Relation.ReflTransGen.single ⟨c.2,rfl⟩
  have hsub : G.cut (subtreeVertices d c) ∩ d.backEdges ⊆
      deletedSubtreeCut d (nonrootComponentEntry d r hr) := by
    intro e he
    have hec := (mem_subtree_cut_iff d c e).mp (Finset.mem_inter.mp he).1
    let b : BackEdge d := ⟨e,(Finset.mem_inter.mp he).2⟩
    have htail := a.leaf_descendant_same d P r hout (.inl (c : V)) (.inl (d.lower e)) hccomp
      (expanded_original_ancestor d (Finset.mem_filter.mp hec.1).2)
    have hhead : a.component d P (.inr (d.anchor e)) ≠ r := by
      intro hh
      let i : d.StarIndex := ⟨d.anchor e,own_back_anchor_active d b⟩
      have hi : i ∈ a.actualComponentStars d P r := Finset.mem_filter.mpr ⟨Finset.mem_univ _,hh⟩
      have ht : d.tree.Ancestor w (d.lower e) := (d.anchor_spec e).2.trans (hheads i hi)
      exact Finset.disjoint_left.mp hdis hec.1 (Finset.mem_filter.mpr ⟨Finset.mem_univ _,ht⟩)
    exact a.foreign_leaf_back_enters d P r hr hmarker hout b htail hhead
  have hmass := Finset.sum_le_sum_of_subset_of_nonneg hsub (fun e _ _ => hx.1 e)
  have hcut := hx.2 (subtreeVertices d c)
    ⟨c,Finset.mem_filter.mpr ⟨Finset.mem_univ _,Relation.ReflTransGen.refl⟩⟩
    ⟨d.tree.root,Finset.mem_compl.mpr (root_not_in_subtree d c)⟩
  rw [subtree_cut_tree_back_partition] at hcut
  have htree : d.treeEdge c ∈ d.group c := (d.mem_group_iff c _).mpr
    ⟨d.treeEdge_upper c,by rw [d.treeEdge_lower]; exact Relation.ReflTransGen.refl⟩
  have hnotback : d.treeEdge c ∉ G.cut (subtreeVertices d c) ∩ d.backEdges := by
    intro h
    exact (Finset.mem_sdiff.mp (Finset.mem_inter.mp h).2).2
      (Finset.mem_image.mpr ⟨c,Finset.mem_univ _,rfl⟩)
  rw [edgeSum,Finset.sum_insert hnotback] at hcut
  have hnotgroup : d.treeEdge c ∉ d.group w := fun h =>
    Finset.disjoint_left.mp (d.groups_disjoint c w hcw) htree h
  have hinc : d.treeEdge c ∈ G.cut {d.tree.parent w} := by
    rw [← hcp]
    exact group_subset_center_cut d hs c htree
  have hdegsub : insert (d.treeEdge c) (d.group w) ⊆ G.cut {d.tree.parent w} :=
    Finset.insert_subset hinc (group_subset_center_cut d hs w)
  have hdeg := Finset.sum_le_sum_of_subset_of_nonneg hdegsub (fun e _ _ => hx.1 e)
  change edgeSum x (insert (d.treeEdge c) (d.group w)) ≤ edgeSum x (G.cut {d.tree.parent w}) at hdeg
  rw [edgeSum,Finset.sum_insert hnotgroup] at hdeg
  change x (d.treeEdge c)+edgeSum x (d.group w) ≤ _ at hdeg
  rw [group_mass_eq_tree_add_backs] at hdeg
  rw [componentEntryCoverage_eq_deleted d x r hr]
  unfold degreeExcess
  change _ ≤ ∑ e ∈ deletedSubtreeCut d (nonrootComponentEntry d r hr), x e
  linarith only [hmass,hcut,hdeg]

end TSP.Improvements20261105
