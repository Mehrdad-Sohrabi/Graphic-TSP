import TSP.Improvements20261105.CurrentProjectedUnaryZeroDeficit
import TSP.Improvements20261105.ZeroReceiverLoad
import TSP.Improvements20261105.ZeroReceiverSelectedScalar
import TSP.Improvements20261105.CanonicalHeadLoad

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem actual_high_q_selected_zero_receiver
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (rootStar : (d).StarIndex)
    (Y R : E ⊕ (d).StarIndex → ℝ)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (eligible T : Finset (d).tree.Child) (i : (d).StarIndex) (s : (d).tree.Child)
    (hp : (d).centers i=(s:V)) (hl : s ∈ projectionLinks d x)
    (hq : 1/2 ≤ x ((d).treeEdge s)) (hsmall : edgeSum z ((d).backGroup i.1) ≤ 1) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) i.1 ≤
      -48*(1-x ((d).treeEdge s)-outgoingBackMass d x s)+1376/361 := by
  have hu := (Finset.mem_filter.mp hl).2.2.2.1
  have hi : unaryNext d s=i.1 := ((unaryNext_spec d s hu).2 i.1 hp).symm
  have hnr : (d).centers i ≠ (d).tree.root := by rw [hp]; exact s.2
  have huc : childCount d ((d).centers i)=1 := by rwa [hp]
  have hr := current_projected_unary_zero_deficit d hs x z hx hn hcap hm C owner rootStar Y R
    hrep hbacks hloss hterminal i hnr huc hsmall
  have hg := scoredDFS_high_parent_greedy G x hs hc root i.1 s hp hq
  have hI := zero_receiver_noncritical_load d z i.1 (x ((d).treeEdge i.1))
    (fun e _ => hz e) (fun e he => (hzx e).trans (hg e he)) hsmall
  have hRef := refined_fixed_incidence_le_noncritical d x z eligible T i.1
  have hload := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz) i.1
  have hid := projectionLinks_receiver_identity d hs x z hm s hl
  rw [hi] at hid
  have hg0 : 0 ≤ 1-x ((d).treeEdge s)-outgoingBackMass d x s := by
    have hh := (Finset.mem_filter.mp hl).2.2.2.2
    linarith
  exact zero_receiver_selected_scalar (edgeSum z ((d).backGroup i.1)) (x ((d).treeEdge i.1))
    (1-x ((d).treeEdge s)-outgoingBackMass d x s)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)
    (canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
      (projectedOutgoingCoupon d x z) i.1)
    hsmall (hx.1 _) hg0 (by linarith) hr (by linarith)

end TSP.Improvements20261105
