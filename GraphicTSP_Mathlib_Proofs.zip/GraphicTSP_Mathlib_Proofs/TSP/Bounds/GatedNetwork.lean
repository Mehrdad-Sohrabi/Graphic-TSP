import TSP.Improvements20261105.OptionalCirculationDual
import TSP.Improvements20261105.IntegralBinaryCost
import TSP.Chapter06.CirculationDecomposition

/-! The directed network with fixed representative-bypass gadgets. Every
connector is split into a prefix and suffix. Ungated prefixes keep their unit
lower bound; a receiving gate moves the head's paid arc to the split vertex.
The root connector is retained with zero lower bound as a redundant free path. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

inductive BypassKind where
  | disabled | outgoing | twoDirections | sharedGate | outsideGate
  deriving DecidableEq

structure GatePlan where
  kind : d.tree.Child → BypassKind
  receiver : d.tree.Child → d.tree.Child

def GatePlan.UsesGate (P : GatePlan d) (v : d.tree.Child) : Prop :=
  P.kind v = .sharedGate ∨ P.kind v = .outsideGate

def GatePlan.IsReceiver (P : GatePlan d) (v : d.tree.Child) : Prop :=
  ∃ s, P.UsesGate d s ∧ P.receiver s = v

def GatePlan.RespectsTree (P : GatePlan d) : Prop :=
  ∀ s, P.UsesGate d s → d.tree.parent (P.receiver s) = (s : V)

abbrev GatedVertex := FlowVertex d ⊕ (V ⊕ (d.tree.Child × Fin 4))
abbrev GatedArc := FlowArc d ⊕ (V ⊕ (d.tree.Child × Fin 8))

abbrev gatedCenter (v : V) : GatedVertex d := .inl (.inl v)
abbrev gatedAux (v : d.tree.Child) : GatedVertex d := .inl (.inr v)
abbrev gatedTail (v : V) : GatedVertex d := .inr (.inl v)
abbrev gatedHead (v : d.tree.Child) : GatedVertex d := .inr (.inr (v, 0))
abbrev gatedGate (v : d.tree.Child) : GatedVertex d := .inr (.inr (v, 1))
abbrev gatedOutside (v : d.tree.Child) : GatedVertex d := .inr (.inr (v, 2))
abbrev gatedCollector (v : d.tree.Child) : GatedVertex d := .inr (.inr (v, 3))

abbrev gatedSuffixArc (v : d.tree.Child) : GatedArc d := .inl (.inl (.inl v))
abbrev gatedRepArc (v : d.tree.Child) : GatedArc d := .inl (.inl (.inr v))
abbrev gatedBackArc (b : BackEdge d) : GatedArc d := .inl (.inr b)
abbrev gatedTailArc (v : V) : GatedArc d := .inr (.inl v)
abbrev gatedPrefixArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 0))
abbrev gatedFreeArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 1))
abbrev gatedReverseArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 2))
abbrev gatedPaidArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 3))
abbrev gatedBypassArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 4))
abbrev gatedFeedArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 5))
abbrev gatedExitTailArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 6))
abbrev gatedExitGateArc (v : d.tree.Child) : GatedArc d := .inr (.inr (v, 7))

def GatePlan.OutsideBack (P : GatePlan d) (b : BackEdge d) : Prop :=
  P.kind (d.anchor b.1) = .outsideGate ∧
    ¬d.tree.Ancestor (P.receiver (d.anchor b.1)) (d.lower b.1)

noncomputable def gatedBypassSource (P : GatePlan d) (v : d.tree.Child) : GatedVertex d :=
  if P.kind v = .outsideGate then gatedOutside d v else gatedHead d v

noncomputable def gatedBypassTarget (P : GatePlan d) (v : d.tree.Child) : GatedVertex d :=
  match P.kind v with
  | .disabled | .outgoing => gatedTail d v
  | .twoDirections => gatedCenter d v
  | .sharedGate => gatedCollector d v
  | .outsideGate => gatedGate d (P.receiver v)

noncomputable def gatedExtraSrc (P : GatePlan d) (v : d.tree.Child) : Fin 8 → GatedVertex d
  | 0 => gatedCenter d (d.tree.parent v)
  | 1 => gatedHead d v
  | 2 => gatedAux d v
  | 3 => gatedHead d v
  | 4 => gatedBypassSource d P v
  | 5 => gatedOutside d v
  | 6 => gatedCollector d v
  | _ => gatedCollector d v

noncomputable def gatedExtraDst (P : GatePlan d) (v : d.tree.Child) : Fin 8 → GatedVertex d
  | 0 => gatedGate d v
  | 1 => gatedAux d v
  | 2 => gatedHead d v
  | 3 => if P.IsReceiver d v then gatedGate d v else gatedCenter d (d.tree.parent v)
  | 4 => gatedBypassTarget d P v
  | 5 => gatedHead d v
  | 6 => gatedTail d v
  | _ => if P.kind v = .sharedGate then gatedGate d (P.receiver v) else gatedCenter d v

noncomputable def gatedNetwork (P : GatePlan d) : Graph (GatedVertex d) (GatedArc d) where
  src := Sum.elim
    (Sum.elim (Sum.elim (gatedGate d) (gatedAux d)) (fun b => gatedTail d (d.lower b.1)))
    (Sum.elim (gatedCenter d) (fun a => gatedExtraSrc d P a.1 a.2))
  dst := Sum.elim
    (Sum.elim (Sum.elim (gatedAux d) (fun v => gatedCenter d v))
      (fun b => if P.OutsideBack d b then gatedOutside d (d.anchor b.1) else gatedHead d (d.anchor b.1)))
    (Sum.elim (gatedTail d) (fun a => gatedExtraDst d P a.1 a.2))

noncomputable def gatedLower (P : GatePlan d) : GatedArc d → ℕ :=
  Sum.elim (Sum.elim
    (Sum.elim (fun v => if d.tree.parent v = d.tree.root then 0 else 1)
      (fun v => if (d.backGroup v).Nonempty then 0 else 1)) (fun _ => 0))
    (Sum.elim (fun _ => 0) (fun a =>
      if a.2 = 0 ∧ d.tree.parent a.1 ≠ d.tree.root ∧ ¬P.IsReceiver d a.1 then 1 else 0))

noncomputable def gatedUpper (P : GatePlan d) : GatedArc d → Option ℕ :=
  Sum.elim (fun _ => none) (Sum.elim (fun _ => none) (fun a =>
    if a.2 = 1 then some (if d.tree.parent a.1 = d.tree.root then 2 else 1)
    else if a.2 = 4 then some (if P.kind a.1 = .disabled then 0 else 1)
    else if a.2 = 6 ∨ a.2 = 7 then
      (if P.kind a.1 = .sharedGate then none else some 0)
    else none))

def gatedCost : GatedArc d → ℕ :=
  Sum.elim (fun _ => 0) (Sum.elim (fun _ => 0) (fun a => if a.2 = 3 then 1 else 0))

theorem gated_cost_sum (f : GatedArc d → ℝ) :
    (∑ a, (gatedCost d a : ℝ) * f a) = ∑ v, f (gatedPaidArc d v) := by
  simp [gatedCost, Fintype.sum_sum_type, Fintype.sum_prod_type]

theorem gate_receiver_unique (P : GatePlan d) (hP : P.RespectsTree d)
    (s t : d.tree.Child) (hs : P.UsesGate d s) (ht : P.UsesGate d t)
    (he : P.receiver s = P.receiver t) : s = t := by
  apply Subtype.ext
  have hh := congrArg (fun v : d.tree.Child => d.tree.parent v) he
  change d.tree.parent (P.receiver s) = d.tree.parent (P.receiver t) at hh
  rwa [hP s hs, hP t ht] at hh

end TSP.Improvements20261105
