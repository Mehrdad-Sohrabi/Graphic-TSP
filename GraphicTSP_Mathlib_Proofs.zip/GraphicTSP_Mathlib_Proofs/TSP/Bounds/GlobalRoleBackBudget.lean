import TSP.Improvements20261105.GlobalRoleWeightBudget
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.global_role_back_budget (hs : G.IsSimple) (hc : IsTwoVertexConnected G) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P)) :
    (∑ i ∈ pairStarHeads d (a.KLeafPairs d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.componentStarUnion d P (a.largeRemainingLeafRoots d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.componentStarUnion d P (a.solePairLeafRoots d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.componentStarUnion d P (a.oneExtraBackLeafRoots d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackSingleLeafRoots d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackTwoHeadLeafRoots d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.componentStarUnion d P (a.noPairLeafRoots d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.selectedHighQHeads d x z C, ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.internalUnmatchedHeads d P x z C, ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ pairStarHeads d (a.internalMatchingPairs d P x z C), ((d.backGroup i.1).card : ℝ))+
      (∑ i ∈ a.remainingRootHeads d P x z C, ((d.backGroup i.1).card : ℝ)) ≤ (d.backEdges.card : ℝ) := by
  exact (a.global_role_weight_budget d hs hc x z hx hn hcap hm C P hP t ht f hf hb ha hcan
    (fun i => ((d.backGroup i.1).card : ℝ)) (fun _ => Nat.cast_nonneg _)).trans
    (sum_star_back_counts_real d)

end TSP.Improvements20261105
