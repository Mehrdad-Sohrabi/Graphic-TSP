import TSP.Improvements20261105.FourBackPositiveThreeTargetScalar
import TSP.Improvements20261105.FourBackPositiveFourGoodTargetScalar
import TSP.Improvements20261105.FourBackPositiveFourBadTargetScalar
import TSP.Improvements20261105.FourBackPositiveFiveTargetScalar
import TSP.Improvements20261105.FourBackPositiveLargeTargetScalar
import TSP.Improvements20261105.FourBackNoncriticalBound

/-! A continuous paired inequality for a selected three-back source and
positive greedy target of arbitrary count. All rational cases are checked by Lean. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 6000000
set_option Elab.async false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

theorem four_back_greedy_positive_pair_scalar
    (r bad : ℕ) (hr : 3 ≤ r) (hbad : bad ≤ 1)
    (q e z a o S I H g : ℝ) (hq : (1/4 : ℝ) ≤ q)
    (he0 : 0 ≤ e) (hem : e ≤ 4*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (hz0 : 0 ≤ z) (ha : 1 ≤ a)
    (hmass : q+o+z+a=2) (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hS : S ≤ max (192*q-48) (144*q-684/19+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (htarget : a ≤ (r : ℝ)*z)
    (hgood : bad=0 → e ≤ q)
    (hgate : q ≤ 9/25 ∨ 43/100 ≤ q ∨ q+e ≤ 91/100)
    (hH0 : 0 ≤ H)
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(4+(r : ℝ))+2*(bad : ℝ) := by
  have hb0 : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg _
  by_cases h3 : r=3
  · have ht3 : a ≤ 3*z := by simpa only [h3,Nat.cast_ofNat] using htarget
    have hh := four_back_greedy_positive_threetarget_scalar q e z a o S I H g hq he0 hem heq ho0 hoe hz0 ha hmass hg0 hghalf hgap hS hIall ht3 hgate hH0 hHL hHR
    rw [h3,Nat.cast_ofNat]
    linarith only [hh,hb0]
  by_cases h4 : r=4
  · have ht4 : a ≤ 4*z := by simpa only [h4,Nat.cast_ofNat] using htarget
    rw [h4,Nat.cast_ofNat]
    by_cases hb : bad=0
    · have hh := four_back_greedy_positive_fourgoodtarget_scalar q e z a o S I H g hq he0 hem heq ho0 hoe hz0 ha hmass hg0 hghalf hgap hS hIall ht4 (hgood hb) hgate hH0 hHL hHR
      linarith only [hh,hb0]
    · have hb1 : bad=1 := by omega
      have hh := four_back_greedy_positive_fourbadtarget_scalar q e z a o S I H g hq he0 hem heq ho0 hoe hz0 ha hmass hg0 hghalf hgap hS hIall ht4 hgate hH0 hHL hHR
      rw [hb1,Nat.cast_one]
      linarith only [hh]
  by_cases h5 : r=5
  · have ht5 : a ≤ 5*z := by simpa only [h5,Nat.cast_ofNat] using htarget
    have hh := four_back_greedy_positive_fivetarget_scalar q e z a o S I H g hq he0 hem heq ho0 hoe hz0 ha hmass hg0 hghalf hgap hS hIall ht5 hgate hH0 hHL hHR
    rw [h5,Nat.cast_ofNat]
    linarith only [hh,hb0]
  have hr6 : (6 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 6≤r by omega)
  have hh := four_back_greedy_positive_largetarget_scalar q e z a o S I H g hq he0 hem heq ho0 hoe hz0 ha hmass hg0 hghalf hgap hS hIall hgate hH0 hHL hHR
  linarith only [hh,hb0,hr6]

end TSP.Improvements20261105
