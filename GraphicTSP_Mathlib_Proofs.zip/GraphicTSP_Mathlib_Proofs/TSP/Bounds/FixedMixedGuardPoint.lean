import TSP.Improvements20261105.FixedPositiveTerminalFamily
import TSP.Improvements20261105.MixedTerminalGuards
import TSP.Improvements20261105.TerminalQDeficit

/-! One Q point supports every fixed positive and eligible zero guard.
The resulting zero envelopes and positive deficit bounds hold together. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem zero_head_not_positive_terminal (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (i : d.StarIndex) (hi : edgeSum x (d.backGroup i.1) ≤ 1) :
    i ∉ fixedPositiveTerminalHeads d x := by
  intro hp
  have hh := (Finset.mem_filter.mp hp).2.2.1
  have he := degreeExcess_nonnegative G hx hn (d.tree.parent i.1)
  unfold SurvivingPositive at hh
  linarith

theorem positive_terminal_not_zero (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (i : d.StarIndex) (hi : i ∈ fixedPositiveTerminalHeads d x) :
    i ∉ fixedZeroTerminalHeads d x := by
  intro hz
  exact zero_head_not_positive_terminal d x hx hn i (Finset.mem_filter.mp hz).2.2 hi

theorem exists_fixed_mixed_guard_point (hs : G.IsSimple) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (Q : E ⊕ d.StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G d.centers owner)
    (t : d.tree.Child → ℝ) (ht : ∀ c, t c ≠ 0 → SurvivingPositive d x c)
    (hr : ∀ c, Q (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+t c)
    (hb : ∀ e ∈ d.backEdges, Q (.inl e) = 1-x e/2)
    (hfull : ∀ i ∈ fixedPositiveTerminalHeads d x, t i.1 = 1-x (d.treeEdge i.1)) :
    ∃ (R : E ⊕ d.StarIndex → ℝ) (m : d.StarIndex → ℝ),
      R ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ i, R (.inr i) = Q (.inr i)) ∧
      (∀ i ∈ fixedZeroTerminalHeads d x ∪ fixedPositiveTerminalHeads d x, 0 ≤ m i) ∧
      (∀ i ∈ fixedZeroTerminalHeads d x,
        (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
          max (x (d.treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i) ∧
      (∀ i ∈ fixedPositiveTerminalHeads d x,
        m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1) ∧
      edgeSum R (nonremovableRepresentatives d.stars) ≤ edgeSum Q (nonremovableRepresentatives d.stars)-
        ((∑ i ∈ fixedZeroTerminalHeads d x, m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, m i)) ∧
      (∀ i, edgeSum Q (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
        (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Q i else 0)+
        2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0)) ∧
      (∀ i, edgeSum x (d.backGroup i.1) ≤ 1 →
        max (R (.inr i)-edgeSum x (d.stars i)/2)
          ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
            -zeroQCredit d x Q i) ∧
      (∀ i ∈ fixedPositiveTerminalHeads d x,
        (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
          -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1) ∧
      (∀ e, (∀ b ∈ fixedZeroTerminalBacks d x ∪ fixedPositiveTerminalBacks d x,
        e ∉ (fundamentalCycleEdges d b).map Function.Embedding.inl) → R e = Q e) := by
  let k : BackEdge d → ℝ := fun b => zeroGuardCapacity d x Q (ownBackStar d b)
  have hcredit (i : d.StarIndex) (ha : edgeSum x (d.backGroup i.1) ≤ 1) :
      0 ≤ zeroQCredit d x Q i ∧ zeroQCredit d x Q i ≤ x (d.treeEdge i.1) :=
    actual_zero_Q_credit_bounds d hs x hx hn t ht owner ho Q hQ hr hb i ha
  have hk : ∀ b ∈ fixedZeroTerminalBacks d x, 0 ≤ k b := by
    intro b hbF
    have ha : edgeSum x (d.backGroup (ownBackStar d b).1) ≤ 1 := fixedZeroTerminalBacks_zero d x b hbF
    exact (zeroGuardCapacity_bounds d x Q (ownBackStar d b) ha (hcredit _ ha).2).1
  have hdis := fixed_terminal_families_disjoint d x hx hn
  obtain ⟨R, m, hR, hm, hmz, hmp, hout, hc, _, hsave, hloss⟩ :=
    exists_mixed_terminal_guards d hs x hx hn hcap owner ho Q hQ t ht hr hb
      (fixedZeroTerminalBacks d x) (fixedPositiveTerminalBacks d x) hdis
      (fixed_terminal_union_headfree d x) (fun b hb c hc hne => fixed_terminal_union_distinct d x b c hb hc hne)
      (fixedZeroTerminalBacks_zero d x) k hk
  have hzmem (i : d.StarIndex) (hi : i ∈ fixedZeroTerminalHeads d x) :
      fixedOwnBack d i ∈ fixedZeroTerminalBacks d x := Finset.mem_image.mpr ⟨i, hi, rfl⟩
  have hpmem (i : d.StarIndex) (hi : i ∈ fixedPositiveTerminalHeads d x) :
      fixedOwnBack d i ∈ fixedPositiveTerminalBacks d x := Finset.mem_image.mpr ⟨i, hi, rfl⟩
  have hloss' (i : d.StarIndex) :
      edgeSum Q (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
        (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Q i else 0)+
        2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0) := by
    have hpSum : (∑ b ∈ fixedPositiveTerminalBacks d x, if d.anchor b.1 = i.1 then m b else 0) =
        if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0 := by
      calc
        _ = ∑ b ∈ fixedPositiveTerminalBacks d x,
            if d.anchor b.1 = i.1 then (15/88 : ℝ)*terminalSubtreeGuardValue d x (ownBackStar d b).1 else 0 := by
          apply Finset.sum_congr rfl
          intro b hbF
          rw [hmp b hbF]
          rfl
        _ = _ := fixed_terminal_back_fiber d (fixedPositiveTerminalHeads d x)
          (fun j => (15/88 : ℝ)*terminalSubtreeGuardValue d x j.1) i
    have hh := hloss i
    dsimp only [k] at hh
    rwa [fixed_zero_guard_cap_sum, hpSum] at hh
  refine ⟨R, fun i => m (fixedOwnBack d i), hR, hc, ?_, ?_, ?_, ?_, hloss', ?_, ?_, hout⟩
  · intro i hi
    apply hm
    rcases Finset.mem_union.mp hi with hz | hp
    · exact Finset.mem_union_left _ (hzmem i hz)
    · exact Finset.mem_union_right _ (hpmem i hp)
  · intro i hi
    simpa only [fixedOwnBack_anchor, k, ownBackStar_fixed] using hmz _ (hzmem i hi)
  · intro i hi
    simpa only [fixedOwnBack_anchor] using hmp _ (hpmem i hi)
  · rw [Finset.sum_union hdis] at hsave
    have hzSum : (∑ b ∈ fixedZeroTerminalBacks d x, m b) =
        ∑ i ∈ fixedZeroTerminalHeads d x, m (fixedOwnBack d i) :=
      Finset.sum_image (fun i _ j _ h => fixedOwnBack_injective d h)
    have hpSum : (∑ b ∈ fixedPositiveTerminalBacks d x, m b) =
        ∑ i ∈ fixedPositiveTerminalHeads d x, m (fixedOwnBack d i) :=
      Finset.sum_image (fun i _ j _ h => fixedOwnBack_injective d h)
    rwa [hzSum, hpSum] at hsave
  · intro i hi
    apply zero_guard_completed_Q_preserved d x t Q R hr hb i
      (zero_head_increase_eq_zero d x hx hn t ht i.1 hi) hi (hcredit i hi).2 (hc i)
    have hh := hloss' i
    rw [if_neg (zero_head_not_positive_terminal d x hx hn i hi), mul_zero, add_zero] at hh
    by_cases hmem : i ∈ fixedZeroTerminalHeads d x
    · simpa only [if_pos hmem] using hh
    · rw [if_neg hmem, mul_zero] at hh
      have hk0 := (zeroGuardCapacity_bounds d x Q i hi (hcredit i hi).2).1
      linarith
  · intro i hi
    have hp := (Finset.mem_filter.mp hi).2
    apply positive_terminal_Q_deficit d hs x hx hn hcap i hp.1 hp.2.2 hp.2.1 Q R t hr hb (hfull i hi)
    have hh := hloss' i
    simpa only [if_pos hi, if_neg (positive_terminal_not_zero d x hx hn i hi), zero_mul, mul_zero, zero_add] using hh

end TSP.Improvements20261105
