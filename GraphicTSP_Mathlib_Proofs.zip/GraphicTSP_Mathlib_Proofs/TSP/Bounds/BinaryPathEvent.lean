import Mathlib.Tactic

/-! The deterministic binary path inequality behind the sharp terminal
cycle event bound, and its finite weighted form. -/
namespace TSP.Improvements20261105
open scoped BigOperators

noncomputable def bitValue (b : Bool) : ℝ := if b then 1 else 0
noncomputable def firstBit : List Bool → ℝ
  | [] => 0
  | a :: _ => bitValue a
noncomputable def lastBit : List Bool → ℝ
  | [] => 0
  | [a] => bitValue a
  | _ :: b :: l => lastBit (b :: l)
noncomputable def allBits : List Bool → ℝ
  | [] => 1
  | a :: l => if a then allBits l else 0
noncomputable def pathVariation : List Bool → ℝ
  | [] => 0
  | [_] => 0
  | a :: b :: l => (if a = b then 0 else 1) + pathVariation (b :: l)

theorem allBits_box (l : List Bool) : 0 ≤ allBits l ∧ allBits l ≤ 1 := by
  induction l with
  | nil => norm_num [allBits]
  | cons a l ih => cases a <;> simp [allBits, ih]

theorem allBits_eq_indicator (l : List Bool) : allBits l = if ∀ b ∈ l, b = true then (1 : ℝ) else 0 := by
  induction l with
  | nil => simp [allBits]
  | cons a l ih => cases a <;> simp [allBits, ih]

theorem binary_path_event (l : List Bool) :
    firstBit l + lastBit l ≤ 2 * allBits l + pathVariation l := by
  induction l with
  | nil => norm_num [firstBit, lastBit, allBits, pathVariation]
  | cons a l ih =>
    cases l with
    | nil => cases a <;> norm_num [firstBit, lastBit, allBits, pathVariation, bitValue]
    | cons b l =>
      have hbox := (allBits_box l).2
      cases a <;> cases b <;>
        simp [firstBit, lastBit, allBits, pathVariation, bitValue] at * <;>
        linarith

theorem weighted_binary_path_event {I : Type} [Fintype I]
    (w : I → ℝ) (hw : ∀ i, 0 ≤ w i) (l : I → List Bool) :
    (∑ i, w i * firstBit (l i)) + (∑ i, w i * lastBit (l i)) -
      (∑ i, w i * pathVariation (l i)) ≤ 2 * ∑ i, w i * allBits (l i) := by
  have h := Finset.sum_le_sum (s := Finset.univ)
    (fun i _ => mul_le_mul_of_nonneg_left (binary_path_event (l i)) (hw i))
  simp only [mul_add, Finset.sum_add_distrib] at h
  have hh : (∑ i, w i * (2 * allBits (l i))) = 2 * ∑ i, w i * allBits (l i) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [hh] at h
  linarith

theorem parity_path_mismatch (a b treeChosen treeTotal backChosen : ℕ)
    (ha : a ≤ 1) (hb : b ≤ 1) (ht : treeChosen ≤ treeTotal)
    (hparity : (a + b + treeChosen + backChosen) % 2 = treeTotal % 2)
    (hne : a ≠ b) : 1 ≤ treeTotal - treeChosen + backChosen := by omega

end TSP.Improvements20261105
