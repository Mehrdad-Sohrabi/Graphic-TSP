import TSP.Improvements20261105.GatedDropObjective
import TSP.Improvements20261105.CanonicalGateOwners

/-! Passing from an actual canonical optimum to its independent drop
coordinates preserves optimality and every canonical priority. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem gatedCutCount_congr (P : GatePlan d) (p q : GatedVertex d → ℤ)
    (hpre : ∀ v, gatedPrefixDrop d p v = gatedPrefixDrop d q v)
    (hsuf : ∀ v, gatedSuffixDrop d p v = gatedSuffixDrop d q v)
    (hrep : ∀ v, gatedRepresentativeDrop d p v = gatedRepresentativeDrop d q v) :
    gatedCutCount d P p = gatedCutCount d P q := by
  unfold gatedCutCount
  congr 1
  ext a
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · have hh := hsuf v
    unfold gatedSuffixDrop at hh
    simp only [gatedLower, gatedNetwork, Sum.elim_inl]
    omega
  · have hh := hrep v
    unfold gatedRepresentativeDrop at hh
    simp only [gatedLower, gatedNetwork, Sum.elim_inl, Sum.elim_inr]
    omega
  · simp [gatedLower]
  · simp [gatedLower]
  · by_cases hk : k = 0
    · subst k
      have hh := hpre v
      unfold gatedPrefixDrop at hh
      simp only [gatedLower, gatedNetwork, gatedExtraSrc, gatedExtraDst,
        Sum.elim_inl, Sum.elim_inr]
      omega
    · simp [gatedLower, hk]

theorem gatedDropsOf_rebuild_nondecreasing (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p) :
    realCapacityDualValue (gatedNetwork d P) (fun e => (gatedCost d e : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) ≤
    realCapacityDualValue (gatedNetwork d P) (fun e => (gatedCost d e : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t)
        (fun v => ((gatedDropsOf d p).potential d P v : ℝ)) := by
  rw [gated_augmented_dual_formula, gated_augmented_dual_formula]
  apply Finset.sum_le_sum
  intro v _
  rw [GatedDrops.potential_reward, GatedDrops.potential_headSelector,
    GatedDrops.potential_penalty d P hP, gatedDropsOf_reward]
  have hh := gatedDropsOf_penalty_le d P hP p hp v
  change _ ≤ (gatedTrueReward d P p v : ℝ) -
    ((gatedFreeBase d v : ℝ) + t v) * max (gatedHeadSelector d p v : ℝ) 0 - _
  linarith

theorem gatedDropsOf_rebuild_canonical (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : CanonicalGatedFor d P t f p) :
    CanonicalGatedFor d P t f ((gatedDropsOf d p).potential d P) := by
  let q := (gatedDropsOf d p).potential d P
  have hq : GatedDualFeasible d P q :=
    GatedDrops.potential_feasible d P _ (gatedDropsOf_admissible d hp.1.1)
  have hbetter := gatedDropsOf_rebuild_nondecreasing d P hP t p hp.1.1
  have hopt := gated_optimal_of_improvement d P t f hf hb p q hp.1 hq hbetter
  have hpre : gatedPrefixCount d P q = gatedPrefixCount d P p := by
    simp [q, gatedPrefixCount, gatedDropsOf]
  have hcuts : gatedCutCount d P q = gatedCutCount d P p := by
    apply gatedCutCount_congr
    · intro v; simp [q, gatedDropsOf]
    · intro v; simp [q, gatedDropsOf]
    · intro v; simp [q, gatedDropsOf]
  have hheads : gatedSelectedHeadCount d q = gatedSelectedHeadCount d p := by
    simp [q, gatedSelectedHeadCount, gatedDropsOf]
  refine ⟨hopt, ?_, ?_, ?_⟩
  · intro z hz
    rw [hpre]
    exact hp.2.1 z hz
  · intro z hz he
    rw [hcuts]
    exact hp.2.2.1 z hz (he.trans hpre)
  · intro z hz he₁ he₂
    rw [hheads]
    exact hp.2.2.2 z hz (he₁.trans hpre) (he₂.trans hcuts)

theorem exists_canonical_gated_drops (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) :
    ∃ (f : GatedArc d → ℝ) (a : GatedDrops d),
      Chapter06.Balanced (gatedNetwork d P) f ∧
      RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f ∧
      a.Admissible d P ∧ CanonicalGatedFor d P t f (a.potential d P) := by
  obtain ⟨f, p, hf, hb, hp⟩ := exists_canonical_gated_dual d hs hc P t ht
  exact ⟨f, gatedDropsOf d p, hf, hb, gatedDropsOf_admissible d hp.1.1,
    gatedDropsOf_rebuild_canonical d P hP t f hf hb p hp⟩

end TSP.Improvements20261105
