import TSP.Improvements20261105.GatedConvexArms
import TSP.Improvements20261105.GatedAugmentedDual

/-! Joint completion of arbitrary fixed connector and deficit arms.
The output is an actual feasible graph point and a binary-selector dual;
no target approximation inequality is an input. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def extendStarValue (a : d.StarIndex → ℝ) (v : d.tree.Child) : ℝ :=
  if h : (d.backGroup v).Nonempty then a ⟨v, h⟩ else 0

@[simp] theorem extendStarValue_active (a : d.StarIndex → ℝ) (i : d.StarIndex) :
    extendStarValue d a i.1 = a i := by simp [extendStarValue, i.2]

theorem sum_extendStarValue (a : d.StarIndex → ℝ) :
    (∑ v : d.tree.Child, extendStarValue d a v) = ∑ i : d.StarIndex, a i := by
  have he := Finset.sum_subtype (p := fun v : d.tree.Child => (d.backGroup v).Nonempty)
    (F := inferInstanceAs (Fintype d.StarIndex))
    (Finset.univ.filter (fun v : d.tree.Child => (d.backGroup v).Nonempty))
    (by intro v; simp) (extendStarValue d a)
  have hf : (∑ v ∈ Finset.univ.filter (fun v : d.tree.Child => (d.backGroup v).Nonempty),
      extendStarValue d a v) = ∑ v : d.tree.Child, extendStarValue d a v := by
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro v _ hv
    have hn : ¬(d.backGroup v).Nonempty := by simpa using hv
    simp [extendStarValue, hn]
  rw [hf] at he
  simpa only [extendStarValue_active] using he

noncomputable def jointHeadTerm (C E : ℝ) (ν : ℝ) : ℝ :=
  ν * E + (1 - ν) * max C E

theorem jointHeadTerm_identity (C E ν : ℝ) :
    jointHeadTerm C E ν = max C E - (max C E - E) * ν := by
  unfold jointHeadTerm
  ring

theorem exists_joint_gated_completion (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.ValidGadgets d)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (C A : d.StarIndex → ℝ) (D : ℝ) (hD : 0 < D) :
    ∃ (Z : (E ⊕ d.StarIndex) → ℝ) (p : GatedVertex d → ℤ),
      Z ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ a, gatedUpper d P a = none →
        p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)) ∧
      (∀ v, gatedHeadSelector d p v = 0 ∨ gatedHeadSelector d p v = 1) ∧
      edgeSum Z (nonremovableRepresentatives d.stars) =
        ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 ∧
      (∑ i : d.StarIndex,
        max (C i + 3 * D * (Z (Sum.inr i) - gatedArmBase d i.1))
          (A i + 3 * D * ((d.stars i).card - 1 -
            edgeSum Z (starRepresentatives d.stars i) - gatedArmBase d i.1))) ≤
      (∑ i : d.StarIndex, jointHeadTerm (C i) (A i) (gatedHeadSelector d p i.1 : ℝ)) +
        2 * D * optionalDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
          (gatedLower d P) (gatedUpper d P) (fun v => (p v : ℝ)) := by
  let t₀ := fun i : d.StarIndex => (max (C i) (A i) - A i) / (2 * D)
  let t := extendStarValue d t₀
  have ht : ∀ v, 0 ≤ t v := by
    intro v
    dsimp [t, extendStarValue]
    split_ifs
    · exact div_nonneg (sub_nonneg.mpr (le_max_right _ _)) (by positivity)
    · exact le_rfl
  obtain ⟨f, p, hf, hb, hp, hdual⟩ := exists_augmented_gated_primal_dual d hs hc P t ht
  obtain ⟨Z, hZ, hZc, hZa, hZn⟩ := exists_convex_gated_arms d hs P hP owner ho t ht f hf hb
  refine ⟨Z, p, hZ, hp, gated_head_selector_binary d P p hp, hZn, ?_⟩
  have htvalue : ∀ i : d.StarIndex, 2 * D * t i.1 = max (C i) (A i) - A i := by
    intro i
    dsimp only [t]
    rw [extendStarValue_active]
    dsimp only [t₀]
    field_simp
  have hlocal : ∀ i : d.StarIndex,
      max (C i + 3 * D * (Z (Sum.inr i) - gatedArmBase d i.1))
        (A i + 3 * D * ((d.stars i).card - 1 -
          edgeSum Z (starRepresentatives d.stars i) - gatedArmBase d i.1)) ≤
      max (C i) (A i) + 2 * D * f (gatedPaidArc d i.1) := by
    intro i
    apply max_le
    · nlinarith [hZc i, le_max_left (C i) (A i)]
    · nlinarith [hZa i, htvalue i]
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hlocal i)
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum] at hsum
  have hn : ∀ a, 0 ≤ f a := fun a => (Nat.cast_nonneg _).trans (hb a).1
  have hpays : (∑ i : d.StarIndex, f (gatedPaidArc d i.1)) ≤
      ∑ v : d.tree.Child, f (gatedPaidArc d v) := by
    have he : (∑ i : d.StarIndex, f (gatedPaidArc d i.1)) =
        ∑ v ∈ Finset.univ.filter (fun v : d.tree.Child => (d.backGroup v).Nonempty),
          f (gatedPaidArc d v) :=
      (Finset.sum_subtype _ (by intro; simp) (fun v => f (gatedPaidArc d v))).symm
    rw [he]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun v _ _ => hn _)
  have hcorr : (∑ v : d.tree.Child, t v * (gatedHeadSelector d p v : ℝ)) =
      ∑ i : d.StarIndex, t₀ i * (gatedHeadSelector d p i.1 : ℝ) := by
    have he : (fun v => t v * (gatedHeadSelector d p v : ℝ)) =
        extendStarValue d (fun i => t₀ i * (gatedHeadSelector d p i.1 : ℝ)) := by
      funext v
      dsimp [t, extendStarValue]
      split_ifs <;> simp
    rw [he, sum_extendStarValue]
  have hshift := gated_augmented_dual_selector_shift d P t p hp
  rw [hdual, hcorr] at hshift
  have hterms : (∑ i : d.StarIndex, jointHeadTerm (C i) (A i) (gatedHeadSelector d p i.1 : ℝ)) =
      (∑ i : d.StarIndex, max (C i) (A i)) -
        2 * D * ∑ i : d.StarIndex, t₀ i * (gatedHeadSelector d p i.1 : ℝ) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    rw [jointHeadTerm_identity]
    have ht' : 2 * D * t₀ i = max (C i) (A i) - A i := by
      simpa only [t, extendStarValue_active] using htvalue i
    rw [← ht']
    ring
  rw [hterms]
  nlinarith

end TSP.Improvements20261105
