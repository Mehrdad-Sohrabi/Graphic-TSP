import TSP.Improvements20261105.GatedAtomArms

/-! Average the actual binary graph points, preserving their two linear
arms. The positive-part moment identity pays only the enlarged capacity. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedArmBase (v : d.tree.Child) : ℝ :=
  if d.tree.parent v = d.tree.root then 1 else 1 / 3

theorem gatedAtomPoint_separate_arms (P : GatePlan d) (hP : P.ValidGadgets d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ))) (i : d.StarIndex) :
    gatedAtomPoint d g (Sum.inr i) ≤ gatedArmBase d i.1 +
      (2 / 3) * (g (gatedPaidArc d i.1) : ℝ) ∧
    (d.stars i).card - 1 - edgeSum (gatedAtomPoint d g) (starRepresentatives d.stars i) ≤
      gatedArmBase d i.1 + (2 / 3) * ((g (gatedPaidArc d i.1) : ℝ) +
        gatedFreeExcess d (fun a => (g a : ℝ)) i.1) := by
  by_cases hi : d.tree.parent i.1 = d.tree.root
  · simp only [gatedArmBase, if_pos hi]
    refine ⟨?_, gatedAtomPoint_root_head d P hP g hg hb i hi⟩
    rw [gatedAtomPoint_root_connector d g i hi]
    exact le_add_of_nonneg_right (mul_nonneg (by norm_num) (Nat.cast_nonneg _))
  · simp only [gatedArmBase, if_neg hi]
    exact ⟨gatedAtomPoint_connector d P hP.tree g hg hb i hi,
      gatedAtomPoint_head d P hP.tree g hg hb i hi⟩

noncomputable def finitePointAverage {ι A : Type} [Fintype ι]
    (w : ι → ℝ) (z : ι → A → ℝ) (a : A) : ℝ := ∑ j, w j * z j a

theorem finitePointAverage_edgeSum {ι A : Type} [Fintype ι] [Fintype A]
    (w : ι → ℝ) (z : ι → A → ℝ) (S : Finset A) :
    edgeSum (finitePointAverage w z) S = ∑ j, w j * edgeSum (z j) S := by
  unfold edgeSum finitePointAverage
  rw [Finset.sum_comm]
  simp only [Finset.mul_sum]

theorem finite_average_affine {ι : Type} [Fintype ι]
    (w x : ι → ℝ) (hs : ∑ j, w j = 1) (a b : ℝ) :
    (∑ j, w j * (a + b * x j)) = a + b * ∑ j, w j * x j := by
  simp only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hs, one_mul]
  congr 1
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  ring

theorem finite_average_deficit {ι A : Type} [Fintype ι] [Fintype A]
    (w : ι → ℝ) (z : ι → A → ℝ) (hs : ∑ j, w j = 1) (S : Finset A) (a : ℝ) :
    (∑ j, w j * (a - edgeSum (z j) S)) = a - edgeSum (finitePointAverage w z) S := by
  simp only [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul, hs, one_mul,
    finitePointAverage_edgeSum]

theorem finitePointAverage_projected {ι : Type} [Fintype ι]
    (owner : E → Option d.StarIndex) (w : ι → ℝ) (z : ι → (E ⊕ d.StarIndex) → ℝ)
    (hw : ∀ j, 0 ≤ w j) (hs : ∑ j, w j = 1)
    (hz : ∀ j, z j ∈ projectedFrameworkTwo G d.centers owner) :
    finitePointAverage w z ∈ projectedFrameworkTwo G d.centers owner := by
  rw [projectedFrameworkTwo_eq_oddJoinPolytope] at hz ⊢
  have hh := (convex_convexHull ℝ _).finsum_mem hw
    (by simpa only [finsum_eq_sum_of_fintype] using hs) (fun j _ => hz j)
  have he : finitePointAverage w z = ∑ j, w j • z j := by
    funext a
    simp [finitePointAverage]
  rw [he]
  simpa only [finsum_eq_sum_of_fintype] using hh

theorem exists_convex_gated_arms (hs : G.IsSimple) (P : GatePlan d) (hP : P.ValidGadgets d)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f) :
    ∃ Z : (E ⊕ d.StarIndex) → ℝ,
      Z ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ i : d.StarIndex, Z (Sum.inr i) ≤ gatedArmBase d i.1 +
        (2 / 3) * f (gatedPaidArc d i.1)) ∧
      (∀ i : d.StarIndex, (d.stars i).card - 1 - edgeSum Z (starRepresentatives d.stars i) ≤
        gatedArmBase d i.1 + (2 / 3) * (f (gatedPaidArc d i.1) + t i.1)) ∧
      edgeSum Z (nonremovableRepresentatives d.stars) =
        ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 := by
  obtain ⟨ι, hi, w, g, hw, hsum, hgb, hbounds, hm, hk⟩ :=
    real_capacity_circulation_nat_mixture (gatedNetwork d P) (gatedLower d P)
      (gatedAugmentedUpper d P t) f hf hb
  have hloose : ∀ j, GatedLooseBounds d P (fun a => (g j a : ℝ)) :=
    fun j => gated_rounded_augmented_loose d P t (g j) (hbounds j)
  let z := fun j => gatedAtomPoint d (g j)
  let Z := finitePointAverage w z
  refine ⟨Z, finitePointAverage_projected d owner w z (fun j => (hw j).le) hsum
    (fun j => gatedAtomPoint_feasible d hs P hP owner ho (g j) (hgb j) (hloose j)), ?_, ?_, ?_⟩
  · intro i
    have hh := Finset.sum_le_sum (s := Finset.univ) (fun j _ =>
      mul_le_mul_of_nonneg_left (gatedAtomPoint_separate_arms d P hP (g j) (hgb j) (hloose j) i).1
        (hw j).le)
    rw [finite_average_affine w _ hsum, hm] at hh
    exact hh
  · intro i
    have hh := Finset.sum_le_sum (s := Finset.univ) (fun j _ =>
      mul_le_mul_of_nonneg_left (gatedAtomPoint_separate_arms d P hP (g j) (hgb j) (hloose j) i).2
        (hw j).le)
    rw [finite_average_deficit w z hsum, finite_average_affine w _ hsum] at hh
    have he : (∑ j, w j * ((g j (gatedPaidArc d i.1) : ℝ) +
        gatedFreeExcess d (fun a => (g j a : ℝ)) i.1)) =
        f (gatedPaidArc d i.1) + gatedFreeExcess d f i.1 := by
      simp only [mul_add, Finset.sum_add_distrib, hm, gatedFreeExcess]
      rw [hk]
    rw [he] at hh
    have hu := (hb (gatedFreeArc d i.1)).2 _ (gatedAugmentedUpper_free d P t i.1)
    have hex : gatedFreeExcess d f i.1 ≤ t i.1 :=
      max_le (by linarith) (ht i.1)
    exact hh.trans (by linarith)
  · change edgeSum (finitePointAverage w z) _ = _
    rw [finitePointAverage_edgeSum]
    have hz : ∀ j, edgeSum (z j) (nonremovableRepresentatives d.stars) =
        ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 :=
      fun j => gatedAtomPoint_nonremovable_sum d P hP.tree (g j) (hgb j) (hloose j)
    simp only [hz, ← Finset.sum_mul, hsum, one_mul]

end TSP.Improvements20261105
