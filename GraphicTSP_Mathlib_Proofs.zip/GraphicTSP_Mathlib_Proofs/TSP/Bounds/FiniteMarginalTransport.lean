import TSP.Chapter02.FiniteCoupling

/-! Finite marginal transport identities, including events and arbitrary
functions of one local choice. No measure-theoretic assumptions are used. -/
namespace TSP.Improvements20261105
open Classical
open scoped BigOperators
variable {I J : Type} [Fintype I] [Fintype J] [DecidableEq J]

theorem weighted_function_transport (w : I → ℝ) (v : J → ℝ) (choice : I → J)
    (hm : ∀ j, ∑ i, w i * (if choice i = j then 1 else 0) = v j) (f : J → ℝ) :
    ∑ i, w i * f (choice i) = ∑ j, v j * f j := by
  have hlocal : ∀ i, w i * f (choice i) =
      ∑ j, (w i * (if choice i = j then 1 else 0)) * f j := by
    intro i
    rw [Finset.sum_eq_single (choice i)]
    · simp
    · intro j _ hj
      simp [Ne.symm hj]
    · simp
  simp_rw [hlocal]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  rw [← Finset.sum_mul, hm]

theorem product_left_weighted_sum (w : I → ℝ) (v : J → ℝ) (hv : ∑ j, v j = 1) (f : I → ℝ) :
    (∑ ij : I × J, (w ij.1 * v ij.2) * f ij.1) = ∑ i, w i * f i := by
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro i _
  calc
    _ = (w i * f i) * ∑ j, v j := by rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro j _; ring
    _ = w i * f i := by rw [hv, mul_one]

theorem product_right_weighted_sum (w : I → ℝ) (v : J → ℝ) (hw : ∑ i, w i = 1) (f : J → ℝ) :
    (∑ ij : I × J, (w ij.1 * v ij.2) * f ij.2) = ∑ j, v j * f j := by
  rw [Fintype.sum_prod_type, Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  calc
    _ = (∑ i, w i) * (v j * f j) := by rw [Finset.sum_mul]; apply Finset.sum_congr rfl; intro i _; ring
    _ = v j * f j := by rw [hw, one_mul]

theorem weighted_sum_eq_on_positive (w : I → ℝ) (hw : ∀ i, 0 ≤ w i) (f g : I → ℝ)
    (hfg : ∀ i, 0 < w i → f i = g i) : ∑ i, w i * f i = ∑ i, w i * g i := by
  apply Finset.sum_congr rfl
  intro i _
  by_cases hi : w i = 0
  · simp [hi]
  · rw [hfg i (lt_of_le_of_ne (hw i) (Ne.symm hi))]

end TSP.Improvements20261105
