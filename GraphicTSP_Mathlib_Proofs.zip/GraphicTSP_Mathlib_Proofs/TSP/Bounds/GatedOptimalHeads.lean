import TSP.Improvements20261105.GatedNoRepresentativeDrop

/-! At an optimal augmented dual, a selected head saturates its free arc
and carries no reverse flow. Inactive DFS groups therefore cannot be selected. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem normalizeGatedFree_reverse (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    normalizeGatedFree d P f (gatedReverseArc d v) = f (gatedReverseArc d v) := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow]

theorem gated_loose_head_balance (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : GatedLooseBounds d P f) (v : d.tree.Child) :
    (∑ b ∈ d.backGroup v, gatedBackVector d f b) + f (gatedReverseArc d v) =
      f (gatedFreeArc d v) + f (gatedPaidArc d v) + f (gatedBypassArc d v) := by
  obtain ⟨hn, hnb⟩ := gated_loose_normalized d P f hf hb
  have hh := gated_head_balance d P hP _ hn hnb v
  simp only [normalizeGatedFree_backVector, normalizeGatedFree_reverse,
    normalizeGatedFree_free, normalizeGatedFree_paid, normalizeGatedFree_bypass] at hh
  linarith

theorem gated_selected_head_flow (P : GatePlan d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (he : realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
        ∑ v : d.tree.Child, f (gatedPaidArc d v))
    (v : d.tree.Child) (hv : gatedHeadSelector d p v = 1) :
    f (gatedReverseArc d v) = 0 ∧ f (gatedFreeArc d v) = (gatedFreeBase d v : ℝ) + t v := by
  have hc := gated_optimal_complementary d P t f hf hb p hp he
  have hn : ∀ a, 0 ≤ f a := fun a => (Nat.cast_nonneg _).trans (hb a).1
  dsimp [gatedHeadSelector] at hv
  constructor
  · apply le_antisymm _ (hn _)
    by_contra hpos
    have hlow : (gatedLower d P (gatedReverseArc d v) : ℝ) < f (gatedReverseArc d v) := by
      simpa [gatedLower] using lt_of_not_ge hpos
    have hh := hc.2 _ hlow
    simp [gatedCost, gatedNetwork, gatedExtraSrc, gatedExtraDst] at hh
    omega
  · apply le_antisymm ((hb _).2 _ (gatedAugmentedUpper_free d P t v))
    by_contra hlt
    have hh := hc.1 _ _ (gatedAugmentedUpper_free d P t v) (lt_of_not_ge hlt)
    simp [gatedCost, gatedNetwork, gatedExtraSrc, gatedExtraDst] at hh
    omega

theorem gated_optimal_inactive_head_zero (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (he : realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
        ∑ v : d.tree.Child, f (gatedPaidArc d v))
    (v : d.tree.Child) (hv : ¬(d.backGroup v).Nonempty) : gatedHeadSelector d p v = 0 := by
  by_contra hz
  have hsel := (gated_head_selector_binary d P p hp v).resolve_left hz
  obtain ⟨hr, hfree⟩ := gated_selected_head_flow d P t f hf hb p hp he v hsel
  have hbal := gated_loose_head_balance d P hP f hf (gated_augmented_loose d P t f hb) v
  rw [Finset.not_nonempty_iff_eq_empty.mp hv] at hbal
  simp only [Finset.sum_empty, zero_add, hr, hfree] at hbal
  have hbase : (1 : ℝ) ≤ gatedFreeBase d v := by
    unfold gatedFreeBase
    split_ifs <;> norm_num
  have hn : ∀ a, 0 ≤ f a := fun a => (Nat.cast_nonneg _).trans (hb a).1
  linarith [ht v, hn (gatedPaidArc d v), hn (gatedBypassArc d v)]

end TSP.Improvements20261105
