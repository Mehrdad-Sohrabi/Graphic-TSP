import TSP.Improvements20261105.OptionalCirculationDual

/-! A feasible nonnegative circulation with integral lower bounds admits a
coordinatewise smaller feasible circulation bounded by the total lower demand.
This supplies compactness even when some original arcs have no upper bound. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem circulation_cut_balance (N : Graph V E) (f : E → ℝ) (hf : Balanced N f)
    (S : V → Prop) [DecidablePred S] :
    (∑ e, if S (N.src e) ∧ ¬S (N.dst e) then f e else 0) =
      ∑ e, if ¬S (N.src e) ∧ S (N.dst e) then f e else 0 := by
  have hh := balanced_potential_sum N f hf (fun v => if S v then (1 : ℝ) else 0)
  have he : (∑ e, f e * ((if S (N.dst e) then (1 : ℝ) else 0) -
      (if S (N.src e) then 1 else 0))) =
      (∑ e, if ¬S (N.src e) ∧ S (N.dst e) then f e else 0) -
        ∑ e, if S (N.src e) ∧ ¬S (N.dst e) then f e else 0 := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro e _
    by_cases hs : S (N.src e) <;> by_cases hd : S (N.dst e) <;> simp [hs, hd]
  change (∑ e, f e * ((if S (N.dst e) then (1 : ℝ) else 0) -
    (if S (N.src e) then 1 else 0))) = 0 at hh
  rw [he] at hh
  linarith

theorem positive_potential_bounds_flow (N : Graph V E) (lower f : E → ℝ)
    (hl : ∀ e, 0 ≤ lower e) (hb : ∀ e, lower e ≤ f e) (hf : Balanced N f)
    (p : V → ℤ) (hp : ∀ e, lower e < f e → p (N.src e) < p (N.dst e)) :
    ∀ e, f e ≤ ∑ a, lower a := by
  classical
  intro e
  by_cases he : lower e = f e
  · rw [← he]
    exact Finset.single_le_sum (fun a _ => hl a) (Finset.mem_univ e)
  · have he' : lower e < f e := lt_of_le_of_ne (hb e) he
    have hpe := hp e he'
    let S : V → Prop := fun v => p v ≤ p (N.src e)
    have hc := circulation_cut_balance N f hf S
    have hecross : S (N.src e) ∧ ¬S (N.dst e) := ⟨le_rfl, not_le.mpr hpe⟩
    have ho : f e ≤ ∑ a, if S (N.src a) ∧ ¬S (N.dst a) then f a else 0 := by
      have hh := Finset.single_le_sum (s := Finset.univ) (a := e)
        (f := fun a => if S (N.src a) ∧ ¬S (N.dst a) then f a else 0)
        (by intro a _; dsimp only; split_ifs; exact (hl a).trans (hb a); exact le_rfl)
        (Finset.mem_univ e)
      simpa only [if_pos hecross] using hh
    have ho' := ho.trans (le_of_eq hc)
    apply ho'.trans
    apply Finset.sum_le_sum
    intro a _
    by_cases ha : ¬S (N.src a) ∧ S (N.dst a)
    · rw [if_pos ha]
      by_contra hgt
      have hpa := hp a (lt_of_not_ge hgt)
      dsimp [S] at ha
      omega
    · rw [if_neg ha]
      exact hl a

theorem nat_circulation_dominated_bounded (N : Graph V E) (lower g : E → ℕ)
    (hg : Balanced N (fun e => (g e : ℝ))) (hl : ∀ e, lower e ≤ g e) :
    ∃ h : E → ℕ, Balanced N (fun e => (h e : ℝ)) ∧
      (∀ e, lower e ≤ h e ∧ h e ≤ g e ∧ h e ≤ ∑ a, lower a) := by
  have hfeas : ∃ f : E → ℝ, Balanced N f ∧ OptionalFlowBounds lower (fun e => some (g e)) f := by
    refine ⟨fun e => (g e : ℝ), hg, ?_⟩
    intro e
    refine ⟨by dsimp only; exact_mod_cast hl e, ?_⟩
    intro u hu
    have he : g e = u := Option.some.inj hu
    simp [he]
  obtain ⟨h, hh, hb, ho⟩ := exists_minimum_integral_circulation N (fun _ => 1) lower
    (fun e => some (g e)) hfeas
  have hbox : ∀ e, (lower e : ℝ) ≤ (h e : ℝ) ∧ (h e : ℝ) ≤ g e :=
    fun e => ⟨(hb e).1, (hb e).2 (g e) rfl⟩
  have hopt : ∀ f : E → ℝ, Balanced N f →
      (∀ e, (lower e : ℝ) ≤ f e ∧ f e ≤ g e) →
      (∑ e, ((1 : ℤ) : ℝ) * (h e : ℝ)) ≤ ∑ e, ((1 : ℤ) : ℝ) * f e := by
    intro f hf hfb
    apply ho f hf
    intro e
    refine ⟨(hfb e).1, ?_⟩
    intro u hu
    have he := Option.some.inj hu
    simpa [← he] using (hfb e).2
  obtain ⟨p, _, hp⟩ := optimal_circulation_complementary_potential N (fun _ => 1)
    (fun e => (lower e : ℝ)) (fun e => (g e : ℝ)) (fun e => (h e : ℝ)) hh hbox hopt
  have hbound := positive_potential_bounds_flow N (fun e => (lower e : ℝ))
    (fun e => (h e : ℝ)) (fun _ => Nat.cast_nonneg _) (fun e => (hb e).1) hh p
    (by intro e he; have hh' := hp e he; omega)
  have hbound' : ∀ e, h e ≤ ∑ a, lower a := by
    intro e
    have hh' := hbound e
    dsimp only at hh'
    exact_mod_cast hh'
  exact ⟨h, hh, fun e => ⟨by exact_mod_cast (hbox e).1,
    by exact_mod_cast (hbox e).2, hbound' e⟩⟩

theorem real_circulation_dominated_bounded (N : Graph V E) (lower : E → ℕ)
    (f : E → ℝ) (hf : Balanced N f) (hl : ∀ e, (lower e : ℝ) ≤ f e) :
    ∃ h : E → ℝ, Balanced N h ∧
      ∀ e, (lower e : ℝ) ≤ h e ∧ h e ≤ f e ∧ h e ≤ (∑ a, lower a : ℕ) := by
  obtain ⟨ι, hi, w, g, hw, hsum, hgb, hbounds, hm⟩ := bounded_circulation_nat_mixture N f
    lower (fun e => ⌈f e⌉₊) hf (fun e => ⟨hl e, Nat.le_ceil (f e)⟩)
  choose h hh hhb using fun i => nat_circulation_dominated_bounded N lower (g i)
    (hgb i) (fun e => (hbounds i e).1)
  let H : E → ℝ := fun e => ∑ i, w i * (h i e : ℝ)
  have hH : Balanced N H := by
    intro v
    change arcSum N.src (routeFlow (fun i e => (h i e : ℝ)) w) v =
      arcSum N.dst (routeFlow (fun i e => (h i e : ℝ)) w) v
    rw [arcSum_routeFlow, arcSum_routeFlow]
    apply Finset.sum_congr rfl
    intro i _
    rw [hh i v]
  refine ⟨H, hH, ?_⟩
  intro e
  have hlo : (∑ i, w i * (lower e : ℝ)) ≤ H e :=
    Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
      (by exact_mod_cast (hhb i e).1) (hw i).le)
  have hhi : H e ≤ ∑ i, w i * (g i e : ℝ) :=
    Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
      (by exact_mod_cast (hhb i e).2.1) (hw i).le)
  have hcap : H e ≤ ∑ i, w i * ((∑ a, lower a : ℕ) : ℝ) :=
    Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
      (by exact_mod_cast (hhb i e).2.2) (hw i).le)
  simp only [← Finset.sum_mul, hsum, one_mul] at hlo hcap
  rw [hm] at hhi
  exact ⟨hlo, hhi, hcap⟩

end TSP.Improvements20261105
