import TSP.Improvements20261105.GatedCoverage

/-! Tail, outside-head and receiving-gate conservation. These equations
ensure that a positive bypass has the selected back-edge witnesses required
by the simultaneous binary cut proof. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

@[simp] theorem bypassSource_ne_tail (P : GatePlan d) (s : d.tree.Child) (v : V) :
    gatedBypassSource d P s ≠ gatedTail d v := by
  unfold gatedBypassSource
  split_ifs <;> simp

@[simp] theorem bypassTarget_tail_iff (P : GatePlan d) (s : d.tree.Child) (v : V) :
    gatedBypassTarget d P s = gatedTail d v ↔
      (P.kind s = .disabled ∨ P.kind s = .outgoing) ∧ (s : V) = v := by
  cases hk : P.kind s <;> simp [gatedBypassTarget, hk]

@[simp] theorem bypassSource_gate_ne (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassSource d P s ≠ gatedGate d v := by
  unfold gatedBypassSource
  split_ifs <;> simp

@[simp] theorem bypassTarget_gate_iff (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassTarget d P s = gatedGate d v ↔
      P.kind s = .outsideGate ∧ P.receiver s = v := by
  cases hk : P.kind s <;> simp [gatedBypassTarget, hk]

@[simp] theorem bypassSource_outside_iff (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassSource d P s = gatedOutside d v ↔ P.kind s = .outsideGate ∧ s = v := by
  unfold gatedBypassSource
  by_cases hh : P.kind s = .outsideGate <;> simp [hh]

@[simp] theorem bypassTarget_ne_outside (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassTarget d P s ≠ gatedOutside d v := by
  cases hk : P.kind s <;> simp [gatedBypassTarget, hk]

noncomputable def gatedTailInput (P : GatePlan d) (f : GatedArc d → ℝ) (v : V) : ℝ :=
  ∑ s : d.tree.Child, if (s : V) = v then
    (if P.kind s = .disabled ∨ P.kind s = .outgoing then f (gatedBypassArc d s) else 0) +
      f (gatedExitTailArc d s) else 0

noncomputable def gatedGateInput (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) : ℝ :=
  ∑ s : d.tree.Child, if P.receiver s = v then
    (if P.kind s = .outsideGate then f (gatedBypassArc d s) else 0) +
      (if P.kind s = .sharedGate then f (gatedExitGateArc d s) else 0) else 0

noncomputable def gatedOutsideInput (P : GatePlan d) (f : GatedArc d → ℝ)
    (v : d.tree.Child) : ℝ :=
  ∑ b : BackEdge d, if d.anchor b.1 = v ∧ P.OutsideBack d b then f (gatedBackArc d b) else 0

theorem gated_balance_tail (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) (v : V) :
    (∑ b : BackEdge d, if d.lower b.1 = v then f (gatedBackArc d b) else 0) =
      f (gatedTailArc d v) + gatedTailInput d P f v := by
  have hh := hf (gatedTail d v)
  simp [arcSum, gatedNetwork, gatedExtraSrc, gatedExtraDst, Fintype.sum_sum_type,
    Fintype.sum_prod_type, Fin.sum_univ_succ, ite_eq_iff, ite_and,
    Finset.sum_add_distrib, add_assoc] at hh
  have hi : gatedTailInput d P f v =
      (∑ s : d.tree.Child, if P.kind s = .disabled ∨ P.kind s = .outgoing then
        if (s : V) = v then f (gatedBypassArc d s) else 0 else 0) +
      ∑ s : d.tree.Child, if (s : V) = v then f (gatedExitTailArc d s) else 0 := by
    unfold gatedTailInput
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro s _
    split_ifs <;> simp_all
  rw [hi]
  exact hh

theorem gated_balance_gate (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) (v : d.tree.Child) :
    f (gatedSuffixArc d v) = f (gatedPrefixArc d v) +
      (if P.IsReceiver d v then f (gatedPaidArc d v) else 0) + gatedGateInput d P f v := by
  have hh := hf (gatedGate d v)
  simp [arcSum, gatedNetwork, gatedExtraSrc, gatedExtraDst, Fintype.sum_sum_type,
    Fintype.sum_prod_type, Fin.sum_univ_succ, ite_eq_iff, ite_and,
    Finset.sum_add_distrib, add_assoc] at hh
  have hp : (∑ s : d.tree.Child, if P.IsReceiver d s then
      if s = v then f (gatedPaidArc d s) else 0 else 0) =
      if P.IsReceiver d v then f (gatedPaidArc d v) else 0 := by
    rw [Finset.sum_eq_single v]
    · simp
    · intro s _ hs; simp [hs]
    · simp
  rw [hp] at hh
  have hi : gatedGateInput d P f v =
      (∑ s : d.tree.Child, if P.kind s = .outsideGate then
        if P.receiver s = v then f (gatedBypassArc d s) else 0 else 0) +
      ∑ s : d.tree.Child, if P.kind s = .sharedGate then
        if P.receiver s = v then f (gatedExitGateArc d s) else 0 else 0 := by
    unfold gatedGateInput
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro s _
    split_ifs <;> simp_all
  rw [hi]
  simpa only [add_assoc] using hh

theorem gated_balance_outside (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) (v : d.tree.Child) :
    f (gatedFeedArc d v) + (if P.kind v = .outsideGate then f (gatedBypassArc d v) else 0) =
      gatedOutsideInput d P f v := by
  have hh := hf (gatedOutside d v)
  simp [arcSum, gatedNetwork, gatedExtraSrc, gatedExtraDst, Fintype.sum_sum_type,
    Fintype.sum_prod_type, Fin.sum_univ_succ, ite_eq_iff, ite_and,
    Finset.sum_add_distrib, add_assoc] at hh
  have hp : (∑ s : d.tree.Child, if P.kind s = .outsideGate then
      if s = v then f (gatedBypassArc d s) else 0 else 0) =
      if P.kind v = .outsideGate then f (gatedBypassArc d v) else 0 := by
    rw [Finset.sum_eq_single v]
    · simp
    · intro s _ hs; simp [hs]
    · simp
  rw [hp] at hh
  simpa [gatedOutsideInput, ite_and, and_comm, add_comm] using hh

theorem gated_gate_input_le_foreign (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.IsReceiver d v) :
    gatedGateInput d P f v ≤ ∑ b ∈ deletedSubtreeCut d v, gatedBackVector d f b := by
  have hg := gated_balance_gate d P f hf v
  rw [if_pos hv, gated_foreign_coverage d P hP f hf v] at hg
  have hp := gated_nonnegative d P f hb (gatedPrefixArc d v)
  linarith

end TSP.Improvements20261105
