import TSP.Improvements20261105.AllocatedLeafHeads
import TSP.Improvements20261105.KLeafDisjoint
import TSP.Improvements20261105.MatchingLeafDisjoint
import TSP.Improvements20261105.LargeRemainingLeafOwners
import TSP.Improvements20261105.SolePairLeafDisjoint
import TSP.Improvements20261105.OneExtraBackLeafDisjoint
import TSP.Improvements20261105.TwoBackSingleLeafDisjoint
import TSP.Improvements20261105.TwoOneBackLeafDisjoint
import TSP.Improvements20261105.NoPairLeafOwners

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.allocatedLeafHeads_sum (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P)) (g : d.StarIndex → ℝ) :
    (∑ i ∈ a.allocatedLeafHeads d P x z C, g i)=
      (∑ i ∈ a.paidLeafHeads d P x, g i)+
      (∑ i ∈ pairStarHeads d (a.KLeafPairs d P x z C), g i)+
      (∑ i ∈ pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.largeRemainingLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.solePairLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.oneExtraBackLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackSingleLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackTwoHeadLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.noPairLeafRoots d P x z C), g i) := by
  have hd0 := a.KLeafHeads_disjoint_paid d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd1 := a.multiplePairHeads_disjoint_prior d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd2 := a.largeRemainingLeafHeads_disjoint d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd3 := a.solePairLeafHeads_disjoint d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd4 := a.oneExtraBackLeafHeads_disjoint d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd5 := a.twoBackSingleLeafHeads_disjoint d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd6 := a.twoBackTwoHeadLeafHeads_disjoint_prior d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd7 := a.noPairLeafHeads_disjoint_prior d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hd6single := a.componentStarUnion_disjoint d P _ _ (a.twoBackTwoHeadLeafRoots_disjoint_single d P x z C)
  have hd6all := Finset.disjoint_union_right.mpr ⟨hd6,hd6single⟩
  rw [allocatedLeafHeads,Finset.sum_union hd7.symm,Finset.sum_union hd6all.symm,Finset.sum_union hd5.symm,Finset.sum_union hd4.symm,Finset.sum_union hd3.symm,Finset.sum_union hd2.symm,Finset.sum_union hd1.symm,Finset.sum_union hd0.symm]

end TSP.Improvements20261105
