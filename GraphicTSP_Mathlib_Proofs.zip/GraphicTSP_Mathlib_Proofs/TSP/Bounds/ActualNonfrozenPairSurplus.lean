import TSP.Improvements20261105.NonfrozenPairCost
import TSP.Improvements20261105.ActualPairTent

/-! Actual nonfrozen matching pairs, in the actual scored DFS and
simultaneous guarded construction, pay their source-complement fee
and retain the surplus 61/5 using their original source back count. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_nonfrozen_pair_leaf_surplus
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum x ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i j : (d).StarIndex) (hi : i.1 ∈ C.matching) (hj : j.1 = unaryNext d i.1)
    (hnot : ¬HSourceFrozen d x z C i.1) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)+
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)-
      (415/2 : ℝ)*(fixedProjectionCharge d x (allFullOverrideTargets d x) i.1+
        fixedProjectionCharge d x (allFullOverrideTargets d x) j.1)+24*(1-x ((d).treeEdge i.1)-survivingExcess d x i.1)+(61/5) ≤
      4*(((d).backGroup i.1).card+1 : ℝ) := by
  have hcost := current_nonfrozen_pair_cost d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero i j hi hj hnot
  have hpos := (Finset.mem_filter.mp (C.link_subset hi)).2.2.1
  have htent := scoredDFS_source_leaf_surplus G x hs hc root hx hn hcap i.1 hpos
  linarith only [hcost,htent]

end TSP.Improvements20261105
