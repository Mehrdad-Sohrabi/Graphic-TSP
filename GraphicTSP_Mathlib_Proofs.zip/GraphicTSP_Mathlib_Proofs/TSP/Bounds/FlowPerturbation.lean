import TSP.Improvements20261105.CirculationDual

/-! A common positive step in a finite flow box, and the no-negative-
direction consequence of actual minimum-cost optimality. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem finite_positive_lower_bound (b : E → ℝ) (hb : ∀ e, 0 < b e) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ e, ε ≤ b e := by
  classical
  let S := insert (1 : ℝ) (Finset.univ.image b)
  have hS : S.Nonempty := Finset.insert_nonempty _ _
  refine ⟨S.min' hS, ?_, ?_⟩
  · have hm := Finset.min'_mem S hS
    rcases Finset.mem_insert.mp hm with hm | hm
    · rw [hm]; norm_num
    · obtain ⟨e, _, heq⟩ := Finset.mem_image.mp hm
      rw [← heq]
      exact hb e
  · intro e
    exact Finset.min'_le _ _ (Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨e, Finset.mem_univ _, rfl⟩))

theorem finite_box_direction_step (lower upper f d : E → ℝ)
    (hbox : ∀ e, lower e ≤ f e ∧ f e ≤ upper e)
    (hlow : ∀ e, f e = lower e → 0 ≤ d e)
    (hup : ∀ e, f e = upper e → d e ≤ 0) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ e, lower e ≤ f e + ε * d e ∧ f e + ε * d e ≤ upper e := by
  classical
  let b : E → ℝ := fun e => if 0 < d e then (upper e - f e) / (d e + 1)
    else if d e < 0 then (f e - lower e) / (1 - d e) else 1
  have hb : ∀ e, 0 < b e := by
    intro e
    dsimp [b]
    split_ifs with hp hn
    · apply div_pos _ (by linarith)
      have hf : f e < upper e := lt_of_le_of_ne (hbox e).2
        (fun heq => (not_lt_of_ge (hup e heq)) hp)
      linarith
    · apply div_pos _ (by linarith)
      have hf : lower e < f e := lt_of_le_of_ne (hbox e).1
        (fun heq => (not_lt_of_ge (hlow e heq.symm)) hn)
      linarith
    · norm_num
  obtain ⟨ε, hε, hεb⟩ := finite_positive_lower_bound b hb
  refine ⟨ε, hε, ?_⟩
  intro e
  have hh := hεb e
  dsimp [b] at hh
  by_cases hp : 0 < d e
  · rw [if_pos hp] at hh
    have hmul := (le_div_iff₀ (by linarith : 0 < d e + 1)).mp hh
    constructor <;> nlinarith [(hbox e).1]
  · rw [if_neg hp] at hh
    by_cases hn : d e < 0
    · rw [if_pos hn] at hh
      have hmul := (le_div_iff₀ (by linarith : 0 < 1 - d e)).mp hh
      constructor <;> nlinarith [(hbox e).2]
    · have hz : d e = 0 := by linarith
      simpa [hz] using hbox e

theorem arcSum_smul (endpoint : E → V) (a : ℝ) (f : E → ℝ) (v : V) :
    arcSum endpoint (fun e => a * f e) v = a * arcSum endpoint f v := by
  unfold arcSum
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e _
  split_ifs <;> simp

theorem balanced_add_smul (N : Graph V E) (f d : E → ℝ)
    (hf : Balanced N f) (hd : Balanced N d) (a : ℝ) :
    Balanced N (fun e => f e + a * d e) := by
  intro v
  rw [arcSum_add, arcSum_add, arcSum_smul, arcSum_smul, hf v, hd v]

theorem optimal_flow_direction_nonnegative (N : Graph V E) (c lower upper f : E → ℝ)
    (hf : Balanced N f) (hbox : ∀ e, lower e ≤ f e ∧ f e ≤ upper e)
    (hopt : ∀ g : E → ℝ, Balanced N g → (∀ e, lower e ≤ g e ∧ g e ≤ upper e) →
      (∑ e, c e * f e) ≤ ∑ e, c e * g e)
    (d : E → ℝ) (hd : Balanced N d)
    (hlow : ∀ e, f e = lower e → 0 ≤ d e)
    (hup : ∀ e, f e = upper e → d e ≤ 0) : 0 ≤ ∑ e, c e * d e := by
  obtain ⟨ε, hε, hb⟩ := finite_box_direction_step lower upper f d hbox hlow hup
  have hh := hopt (fun e => f e + ε * d e) (balanced_add_smul N f d hf hd ε) hb
  have heq : (∑ e, c e * (f e + ε * d e)) =
      (∑ e, c e * f e) + ε * ∑ e, c e * d e := by
    rw [Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro e _
    ring
  rw [heq] at hh
  have hh' : 0 ≤ ε * ∑ e, c e * d e := by linarith
  by_contra hneg
  have hs : (∑ e, c e * d e) < 0 := lt_of_not_ge hneg
  have hm := mul_neg_of_pos_of_neg hε hs
  linarith

end TSP.Improvements20261105
