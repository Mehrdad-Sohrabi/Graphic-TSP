import TSP.Improvements20261105.KStarPairOwners
import TSP.Improvements20261105.PaidLeafOwners

/-! Whole leaves containing a protected unmatched pair are selected
from the actual canonical components. Multiple pairs in one leaf retain
disjoint head budgets, while its leaf charge is counted only once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.KLeafPairs (P : GatePlan d) (a : GatedDrops d) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) : Finset (d.StarIndex × d.StarIndex) :=
  (KUnmatchedStarPairs d x z C).filter (fun p => a.headComponent d P p.1.1 ∈ a.headfulLeafComponents d P)

noncomputable def GatedDrops.KLeafRoots (P : GatePlan d) (a : GatedDrops d) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) : Finset (FlowVertex d) :=
  (a.KLeafPairs d P x z C).image (fun p => a.component d P (.inr p.1.1))

theorem GatedDrops.KLeafPairs_subset (P : GatePlan d) (a : GatedDrops d) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    a.KLeafPairs d P x z C ⊆ KUnmatchedStarPairs d x z C := Finset.filter_subset _ _

theorem GatedDrops.KLeafRoots_card (P : GatePlan d) (a : GatedDrops d) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    (a.KLeafRoots d P x z C).card ≤ (a.KLeafPairs d P x z C).card := Finset.card_image_le

theorem GatedDrops.KLeafRoots_headful_subset (P : GatePlan d) (a : GatedDrops d) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    a.KLeafRoots d P x z C ⊆ (a.headfulLeafComponents d P).image
      (fun r : a.Component d P => (r : FlowVertex d)) := by
  intro r hr
  obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hr
  exact Finset.mem_image.mpr ⟨a.headComponent d P p.1.1,(Finset.mem_filter.mp hp).2,rfl⟩

theorem GatedDrops.paidLeafHeads_eq_starUnion (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    a.paidLeafHeads d P x = a.componentStarUnion d P (a.paidLeafRoots d P x) := by
  rw [paidLeafHeads,← a.positiveTerminalLeafStars d P x]
  ext i
  simp only [paidLeafRoots,componentStarUnion,Finset.mem_union,Finset.mem_biUnion]
  constructor
  · rintro (⟨r,hr,hi⟩ | ⟨r,hr,hi⟩)
    · exact ⟨r,Or.inl hr,hi⟩
    · exact ⟨r,Or.inr hr,hi⟩
  · rintro ⟨r,hr,hi⟩
    rcases hr with hz | hp
    · exact Or.inl ⟨r,hz,hi⟩
    · exact Or.inr ⟨r,hp,hi⟩

theorem KStarPair_same_component (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (p : d.StarIndex × d.StarIndex) (hp : p ∈ KUnmatchedStarPairs d x z C) :
    a.component d P (.inr p.1.1) = a.component d P (.inr p.2.1) := by
  have hh := (Finset.mem_filter.mp hp).2
  have he := KUnmatchedOrigins_same_component d hs x z hx hn (415/2) (704/5) 60 C
    P hP t ht f hf hb a ha hcan p.1.1 hh.1
  rw [hh.2] at he
  exact congrArg Subtype.val he

theorem KStarPair_component_not_paid (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (p : d.StarIndex × d.StarIndex) (hp : p ∈ KUnmatchedStarPairs d x z C) :
    a.component d P (.inr p.1.1) ∉ a.paidLeafRoots d P x := by
  intro hpaid
  have hsame := KStarPair_same_component d hs x z hx hn C P hP t ht f hf hb a ha hcan p hp
  rcases Finset.mem_union.mp hpaid with hz | hpos
  · have hzero := (a.zeroLeafRoot_spec d P x _ hz).2.2.2.2 p.1.1
      (Finset.mem_filter.mpr ⟨Finset.mem_univ _,p.1.2,rfl⟩)
    have hprotected := KUnmatchedOrigins_protected d x z (415/2) (704/5) 60 C p.1.1
      (Finset.mem_filter.mp hp).2.1
    have hpositive := (lt_max_iff.mp hprotected.2.1).resolve_right (lt_irrefl _)
    have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent p.1.1)
    linarith
  · obtain ⟨i,hi,he⟩ := Finset.mem_image.mp hpos
    have hh := Finset.mem_filter.mp hi
    have hsingle := a.headfree_entry_component_singleton d P i (Finset.mem_filter.mp hh.1).2.1
      (a.connector_entry_marker d P i.1 hh.2.1)
    have hfirst : p.1 ∈ a.actualComponentStars d P (.inr i.1) :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,he.symm⟩
    have hsecond : p.2 ∈ a.actualComponentStars d P (.inr i.1) :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,hsame.symm.trans he.symm⟩
    rw [hsingle,Finset.mem_singleton] at hfirst hsecond
    exact KUnmatchedStarPairs_ne d hs x z hx hn hcap hm C p hp (hfirst.trans hsecond.symm)

end TSP.Improvements20261105
