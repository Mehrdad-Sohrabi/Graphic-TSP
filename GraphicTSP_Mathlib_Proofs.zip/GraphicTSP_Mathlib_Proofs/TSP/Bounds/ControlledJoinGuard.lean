import TSP.Improvements20261105.ControlledEventThinning
import TSP.Improvements20261105.CyclePairLoss

/-! A feasible cycle guard with a controlled two-edge star cost. The cap
is obtained by thinning only atoms containing the representative. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Classical
open scoped BigOperators symmDiff
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

 theorem JoinMixture.controlled_guard {G : Graph V E} {T : Finset V}
    (M : JoinMixture G T) (C N : Finset E) (e : E)
    (hC : ∀ v, Even (G.intDegree C v)) (hNC : N ⊆ C)
    (q k f : ℝ) (hk : 0 ≤ k) (hf : 0 ≤ f) (hf1 : f ≤ 1)
    (he : M.point e ≤ q/2) :
    ∃ (R : JoinMixture G T) (m : ℝ),
      0 ≤ m ∧ f * max (M.eventMass N - max (q-k) 0/2) 0 ≤ m ∧
      (∀ a ∉ C, R.point a = M.point a) ∧
      (∀ a ∈ N, R.point a = M.point a - m) ∧
      (∀ (S : Finset E) (a : E), e ≠ a → S ∩ C = {e,a} →
        edgeSum M.point S - edgeSum R.point S ≤ f*k) ∧
      (∀ S : Finset E, edgeSum M.point S - edgeSum R.point S ≤ ((S ∩ C).card : ℝ)*m) ∧
      (∀ S : Finset E, Disjoint S C → R.eventMass S = M.eventMass S) := by
  let A : Finset M.Index := Finset.univ.filter (fun i => N ⊆ M.atoms i)
  let B : Finset M.Index := A.filter (fun i => e ∈ M.atoms i)
  have hBA : B ⊆ A := Finset.filter_subset _ _
  have hbad : (∑ i ∈ B, M.weights i) ≤ q/2 := by
    apply le_trans ?_ he
    calc
      _ = ∑ i ∈ B, M.weights i * incidence (M.atoms i) e := by
        apply Finset.sum_congr rfl
        intro i hi
        simp [incidence, (Finset.mem_filter.mp hi).2]
      _ ≤ M.point e := by
        apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
        intro i _ _
        have hwi := M.nonnegative i
        simp only [incidence]
        split_ifs <;> positivity
  obtain ⟨r, hr, hoff, _, hcap, hmass⟩ :=
    controlled_event_thinning M.weights A B hBA M.nonnegative q k hk hbad
  have hscaled : ∀ i, 0 ≤ f*r i ∧ f*r i ≤ M.weights i := by
    intro i
    refine ⟨mul_nonneg hf (hr i).1, ?_⟩
    calc
      f*r i ≤ 1*r i := mul_le_mul_of_nonneg_right hf1 (hr i).1
      _ ≤ M.weights i := by simpa using (hr i).2
  have hselected : ∀ i, f*r i ≠ 0 → N ⊆ M.atoms i := by
    intro i hi
    by_contra hn
    have hz := hoff i (by simpa only [A, Finset.mem_filter, Finset.mem_univ, true_and] using hn)
    exact hi (by rw [hz, mul_zero])
  have hmarked : (∑ i, r i * incidence (M.atoms i) e) = ∑ i ∈ B, r i := by
    calc
      _ = ∑ i ∈ A, r i * incidence (M.atoms i) e := by
        symm
        apply Finset.sum_subset (Finset.subset_univ _)
        intro i _ hi
        rw [hoff i hi, zero_mul]
      _ = _ := by
        conv_rhs => rw [Finset.sum_filter]
        apply Finset.sum_congr rfl
        intro i _
        by_cases hi : e ∈ M.atoms i <;> simp [incidence, hi]
  let m := ∑ i, f*r i
  have hm0 : 0 ≤ m := Finset.sum_nonneg (fun i _ => (hscaled i).1)
  have hlower : f * max (M.eventMass N - max (q-k) 0/2) 0 ≤ m := by
    have hr0 : 0 ≤ ∑ i, r i := Finset.sum_nonneg (fun i _ => (hr i).1)
    have hevent : M.eventMass N = ∑ i ∈ A, M.weights i := M.eventMass_filter N
    have hm := mul_le_mul_of_nonneg_left (max_le (hevent ▸ hmass) hr0) hf
    simpa only [m, Finset.mul_sum] using hm
  refine ⟨M.thin C hC (fun i => f*r i) hscaled, m, hm0, hlower, ?_, ?_, ?_, ?_, ?_⟩
  · intro a ha
    rw [M.thin_point, thinnedCyclePoint_outside _ _ _ _ a ha]
    rfl
  · intro a ha
    rw [M.thin_point, thinnedCyclePoint_selected _ _ _ _ a (hNC ha)
      (fun i hi => hselected i hi ha)]
    rfl
  · intro S a hea hSC
    rw [M.thin_point]
    have hh := thinnedCyclePoint_pair_loss M.weights M.atoms C S (fun i => f*r i)
      (fun i => (hscaled i).1) e a hea hSC
    have hs : (∑ i, f*r i*incidence (M.atoms i) e) = f*∑ i ∈ B, r i := by
      simp only [mul_assoc, ← Finset.mul_sum, hmarked]
    rw [hs] at hh
    have hc := mul_le_mul_of_nonneg_left hcap hf
    change edgeSum M.point S - edgeSum (thinnedCyclePoint M.weights M.atoms C (fun i => f*r i)) S ≤ _ at hh
    linarith
  · intro S
    rw [M.thin_point]
    exact thinnedCyclePoint_set_loss M.weights M.atoms C S (fun i => f*r i) (fun i => (hscaled i).1)
  · intro S hS
    exact M.thin_preserves_event C hC (fun i => f*r i) hscaled S hS

end TSP.Improvements20261105
