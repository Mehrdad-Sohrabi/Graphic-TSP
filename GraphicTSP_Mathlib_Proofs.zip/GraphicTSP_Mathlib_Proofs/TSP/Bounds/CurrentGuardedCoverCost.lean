import TSP.Improvements20261105.CurrentGuardedDeficits
import TSP.Improvements20261105.PositiveTerminalOwnFee
import TSP.Improvements20261105.TerminalForcedConnectors

/-! Every nonroot head of the actual simultaneous construction retains
its fixed cover bound in the signed P/Q arm. Actual-zero and erased-positive
heads are proved by different valid inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem currentIncomingForceCharge_nonnegative (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (i : d.StarIndex) :
    0 ≤ currentIncomingForceCharge d x z C i := by
  unfold currentIncomingForceCharge
  split_ifs with hnr hu
  · have hge := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
      (fixedHForceTargets d x z (415/2) (704/5) C) ⟨d.centers i,hnr⟩
    exact mul_nonneg (by norm_num) (sub_nonneg.mpr hge)
  · exact le_rfl
  · exact le_rfl

theorem current_guarded_max_cover (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1+currentIncomingForceCharge d x z C i := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  have hH := fixedHForceTargets_subset d x z (415/2) (704/5) C
  have hT : ∀ s ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d s := by
    intro c hc
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hc
    exact (Finset.mem_filter.mp hj).2.1
  have hir : i ≠ rootStar := fun he => hnr (he ▸ hroot)
  have hforce := currentIncomingForceCharge_nonnegative d hs x z hx hn hcap hm C i
  have hd := current_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar Y R hY
    hrep hbacks hloss hterminal hzero i hnr
  have hconn : pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        C.cover i.1+currentIncomingForceCharge d x z C i := by
    by_cases hu : childCount d (d.centers i) = 1
    · let v : d.tree.Child := ⟨d.centers i,hnr⟩
      have hc := terminal_forcedPQ_connector_unary d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
        (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) C H hH (fixedPositiveTerminalChildren d x) hT owner ho rootStar R hR
        i hir v rfl hu
      simpa only [currentIncomingForceCharge,dif_pos hnr,if_pos hu] using hc
    · have hcount : 0 < childCount d (d.centers i) := by
        apply Finset.card_pos.mpr
        exact ⟨i.1,Finset.mem_filter.mpr ⟨Finset.mem_univ _,rfl⟩⟩
      have hc := terminal_forcedPQ_connector_many d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
        (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) C H hH (fixedPositiveTerminalChildren d x) hT owner ho rootStar R hR
        i hir (by omega)
      simpa only [currentIncomingForceCharge,dif_pos hnr,if_neg hu,add_zero] using hc
  apply (sub_le_iff_le_add).mpr
  apply max_le <;> linarith

end TSP.Improvements20261105
