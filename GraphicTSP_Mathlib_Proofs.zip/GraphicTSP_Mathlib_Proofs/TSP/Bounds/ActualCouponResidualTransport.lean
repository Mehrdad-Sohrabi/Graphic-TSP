import TSP.Improvements20261105.KStarPairOwners
import TSP.Improvements20261105.UnaryCouponGeometry

/-! Actual positive outgoing residuals have unique headed receivers.
Both endpoint maps are injective, and the sums are transported without
charging any receiver twice. No assertion about receiver payment is assumed. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def actualCouponResidual (x z : E → ℝ) (i : d.StarIndex) : ℝ :=
  couponResidual d (fixedGatePlan d x) (fun e => x e.1) (projectedOutgoingCoupon d x z) i.1

noncomputable def couponResidualStarPairs (x z : E → ℝ) (H : Finset d.StarIndex) :
    Finset (d.StarIndex × d.StarIndex) :=
  Finset.univ.filter (fun p => p.1 ∈ H ∧ 0 < actualCouponResidual d x z p.1 ∧
    d.tree.parent (p.2.1 : V) = (p.1.1 : V))

theorem actualCouponResidual_nonnegative (x z : E → ℝ) (i : d.StarIndex) :
    0 ≤ actualCouponResidual d x z i := by
  unfold actualCouponResidual couponResidual
  split_ifs
  · exact le_max_right _ _
  · exact le_rfl

theorem couponResidualStarPairs_fst_image (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (H : Finset d.StarIndex) :
    (couponResidualStarPairs d x z H).image Prod.fst =
      H.filter (fun i => 0 < actualCouponResidual d x z i) := by
  ext i
  constructor
  · intro hi
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hi
    have hh := (Finset.mem_filter.mp hp).2
    exact Finset.mem_filter.mpr ⟨hh.1,hh.2.1⟩
  · intro hi
    have hh := Finset.mem_filter.mp hi
    obtain ⟨u,hu,_⟩ := fixedGatePlan_positive_residual_receiver d hs x z hx hcap i.1 i.2 hh.2
    let j : d.StarIndex := ⟨u,hu.2.1⟩
    exact Finset.mem_image.mpr ⟨(i,j),Finset.mem_filter.mpr ⟨Finset.mem_univ _,hh.1,hh.2,hu.1⟩,rfl⟩

theorem couponResidualStarPairs_fst_injective (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (H : Finset d.StarIndex) :
    Set.InjOn Prod.fst (couponResidualStarPairs d x z H : Set (d.StarIndex × d.StarIndex)) := by
  intro p hp q hq he
  have hp' := (Finset.mem_filter.mp hp).2
  have hq' := (Finset.mem_filter.mp hq).2
  have hqpar : d.tree.parent (q.2.1 : V) = (p.1.1 : V) := by rw [hq'.2.2,he]
  have hpcount : childCount d p.1.1=1 := by
    have hk : (fixedGatePlan d x).kind p.1.1 = .outgoing := by
      by_contra hn
      have hpos := hp'.2.1
      simp [actualCouponResidual,couponResidual,hn] at hpos
    exact fixedGatePlan_active_outgoing_unary d hs x p.1.1 hk p.1.2
  have hnext := unique_child_of_count_one d p.1.1 hpcount
  obtain ⟨v,hv,honly⟩ := hnext
  apply Prod.ext he
  apply Subtype.ext
  exact (honly p.2.1 hp'.2.2).trans (honly q.2.1 hqpar).symm

theorem couponResidualStarPairs_snd_injective (x z : E → ℝ) (H : Finset d.StarIndex) :
    Set.InjOn Prod.snd (couponResidualStarPairs d x z H : Set (d.StarIndex × d.StarIndex)) := by
  intro p hp q hq he
  apply Prod.ext _ he
  apply Subtype.ext
  apply Subtype.ext
  have hp' := (Finset.mem_filter.mp hp).2.2.2
  have hq' := (Finset.mem_filter.mp hq).2.2.2
  rw [← hp',← hq',he]

theorem couponResidualStarPairs_receiver_shape (hs : G.IsSimple) (x z : E → ℝ)
    (H : Finset d.StarIndex) (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ couponResidualStarPairs d x z H) :
    d.centers p.2 ≠ d.tree.root ∧ Even (G.intDegree d.treeEdges (d.centers p.2)) ∧
      d.tree.depth (p.1.1 : V) < d.tree.depth (p.2.1 : V) := by
  have hp' := (Finset.mem_filter.mp hp).2
  have hk : (fixedGatePlan d x).kind p.1.1 = .outgoing := by
    by_contra hn
    have hpos := hp'.2.1
    simp [actualCouponResidual,couponResidual,hn] at hpos
  have hc := fixedGatePlan_active_outgoing_unary d hs x p.1.1 hk p.1.2
  have hd := tree_degree_eq d (p.1.1 : V)
  rw [if_neg p.1.1.2,hc] at hd
  have hdepth := d.tree.parent_depth (p.2.1 : V) p.2.1.2
  rw [hp'.2.2] at hdepth
  change d.tree.parent (p.2.1 : V) ≠ d.tree.root ∧
    Even (G.intDegree d.treeEdges (d.tree.parent (p.2.1 : V))) ∧ _
  rw [hp'.2.2,hd]
  exact ⟨p.1.1.2,by norm_num,by omega⟩

theorem couponResidualStarPairs_fee_bounds (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (H : Finset d.StarIndex) (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ couponResidualStarPairs d x z H) :
    actualCouponResidual d x z p.1 ≤ min (2-x (d.treeEdge p.2.1)-edgeSum z (d.backGroup p.2.1)) (1/2) ∧
    actualCouponResidual d x z p.1 ≤ max (x (d.treeEdge p.2.1)+edgeSum z (d.backGroup p.2.1)-1) 0 := by
  have hp' := (Finset.mem_filter.mp hp).2
  have hk : (fixedGatePlan d x).kind p.1.1 = .outgoing := by
    by_contra hn
    have hpos := hp'.2.1
    simp [actualCouponResidual,couponResidual,hn] at hpos
  have hc := fixedGatePlan_active_outgoing_unary d hs x p.1.1 hk p.1.2
  have hpos : 0 < max (projectedOutgoingCoupon d x z p.1.1-outgoingBackMass d x p.1.1) 0 := by
    simpa only [actualCouponResidual,couponResidual,if_pos hk,tailBackMass_original] using hp'.2.1
  have hbound := projected_residual_receiver_bounds d hs x z hx.1 p.1.1 p.2.1 hc hp'.2.2
    (projected_residual_positive_complement d x z p.1.1 hpos) hm
  simpa only [actualCouponResidual,couponResidual,if_pos hk,tailBackMass_original] using hbound

theorem actualCouponResidual_family_transport (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (H : Finset d.StarIndex) :
    (∑ i ∈ H, actualCouponResidual d x z i) ≤
      ∑ j ∈ (couponResidualStarPairs d x z H).image Prod.snd,
        min (2-x (d.treeEdge j.1)-edgeSum z (d.backGroup j.1)) (1/2) := by
  have he : (∑ i ∈ H.filter (fun i => 0 < actualCouponResidual d x z i), actualCouponResidual d x z i) =
      ∑ i ∈ H, actualCouponResidual d x z i := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro i hi
    by_cases hp : 0 < actualCouponResidual d x z i
    · rw [if_pos hp]
    · rw [if_neg hp]
      exact (le_antisymm (le_of_not_gt hp) (actualCouponResidual_nonnegative d x z i)).symm
  rw [← he,← couponResidualStarPairs_fst_image d hs x z hx hcap H]
  rw [Finset.sum_image (fun p hp q hq he => couponResidualStarPairs_fst_injective d hs x z hx hcap H hp hq he)]
  rw [Finset.sum_image (fun p hp q hq he => couponResidualStarPairs_snd_injective d x z H hp hq he)]
  exact Finset.sum_le_sum (fun p hp => (couponResidualStarPairs_fee_bounds d hs x z hx hcap hm H p hp).1)

theorem actualCouponResidual_family_mass_transport (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (H : Finset d.StarIndex) :
    (∑ i ∈ H, actualCouponResidual d x z i) ≤
      ∑ j ∈ (couponResidualStarPairs d x z H).image Prod.snd,
        max (x (d.treeEdge j.1)+edgeSum z (d.backGroup j.1)-1) 0 := by
  have he : (∑ i ∈ H.filter (fun i => 0 < actualCouponResidual d x z i), actualCouponResidual d x z i) =
      ∑ i ∈ H, actualCouponResidual d x z i := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro i hi
    by_cases hp : 0 < actualCouponResidual d x z i
    · rw [if_pos hp]
    · rw [if_neg hp]
      exact (le_antisymm (le_of_not_gt hp) (actualCouponResidual_nonnegative d x z i)).symm
  rw [← he,← couponResidualStarPairs_fst_image d hs x z hx hcap H]
  rw [Finset.sum_image (fun p hp q hq he => couponResidualStarPairs_fst_injective d hs x z hx hcap H hp hq he)]
  rw [Finset.sum_image (fun p hp q hq he => couponResidualStarPairs_snd_injective d x z H hp hq he)]
  exact Finset.sum_le_sum (fun p hp => (couponResidualStarPairs_fee_bounds d hs x z hx hcap hm H p hp).2)

end TSP.Improvements20261105
