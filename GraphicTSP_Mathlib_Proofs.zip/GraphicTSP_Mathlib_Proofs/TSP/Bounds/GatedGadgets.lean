import TSP.Improvements20261105.GatedPositiveEdges

/-! The fixed gadget hypotheses contain only original tree incidences and
whether a child has an own back edge. Positive flow then yields the previously
proved simultaneous-deletion witnesses. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

structure GatePlan.ValidGadgets (P : GatePlan d) : Prop where
  tree : P.RespectsTree d
  root : ∀ v : d.tree.Child, d.tree.parent v = d.tree.root → P.kind v = .disabled
  two : ∀ v, P.kind v = .twoDirections →
    ∃ c₁ c₂ : d.tree.Child, c₁ ≠ c₂ ∧ d.tree.parent c₁ = (v : V) ∧
      d.tree.parent c₂ = (v : V) ∧ ¬(d.backGroup c₁).Nonempty ∧ ¬(d.backGroup c₂).Nonempty
  shared : ∀ v, P.kind v = .sharedGate →
    ∃ c : d.tree.Child, c ≠ P.receiver v ∧ d.tree.parent c = (v : V) ∧ ¬(d.backGroup c).Nonempty

theorem gated_bypass_disabled (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.kind v = .disabled) : f (gatedBypassArc d v) = 0 := by
  have hh := (hb (gatedBypassArc d v)).2 0 (by simp [gatedUpper, hv])
  norm_num at hh
  exact le_antisymm hh (gated_nonnegative d P f hb _)

theorem gated_outgoing_witness (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.kind v = .outgoing) (hp : 0 < f (gatedBypassArc d v)) :
    OriginalBypassWitness d (gatedPositiveBacks d f) v := by
  apply outgoing_bypass_gadget
  apply gated_positive_tail_input d P f hf hb v
  have hh := gated_tail_term_le d P f hb v
  rw [if_pos (Or.inr hv)] at hh
  have he := gated_nonnegative d P f hb (gatedExitTailArc d v)
  linarith

theorem gated_shared_witness (P : GatePlan d) (hP : P.ValidGadgets d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.kind v = .sharedGate) (hp : 0 < f (gatedBypassArc d v)) :
    OriginalBypassWitness d (gatedPositiveBacks d f) v := by
  by_cases ht : 0 < f (gatedExitTailArc d v)
  · apply outgoing_bypass_gadget
    apply gated_positive_tail_input d P f hf hb v
    have hh := gated_tail_term_le d P f hb v
    have hd : ¬(P.kind v = .disabled ∨ P.kind v = .outgoing) := by simp [hv]
    rw [if_neg hd, zero_add] at hh
    exact ht.trans_le hh
  · have hbyp := gated_balance_collector d P f hf v
    rw [if_pos hv] at hbyp
    have hgate : 0 < f (gatedExitGateArc d v) := by linarith
    have hi := gated_gate_term_le d P f hb v
    have hn : P.kind v ≠ .outsideGate := by simp [hv]
    rw [if_neg hn, if_pos hv, zero_add] at hi
    have hcover := gated_positive_receiver_input d P hP.tree f hf hb (P.receiver v)
      ⟨v, Or.inl hv, rfl⟩ (hgate.trans_le hi)
    obtain ⟨c, hc, hpc, hnc⟩ := hP.shared v hv
    exact nonremovable_foreign_bypass_gadget d _ (gatedPositiveBacks_subset d f) v c (P.receiver v)
      hc hpc (hP.tree v (Or.inl hv)) hnc
      (gated_nonremovable_selected_cover d P hP.tree f hf hb c hnc) hcover

theorem gated_outside_witness (hs : G.IsSimple) (P : GatePlan d) (hP : P.ValidGadgets d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.kind v = .outsideGate) (hp : 0 < f (gatedBypassArc d v)) :
    OriginalBypassWitness d (gatedPositiveBacks d f) v := by
  have hi := gated_gate_term_le d P f hb v
  have hn : P.kind v ≠ .sharedGate := by simp [hv]
  rw [if_pos hv, if_neg hn, add_zero] at hi
  have hcover := gated_positive_receiver_input d P hP.tree f hf hb (P.receiver v)
    ⟨v, Or.inr hv, rfl⟩ (hp.trans_le hi)
  obtain ⟨b, hbsel, hbown, hbout⟩ := gated_positive_outside_back d P f hf hb v hv hp
  have hdesc := ((d.mem_backGroup_iff v b).mp hbown).2.2
  obtain ⟨c, hpc, hcb⟩ := d.tree.exists_child_below hdesc
    (Chapter10.backGroup_lower_ne_child d hs v hbown).symm
  have hne : c ≠ P.receiver v := by
    intro heq
    exact hbout (heq ▸ hcb)
  exact own_other_foreign_bypass_gadget d _ v c (P.receiver v) hne hpc
    (hP.tree v (Or.inr hv)) b hbsel hbown hcb hcover

theorem gated_positive_bypass_witness (hs : G.IsSimple) (P : GatePlan d) (hP : P.ValidGadgets d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hp : 0 < f (gatedBypassArc d v)) :
    OriginalBypassWitness d (gatedPositiveBacks d f) v := by
  cases hv : P.kind v with
  | disabled => rw [gated_bypass_disabled d P f hb v hv] at hp; exact (lt_irrefl _ hp).elim
  | outgoing => exact gated_outgoing_witness d P f hf hb v hv hp
  | twoDirections =>
    obtain ⟨c₁, c₂, hne, hp₁, hp₂, hn₁, hn₂⟩ := hP.two v hv
    exact two_nonremovable_bypass_gadget d _ (gatedPositiveBacks_subset d f) v c₁ c₂ hne hp₁ hp₂
      hn₁ hn₂ (gated_nonremovable_selected_cover d P hP.tree f hf hb c₁ hn₁)
      (gated_nonremovable_selected_cover d P hP.tree f hf hb c₂ hn₂)
  | sharedGate => exact gated_shared_witness d P hP f hf hb v hv hp
  | outsideGate => exact gated_outside_witness d hs P hP f hf hb v hv hp

end TSP.Improvements20261105
