import TSP.Improvements20261105.ScorePaymentArithmetic
import TSP.Improvements20261105.LeafBackOrder

/-! A designated last back and a mass pool pay one leaf. Projection
losses are charged once, to their actual tail. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph ScoredParameters Classical
open scoped BigOperators
variable {E : Type} [Fintype E] [DecidableEq E]

theorem mass_pool_payment (B : Finset E) (x z p : E → ℝ)
    (hx : 1 ≤ edgeSum x B) (hp : ∀ e ∈ B, p e = massSlope * z e) :
    1 ≤ edgeSum p B + massSlope * edgeSum (fun e => x e - z e) B := by
  have he : edgeSum p B = massSlope * edgeSum z B := by
    rw [edgeSum, Finset.sum_congr rfl hp, ← Finset.mul_sum]
    rfl
  have hd : edgeSum (fun e => x e - z e) B = edgeSum x B - edgeSum z B := Finset.sum_sub_distrib
  rw [he, hd]
  have hh := mul_le_mul_of_nonneg_left hx (show 0 ≤ massSlope by norm_num [massSlope])
  have hc := massSlope_ge_one
  nlinarith

theorem designated_leaf_payment (B S : Finset E) (hSB : S ⊆ B) (b : E) (hb : b ∈ S)
    (x z p : E → ℝ) (hx : ∀ e, 0 ≤ x e) (hzx : ∀ e, z e ≤ x e)
    (hp : ∀ e ∈ B, 0 ≤ p e) (hmass : 1 ≤ edgeSum x B)
    (t : ℕ) (benchmark M : ℝ) (hM : M ≤ upper t) (hxb : x b ≤ M)
    (hdef : coefficient t * min (edgeSum x (S.erase b)) (1 - M) ≤ benchmark - x b)
    (hpaid : (localMassSlope t / coefficient t) * (benchmark - z b) ≤ p b)
    (hpool : ∀ e ∈ B \ S, p e = massSlope * z e) :
    1 ≤ edgeSum p B + massSlope * edgeSum (fun e => x e - z e) B := by
  let A := edgeSum x (S.erase b)
  let N := edgeSum x (B \ S)
  have hN : 0 ≤ N := Finset.sum_nonneg (fun e _ => hx e)
  have hsplit : edgeSum x B = A + x b + N := by
    have hs := Finset.sum_sdiff (f := x) hSB
    have he := Finset.sum_erase_add S x hb
    change N + edgeSum x S = edgeSum x B at hs
    change A + x b = edgeSum x S at he
    linarith
  have hcover : 1 - M ≤ A + N := by linarith
  have hlast := last_score_payment_cover t (hzx b) hN hM hcover hdef
  have hpB : p b + edgeSum p (B \ S) ≤ edgeSum p B := by
    have hs := Finset.sum_sdiff (f := p) hSB
    have he := Finset.single_le_sum (s := S) (fun e he => hp e (hSB he)) hb
    change edgeSum p (B \ S) + edgeSum p S = edgeSum p B at hs
    change p b ≤ edgeSum p S at he
    linarith
  have hpoolEq : edgeSum p (B \ S) = massSlope * edgeSum z (B \ S) := by
    rw [edgeSum, Finset.sum_congr rfl hpool, ← Finset.mul_sum]
    rfl
  have hdelta : edgeSum (fun e => x e - z e) (B \ S) ≤ edgeSum (fun e => x e - z e) B :=
    Finset.sum_le_sum_of_subset_of_nonneg Finset.sdiff_subset (fun e _ _ => sub_nonneg.mpr (hzx e))
  have hdeltaEq : edgeSum (fun e => x e - z e) (B \ S) = N - edgeSum z (B \ S) :=
    Finset.sum_sub_distrib
  rw [hdeltaEq] at hdelta
  have hdelta' := mul_le_mul_of_nonneg_left hdelta (show 0 ≤ massSlope by norm_num [massSlope])
  rw [hpoolEq] at hpB
  linarith

end TSP.Improvements20261105
