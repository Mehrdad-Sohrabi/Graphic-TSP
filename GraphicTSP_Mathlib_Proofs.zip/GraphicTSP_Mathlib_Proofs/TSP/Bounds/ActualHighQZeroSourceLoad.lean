import TSP.Improvements20261105.ActualHighQEffectiveSource
import TSP.Improvements20261105.EffectiveSourceCoupon

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem actual_high_q_zero_source_load
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (rootStar : (d).StarIndex)
    (Y : E ⊕ (d).StarIndex → ℝ) (i : (d).StarIndex)
    (hY : ((d).stars i).card-1-edgeSum Y (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
      -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hprotected : ProtectedHead d x z (415/2) (704/5) C i.1)
    (hq : 1/2 ≤ x ((d).treeEdge i.1)) (ho : outgoingBackMass d x i.1 ≤ survivingExcess d x i.1)
    (hu : childCount d i.1=1) (eligible R : Finset (d).tree.Child) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) R
        (projectedOutgoingCoupon d x z) i.1-
      48*(1-x ((d).treeEdge i.1)-outgoingBackMass d x i.1) ≤
        4*((((d).backGroup i.1).card : ℝ)) := by
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  have hpos : 1 < edgeSum z ((d).backGroup i.1) := by
    have hp := hprotected.2.1
    rw [← he] at hp
    have hh := (lt_max_iff.mp hp).resolve_right (lt_irrefl _)
    linarith
  have hb := effective_source_load d x z (fixedCriticalHeads d x z eligible) R i.1
    hprotected.1 hu hq hpos (ho.trans (survivingExcess_bounds d hs hx hcap i.1).2)
  have hh := actual_high_q_effective_source G x z hs hc root hx hn hcap hz hzx hm C
    owner rootStar Y i hY hprotected hq ho eligible R
  rw [hb]
  linarith only [hh]

end TSP.Improvements20261105
