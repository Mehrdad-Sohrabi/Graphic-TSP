import TSP.Improvements20261105.GreedyPackedOldRows

/-! Continuous greedy packing envelopes. No numerical grid is used. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000

noncomputable def greedyOldEnvelope (q a : ℝ) (k : ℕ) : ℝ :=
  if q ≤ 1/4 then 0 else packedOldRamp q a k

noncomputable def greedyMuEnvelope (q a : ℝ) (k : ℕ) : ℝ :=
  if q ≤ 9/38 then 0 else
    max ((k : ℝ)*((19/10)*q-9/20)+max ((19/10)*(a-k*q)-9/20) 0-1/10) 0

theorem greedy_ordinary_five_packed_new (q a : ℝ) (k : ℕ)
    (hk : k<5) (hq0 : 0 ≤ q) (hqh : q ≤ 1/2) (ha : 1 ≤ a)
    (hpack : a+q ≤ 2) (hlo : (k : ℝ)*q ≤ a) (hhi : a ≤ ((k : ℝ)+1)*q)
    (hgate : q ≤ 41/150 ∨ 211/500 ≤ q ∨ q+a ≤ 2-9/100) :
    24*(a-1)+(360/19)*greedyMuEnvelope q a k+
      (96/19)*((100/57)*a-1)-84*q ≤ 20 := by
  rcases hgate with hg | hg | hg <;>
    interval_cases k <;>
    norm_num only [greedyMuEnvelope,Nat.cast_ofNat,Nat.cast_zero,zero_mul] at * <;>
    simp only [max_def] <;>
    split_ifs <;> linarith

end TSP.Improvements20261105
