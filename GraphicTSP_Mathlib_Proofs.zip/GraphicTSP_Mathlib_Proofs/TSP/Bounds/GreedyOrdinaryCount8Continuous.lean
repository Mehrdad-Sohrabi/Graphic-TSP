import TSP.Improvements20261105.GreedyFinitePackingScalar

/-! Continuous real-weight packing bound. The proof exhausts integer packing
indices and exact max/min branches; no sampled points or solver assumptions. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000

theorem greedy_ordinary_8_continuous_new (q a : ℝ) (k : ℕ)
    (hk : k<8) (hq0 : 0 ≤ q) (hqh : q ≤ 1/2) (ha : 1 ≤ a)
    (hpack : a+q ≤ 2) (hlo : (k : ℝ)*q ≤ a) (hhi : a ≤ ((k : ℝ)+1)*q)
    (hgate : q ≤ 73/450 ∨ 43/125 ≤ q ∨ q+a ≤ 2-9/100)
    : 24*(a-1)+(360/19)*greedyMuEnvelope q a k+
      (96/19)*((100/57)*a-1)-84*q ≤ 32 := by
  rcases hgate with hg | hg | hg <;>
    interval_cases k <;>
    norm_num only [greedyMuEnvelope,Nat.cast_ofNat,Nat.cast_zero,zero_mul] at * <;>
    simp only [max_def,min_def] <;>
    split_ifs <;> linarith

end TSP.Improvements20261105
