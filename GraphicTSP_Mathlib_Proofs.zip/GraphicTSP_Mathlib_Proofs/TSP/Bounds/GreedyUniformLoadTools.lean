import TSP.Improvements20261105.GreedyOrdinaryOldLoad
import TSP.Improvements20261105.GreedyFreePositiveLoad

/-! Uniform large-count and protected old-arm payments on actual edge sums. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem greedy_uncouponed_uniform_cap (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : 0 ≤ q) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hzq : ∀ e ∈ d.backGroup s, z e ≤ q)
    (hpack : edgeSum z (d.backGroup s)+q ≤ 2) :
    24*(edgeSum z (d.backGroup s)-1)+noncriticalIncidence d z s ≤ 56 := by
  have ho := greedy_ramp_mass_bound (d.backGroup s) z q (by linarith) hz hzq hpack
  have hn := greedy_signed_ramp_mass_bound (d.backGroup s) z q (by linarith) hz hzq hpack
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h3 := min_le_right (((d.backGroup s).card : ℝ)-1)
    (ScoredParameters.massSlope*edgeSum z (d.backGroup s)-1)
  unfold noncriticalIncidence
  rw [add_max]
  apply max_le
  · unfold oldIncidence
    unfold starIncidenceRamp edgeSum at h1 ⊢
    linarith
  · unfold mixedNoncriticalIncidence
    simp only [signedStarIncidence, starIncidenceRamp, edgeSum, ScoredParameters.massSlope] at h2 h3 hpack ⊢
    norm_num only at h2 h3 ⊢
    linarith

theorem greedy_protected_old_load (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : 0 ≤ q) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hcap : ∀ e ∈ d.backGroup s, z e ≤ q) (ha : 1 ≤ edgeSum z (d.backGroup s))
    (hpack : edgeSum z (d.backGroup s)+q ≤ 2) :
    24*(edgeSum z (d.backGroup s)-1)+24*oldIncidence d z s-(824/5)*q+
      24*min (2-q-edgeSum z (d.backGroup s)) (1/2) ≤ 4*(d.backGroup s).card := by
  let a := edgeSum z (d.backGroup s)
  let n : ℝ := (d.backGroup s).card
  have hcount : a ≤ n*q := by
    have hh := Finset.sum_le_sum hcap
    simpa [a,n,edgeSum] using hh
  have hquad := Finset.sum_le_sum (s := d.backGroup s)
    (fun e he => greedy_ramp_quadratic (z e) q (hz e he) (hcap e he))
  simp only [← Finset.mul_sum] at hquad
  have hr : starIncidenceRamp d (1/2) z s ≤ 2*q*a := hquad
  have hmin := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have hres := min_le_right (2-q-a) (1/2 : ℝ)
  have hprod := mul_le_mul_of_nonneg_left hpack hq
  have hbound : 24*(a-1)+24*oldIncidence d z s-(824/5)*q+
      24*min (2-q-a) (1/2) ≤ 36-(464/5)*q := by
    unfold oldIncidence
    change a+q ≤ 2 at hpack
    change q*(a+q) ≤ q*2 at hprod
    nlinarith only [hr,hmin,hres,hpack,hprod,sq_nonneg q]
  have hh := four_count_affine_bound n q 36 (464/5) (Nat.cast_nonneg _) hq
    (by norm_num) (by norm_num) (ha.trans hcount) (by norm_num)
  exact hbound.trans hh

end TSP.Improvements20261105
