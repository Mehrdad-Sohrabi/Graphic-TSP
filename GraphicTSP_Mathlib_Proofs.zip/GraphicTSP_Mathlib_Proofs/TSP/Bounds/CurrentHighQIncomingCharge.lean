import TSP.Improvements20261105.CurrentProjectedBranchSource

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_high_q_incoming_charge (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s : d.tree.Child) (j : d.StarIndex)
    (hl : s ∈ projectionLinks d x) (hu : s ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hp : d.centers j=(s:V)) (hq : 1/2 ≤ x (d.treeEdge s)) :
    currentIncomingForceCharge d x z C j ≤ 60*(1-x (d.treeEdge s)) := by
  have hnr : d.centers j ≠ d.tree.root := by rw [hp]; exact s.2
  have huc : childCount d (d.centers j)=1 := by rw [hp]; exact (Finset.mem_filter.mp hl).2.2.2.1
  have he : (⟨d.centers j,hnr⟩ : d.tree.Child)=s := Subtype.ext hp
  have hno : s ∉ fixedHForceTargets d x z (415/2) (704/5) C := by
    intro h
    exact hu (Finset.mem_union_right _ (fixedHForceTargets_subset d x z (415/2) (704/5) C h))
  rw [currentIncomingForceCharge,dif_pos hnr,if_pos huc,he,forcedCoverIncrease,if_neg hno]
  have hh := protectedCoverIncrease_change d hs x z hx hn hcap hm (415/2) (704/5) 60
    (by norm_num) (by norm_num) (by norm_num) C s
  rwa [min_eq_right (by linarith)] at hh

end TSP.Improvements20261105
