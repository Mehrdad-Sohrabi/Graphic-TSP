import Mathlib.Tactic

/-! The high-q source with a projected-small receiver needs only the
count arm for two backs and the universal high-q load for larger stars. -/
namespace TSP.Improvements20261105
set_option autoImplicit false

theorem high_q_zero_source_two_scalar (E q o r load : ℝ)
    (hE : E ≤ 1-q) (ho : 0 ≤ o)
    (hprotected : r ≤ -60*(1-q))
    (hintrinsic : r ≤ (415/2)*E-(704/5)*q-(3483/10)*o)
    (hload : load ≤ 24*E+24) :
    r+load-24*((1-q)+(1-q-o)) ≤ 0 := by
  linarith

theorem high_q_zero_source_large_scalar (E q o r load : ℝ)
    (hE : E ≤ 1-q) (ho : 0 ≤ o)
    (hprotected : r ≤ -60*(1-q))
    (hintrinsic : r ≤ (415/2)*E-(704/5)*q-(3483/10)*o)
    (hload : load ≤ 48+240/361) :
    r+load-24*((1-q)+(1-q-o)) ≤ 12 := by
  linarith

theorem high_q_zero_source_count_scalar (t : ℕ) (E q o r load : ℝ)
    (ht : 2 ≤ t) (hE : E ≤ 1-q) (ho : 0 ≤ o)
    (hprotected : r ≤ -60*(1-q))
    (hintrinsic : r ≤ (415/2)*E-(704/5)*q-(3483/10)*o)
    (hload : load ≤ 48+240/361) (hcount : load ≤ 24*E+24*((t:ℝ)-1)) :
    r+load-24*((1-q)+(1-q-o)) ≤ 4*(t:ℝ) := by
  by_cases ht2 : t=2
  · subst t
    norm_num at hcount ⊢
    have hh := high_q_zero_source_two_scalar E q o r load hE ho hprotected hintrinsic hcount
    linarith
  · have ht3 : 3 ≤ t := by omega
    have htR : (3:ℝ) ≤ t := by exact_mod_cast ht3
    have hh := high_q_zero_source_large_scalar E q o r load hE ho hprotected hintrinsic hload
    linarith

end TSP.Improvements20261105
