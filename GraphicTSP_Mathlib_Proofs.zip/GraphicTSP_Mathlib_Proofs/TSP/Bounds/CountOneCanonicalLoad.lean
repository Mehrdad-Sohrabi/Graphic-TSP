import TSP.Improvements20261105.ScoredUniformNetLoad
import TSP.Improvements20261105.NoncriticalCountLoad

/-! A head with one actual back edge has nonpositive canonical load,
including its residual coupon. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem count_one_canonical_load (x z : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (hcap : ∀ e, x e ≤ 1) (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (eligible T : Finset d.tree.Child) (s : d.tree.Child) (hcount : (d.backGroup s).card=1) :
    canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
      (projectedOutgoingCoupon d x z) s ≤ 0 := by
  have hinc := (refined_fixed_incidence_le_noncritical d x z eligible T s).trans
    (noncriticalIncidence_le_count d z s)
  rw [hcount] at hinc
  norm_num only [Nat.cast_one,sub_self,mul_zero] at hinc
  have hmass := Finset.sum_le_sum (s := d.backGroup s) (fun e _ => (hzx e).trans (hcap e))
  simp only [Finset.sum_const,hcount,one_smul] at hmass
  have hload := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun c => projectedOutgoingCoupon_nonneg d x z hx hcap hz c) s
  change edgeSum z (d.backGroup s) ≤ 1 at hmass
  linarith only [hload,hinc,hmass]

end TSP.Improvements20261105
