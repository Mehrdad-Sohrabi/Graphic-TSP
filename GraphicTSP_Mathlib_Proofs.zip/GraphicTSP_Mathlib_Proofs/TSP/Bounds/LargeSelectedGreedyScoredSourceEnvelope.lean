import TSP.Improvements20261105.ActualCriticalLinearEnvelope
import TSP.Improvements20261105.UniformRampLinearEnvelope

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem rawCriticalIncidence_uniform_score_at_cap (x z : E → ℝ) (s : d.tree.Child)
    (U B : ℝ) (hB0 : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20)
    (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e) (hcap : ∀ e ∈ d.backGroup s, z e ≤ U) :
    rawCriticalIncidence d x z s ≤
      (360/19)*(B*edgeSum z (d.backGroup s)-1/10)+
        (96/19)*(ScoredParameters.localMassSlope (d.backGroup s).card/ScoredParameters.coefficient (d.backGroup s).card)*
          (((d.backGroup s).card : ℝ)*winningBenchmark d x s-edgeSum z (d.backGroup s))-96/19 := by
  have hr := Finset.sum_le_sum (s := d.backGroup s) (fun e he =>
    incidenceRamp_linear_cap (9/20) U B (z e) hB0 (by linarith only [hBd])
      (by linarith only [hBU]) (hz e he) (hcap e he))
  have hp := Finset.sum_le_sum (s := d.backGroup s) (fun e _ =>
    ScoredParameters.perBackPayment_le_score_defect (d.backGroup s).card (winningBenchmark d x s) (z e))
  simp only [← Finset.mul_sum,Finset.sum_sub_distrib,Finset.sum_const,nsmul_eq_mul] at hr hp
  unfold rawCriticalIncidence signedStarIncidence starIncidenceRamp headScoreSum edgeSum
  linarith only [hr,hp]

end TSP.Improvements20261105
