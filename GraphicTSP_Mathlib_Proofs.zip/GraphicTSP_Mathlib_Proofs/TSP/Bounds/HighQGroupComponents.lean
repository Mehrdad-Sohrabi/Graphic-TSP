import TSP.Improvements20261105.HighQGroupShapes
import TSP.Improvements20261105.ProjectedCoverComponents
import TSP.Improvements20261105.ZeroLeafGlobalBudget

/-! A high-q group stays in one actual canonical component. If any of its
heads is selected, none of the group's back budgets belongs to a paid leaf. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (x z : E → ℝ) (hcap : ∀ e, x e ≤ 1)
variable (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
  fixedRemoval d x (allFullOverrideTargets d x) s)
variable (C : ProjectedCoverWitness d x z (415/2) (704/5))
variable (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
variable (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
variable (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
variable (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

include hs hcap hm hP ht hf hb ha hcan in
theorem canonical_highQGroup_same_component (i : d.StarIndex)
    (hi : HighQGroupOwner d x z C i.1) (u : d.tree.Child) (hu : u ∈ highQGroupChildren d x z C i.1) :
    a.headComponent d P i.1 = a.headComponent d P u := by
  have hij := canonical_active_unary_same_component d hs P hP t ht f hf hb a ha hcan i.1 (unaryNext d i.1)
    (Finset.mem_filter.mp hi.2.1).2.2.2.1 (projectionLinks_parent d x i.1 hi.2.1) i.2
  rcases (mem_highQGroupChildren d x z C i.1 u).mp hu with he | he | ⟨hj,he⟩
  · rw [he]
  · rw [he]
    exact hij
  · have hl := C.link_subset hj
    have hactive := projectionLink_receiver_head d hs x z hcap hm i.1 hi.2.1
    have hjk := canonical_active_unary_same_component d hs P hP t ht f hf hb a ha hcan
      (unaryNext d i.1) (unaryNext d (unaryNext d i.1))
      (Finset.mem_filter.mp hl).2.2.2.1 (projectionLinks_parent d x _ hl) hactive
    rw [he]
    exact hij.trans hjk

include hs hcap hm hP ht hf hb ha hcan in
theorem canonical_highQGroup_internal (hc : IsTwoVertexConnected G) (i : d.StarIndex)
    (hi : HighQGroupOwner d x z C i.1)
    (hsel : ∃ v ∈ highQGroupChildren d x z C i.1, a.head v=1)
    (u : d.tree.Child) (hu : u ∈ highQGroupChildren d x z C i.1) :
    a.headComponent d P u ∈ a.internalComponents d P := by
  obtain ⟨v,hv,hvsel⟩ := hsel
  have hiv := canonical_highQGroup_same_component d hs x z hcap hm C P hP t ht f hf hb a ha hcan i hi v hv
  have hiu := canonical_highQGroup_same_component d hs x z hcap hm C P hP t ht f hf hb a ha hcan i hi u hu
  rw [← hiu, hiv]
  exact canonical_selected_headComponent_internal d hs hc P hP t ht f hf hb a ha hcan v hvsel

include hs hcap hm hP ht hf hb ha hcan in
theorem canonical_highQGroup_disjoint_leaf_heads (hc : IsTwoVertexConnected G) (i : d.StarIndex)
    (hi : HighQGroupOwner d x z C i.1)
    (hsel : ∃ v ∈ highQGroupChildren d x z C i.1, a.head v=1)
    (L : Finset (FlowVertex d))
    (hL : L ⊆ (a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d))) :
    Disjoint (highQGroupStars d x z C i.1) (a.componentStarUnion d P L) := by
  apply Finset.disjoint_left.mpr
  intro j hj hleaf
  have hint := canonical_highQGroup_internal d hs x z hcap hm C P hP t ht f hf hb a ha hcan
    hc i hi hsel j.1 (Finset.mem_filter.mp hj).2
  obtain ⟨r,hr,hjr⟩ := Finset.mem_biUnion.mp hleaf
  obtain ⟨r₀,hr₀,rfl⟩ := Finset.mem_image.mp (hL hr)
  have heq : a.headComponent d P j.1=r₀ := Subtype.ext (Finset.mem_filter.mp hjr).2
  rw [heq] at hint
  exact (Finset.mem_filter.mp hr₀).2.1 (Finset.mem_filter.mp hint).2

include hs hcap hm hP ht hf hb ha hcan in
theorem canonical_highQGroup_disjoint_components (i : d.StarIndex)
    (hi : HighQGroupOwner d x z C i.1) (L : Finset (FlowVertex d))
    (hL : (a.headComponent d P i.1 : FlowVertex d) ∉ L) :
    Disjoint (highQGroupStars d x z C i.1) (a.componentStarUnion d P L) := by
  apply Finset.disjoint_left.mpr
  intro j hj hleaf
  obtain ⟨r,hr,hjr⟩ := Finset.mem_biUnion.mp hleaf
  have he := canonical_highQGroup_same_component d hs x z hcap hm C P hP t ht f hf hb a ha hcan
    i hi j.1 (Finset.mem_filter.mp hj).2
  have hjr' : (a.headComponent d P j.1 : FlowVertex d)=r := (Finset.mem_filter.mp hjr).2
  apply hL
  rw [he,hjr']
  exact hr

end TSP.Improvements20261105
