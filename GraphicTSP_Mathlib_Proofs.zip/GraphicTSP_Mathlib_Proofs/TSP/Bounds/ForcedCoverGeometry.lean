import TSP.Improvements20261105.MatchedTargetForces
import TSP.Improvements20261105.ProtectedCoverPayment

/-! The simultaneous K/H changes have disjoint origins. In particular,
no original matching source is altered by either force. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem fixed_matching_source_target_disjoint (x z : E → ℝ) (P Q : ℝ)
    (C : ProjectedCoverWitness d x z P Q) :
    Disjoint C.matching (C.matching.image (unaryNext d)) := by
  have hl (s : d.tree.Child) (hs : s ∈ C.matching) : id s ≠ unaryNext d s := by
    intro he
    have hp := projectionLinks_parent d x s (C.link_subset hs)
    have hd := d.tree.parent_depth (unaryNext d s) (unaryNext d s).2
    change s = unaryNext d s at he
    rw [hp, ← he] at hd
    omega
  simpa using (matching_endpoint_disjointness id (unaryNext d) C.matching hl C.matching_endpoints).2.2

theorem protectedCoverIncrease_endpoint (x z : E → ℝ) (P Q K : ℝ)
    (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child)
    (he : s ∈ matchingEndpoints id (unaryNext d) C.matching) :
    protectedCoverIncrease d x z P Q K C s = coveredPIncrease d x P Q C.cover s := by
  have hp : ¬ProtectedHead d x z P Q C s := fun h => h.2.2 he
  simp [protectedCoverIncrease, hp]

theorem forcedCoverIncrease_source (x z : E → ℝ) (P Q K D B : ℝ)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d)) (s : d.tree.Child) (hs : s ∈ C.matching) :
    forcedCoverIncrease d x z P Q K D B C H s = coveredPIncrease d x P Q C.cover s := by
  have hn : s ∉ H := fun h => Finset.disjoint_left.mp
    (fixed_matching_source_target_disjoint d x z P Q C) hs (hH h)
  rw [forcedCoverIncrease, if_neg hn]
  exact protectedCoverIncrease_endpoint d x z P Q K C s (by simp [matchingEndpoints, hs])

theorem forcedCoverIncrease_target (x z : E → ℝ) (P Q K D B : ℝ)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d)) (s : d.tree.Child) (hs : s ∈ H) :
    forcedCoverIncrease d x z P Q K D B C H s =
      max (coveredPIncrease d x P Q C.cover s) (targetForceThreshold d x P Q D B s) := by
  rw [forcedCoverIncrease, if_pos hs, protectedCoverIncrease_endpoint d x z P Q K C s]
  exact Finset.mem_union_right _ (hH hs)

theorem forcedCoverIncrease_root (x z : E → ℝ) (P Q K D B : ℝ)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d)) (s : d.tree.Child)
    (hr : d.tree.parent s = d.tree.root) : forcedCoverIncrease d x z P Q K D B C H s = 0 := by
  have hn : s ∉ H := by
    intro hh
    obtain ⟨u, hu, heu⟩ := Finset.mem_image.mp (hH hh)
    have hp := projectionLinks_parent d x u (C.link_subset hu)
    rw [heu, hr] at hp
    exact u.2 hp.symm
  have hp : ¬ProtectedHead d x z P Q C s := fun h => h.1 hr
  simp [forcedCoverIncrease, hn, protectedCoverIncrease, hp, coveredPIncrease, hr]

theorem forcedCoverIncrease_inactive (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K D B : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d)) (s : d.tree.Child)
    (ha : ¬(d.backGroup s).Nonempty) : forcedCoverIncrease d x z P Q K D B C H s = 0 := by
  have he := Finset.not_nonempty_iff_eq_empty.mp ha
  have hnH : s ∉ H := by
    intro hh
    have h := matched_target_available d hs x z hx hn hm P Q C s (hH hh)
    rw [he] at h
    simp only [edgeSum, Finset.sum_empty] at h
    have hc := hcap (d.treeEdge s)
    linarith
  have hp := protectedCoverIncrease_bounds d hs x z hx hn hcap hm P Q K hP hQ hK hKQ C s
  have hb := survivingExcess_le_original_back d x hx hn s
  rw [he] at hb
  simp only [edgeSum, Finset.sum_empty] at hb
  rw [forcedCoverIncrease, if_neg hnH]
  exact le_antisymm (hp.2.2.trans hb) hp.2.1

theorem forcedCoverIncrease_extension (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K D B : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d)) (s : d.tree.Child) :
    extendNonrootRepairs d (fun i => forcedCoverIncrease d x z P Q K D B C H i.1) s =
      forcedCoverIncrease d x z P Q K D B C H s := by
  by_cases ha : (d.backGroup s).Nonempty
  · by_cases hr : d.tree.parent s = d.tree.root
    · rw [extendNonrootRepairs_root d _ s hr, forcedCoverIncrease_root d x z P Q K D B C H hH s hr]
    · simp only [extendNonrootRepairs, dif_pos ha, if_neg hr]
  · rw [extendNonrootRepairs_inactive d _ s ha,
      forcedCoverIncrease_inactive d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H hH s ha]

theorem forcedCoverIncrease_ge_base (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K D B : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child) (s : d.tree.Child) :
    coveredPIncrease d x P Q C.cover s ≤ forcedCoverIncrease d x z P Q K D B C H s := by
  have hp := (protectedCoverIncrease_bounds d hs x z hx hn hcap hm P Q K hP hQ hK hKQ C s).1
  unfold forcedCoverIncrease
  split_ifs
  · exact hp.trans (le_max_left _ _)
  · exact hp

end TSP.Improvements20261105
