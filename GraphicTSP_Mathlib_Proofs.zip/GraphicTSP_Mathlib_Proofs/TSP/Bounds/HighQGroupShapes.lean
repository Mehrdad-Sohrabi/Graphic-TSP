import TSP.Improvements20261105.HighQGroupOwnership

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem highQGroupStars_pair (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (i j : d.StarIndex)
    (hj : j.1=unaryNext d i.1) (hn : j.1 ∉ C.matching) :
    highQGroupStars d x z C i.1 = {i,j} := by
  ext u
  simp only [highQGroupStars, Finset.mem_filter, Finset.mem_univ, true_and,
    mem_highQGroupChildren, ← hj, hn, false_and, or_false,
    Finset.mem_insert, Finset.mem_singleton, Subtype.ext_iff]

theorem highQGroupStars_triple (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (i j k : d.StarIndex)
    (hj : j.1=unaryNext d i.1) (hk : k.1=unaryNext d j.1) (hm : j.1 ∈ C.matching) :
    highQGroupStars d x z C i.1 = {i,j,k} := by
  ext u
  simp only [highQGroupStars, Finset.mem_filter, Finset.mem_univ, true_and,
    mem_highQGroupChildren, ← hj, ← hk, hm, true_and,
    Finset.mem_insert, Finset.mem_singleton, Subtype.ext_iff]

theorem projectionLink_ne_next (x : E → ℝ) (s : d.tree.Child)
    (hl : s ∈ projectionLinks d x) : s≠unaryNext d s := by
  have hp := projectionLinks_parent d x s hl
  have hd := d.tree.parent_depth (unaryNext d s) (unaryNext d s).2
  rw [hp] at hd
  intro he
  rw [← he] at hd
  omega

theorem highQGroupStars_pair_distinct (x : E → ℝ) (i j : d.StarIndex)
    (hl : i.1 ∈ projectionLinks d x) (hj : j.1=unaryNext d i.1) : i≠j := by
  intro he
  have hv := congrArg Subtype.val he
  exact projectionLink_ne_next d x i.1 hl (hv.trans hj)

theorem highQGroupStars_triple_distinct (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (i j k : d.StarIndex)
    (hl : i.1 ∈ projectionLinks d x) (hj : j.1=unaryNext d i.1)
    (hk : k.1=unaryNext d j.1) (hm : j.1 ∈ C.matching) :
    i≠j ∧ i≠k ∧ j≠k := by
  refine ⟨highQGroupStars_pair_distinct d x i j hl hj, ?_,
    highQGroupStars_pair_distinct d x j k (C.link_subset hm) hk⟩
  have hpj : d.tree.parent j.1=(i.1 : V) := by rw [hj]; exact projectionLinks_parent d x i.1 hl
  have hpk : d.tree.parent k.1=(j.1 : V) := by rw [hk]; exact projectionLinks_parent d x j.1 (C.link_subset hm)
  have hdj := d.tree.parent_depth j.1 j.1.2
  have hdk := d.tree.parent_depth k.1 k.1.2
  rw [hpj] at hdj
  rw [hpk] at hdk
  intro he
  subst k
  omega

end TSP.Improvements20261105
