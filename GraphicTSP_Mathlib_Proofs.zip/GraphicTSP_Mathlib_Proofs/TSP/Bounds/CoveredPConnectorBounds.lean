import TSP.Improvements20261105.CoveredPExport

/-! Connector estimates for the actual feasible P point, with the single
shared projection reserve removed explicitly. -/
namespace TSP.Improvements20261105
open Graph Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem coveredP_connector_many (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner) (rootStar : d.StarIndex)
    (i : d.StarIndex) (hi : i ≠ rootStar) (hc : 2 ≤ childCount d (d.centers i)) :
    (3 / 2 : ℝ) * (generalPoint d owner rootStar x (fun j => coveredPIncrease d x P Q C.cover j.1) (.inr i) - 1 / 3) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := by
  have hp := enlarged_connector_many_children d hs owner ho rootStar x hx hcap _
    (coveredPIncrease_admissible d hs x z hx hn hcap hm P Q hP hQ C) i hi hc
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  linarith

theorem coveredP_connector_unary (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner) (rootStar : d.StarIndex)
    (i : d.StarIndex) (hi : i ≠ rootStar) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hc : childCount d v = 1) :
    (3 / 2 : ℝ) * (generalPoint d owner rootStar x (fun j => coveredPIncrease d x P Q C.cover j.1) (.inr i) - 1 / 3) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
      max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 := by
  have hp := enlarged_connector_one_child d hs owner ho rootStar x hx hcap _
    (coveredPIncrease_admissible d hs x z hx hn hcap hm P Q hP hQ C) i hi v hv hc
  rw [coveredPIncrease_extension d hs x z hx hn hcap hm P Q hP hQ C v] at hp
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  have h0 : 0 ≤ fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 :=
    (tau_nonneg _ _).trans ht
  have he0 : 0 ≤ max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 := le_max_right _ _
  have hmax : max (starTau d x i) (max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
      max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 :=
    max_le (ht.trans (le_add_of_nonneg_right he0)) (le_add_of_nonneg_left h0)
  linarith

end TSP.Improvements20261105
