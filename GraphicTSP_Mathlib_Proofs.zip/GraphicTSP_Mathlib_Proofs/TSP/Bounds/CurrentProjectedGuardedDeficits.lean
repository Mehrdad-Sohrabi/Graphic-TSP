import TSP.Improvements20261105.ProjectedZeroDeficitFloor
import TSP.Improvements20261105.ProjectedGuardedPositiveDeficits
import TSP.Improvements20261105.TerminalForcedDeficits

/-! Every nonroot head of the actual simultaneous construction retains
its fixed cover bound in the signed P/Q arm. Actual-zero and erased-positive
heads are proved by different valid inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_guarded_deficit_cover (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  have hH := fixedHForceTargets_subset d x z (415/2) (704/5) C
  by_cases hi : 1 < edgeSum z (d.backGroup i.1)
  · exact terminal_forcedPQ_deficit_le_cover d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) C H hH
      (fixedPositiveTerminalChildren d x) owner rootStar R i hnr
      (guarded_projected_positive_Q_deficit d x z Y R hrep hbacks hloss hterminal i hi)
  · have ha : edgeSum z (d.backGroup i.1) ≤ 1 := le_of_not_gt hi
    let delta : d.StarIndex → ℝ := terminalPIncrease d x (fixedPositiveTerminalChildren d x)
      (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H j.1)
    have hd : AdmissibleAdjustment d x delta := by
      apply terminalPIncrease_admissible d hs x hx hn hcap
      exact forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
        (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) C H hH
    have hdef := guarded_projected_zero_deficit_floor d hs x z hx hn hcap hm Y R hY
      (415/2) (704/5) (by norm_num) (by norm_num) delta hd owner rootStar i hnr ha (hzero i ha)
    have hf := C.floor_bound i.1
    change pqDeficitArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i-_ ≤ _
    linarith

end TSP.Improvements20261105
