import TSP.Improvements20261105.GatedBinaryCuts

/-! The exact integer-potential dual objective, with every lower-bound
reward and every finite-capacity penalty retained. -/
namespace TSP.Improvements20261105
set_option maxHeartbeats 2000000
set_option maxRecDepth 4096
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedTrueReward (P : GatePlan d) (p : GatedVertex d → ℤ)
    (v : d.tree.Child) : ℤ :=
  (if d.tree.parent v = d.tree.root then 0 else gatedSuffixDrop d p v) +
  (if (d.backGroup v).Nonempty then 0 else gatedRepresentativeDrop d p v) +
  (if d.tree.parent v ≠ d.tree.root ∧ ¬P.IsReceiver d v then gatedPrefixDrop d p v else 0)

noncomputable def gatedBypassPenalty (P : GatePlan d) (p : GatedVertex d → ℤ)
    (v : d.tree.Child) : ℝ :=
  if P.kind v = .disabled then 0 else
    max ((p (gatedBypassTarget d P v) : ℝ) - p (gatedBypassSource d P v)) 0

theorem gated_arc_sum_partition (F : GatedArc d → ℝ) :
    (∑ a, F a) =
      (∑ v : d.tree.Child, (F (gatedSuffixArc d v) + F (gatedRepArc d v))) +
      (∑ b : BackEdge d, F (gatedBackArc d b)) +
      (∑ v : V, F (gatedTailArc d v)) +
      ∑ v : d.tree.Child, (F (gatedPrefixArc d v) + F (gatedFreeArc d v) +
        F (gatedReverseArc d v) + F (gatedPaidArc d v) + F (gatedBypassArc d v) +
        F (gatedFeedArc d v) + F (gatedExitTailArc d v) + F (gatedExitGateArc d v)) := by
  simp [Fintype.sum_sum_type, Fintype.sum_prod_type, Fin.sum_univ_succ,
    Finset.sum_add_distrib]
  ring

theorem gated_augmented_dual_formula (P : GatePlan d) (t : d.tree.Child → ℝ)
    (p : GatedVertex d → ℤ) :
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
    ∑ v : d.tree.Child, ((gatedTrueReward d P p v : ℝ) -
      ((gatedFreeBase d v : ℝ) + t v) * max (gatedHeadSelector d p v : ℝ) 0 -
      gatedBypassPenalty d P p v) := by
  let value := fun a : GatedArc d =>
    (gatedLower d P a : ℝ) * ((gatedCost d a : ℝ) -
      ((p ((gatedNetwork d P).dst a) : ℝ) - p ((gatedNetwork d P).src a))) -
      match gatedAugmentedUpper d P t a with
      | none => 0
      | some u => (u - gatedLower d P a) * max
          ((p ((gatedNetwork d P).dst a) : ℝ) - p ((gatedNetwork d P).src a) - gatedCost d a) 0
  have hback : ∀ b : BackEdge d, value (gatedBackArc d b) = 0 := by
    intro b
    simp [value, gatedLower, gatedCost, gatedAugmentedUpper, gatedUpper]
  have htail : ∀ v : V, value (gatedTailArc d v) = 0 := by
    intro v
    simp [value, gatedLower, gatedCost, gatedAugmentedUpper, gatedUpper]
  have hlocal : ∀ v : d.tree.Child,
      (value (gatedSuffixArc d v) + value (gatedRepArc d v)) +
        (value (gatedPrefixArc d v) + value (gatedFreeArc d v) +
          value (gatedReverseArc d v) + value (gatedPaidArc d v) + value (gatedBypassArc d v) +
          value (gatedFeedArc d v) + value (gatedExitTailArc d v) + value (gatedExitGateArc d v)) =
        (gatedTrueReward d P p v : ℝ) -
          ((gatedFreeBase d v : ℝ) + t v) * max (gatedHeadSelector d p v : ℝ) 0 -
          gatedBypassPenalty d P p v := by
    intro v
    by_cases hr : d.tree.parent v = d.tree.root <;>
      by_cases hb : (d.backGroup v).Nonempty <;>
      by_cases hrec : P.IsReceiver d v <;> cases hk : P.kind v <;>
      simp [value, gatedAugmentedUpper, gatedUpper, gatedLower, gatedCost, gatedNetwork,
        gatedExtraSrc, gatedExtraDst, gatedTrueReward, gatedPrefixDrop, gatedSuffixDrop,
        gatedRepresentativeDrop, gatedHeadSelector, gatedBypassPenalty, gatedFreeBase,
        gatedBypassSource, gatedBypassTarget, hr, hb, hrec, hk] <;> ring
  change (∑ a, value a) = _
  rw [gated_arc_sum_partition]
  simp only [hback, htail, Finset.sum_const_zero, add_zero, ← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl (fun v _ => hlocal v)

end TSP.Improvements20261105
