import TSP.Improvements20261105.UnclassifiedProjection

/-! Fixed preselector removal amounts: ordinary classified centers,
prospective unary-target full overrides, and unclassified zero heads. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter08 Chapter10 Manuscript20261020
open Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

def FullOverrideAt {G : Graph V E} (d : DFSData G) (x : E → ℝ) (v : d.tree.Child) : Prop :=
  ∃ u : d.tree.Child, d.tree.parent v = u ∧ childCount d u = 1 ∧
    x (d.treeEdge u) + outgoingBackMass d x u < 1

theorem full_override_classified {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (v : d.tree.Child) (hv : FullOverrideAt d x v) :
    ClassifiedCenter d x (d.tree.parent v) := by
  obtain ⟨u, hp, hc, hm⟩ := hv
  rw [hp]
  exact unary_target_classified d hsimple x u v hc hp hm

theorem full_override_child_set {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (v : d.tree.Child) (hv : FullOverrideAt d x v) : Chapter11.childSet d (d.tree.parent v) = {v} := by
  obtain ⟨u, hp, hc, _⟩ := hv
  ext w
  constructor
  · intro hw
    apply Finset.mem_singleton.mpr
    exact one_child_unique d u hc w v ((Finset.mem_filter.mp hw).2.trans hp) hp
  · intro hw
    rw [Finset.mem_singleton.mp hw]
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩

/-- The exact unary matching identity uses current incoming and outgoing
weights and the full target-center excess. -/
theorem full_override_identity {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (u v : d.tree.Child) (hp : d.tree.parent v = u) (hc : childCount d u = 1) :
    x (d.treeEdge v) + (edgeSum x (d.backGroup v) - degreeExcess G x (d.tree.parent v)) =
      2 - x (d.treeEdge u) - outgoingBackMass d x u := by
  have hd := one_child_degree d hsimple x u v hc hp
  rw [loopless_degree_eq_cut G hsimple.1] at hd
  unfold degreeExcess
  rw [hp]
  linarith

theorem full_override_available {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (hcap : ∀ e, x e ≤ 1) (v : d.tree.Child) (hv : FullOverrideAt d x v) :
    degreeExcess G x (d.tree.parent v) < edgeSum x (d.backGroup v) := by
  obtain ⟨u, hp, hc, hm⟩ := hv
  have hid := full_override_identity d hsimple x u v hp hc
  have hq := hcap (d.treeEdge v)
  linarith

noncomputable def fixedRemoval {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (T : Finset d.tree.Child) (v : d.tree.Child) : ℝ :=
  if ClassifiedCenter d x (d.tree.parent v) then
    if v ∈ T then degreeExcess G x (d.tree.parent v) else ordinaryRemoval d x v
  else zeroRemoval d x v

theorem fixedRemoval_bounds {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child) (hT : ∀ v ∈ T, FullOverrideAt d x v) (v : d.tree.Child) :
    0 ≤ fixedRemoval d x T v ∧ fixedRemoval d x T v ≤ edgeSum x (d.backGroup v) := by
  unfold fixedRemoval
  split_ifs with hc ht
  · exact ⟨degreeExcess_nonnegative G hx hn _, (full_override_available d hsimple x hcap v (hT v ht)).le⟩
  · exact ordinaryRemoval_bounds d hx hn v
  · exact zeroRemoval_bounds d hx.1 hcap v

theorem fixedRemoval_surviving {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child) (v : d.tree.Child) (hv : SurvivingPositive d x v) :
    fixedRemoval d x T v = degreeExcess G x (d.tree.parent v) := by
  rw [fixedRemoval, if_pos (surviving_center_classified d hx.1 v hv)]
  split_ifs
  · rfl
  · exact ordinaryRemoval_surviving d hsimple hx hn v hv

theorem fixed_projected_positive_iff {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child) (v : d.tree.Child) :
    1 < edgeSum x (d.backGroup v) - fixedRemoval d x T v ↔ SurvivingPositive d x v := by
  constructor
  · intro hp
    unfold fixedRemoval at hp
    split_ifs at hp with hc ht
    · unfold SurvivingPositive
      linarith
    · exact (ordinary_projected_positive_iff d hsimple hx hn v).mp hp
    · rw [zero_projected_mass] at hp
      have hh := min_le_right (edgeSum x (d.backGroup v)) (1 - x (d.treeEdge v))
      have hq := hx.1 (d.treeEdge v)
      linarith
  · intro hv
    rw [fixedRemoval_surviving d hsimple hx hn T v hv]
    unfold SurvivingPositive at hv
    linarith

theorem fixedRemoval_shared_center_budget {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child) (hT : ∀ v ∈ T, FullOverrideAt d x v) (u : V) :
    (∑ v ∈ Chapter11.childSet d u, max
      (tau (edgeSum x (d.group v)) (degreeExcess G x u)) (fixedRemoval d x T v)) ≤ degreeExcess G x u := by
  have hparent : ∀ v ∈ Chapter11.childSet d u, d.tree.parent v = u :=
    fun v hv => (Finset.mem_filter.mp hv).2
  by_cases hu : ClassifiedCenter d x u
  · by_cases hex : ∃ v ∈ T, d.tree.parent v = u
    · obtain ⟨v, hvT, hvu⟩ := hex
      have hset : Chapter11.childSet d u = {v} := by
        simpa only [hvu] using full_override_child_set d x v (hT v hvT)
      rw [hset, Finset.sum_singleton, fixedRemoval, hvu, if_pos hu, if_pos hvT]
      have ht := tau_le_half (s := edgeSum x (d.group v)) (degreeExcess_nonnegative G hx hn u)
      exact max_le (by linarith [degreeExcess_nonnegative G hx hn u]) le_rfl
    · have heq : (∑ v ∈ Chapter11.childSet d u, max
          (tau (edgeSum x (d.group v)) (degreeExcess G x u)) (fixedRemoval d x T v)) =
          ∑ v ∈ Chapter11.childSet d u, sharedProjectionCharge d x v := by
        apply Finset.sum_congr rfl
        intro v hv
        have hnT : v ∉ T := fun h => hex ⟨v, h, hparent v hv⟩
        simp only [fixedRemoval, sharedProjectionCharge, hparent v hv, hu, if_true, hnT, if_false]
      rw [heq]
      exact sharedProjection_center_budget d hsimple hx hn u
  · have heq : (∑ v ∈ Chapter11.childSet d u, max
        (tau (edgeSum x (d.group v)) (degreeExcess G x u)) (fixedRemoval d x T v)) =
        ∑ v ∈ Chapter11.childSet d u, max
          (tau (edgeSum x (d.group v)) (degreeExcess G x u)) (zeroRemoval d x v) := by
      apply Finset.sum_congr rfl
      intro v hv
      simp only [fixedRemoval, hparent v hv, hu, if_false]
    rw [heq]
    exact zeroProjection_shared_center_budget d hsimple hx hn u hu

theorem sum_at_centers {G : Graph V E} (d : DFSData G) (f : d.tree.Child → ℝ) :
    (∑ u, ∑ v ∈ Chapter11.childSet d u, f v) = ∑ v, f v := by
  simp only [Chapter11.childSet, Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro v _
  simp

noncomputable def fixedProjectionCharge {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (T : Finset d.tree.Child) (v : d.tree.Child) : ℝ :=
  max (tau (edgeSum x (d.group v)) (degreeExcess G x (d.tree.parent v))) (fixedRemoval d x T v)

theorem fixedProjection_total_budget {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child) (hT : ∀ v ∈ T, FullOverrideAt d x v) :
    (∑ v : d.tree.Child, fixedProjectionCharge d x T v) ≤
      2 * (edgeSum x Finset.univ - (Fintype.card V : ℝ)) := by
  have hcenter : ∀ u, (∑ v ∈ Chapter11.childSet d u, fixedProjectionCharge d x T v) ≤ degreeExcess G x u := by
    intro u
    have heq : (∑ v ∈ Chapter11.childSet d u, fixedProjectionCharge d x T v) =
        ∑ v ∈ Chapter11.childSet d u, max
          (tau (edgeSum x (d.group v)) (degreeExcess G x u)) (fixedRemoval d x T v) := by
      apply Finset.sum_congr rfl
      intro v hv
      simp only [fixedProjectionCharge, (Finset.mem_filter.mp hv).2]
    rw [heq]
    exact fixedRemoval_shared_center_budget d hsimple hx hn T hT u
  have hs := Finset.sum_le_sum (s := Finset.univ) (fun u _ => hcenter u)
  rwa [sum_at_centers, sum_degreeExcess G hsimple x] at hs

theorem fixedRemoval_total_budget {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child) (hT : ∀ v ∈ T, FullOverrideAt d x v) :
    (∑ v : d.tree.Child, fixedRemoval d x T v) ≤
      2 * (edgeSum x Finset.univ - (Fintype.card V : ℝ)) :=
  (Finset.sum_le_sum (fun v _ => le_max_right _ _)).trans
    (fixedProjection_total_budget d hsimple hx hn T hT)

end TSP.Improvements20261105
