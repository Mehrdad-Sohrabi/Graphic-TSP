import TSP.Improvements20261105.MatchingTargetMassIdentity
import TSP.Improvements20261105.ScoredUniformNetLoad

/-! A matching target with a parent tree edge of weight at least one half
has a uniformly bounded canonical load, including its coupon residual. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_high_parent_target_load
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eligible T : Finset (d).tree.Child) (s t : (d).tree.Child)
    (hsM : s ∈ C.matching) (ht : t=unaryNext d s) (hq : (1/2 : ℝ) ≤ x ((d).treeEdge s)) :
    canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
      (projectedOutgoingCoupon d x z) t ≤ 36 := by
  have hp : (d).tree.parent t=(s : V) := by rw [ht]; exact projectionLinks_parent d x s (C.link_subset hsM)
  have hgreedy (e : E) (he : e ∈ (d).backGroup t) : z e ≤ x ((d).treeEdge t) :=
    (hzx e).trans (scoredDFS_high_parent_greedy G x hs hc root t s hp hq e he)
  have hmass := matching_target_mass_identity d hs x z hm C s t hsM ht
  have ho0 : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hinc := refined_fixed_incidence_le_noncritical d x z eligible T t
  have hload := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun c => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz c) t
  by_cases hpos : 1 ≤ edgeSum z ((d).backGroup t)
  · have hh := small_receiver_noncritical_load d z t (x ((d).treeEdge t)) (1/2)
      (hx.1 _) (by norm_num) (fun e _ => hz e) hgreedy hpos
      (by linarith only [hmass,hq,ho0])
    linarith only [hh,hload,hinc]
  · have hh := noncritical_uniform_linear_envelope d z t 1 (3/2) (29/20)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (fun e _ => hz e) (fun e _ => (hzx e).trans (hcap e))
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hh,hload,hinc,hpos]

end TSP.Improvements20261105
