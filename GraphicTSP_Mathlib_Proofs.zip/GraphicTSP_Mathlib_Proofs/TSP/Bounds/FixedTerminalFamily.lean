import TSP.Improvements20261105.ZeroTerminalGuards
import TSP.Improvements20261105.LeafTerminalChoice

/-! Fix one own back for every eligible terminal head before any dual
selector. Leaf charging only selects among this already fixed family. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def fixedOwnBack (i : d.StarIndex) : BackEdge d :=
  ⟨i.2.choose, ((d.mem_backGroup_iff i.1 i.2.choose).mp i.2.choose_spec).1⟩

 theorem fixedOwnBack_anchor (i : d.StarIndex) : d.anchor (fixedOwnBack d i).1 = i.1 :=
  (d.mem_group i.1 _).mp (Finset.mem_sdiff.mp i.2.choose_spec).1

 theorem fixedOwnBack_injective : Function.Injective (fixedOwnBack d) := by
  intro i j he
  apply Subtype.ext
  have ha := congrArg (fun b : BackEdge d => d.anchor b.1) he
  simpa only [fixedOwnBack_anchor] using ha

def TerminalGuardEligible (i : d.StarIndex) : Prop :=
  HeadFreeBelow d i.1 ∧ ∀ v ∈ strictSubtreeChildren d i.1, childCount d v ≤ 1

noncomputable def fixedZeroTerminalHeads (x : E → ℝ) : Finset d.StarIndex :=
  Finset.univ.filter (fun i => TerminalGuardEligible d i ∧ edgeSum x (d.backGroup i.1) ≤ 1)

noncomputable def fixedZeroTerminalBacks (x : E → ℝ) : Finset (BackEdge d) :=
  (fixedZeroTerminalHeads d x).image (fixedOwnBack d)

 theorem fixedZeroTerminalBacks_headfree (x : E → ℝ) (b : BackEdge d)
    (hb : b ∈ fixedZeroTerminalBacks d x) : HeadFreeBelow d (d.anchor b.1) := by
  obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
  rw [fixedOwnBack_anchor]
  exact (Finset.mem_filter.mp hi).2.1.1

 theorem fixedZeroTerminalBacks_zero (x : E → ℝ) (b : BackEdge d)
    (hb : b ∈ fixedZeroTerminalBacks d x) : edgeSum x (d.backGroup (d.anchor b.1)) ≤ 1 := by
  obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
  rw [fixedOwnBack_anchor]
  exact (Finset.mem_filter.mp hi).2.2

 theorem fixedZeroTerminalBacks_distinct (x : E → ℝ) (b c : BackEdge d)
    (hb : b ∈ fixedZeroTerminalBacks d x) (hc : c ∈ fixedZeroTerminalBacks d x)
    (hne : b ≠ c) : d.anchor b.1 ≠ d.anchor c.1 := by
  obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
  obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp hc
  rw [fixedOwnBack_anchor, fixedOwnBack_anchor]
  intro he
  exact hne (congrArg (fixedOwnBack d) (Subtype.ext he))

 theorem GatedDrops.zero_leaf_fixed_guard_or_branch (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (hout : a.componentOutgoingCuts d P r = ∅)
    (hh : (a.actualComponentHeads d P r).Nonempty) (x : E → ℝ)
    (hzero : ∀ s ∈ a.actualComponentHeads d P r, edgeSum x (d.backGroup s) ≤ 1) :
    ∃ i : d.StarIndex, i.1 ∈ a.actualComponentHeads d P r ∧ HeadFreeBelow d i.1 ∧
      (fixedOwnBack d i ∈ fixedZeroTerminalBacks d x ∨
        ∃ v ∈ strictSubtreeChildren d i.1, 2 ≤ childCount d v) := by
  obtain ⟨s, hs, hterm⟩ := a.headful_leaf_terminal_head d P r hout hh
  let i : d.StarIndex := ⟨s, (Finset.mem_filter.mp hs).2.1⟩
  refine ⟨i, hs, hterm, ?_⟩
  by_cases helig : ∀ v ∈ strictSubtreeChildren d s, childCount d v ≤ 1
  · left
    apply Finset.mem_image.mpr
    exact ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨hterm, helig⟩, hzero s hs⟩, rfl⟩
  · right
    push_neg at helig
    obtain ⟨v, hv, hcount⟩ := helig
    exact ⟨v, hv, by omega⟩

end TSP.Improvements20261105
