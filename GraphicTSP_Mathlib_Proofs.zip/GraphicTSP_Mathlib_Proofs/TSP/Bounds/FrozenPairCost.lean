import TSP.Improvements20261105.PairIncomingBudget
import TSP.Improvements20261105.TerminalHReceiver

/-! Every nonroot head of the actual simultaneous construction retains
its fixed cover bound in the signed P/Q arm. Actual-zero and erased-positive
heads are proved by different valid inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_frozen_pair_cost (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i j : d.StarIndex) (hi : i.1 ∈ C.matching) (hj : j.1 = unaryNext d i.1)
    (hfrozen : HSourceFrozen d x z C i.1) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)+
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)-
      (415/2 : ℝ)*(fixedProjectionCharge d x (allFullOverrideTargets d x) i.1+
        fixedProjectionCharge d x (allFullOverrideTargets d x) j.1) ≤ -(59/80 : ℝ) := by
  obtain ⟨v,hvH,hvi,hunary⟩ := hfrozen
  have hl := (Finset.mem_filter.mp (C.link_subset hi)).2
  have hnr : d.centers i ≠ d.tree.root := by change d.tree.parent i.1 ≠ _; rw [hvi]; exact v.2
  have hir : i ≠ rootStar := fun he => hnr (he ▸ hroot)
  have hnrj : d.centers j ≠ d.tree.root := by
    change d.tree.parent j.1 ≠ d.tree.root
    rw [hj,projectionLinks_parent d x i.1 (C.link_subset hi)]
    exact i.1.2
  have hT : ∀ s ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d s := by
    intro c hc
    obtain ⟨k,hk,rfl⟩ := Finset.mem_image.mp hc
    exact (Finset.mem_filter.mp hk).2.1
  have hci := terminal_H_forced_PQ_connector d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) C (fixedHForceTargets d x z (415/2) (704/5) C)
    (fixedHForceTargets_subset d x z (415/2) (704/5) C)
    (fixedPositiveTerminalChildren d x) hT owner ho rootStar R hR i hir v hvi hunary hvH
  have hdi := current_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar Y R hY
    hrep hbacks hloss hterminal hzero i hnr
  have hslack : -targetForceSlack d x 24 4 v ≤ 0 := neg_nonpos.mpr (le_max_right _ _)
  have hmax : max (C.cover i.1) (-targetForceSlack d x 24 4 v) ≤ max (C.cover i.1) 0 :=
    max_le_max (le_refl _) hslack
  have hmi : max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ max (C.cover i.1) 0 := by
    apply (sub_le_iff_le_add).mpr
    apply max_le
    · change pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-_ ≤ _ at hci
      linarith only [hci,hmax]
    · linarith only [hdi,le_max_left (C.cover i.1) 0]
  have hmj := current_guarded_max_cover d hs x z hx hn hcap hm C owner ho rootStar hroot Y R hY hR
    hrep hbacks hloss hterminal hzero j hnrj
  rw [matched_target_incoming_force_zero d x z C i.1 hi j hj,add_zero] at hmj
  have hpair := C.pair_cost i.1 hi
  rw [← hj] at hpair
  have hin := surviving_incoming_complement d hs x hx i.1 v hvi hl.2.1
  have hthreshold := (Finset.mem_filter.mp hvH).2
  have hq := hx.1 (d.treeEdge i.1)
  have ho0 : 0 ≤ outgoingBackMass d x i.1 := Finset.sum_nonneg (fun e _ => hx.1 e)
  have heta := (preliminaryQIncrease_bounds d hs hx hcap i.1).2.2.1
  have hpz := projectionLink_source_positive d hs x z hx hn hm i.1 (C.link_subset hi)
  have hfloor := (fixedCoverFloor_positive_lower d hs x z hx hcap (704/5) (by norm_num) i.1 hpz).trans
    (C.floor_bound i.1)
  have hpair_bound : C.cover i.1+C.cover j.1 ≤ -(59/80 : ℝ) := by
    linarith only [hpair,hin,hthreshold,hq,ho0]
  have htarget_bound : C.cover j.1 ≤ -(59/80 : ℝ) := by
    linarith only [hpair,hin,hthreshold,hq,ho0,heta,hfloor]
  have htotal : max (C.cover i.1) 0+C.cover j.1 ≤ -(59/80 : ℝ) := by
    by_cases h : C.cover i.1 ≤ 0
    · rw [max_eq_right h,zero_add]; exact htarget_bound
    · rw [max_eq_left (le_of_not_ge h)]; exact hpair_bound
  linarith only [hmi,hmj,htotal]

end TSP.Improvements20261105
