import TSP.Improvements20261105.GatedDropFeasibility
import TSP.Improvements20261105.GatedCollectorClosure

/-! Exact objective in drop coordinates, including all four bypass losses. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.reward (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) : ℤ :=
  (if d.tree.parent v = d.tree.root then 0 else a.suffix v) +
  (if (d.backGroup v).Nonempty then 0 else a.representative v) +
  (if d.tree.parent v ≠ d.tree.root ∧ ¬P.IsReceiver d v then a.pref v else 0)

noncomputable def GatedDrops.penalty (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) : ℤ :=
  match P.kind v with
  | .disabled => 0
  | .outgoing => max (a.head v - a.representative v - a.tail v) 0
  | .twoDirections => max (a.head v - a.representative v) 0
  | .sharedGate => max (max (a.head v - a.representative v - a.tail v)
      (a.head v - a.representative v - a.pref (P.receiver v))) 0
  | .outsideGate => max (a.head v - a.representative v - a.outside v - a.pref (P.receiver v)) 0

@[simp] theorem GatedDrops.potential_reward (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedTrueReward d P (a.potential d P) v = a.reward d P v := by
  simp [gatedTrueReward, GatedDrops.reward]

theorem GatedDrops.potential_gate_receiver (P : GatePlan d) (hP : P.RespectsTree d)
    (a : GatedDrops d) (v : d.tree.Child) (hv : P.UsesGate d v) :
    a.center d (P.receiver v) + a.representative (P.receiver v) + a.suffix (P.receiver v) =
      a.center d v - a.pref (P.receiver v) := by
  have hh := a.center_parent d (P.receiver v)
  rw [hP v hv] at hh
  omega

theorem GatedDrops.potential_penalty (P : GatePlan d) (hP : P.RespectsTree d)
    (a : GatedDrops d) (v : d.tree.Child) :
    gatedBypassPenalty d P (a.potential d P) v = (a.penalty d P v : ℝ) := by
  cases hk : P.kind v
  · simp [gatedBypassPenalty, GatedDrops.penalty, hk]
  · simp only [gatedBypassPenalty, hk, reduceCtorEq, if_false,
      gatedBypassTarget, gatedBypassSource, potential_tail, potential_head,
      GatedDrops.penalty, Int.cast_sub, Int.cast_add, Int.cast_max, Int.cast_zero]
    congr 1
    ring
  · simp only [gatedBypassPenalty, hk, reduceCtorEq, if_false,
      gatedBypassTarget, gatedBypassSource, potential_center, potential_head,
      GatedDrops.penalty, Int.cast_sub, Int.cast_add, Int.cast_max, Int.cast_zero]
    congr 1
    ring
  · have hg := a.potential_gate_receiver d P hP v (Or.inl hk)
    simp only [gatedBypassPenalty, hk, reduceCtorEq, if_false,
      gatedBypassTarget, gatedBypassSource, potential_collector, potential_head,
      GatedDrops.penalty, hg, Int.cast_sub, Int.cast_add, Int.cast_max, Int.cast_zero]
    rw [← max_sub_sub_right]
    congr 2 <;> ring
  · have hg := a.potential_gate_receiver d P hP v (Or.inr hk)
    simp only [gatedBypassPenalty, hk, reduceCtorEq, if_false, if_true,
      gatedBypassTarget, gatedBypassSource, potential_gate, potential_outside,
      GatedDrops.penalty, hg, Int.cast_sub, Int.cast_add, Int.cast_max, Int.cast_zero]
    congr 1
    ring

theorem gatedDropsOf_reward (P : GatePlan d) (p : GatedVertex d → ℤ) (v : d.tree.Child) :
    (gatedDropsOf d p).reward d P v = gatedTrueReward d P p v := rfl

theorem gatedDropsOf_penalty_le (P : GatePlan d) (hP : P.RespectsTree d)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    ((gatedDropsOf d p).penalty d P v : ℝ) ≤ gatedBypassPenalty d P p v := by
  have hgate (hv : P.UsesGate d v) :
      p (gatedGate d (P.receiver v)) = p (gatedCenter d v) - gatedPrefixDrop d p (P.receiver v) := by
    unfold gatedPrefixDrop
    rw [hP v hv]
    omega
  cases hk : P.kind v
  · simp [GatedDrops.penalty, gatedBypassPenalty, hk]
  · simp only [GatedDrops.penalty, gatedDropsOf, hk, gatedHeadSelector,
      gatedRepresentativeDrop, gatedTailDrop, Int.cast_max, Int.cast_sub, Int.cast_zero,
      gatedBypassPenalty, reduceCtorEq, if_false, gatedBypassTarget, gatedBypassSource]
    apply le_of_eq
    congr 1
    ring
  · simp only [GatedDrops.penalty, gatedDropsOf, hk, gatedHeadSelector,
      gatedRepresentativeDrop, Int.cast_max, Int.cast_sub, Int.cast_zero,
      gatedBypassPenalty, reduceCtorEq, if_false, gatedBypassTarget, gatedBypassSource]
    apply le_of_eq
    congr 1
    ring
  · have hg := hgate (Or.inl hk)
    have hc := gated_dual_collector_exits d hp v hk
    have ht : (p (gatedTail d v) : ℝ) ≤ p (gatedCollector d v) := by
      exact_mod_cast (le_max_left _ _).trans hc
    have hgr : (p (gatedGate d (P.receiver v)) : ℝ) ≤ p (gatedCollector d v) := by
      exact_mod_cast (le_max_right _ _).trans hc
    have hge : (p (gatedGate d (P.receiver v)) : ℝ) = p (gatedCenter d v) - gatedPrefixDrop d p (P.receiver v) := by
      exact_mod_cast hg
    simp only [GatedDrops.penalty, gatedDropsOf, hk, gatedHeadSelector,
      gatedRepresentativeDrop, gatedTailDrop, Int.cast_max, Int.cast_sub, Int.cast_zero,
      gatedBypassPenalty, reduceCtorEq, if_false, gatedBypassTarget, gatedBypassSource]
    apply max_le_max_right
    apply max_le
    · linarith
    · linarith
  · have hg := hgate (Or.inr hk)
    simp only [GatedDrops.penalty, gatedDropsOf, hk, gatedHeadSelector,
      gatedRepresentativeDrop, gatedOutsideDrop, Int.cast_max, Int.cast_sub, Int.cast_zero,
      gatedBypassPenalty, reduceCtorEq, if_false, if_true, gatedBypassTarget, gatedBypassSource]
    apply le_of_eq
    congr 1
    rw [hg]
    push_cast
    ring

noncomputable def GatedDrops.value (P : GatePlan d) (t : d.tree.Child → ℝ) (a : GatedDrops d) : ℝ :=
  ∑ v : d.tree.Child, ((a.reward d P v : ℝ) -
    ((gatedFreeBase d v : ℝ) + t v) * (a.head v : ℝ) - (a.penalty d P v : ℝ))

theorem GatedDrops.potential_value (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (a : GatedDrops d) (ha : a.Admissible d P) :
    realCapacityDualValue (gatedNetwork d P) (fun e => (gatedCost d e : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (a.potential d P v : ℝ)) =
        a.value d P t := by
  rw [gated_augmented_dual_formula]
  unfold GatedDrops.value
  apply Finset.sum_congr rfl
  intro v _
  rw [a.potential_reward, a.potential_headSelector, a.potential_penalty d P hP]
  rw [max_eq_left (by exact_mod_cast ha.head_nonneg v)]

end TSP.Improvements20261105
