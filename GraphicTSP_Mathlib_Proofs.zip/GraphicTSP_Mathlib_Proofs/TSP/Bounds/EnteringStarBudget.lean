import TSP.Improvements20261105.SubtreeDirectionBudget
import TSP.Improvements20261105.LeafOriginalSubtree

/-! Entering connector errors at one outside center share one actual
degree-excess budget. Such centers cannot belong to any leaf component. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

 theorem star_foreign_deficit_center_budget (hs : G.IsSimple) (x : E → ℝ)
    (hx : G.SubtourFeasible x) (u : V) (hu : u ≠ d.tree.root) :
    (∑ c ∈ childSet d u, max (edgeSum x (d.group c)-edgeSum x (deletedSubtreeCut d c)) 0) ≤
      degreeExcess G x u := by
  let S := (childSet d u).filter (fun c => edgeSum x (deletedSubtreeCut d c) < edgeSum x (d.group c))
  have hS : S ⊆ childSet d u := Finset.filter_subset _ _
  have hcut := hx.2 (insert u (subtreeBundle d S)) (Finset.insert_nonempty _ _) (by
    refine ⟨d.tree.root, ?_⟩
    simp only [Finset.mem_compl, Finset.mem_insert, not_or]
    exact ⟨hu.symm, root_not_bundle d _⟩)
  rw [vertex_bundle_cut_mass d hs x u S hS, loopless_degree_eq_cut G hs.1] at hcut
  have hsum : (∑ c ∈ childSet d u, max (edgeSum x (d.group c)-edgeSum x (deletedSubtreeCut d c)) 0) =
      ∑ c ∈ S, (edgeSum x (d.group c)-edgeSum x (deletedSubtreeCut d c)) := by
    conv_rhs => rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro c _
    by_cases hc : edgeSum x (deletedSubtreeCut d c) < edgeSum x (d.group c)
    · rw [if_pos hc, max_eq_left (by linarith)]
    · rw [if_neg hc, max_eq_right (by linarith)]
  rw [hsum, Finset.sum_sub_distrib]
  unfold degreeExcess
  linarith

 theorem GatedDrops.true_connector_center_has_outgoing (P : GatePlan d) (a : GatedDrops d)
    (c : d.tree.Child) (hc : expandedConnectorChild d c ∈ a.trueCuts d P) :
    (a.componentOutgoingCuts d P (a.component d P (.inl (d.tree.parent c)))).Nonempty :=
  ⟨expandedConnectorChild d c, Finset.mem_filter.mpr ⟨hc, rfl⟩⟩

 theorem GatedDrops.true_connector_center_outside_leaf (P : GatePlan d) (a : GatedDrops d)
    (c : d.tree.Child) (hc : expandedConnectorChild d c ∈ a.trueCuts d P)
    (r : FlowVertex d) (hr : a.componentOutgoingCuts d P r = ∅) :
    d.tree.parent c ∉ a.originalComponentVertices d P r := by
  intro hmem
  have he := (Finset.mem_filter.mp hmem).2
  have hh := a.true_connector_center_has_outgoing d P c hc
  rw [he, hr] at hh
  exact Finset.not_nonempty_empty hh

 theorem GatedDrops.true_connector_center_nonroot (P : GatePlan d) (a : GatedDrops d)
    (c : d.tree.Child) (hc : expandedConnectorChild d c ∈ a.trueCuts d P) :
    d.tree.parent c ≠ d.tree.root := by
  have hh : 0 < a.trueRoleWeight d P (.inl c) := (Finset.mem_filter.mp hc).2
  intro hroot
  simp [GatedDrops.trueRoleWeight, hroot] at hh

end TSP.Improvements20261105
