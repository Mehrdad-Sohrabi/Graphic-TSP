import TSP.Improvements20261105.MatchingRedistribution

/-! Source caps preserve all link inequalities, including the incoming
inequality at every capped source. -/
namespace TSP.Improvements20261105
open Classical
open scoped BigOperators
variable {V : Type} [Fintype V] [DecidableEq V]

theorem cappedMatchingCover_feasible (links M : Finset V) (next : V → V)
    (floor ell z cap : V → ℝ) (hd : Disjoint M (M.image next))
    (hn : Set.InjOn next (M : Set V))
    (hf : ∀ v, floor v ≤ z v) (hc : ∀ s ∈ links, ell s ≤ z s + z (next s))
    (hcap : ∀ s ∈ M, floor s ≤ cap s)
    (hin : ∀ s ∈ links, next s ∈ M → ell s ≤ floor s + cap (next s)) :
    (∀ v, floor v ≤ cappedMatchingCover M next z cap v) ∧
    (∀ s ∈ links, ell s ≤ cappedMatchingCover M next z cap s + cappedMatchingCover M next z cap (next s)) ∧
    (∀ s ∈ M, cappedMatchingCover M next z cap s ≤ cap s) := by
  refine ⟨?_, ?_, ?_⟩
  · intro v
    by_cases hv : v ∈ M
    · rw [cappedMatchingCover_source M next z cap hd v hv]
      exact le_min (hf v) (hcap v hv)
    · exact (hf v).trans (cappedMatchingCover_other M next z cap v hv)
  · intro s hs
    by_cases hm : s ∈ M
    · rw [cappedMatchingCover_pair M next z cap hd hn s hm]
      exact hc s hs
    · have hsource := cappedMatchingCover_other M next z cap s hm
      by_cases ht : next s ∈ M
      · rw [cappedMatchingCover_source M next z cap hd (next s) ht]
        by_cases hz : z (next s) ≤ cap (next s)
        · rw [min_eq_left hz]
          have hh := hc s hs
          linarith
        · rw [min_eq_right (le_of_lt (lt_of_not_ge hz))]
          have hh := hin s hs ht
          have hh' := hf s
          linarith
      · have htarget := cappedMatchingCover_other M next z cap (next s) ht
        have hh := hc s hs
        linarith
  · intro s hs
    rw [cappedMatchingCover_source M next z cap hd s hs]
    exact min_le_right _ _

theorem predecessor_cover_cap (P Q E q o eta f qR ER : ℝ)
    (hP : 0 ≤ P) (hE : E ≤ 1 - q) (hf : -Q * (q + eta) ≤ f)
    (hid : qR + ER = 1 - q - o) :
    P * E - Q - (P - Q) * o - Q * eta - f ≤ (P - Q) * (qR + ER) := by
  have he := mul_le_mul_of_nonneg_left hE hP
  rw [hid]
  nlinarith

end TSP.Improvements20261105
