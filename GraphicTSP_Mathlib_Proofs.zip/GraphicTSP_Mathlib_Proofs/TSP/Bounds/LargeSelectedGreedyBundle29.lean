import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105

private theorem greedybundle29_cached_cap_000 :
    0 ≤ (3/13 : ℝ) ∧ 0 ≤ 2-(3/13 : ℝ) ∧ (2-(3/13 : ℝ))*(13/46 : ℝ) ≤ 1/2 ∧
    0 ≤ (4/13 : ℝ) ∧ 0 ≤ 19/10-(4/13 : ℝ) ∧ (19/10-(4/13 : ℝ))*(13/46 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_001 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(13/80 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(13/80 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_002 :
    0 ≤ (6/13 : ℝ) ∧ 0 ≤ 2-(6/13 : ℝ) ∧ (2-(6/13 : ℝ))*(13/40 : ℝ) ≤ 1/2 ∧
    0 ≤ (67/130 : ℝ) ∧ 0 ≤ 19/10-(67/130 : ℝ) ∧ (19/10-(67/130 : ℝ))*(13/40 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_003 :
    0 ≤ (1/1 : ℝ) ∧ 0 ≤ 2-(1/1 : ℝ) ∧ (2-(1/1 : ℝ))*(1/2 : ℝ) ≤ 1/2 ∧
    0 ≤ (1/1 : ℝ) ∧ 0 ≤ 19/10-(1/1 : ℝ) ∧ (19/10-(1/1 : ℝ))*(1/2 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_004 :
    0 ≤ (7/5 : ℝ) ∧ 0 ≤ 2-(7/5 : ℝ) ∧ (2-(7/5 : ℝ))*(5/6 : ℝ) ≤ 1/2 ∧
    0 ≤ (34/25 : ℝ) ∧ 0 ≤ 19/10-(34/25 : ℝ) ∧ (19/10-(34/25 : ℝ))*(5/6 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_005 :
    0 ≤ (3/2 : ℝ) ∧ 0 ≤ 2-(3/2 : ℝ) ∧ (2-(3/2 : ℝ))*(1/1 : ℝ) ≤ 1/2 ∧
    0 ≤ (29/20 : ℝ) ∧ 0 ≤ 19/10-(29/20 : ℝ) ∧ (19/10-(29/20 : ℝ))*(1/1 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_006 :
    0 ≤ (65/44 : ℝ) ∧ 0 ≤ 2-(65/44 : ℝ) ∧ (2-(65/44 : ℝ))*(22/23 : ℝ) ≤ 1/2 ∧
    0 ≤ (629/440 : ℝ) ∧ 0 ≤ 19/10-(629/440 : ℝ) ∧ (19/10-(629/440 : ℝ))*(22/23 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_007 :
    0 ≤ (25/24 : ℝ) ∧ 0 ≤ 2-(25/24 : ℝ) ∧ (2-(25/24 : ℝ))*(12/23 : ℝ) ≤ 1/2 ∧
    0 ≤ (83/80 : ℝ) ∧ 0 ≤ 19/10-(83/80 : ℝ) ∧ (19/10-(83/80 : ℝ))*(12/23 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_008 :
    0 ≤ (2/9 : ℝ) ∧ 0 ≤ 2-(2/9 : ℝ) ∧ (2-(2/9 : ℝ))*(9/32 : ℝ) ≤ 1/2 ∧
    0 ≤ (3/10 : ℝ) ∧ 0 ≤ 19/10-(3/10 : ℝ) ∧ (19/10-(3/10 : ℝ))*(9/32 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_009 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(31/192 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(31/192 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_010 :
    0 ≤ (34/23 : ℝ) ∧ 0 ≤ 2-(34/23 : ℝ) ∧ (2-(34/23 : ℝ))*(23/24 : ℝ) ≤ 1/2 ∧
    0 ≤ (329/230 : ℝ) ∧ 0 ≤ 19/10-(329/230 : ℝ) ∧ (19/10-(329/230 : ℝ))*(23/24 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle29_cached_cap_011 :
    0 ≤ (26/25 : ℝ) ∧ 0 ≤ 2-(26/25 : ℝ) ∧ (2-(26/25 : ℝ))*(25/48 : ℝ) ≤ 1/2 ∧
    0 ≤ (259/250 : ℝ) ∧ 0 ≤ 19/10-(259/250 : ℝ) ∧ (19/10-(259/250 : ℝ))*(25/48 : ℝ) ≤ 9/20 := by norm_num

set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t23_r3_all_cell_0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle29_cached_cap_001.1 greedybundle29_cached_cap_001.2.1 greedybundle29_cached_cap_001.2.2.1 greedybundle29_cached_cap_001.2.2.2.1 greedybundle29_cached_cap_001.2.2.2.2.1 greedybundle29_cached_cap_001.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (5539/26:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (126149/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (5539/26:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (45456589/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (2085515/9386:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47516317/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (2085515/9386:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47433117/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (5539/26:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (125861/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (5539/26:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (45364933/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2085515/9386:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47412349/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2085515/9386:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47341461/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_2
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t23_r3_all_cell_3
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t23_r3_all_cell_4
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (5539/26:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (125525/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (5539/26:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (45278749/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (2085515/9386:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47291053/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (2085515/9386:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47255277/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_5
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t23_r3_all_cell_6
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t23_r3_all_cell_7
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle29_cached_cap_004.1 greedybundle29_cached_cap_004.2.1 greedybundle29_cached_cap_004.2.2.1 greedybundle29_cached_cap_004.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (9391/130:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (187081/130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (9391/130:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (67487777/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (3819831/46930:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (77418881/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (3819831/46930:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (77370417/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_8
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t23_r3_all_cell_9
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t23_r3_all_cell_10
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (39/500 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (22/23 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (22/23 : ℝ) (65/44 : ℝ) (629/440 : ℝ) greedybundle29_cached_cap_006.1 greedybundle29_cached_cap_006.2.1 greedybundle29_cached_cap_006.2.2.1 greedybundle29_cached_cap_006.2.2.2.1 greedybundle29_cached_cap_006.2.2.2.2.1 greedybundle29_cached_cap_006.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5345/22:ℝ)*hzl + (60374/6457:ℝ)*hem + (1210080/6457:ℝ)*ho0 + (477792/32285:ℝ)*hgap + (19908/32285:ℝ)*hS + (1/1:ℝ)*hI + (12377/32285:ℝ)*hsource + (1/1:ℝ)*hR + (654/11:ℝ)*hmass
  · linear_combination (1933483/7942:ℝ)*hzl + (415064169/44288563:ℝ)*hem + (8322716112/44288563:ℝ)*ho0 + (3277647888/221442815:ℝ)*hgap + (136568662/221442815:ℝ)*hS + (1/1:ℝ)*hI + (84874153/221442815:ℝ)*hsource + (1/1:ℝ)*hR + (238063/3971:ℝ)*hmass
  · linear_combination (5345/22:ℝ)*hzl + (2073213746/221751475:ℝ)*hem + (8303608968/44350295:ℝ)*ho0 + (3277175328/221751475:ℝ)*hgap + (136548972/221751475:ℝ)*hS + (1/1:ℝ)*hI + (85202503/221751475:ℝ)*hsource + (1/1:ℝ)*hR + (654/11:ℝ)*hmass
  · linear_combination (1933483/7942:ℝ)*hzl + (750163384401/80052282475:ℝ)*hem + (3005836525988/16010456495:ℝ)*ho0 + (3277647888/221751475:ℝ)*hgap + (136568662/221751475:ℝ)*hS + (1/1:ℝ)*hI + (85182813/221751475:ℝ)*hsource + (1/1:ℝ)*hR + (238063/3971:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_11
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (5539/26:ℝ)*hg0 + (6163/26:ℝ)*hgap + (1/1:ℝ)*hH0 + (7075/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (5539/26:ℝ)*hg0 + (6163/26:ℝ)*hgap + (1/1:ℝ)*hH0 + (2624963/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (2085515/9386:ℝ)*hg0 + (2310779/9386:ℝ)*hgap + (1/1:ℝ)*hH0 + (2640011/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (2085515/9386:ℝ)*hg0 + (2310779/9386:ℝ)*hgap + (1/1:ℝ)*hH0 + (2710899/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_12
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (12/23 : ℝ) (25/24 : ℝ) (83/80 : ℝ) greedybundle29_cached_cap_007.1 greedybundle29_cached_cap_007.2.1 greedybundle29_cached_cap_007.2.2.1 greedybundle29_cached_cap_007.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7581/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (465/2:ℝ)*hg0 + (513/2:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2807629/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (465/2:ℝ)*hg0 + (513/2:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (1384900/4693:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (85204/361:ℝ)*hg0 + (93868/361:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (1420344/4693:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (85204/361:ℝ)*hg0 + (93868/361:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_13
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_14
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (5539/26:ℝ)*hg0 + (6163/26:ℝ)*hgap + (1/1:ℝ)*hH0 + (7411/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (5539/26:ℝ)*hg0 + (6163/26:ℝ)*hgap + (1/1:ℝ)*hH0 + (2711147/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (2085515/9386:ℝ)*hg0 + (2310779/9386:ℝ)*hgap + (1/1:ℝ)*hH0 + (2761307/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (2085515/9386:ℝ)*hg0 + (2310779/9386:ℝ)*hgap + (1/1:ℝ)*hH0 + (2797083/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_15
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (12/23 : ℝ) (25/24 : ℝ) (83/80 : ℝ) greedybundle29_cached_cap_007.1 greedybundle29_cached_cap_007.2.1 greedybundle29_cached_cap_007.2.2.1 greedybundle29_cached_cap_007.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (609/2:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (465/2:ℝ)*hg0 + (513/2:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (222601/722:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (465/2:ℝ)*hg0 + (513/2:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (111196/361:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (85204/361:ℝ)*hg0 + (93868/361:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (112572/361:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (85204/361:ℝ)*hg0 + (93868/361:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_16
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_17
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (12/23 : ℝ) (25/24 : ℝ) (83/80 : ℝ) greedybundle29_cached_cap_007.1 greedybundle29_cached_cap_007.2.1 greedybundle29_cached_cap_007.2.2.1 greedybundle29_cached_cap_007.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle29_cached_cap_004.1 greedybundle29_cached_cap_004.2.1 greedybundle29_cached_cap_004.2.2.1 greedybundle29_cached_cap_004.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (917/10:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3141/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (917/10:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1137629/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (171876/1805:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (573308/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (171876/1805:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (575172/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_18
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t23_r3_all_cell_19
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (22/23 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t23_r3_all_cell_20
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle29_cached_cap_001.1 greedybundle29_cached_cap_001.2.1 greedybundle29_cached_cap_001.2.2.1 greedybundle29_cached_cap_001.2.2.2.1 greedybundle29_cached_cap_001.2.2.2.2.1 greedybundle29_cached_cap_001.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (6787/624:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (126149/624:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (2533307/225264:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (45456589/225264:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (2536043/225264:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47516317/225264:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (873081/75088:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15811039/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_21
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (7075/624:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (125861/624:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2624963/225264:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (45364933/225264:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2640011/225264:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47412349/225264:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (903633/75088:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15780487/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_22
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (12/23 : ℝ) (25/24 : ℝ) (83/80 : ℝ) greedybundle29_cached_cap_007.1 greedybundle29_cached_cap_007.2.1 greedybundle29_cached_cap_007.2.2.1 greedybundle29_cached_cap_007.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7581/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (465/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2807629/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (465/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (1384900/4693:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85204/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (1420344/4693:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85204/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_23
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_24
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (7411/624:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (125525/624:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (2711147/225264:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (45278749/225264:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (2761307/225264:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (47291053/225264:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (932361/75088:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15751759/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_25
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (12/23 : ℝ) (25/24 : ℝ) (83/80 : ℝ) greedybundle29_cached_cap_007.1 greedybundle29_cached_cap_007.2.1 greedybundle29_cached_cap_007.2.2.1 greedybundle29_cached_cap_007.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (609/2:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (465/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (222601/722:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (465/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (111196/361:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85204/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (112572/361:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85204/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_26
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_27
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (13/46 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (13/46 : ℝ) (3/13 : ℝ) (4/13 : ℝ) greedybundle29_cached_cap_000.1 greedybundle29_cached_cap_000.2.1 greedybundle29_cached_cap_000.2.2.1 greedybundle29_cached_cap_000.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.1 greedybundle29_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle29_cached_cap_004.1 greedybundle29_cached_cap_004.2.1 greedybundle29_cached_cap_004.2.2.1 greedybundle29_cached_cap_004.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (38303/3120:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (187081/3120:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (13875847/1126320:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (67487777/1126320:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (14257063/1126320:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (77418881/1126320:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (4768509/375440:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (25790139/375440:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_28
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/46 : ℝ) ≤ q) (hqu : q ≤ (12/23 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (12/23 : ℝ) (25/24 : ℝ) (83/80 : ℝ) greedybundle29_cached_cap_007.1 greedybundle29_cached_cap_007.2.1 greedybundle29_cached_cap_007.2.2.1 greedybundle29_cached_cap_007.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.1 greedybundle29_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle29_cached_cap_004.1 greedybundle29_cached_cap_004.2.1 greedybundle29_cached_cap_004.2.2.1 greedybundle29_cached_cap_004.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3141/10:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (917/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (1137629/3610:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (917/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (573308/1805:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (171876/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (575172/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (171876/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t23_r3_all_cell_29
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (12/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t23_r3_all_cell_30
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/23 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (22/23 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (22/23 : ℝ) (65/44 : ℝ) (629/440 : ℝ) greedybundle29_cached_cap_006.1 greedybundle29_cached_cap_006.2.1 greedybundle29_cached_cap_006.2.2.1 greedybundle29_cached_cap_006.2.2.2.1 greedybundle29_cached_cap_006.2.2.2.2.1 greedybundle29_cached_cap_006.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5345/22:ℝ)*hzl + (60374/6457:ℝ)*hem + (1210080/6457:ℝ)*ho0 + (477792/32285:ℝ)*hgap + (19908/32285:ℝ)*hS + (1/1:ℝ)*hI + (12377/32285:ℝ)*hsource + (1/1:ℝ)*hR + (654/11:ℝ)*hmass
  · linear_combination (1933483/7942:ℝ)*hzl + (415064169/44288563:ℝ)*hem + (8322716112/44288563:ℝ)*ho0 + (3277647888/221442815:ℝ)*hgap + (136568662/221442815:ℝ)*hS + (1/1:ℝ)*hI + (84874153/221442815:ℝ)*hsource + (1/1:ℝ)*hR + (238063/3971:ℝ)*hmass
  · linear_combination (5345/22:ℝ)*hzl + (2073213746/221751475:ℝ)*hem + (8303608968/44350295:ℝ)*ho0 + (3277175328/221751475:ℝ)*hgap + (136548972/221751475:ℝ)*hS + (1/1:ℝ)*hI + (85202503/221751475:ℝ)*hsource + (1/1:ℝ)*hR + (654/11:ℝ)*hmass
  · linear_combination (1933483/7942:ℝ)*hzl + (750163384401/80052282475:ℝ)*hem + (3005836525988/16010456495:ℝ)*ho0 + (3277647888/221751475:ℝ)*hgap + (136568662/221751475:ℝ)*hS + (1/1:ℝ)*hI + (85182813/221751475:ℝ)*hsource + (1/1:ℝ)*hR + (238063/3971:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t24_r3_all_cell_0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (9/32 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (9/32 : ℝ) (2/9 : ℝ) (3/10 : ℝ) greedybundle29_cached_cap_008.1 greedybundle29_cached_cap_008.2.1 greedybundle29_cached_cap_008.2.2.1 greedybundle29_cached_cap_008.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle29_cached_cap_001.1 greedybundle29_cached_cap_001.2.1 greedybundle29_cached_cap_001.2.2.1 greedybundle29_cached_cap_001.2.2.2.1 greedybundle29_cached_cap_001.2.2.2.2.1 greedybundle29_cached_cap_001.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (1277/6:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5060/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (1277/6:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1823460/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (160319/722:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1906500/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (160319/722:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1903300/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (9/32 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (9/32 : ℝ) (2/9 : ℝ) (3/10 : ℝ) greedybundle29_cached_cap_008.1 greedybundle29_cached_cap_008.2.1 greedybundle29_cached_cap_008.2.2.1 greedybundle29_cached_cap_008.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (1277/6:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (65636/13:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (1277/6:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (23659152/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (160319/722:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (24732516/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (160319/722:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (24697072/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_2
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (9/32 : ℝ) ≤ q) (hqu : q ≤ (25/48 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t24_r3_all_cell_3
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (25/48 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t24_r3_all_cell_4
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (31/192 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (31/192 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle29_cached_cap_009.1 greedybundle29_cached_cap_009.2.1 greedybundle29_cached_cap_009.2.2.1 greedybundle29_cached_cap_009.2.2.2.1 greedybundle29_cached_cap_009.2.2.2.2.1 greedybundle29_cached_cap_009.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (415/2:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4908/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (415/2:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1770412/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (156215/722:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1848588/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (156215/722:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1847212/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_5
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (31/192 : ℝ) ≤ q) (hqu : q ≤ (9/32 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t24_r3_all_cell_6
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (9/32 : ℝ) ≤ q) (hqu : q ≤ (25/48 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t24_r3_all_cell_7
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (25/48 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t24_r3_all_cell_8
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (9/32 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (9/32 : ℝ) (2/9 : ℝ) (3/10 : ℝ) greedybundle29_cached_cap_008.1 greedybundle29_cached_cap_008.2.1 greedybundle29_cached_cap_008.2.2.1 greedybundle29_cached_cap_008.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle29_cached_cap_004.1 greedybundle29_cached_cap_004.2.1 greedybundle29_cached_cap_004.2.2.1 greedybundle29_cached_cap_004.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (2161/30:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (7532/5:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (2161/30:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (2717188/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (293307/3610:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3118252/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (293307/3610:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (3116388/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_9
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (9/32 : ℝ) ≤ q) (hqu : q ≤ (25/48 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t24_r3_all_cell_10
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (25/48 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t24_r3_all_cell_11
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (19/250 : ℝ))
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (23/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (23/24 : ℝ) (34/23 : ℝ) (329/230 : ℝ) greedybundle29_cached_cap_010.1 greedybundle29_cached_cap_010.2.1 greedybundle29_cached_cap_010.2.2.1 greedybundle29_cached_cap_010.2.2.2.1 greedybundle29_cached_cap_010.2.2.2.2.1 greedybundle29_cached_cap_010.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (11177/46:ℝ)*hzl + (59969/6693:ℝ)*hem + (1252241/6693:ℝ)*ho0 + (164656/11155:ℝ)*hgap + (20582/33465:ℝ)*hS + (1/1:ℝ)*hI + (12883/33465:ℝ)*hsource + (1/1:ℝ)*hR + (1368/23:ℝ)*hmass
  · linear_combination (4043017/16606:ℝ)*hzl + (14465493/1610782:ℝ)*hem + (302188389/1610782:ℝ)*ho0 + (59448936/4026955:ℝ)*hgap + (2477039/4026955:ℝ)*hS + (1/1:ℝ)*hI + (1549916/4026955:ℝ)*hsource + (1/1:ℝ)*hR + (497908/8303:ℝ)*hmass
  · linear_combination (11177/46:ℝ)*hzl + (541922701/60488505:ℝ)*hem + (2261296381/12097701:ℝ)*ho0 + (59440816/4032567:ℝ)*hgap + (7430102/12097701:ℝ)*hS + (1/1:ℝ)*hI + (4667599/12097701:ℝ)*hsource + (1/1:ℝ)*hR + (1368/23:ℝ)*hmass
  · linear_combination (4043017/16606:ℝ)*hzl + (130720549649/14557566870:ℝ)*hem + (545693021249/2911513374:ℝ)*ho0 + (19816312/1344189:ℝ)*hgap + (2477039/4032567:ℝ)*hS + (1/1:ℝ)*hI + (1555528/4032567:ℝ)*hsource + (1/1:ℝ)*hR + (497908/8303:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_12
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (9/32 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (9/32 : ℝ) (2/9 : ℝ) (3/10 : ℝ) greedybundle29_cached_cap_008.1 greedybundle29_cached_cap_008.2.1 greedybundle29_cached_cap_008.2.2.1 greedybundle29_cached_cap_008.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (1277/6:ℝ)*hg0 + (1421/6:ℝ)*hgap + (1/1:ℝ)*hH0 + (21209/78:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (1277/6:ℝ)*hg0 + (1421/6:ℝ)*hgap + (1/1:ℝ)*hH0 + (7869113/28158:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (160319/722:ℝ)*hg0 + (177647/722:ℝ)*hgap + (1/1:ℝ)*hH0 + (2638643/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (160319/722:ℝ)*hg0 + (177647/722:ℝ)*hgap + (1/1:ℝ)*hH0 + (2709531/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_13
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (9/32 : ℝ) ≤ q) (hqu : q ≤ (25/48 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (25/48 : ℝ) (26/25 : ℝ) (259/250 : ℝ) greedybundle29_cached_cap_011.1 greedybundle29_cached_cap_011.2.1 greedybundle29_cached_cap_011.2.2.1 greedybundle29_cached_cap_011.2.2.2.1 greedybundle29_cached_cap_011.2.2.2.2.1 greedybundle29_cached_cap_011.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (189499/650:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (11623/50:ℝ)*hg0 + (12823/50:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (70181339/234650:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (11623/50:ℝ)*hg0 + (12823/50:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (69238331/234650:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (4259687/18050:ℝ)*hg0 + (4692887/18050:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (71010531/234650:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (4259687/18050:ℝ)*hg0 + (4692887/18050:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_14
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (25/48 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle29_cached_cap_002.1 greedybundle29_cached_cap_002.2.1 greedybundle29_cached_cap_002.2.2.1 greedybundle29_cached_cap_002.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.1 greedybundle29_cached_cap_002.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_15
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (9/32 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (9/32 : ℝ) (2/9 : ℝ) (3/10 : ℝ) greedybundle29_cached_cap_008.1 greedybundle29_cached_cap_008.2.1 greedybundle29_cached_cap_008.2.2.1 greedybundle29_cached_cap_008.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.1 greedybundle29_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (1277/6:ℝ)*hg0 + (1421/6:ℝ)*hgap + (1/1:ℝ)*hH0 + (1709/6:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (1277/6:ℝ)*hg0 + (1421/6:ℝ)*hgap + (1/1:ℝ)*hH0 + (625205/2166:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (160319/722:ℝ)*hg0 + (177647/722:ℝ)*hgap + (1/1:ℝ)*hH0 + (212303/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (160319/722:ℝ)*hg0 + (177647/722:ℝ)*hgap + (1/1:ℝ)*hH0 + (215055/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_16
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (9/32 : ℝ) ≤ q) (hqu : q ≤ (25/48 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (25/48 : ℝ) (26/25 : ℝ) (259/250 : ℝ) greedybundle29_cached_cap_011.1 greedybundle29_cached_cap_011.2.1 greedybundle29_cached_cap_011.2.2.1 greedybundle29_cached_cap_011.2.2.2.1 greedybundle29_cached_cap_011.2.2.2.2.1 greedybundle29_cached_cap_011.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (15223/50:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (11623/50:ℝ)*hg0 + (12823/50:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (5564303/18050:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (11623/50:ℝ)*hg0 + (12823/50:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (5559287/18050:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (4259687/18050:ℝ)*hg0 + (4692887/18050:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (5628087/18050:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (4259687/18050:ℝ)*hg0 + (4692887/18050:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_17
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (25/48 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle29_cached_cap_003.1 greedybundle29_cached_cap_003.2.1 greedybundle29_cached_cap_003.2.2.1 greedybundle29_cached_cap_003.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.1 greedybundle29_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_18
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle29_cached_cap_005.1 greedybundle29_cached_cap_005.2.1 greedybundle29_cached_cap_005.2.2.1 greedybundle29_cached_cap_005.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.1 greedybundle29_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle29_cached_cap_004.1 greedybundle29_cached_cap_004.2.1 greedybundle29_cached_cap_004.2.2.1 greedybundle29_cached_cap_004.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.1 greedybundle29_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (432416/2435:ℝ)*ho0 + (33792/2435:ℝ)*hgap + (516896/2435:ℝ)*hgate + (1408/2435:ℝ)*hS + (1/1:ℝ)*hI + (1027/2435:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (157009944/879035:ℝ)*ho0 + (33792/2435:ℝ)*hgap + (187507224/879035:ℝ)*hgate + (1408/2435:ℝ)*hS + (1/1:ℝ)*hI + (1027/2435:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (156172448/880255:ℝ)*ho0 + (12198912/880255:ℝ)*hgap + (186841504/880255:ℝ)*hgate + (508288/880255:ℝ)*hS + (1/1:ℝ)*hI + (371967/880255:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (56706412792/317772055:ℝ)*ho0 + (12198912/880255:ℝ)*hgap + (67777942008/317772055:ℝ)*hgate + (508288/880255:ℝ)*hS + (1/1:ℝ)*hI + (371967/880255:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t24_r3_all_cell_19
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/24 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (23/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

end TSP.Improvements20261105
