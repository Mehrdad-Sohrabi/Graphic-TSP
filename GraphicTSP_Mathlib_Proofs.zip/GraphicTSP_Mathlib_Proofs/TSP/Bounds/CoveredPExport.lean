import TSP.Improvements20261105.CoveredPArms

/-! A positive unary export is exactly one of the fixed cover links.
The extension to actual star coordinates agrees at every child. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem coveredPIncrease_export_link (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (s : d.tree.Child) (hunary : childCount d s = 1)
    (hexport : outgoingBackMass d x s < coveredPIncrease d x P Q C.cover s) :
    s ∈ projectionLinks d x := by
  have ho : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hb := coveredPIncrease_bounds d hs x z hx hn hcap hm P Q hP hQ C s
  have he := (survivingExcess_bounds d hs hx hcap s).2
  have hr : d.tree.parent s ≠ d.tree.root := by
    intro h
    rw [coveredPIncrease, if_pos h] at hexport
    linarith
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hr, by linarith, hunary, by linarith⟩

theorem coveredPIncrease_inactive (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (s : d.tree.Child) (hinactive : ¬(d.backGroup s).Nonempty) :
    coveredPIncrease d x P Q C.cover s = 0 := by
  have he := Finset.not_nonempty_iff_eq_empty.mp hinactive
  have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent s)
  have hz : survivingExcess d x s = 0 := by
    rw [survivingExcess, he]
    simp only [edgeSum, Finset.sum_empty]
    apply max_eq_right
    linarith
  have hb := coveredPIncrease_bounds d hs x z hx hn hcap hm P Q hP hQ C s
  rw [hz] at hb
  exact le_antisymm hb.2 hb.1

theorem coveredPIncrease_extension (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child) :
    extendNonrootRepairs d (fun i => coveredPIncrease d x P Q C.cover i.1) s = coveredPIncrease d x P Q C.cover s := by
  by_cases ha : (d.backGroup s).Nonempty
  · by_cases hr : d.tree.parent s = d.tree.root
    · rw [extendNonrootRepairs_root d _ s hr, coveredPIncrease, if_pos hr]
    · simp only [extendNonrootRepairs, dif_pos ha, if_neg hr]
  · rw [extendNonrootRepairs_inactive d _ s ha, coveredPIncrease_inactive d hs x z hx hn hcap hm P Q hP hQ C s ha]

theorem starTau_le_fixedProjectionCharge (hs : G.IsSimple) (x : E → ℝ)
    (T : Finset d.tree.Child) (i : d.StarIndex) :
    Manuscript20261020.starTau d x i ≤ fixedProjectionCharge d x T i.1 := by
  unfold Manuscript20261020.starTau Manuscript20261020.eta
  rw [loopless_degree_eq_cut G hs.1]
  change Manuscript20261020.tau (x (d.treeEdge i.1) + edgeSum x (d.backGroup i.1))
    (degreeExcess G x (d.centers i)) ≤ _
  rw [← group_mass_eq_tree_add_backs]
  exact le_max_left _ _

end TSP.Improvements20261105
