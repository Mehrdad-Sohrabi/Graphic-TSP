import TSP.Improvements20261105.FixedQFloorBound

/-! At a fixed cover-link receiver, the actual Q connector supplies the
exact negative baseline required by the P interval inequality. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem fixedQ_link_connector (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hl : v ∈ projectionLinks d x) :
    Y (.inr i) - edgeSum x (d.stars i) / 2 =
      -(1 - x (d.treeEdge v) - outgoingBackMass d x v) - degreeExcess G x (d.centers i) / 2 := by
  have hunary := (Finset.mem_filter.mp hl).2.2.2.1
  have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v hunary).2 i.1 hv).symm
  have ht := projectionLinks_override d x v hl
  rw [hnext] at ht
  have hnorm := fixedQ_full_removal_connector d hs x z hx hn hcap Y hY i
    (override_full_removal_identity d hs x z hm i.1 ht) (override_projected_heavy d hs x z hm i.1 ht)
  have hev : Even (G.intDegree d.treeEdges (d.centers i)) := by
    rw [hv, tree_degree_eq, if_neg v.2, hunary]
    norm_num
  rw [if_pos hev] at hnorm
  have hi := projectionLinks_receiver_identity d hs x z hm v hl
  rw [hnext] at hi
  linarith

end TSP.Improvements20261105
