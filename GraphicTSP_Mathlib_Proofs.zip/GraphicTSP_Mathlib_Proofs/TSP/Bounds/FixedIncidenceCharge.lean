import TSP.Improvements20261105.CanonicalCriticalIncidence

/-! A fixed critical classification and its exact headwise charge.
It is independent of the subsequently chosen circulation dual. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def fixedIncidenceCharge (x z : E → ℝ) (C : Finset d.tree.Child)
    (s : d.tree.Child) : ℝ :=
  if s ∈ C then clippedCriticalIncidence d x z s else noncriticalIncidence d z s

noncomputable def retainedIncidenceHeads (z : E → ℝ) (H C : Finset d.tree.Child) : Finset d.tree.Child :=
  if (H ∩ C).Nonempty then H \ countExcluded d (9 / 20) z H (H ∩ C)
  else H \ countExcluded d (1 / 2) z H ∅

theorem fixedIncidenceCharge_sum (x z : E → ℝ) (H C : Finset d.tree.Child) :
    (∑ s ∈ H, fixedIncidenceCharge d x z C s) =
      (∑ s ∈ H ∩ C, clippedCriticalIncidence d x z s) +
      ∑ s ∈ H \ (H ∩ C), noncriticalIncidence d z s := by
  rw [← Finset.sum_sdiff (f := fixedIncidenceCharge d x z C) Finset.inter_subset_left]
  have hi : (∑ s ∈ H ∩ C, fixedIncidenceCharge d x z C s) =
      ∑ s ∈ H ∩ C, clippedCriticalIncidence d x z s := by
    apply Finset.sum_congr rfl
    intro s hs
    simp only [fixedIncidenceCharge, if_pos (Finset.mem_inter.mp hs).2]
  have ho : (∑ s ∈ H \ (H ∩ C), fixedIncidenceCharge d x z C s) =
      ∑ s ∈ H \ (H ∩ C), noncriticalIncidence d z s := by
    apply Finset.sum_congr rfl
    intro s hs
    have hm := Finset.mem_sdiff.mp hs
    have hn : s ∉ C := fun hc => hm.2 (Finset.mem_inter.mpr ⟨hm.1, hc⟩)
    simp only [fixedIncidenceCharge, if_neg hn]
  rw [hi, ho, add_comm]

theorem fixedIncidenceCharge_sum_noncritical (x z : E → ℝ) (H C : Finset d.tree.Child)
    (hC : ¬(H ∩ C).Nonempty) :
    (∑ s ∈ H, fixedIncidenceCharge d x z C s) = ∑ s ∈ H, noncriticalIncidence d z s := by
  rw [fixedIncidenceCharge_sum, Finset.not_nonempty_iff_eq_empty.mp hC]
  simp

theorem ScoreComparisons.restrict {x : E → ℝ} {C C' : Finset d.tree.Child}
    (h : ScoreComparisons d x C) (hsub : C' ⊆ C) : ScoreComparisons d x C' where
  maximum_le := fun s hs => h.maximum_le s (hsub hs)
  dominates := fun s hs e he => h.dominates s (hsub hs) e he

theorem retainedIncidenceHeads_singleton (z : E → ℝ) (s : d.tree.Child)
    (C : Finset d.tree.Child) (hs : s ∈ C) : retainedIncidenceHeads d z {s} C = {s} := by
  have hi : {s} ∩ C = {s} := Finset.inter_eq_left.mpr (Finset.singleton_subset_iff.mpr hs)
  simp [retainedIncidenceHeads, hi, countExcluded]

end TSP.Improvements20261105
