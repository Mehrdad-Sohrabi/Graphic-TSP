import TSP.Improvements20261105.ActualNonfrozenPairSurplus
import TSP.Improvements20261105.RemainingLeafHeadCost

/-! Actual nonfrozen matching pairs, in the actual scored DFS and
simultaneous guarded construction, pay their source-complement fee
and retain the surplus 61/5 using their original source back count. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_large_single_pair_leaf_cost
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum x ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : (r : FlowVertex d) ≠ .inl (d).tree.root)
    (hleaf : r ∈ a.headfulLeafComponents d P) (hnotK : (r : FlowVertex d) ∉ a.KLeafRoots d P x z C)
    (hone : (a.matchingPairsAt d P x z C r).card = 1)
    (hlarge : (3 : ℝ) ≤ ∑ i ∈ a.actualComponentStars d P r \ pairStarHeads d (a.matchingPairsAt d P x z C r),
      (((d).backGroup i.1).card : ℝ)) :
    (∑ i ∈ a.actualComponentStars d P r, guardedNormalizedHeadCost d x z C owner rootStar R a i)+24 ≤
      4*∑ i ∈ a.actualComponentStars d P r, (((d).backGroup i.1).card : ℝ) := by
  obtain ⟨p,hp⟩ := Finset.card_eq_one.mp hone
  have hpmem : p ∈ a.matchingPairsAt d P x z C r := by rw [hp]; exact Finset.mem_singleton_self _
  have hpair := (Finset.mem_filter.mp (Finset.mem_filter.mp hpmem).1).2
  have hnf := a.single_matching_pair_nonfrozen d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan r p hpmem hone
  have hcost := scoredDFS_nonfrozen_pair_leaf_surplus G x z hs hc root hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero p.1 p.2 hpair.1 hpair.2.symm hnf
  have hgamma := (survivingExcess_bounds d hs hx hcap p.1.1).2
  have htarget : (1 : ℝ) ≤ ((d).backGroup p.2.1).card := by exact_mod_cast Finset.card_pos.mpr p.2.2
  have hj1 := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.1)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.1)
    (a.head p.1.1) (by exact_mod_cast ha.head_nonneg p.1.1)
  have hj2 := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.2)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.2)
    (a.head p.2.1) (by exact_mod_cast ha.head_nonneg p.2.1)
  have hpaircost : guardedNormalizedHeadCost d x z C owner rootStar R a p.1+
      guardedNormalizedHeadCost d x z C owner rootStar R a p.2+(61/5 : ℝ) ≤
        4*(((d).backGroup p.1.1).card+((d).backGroup p.2.1).card : ℝ) := by
    unfold guardedNormalizedHeadCost
    linarith only [hcost,hj1,hj2,hgamma,htarget]
  have hrest := a.remaining_leaf_head_sum_nonpositive d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero P hP t ht f hf hb ha hcan r hr hleaf hnotK
  have hsub : pairStarHeads d (a.matchingPairsAt d P x z C r) ⊆ a.actualComponentStars d P r := by
    simpa only [GatedDrops.matchingPairsForRoots,GatedDrops.componentStarUnion,Finset.singleton_biUnion] using
      a.matchingPairHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan {(r : FlowVertex d)}
  have hJ : a.matchingPairsAt d P x z C r ⊆ fixedMatchingStarPairs d x z C := Finset.filter_subset _ _
  have hcostsum := Finset.sum_sdiff hsub (f := guardedNormalizedHeadCost d x z C owner rootStar R a)
  have hbacksum := Finset.sum_sdiff hsub (f := fun i => (((d).backGroup i.1).card : ℝ))
  have hcostpair := fixedMatchingStarPair_family_sum d x z C _ hJ (guardedNormalizedHeadCost d x z C owner rootStar R a)
  have hbackpair := fixedMatchingStarPair_family_sum d x z C _ hJ (fun i => (((d).backGroup i.1).card : ℝ))
  rw [hp,Finset.sum_singleton] at hcostpair hbackpair
  rw [← hp] at hcostpair hbackpair
  linarith only [hpaircost,hrest,hcostsum,hbacksum,hcostpair,hbackpair,hlarge]

theorem scoredDFS_large_no_pair_leaf_cost
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum x ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : (r : FlowVertex d) ≠ .inl (d).tree.root)
    (hleaf : r ∈ a.headfulLeafComponents d P) (hnotK : (r : FlowVertex d) ∉ a.KLeafRoots d P x z C)
    (hno : a.matchingPairsAt d P x z C r = ∅)
    (hlarge : (6 : ℝ) ≤ ∑ i ∈ a.actualComponentStars d P r, (((d).backGroup i.1).card : ℝ)) :
    (∑ i ∈ a.actualComponentStars d P r, guardedNormalizedHeadCost d x z C owner rootStar R a i)+24 ≤
      4*∑ i ∈ a.actualComponentStars d P r, (((d).backGroup i.1).card : ℝ) := by
  have hrest := a.remaining_leaf_head_sum_nonpositive d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero P hP t ht f hf hb ha hcan r hr hleaf hnotK
  simp only [hno,pairStarHeads,Finset.image_empty,Finset.union_empty,Finset.sdiff_empty] at hrest
  linarith only [hrest,hlarge]

end TSP.Improvements20261105
