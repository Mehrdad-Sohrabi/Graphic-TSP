import TSP.Improvements20261105.LeafCoverageAllocation

/-! Entering coverage may be clipped upward to one without a second
shortage reserve. The exact negative true-cut deficit retained in the
remaining-coverage theorem pays for this clipping once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_leaf_clipped_coverage (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (W : Finset (expandedTree d).Child) (hW : W ⊆ a.trueCuts d P) (K : ℝ) :
    24*K+24*(a.activeGateDeficit d P x-a.coverageExcess d P (fun b => x b.1)) ≤
      (∑ w ∈ W, 24*(2-max (componentEntryCoverage d x (w : FlowVertex d)) 1))+
      24*(K-W.card)+24*(edgeSum x Finset.univ-Fintype.card V-totalOverage d x/2) := by
  have hrem := canonical_remaining_coverage_reserve d hs hc P hP t f hf hb a ha hcan hx hcap W hW
  have hlocal (w : (expandedTree d).Child) (_hw : w ∈ W) :
      max (componentEntryCoverage d x (w : FlowVertex d)) 1 ≤
        a.cutCoverage d (fun b => x b.1) w+max (1-a.cutCoverage d (fun b => x b.1) w) 0 := by
    have he := a.entry_coverage_le_cut d x hx.1 w
    have h0 := le_max_right (1-a.cutCoverage d (fun b => x b.1) w) 0
    have h1 := le_max_left (1-a.cutCoverage d (fun b => x b.1) w) 0
    exact max_le (by linarith only [he,h0]) (by linarith only [h1])
  have hsum := Finset.sum_le_sum hlocal
  rw [a.coverageExcess_split d P _ W hW]
  simp only [Finset.sum_add_distrib,Finset.sum_sub_distrib,Finset.sum_const,
    nsmul_eq_mul,mul_one,← Finset.mul_sum] at hrem hsum ⊢
  linarith only [hrem,hsum]

end TSP.Improvements20261105
