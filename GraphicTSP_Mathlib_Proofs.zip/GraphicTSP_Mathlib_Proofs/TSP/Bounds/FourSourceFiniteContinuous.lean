import TSP.Improvements20261105.ScoredSourceCount4Continuous
import TSP.Improvements20261105.GreedySourceCount4Continuous
/-! Exhaustive selection of the continuous source rows. The score intervals
cover real values, and both ramp packing and the critical floor are retained. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 8000000

theorem scored_source_four_per_back (t j : ℕ) (ht0 : 4 ≤ t) (ht1 : t ≤ 4)
    (hj : j < sourceScoreDenominator t) (B b : ℝ) (hb0 : 0 ≤ b) (hbB : b ≤ B)
    (hB : B ≤ ((j : ℝ)+1)/(sourceScoreDenominator t : ℝ)) :
    (360/19)*max ((19/10)*b-9/20) 0+
      (96/19)*min ((ScoredParameters.localMassSlope t/ScoredParameters.coefficient t)*(B-b))
        ((100/57)*b) ≤ sourceScoreSlope t j*b := by
  interval_cases t
  · have hh := scored_source_4_per_back j (by simpa [sourceScoreDenominator] using hj) B b hb0 hbB
      (by simpa [sourceScoreDenominator] using hB)
    convert hh using 1 <;> norm_num [ScoredParameters.localMassSlope,ScoredParameters.upper,ScoredParameters.coefficient]

theorem scored_source_four_continuous (t j k bad : ℕ) (ht0 : 4 ≤ t) (ht1 : t ≤ 4)
    (hj : j < sourceScoreDenominator t) (hk : k < t) (hbad : bad ≤ 1)
    (M q R a I g : ℝ)
    (hlo : ScoredParameters.lower t ≤ M) (hhi : M ≤ ScoredParameters.upper t)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R)
    (hchoice : M ≤ q+ScoredParameters.coefficient t*R) (hcap : M+R ≤ 1)
    (ha : 1 ≤ a) (hcount : a ≤ (t : ℝ)*M) (hpack : a+q ≤ 2) (hRE : R ≤ a-1)
    (hka : (k : ℝ)*M ≤ a) (hak : a ≤ ((k : ℝ)+1)*M)
    (hscorelo : (j : ℝ)/(sourceScoreDenominator t : ℝ) ≤ q+ScoredParameters.coefficient t*R)
    (hscorehi : q+ScoredParameters.coefficient t*R ≤ ((j : ℝ)+1)/(sourceScoreDenominator t : ℝ))
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hggap : g+q+a ≤ 2)
    (hgood : t%2=0 → bad=0 → a+q-1 ≤ ((t : ℝ)/2)*M)
    (hN : I ≤ max (24*greedyOldEnvelope M a k)
      ((360/19)*packedSignedMu M a k+(96/19)*((100/57)*a-1)))
    (hC : I ≤ max (min
      ((360/19)*packedSignedMu M a k+
        (96/19)*(ScoredParameters.localMassSlope t/ScoredParameters.coefficient t)*
          ((t : ℝ)*(q+ScoredParameters.coefficient t*R)-a)-96/19)
      (min (sourceScoreSlope t j*a-(360/19)*(1/10)-96/19)
        (if t=7 then sourceScoreSecantSlope t j*a+(t : ℝ)*sourceScoreSecantOffset t j-(360/19)*(1/10)-96/19
         else sourceScoreSlope t j*a-(360/19)*(1/10)-96/19)))
      (-(124/5)*(2-a))) :
    (415/2)*(a-1-R)-(704/5)+24*(a-1+g)+I ≤ 4*((t : ℝ)+1)+2*(bad : ℝ) := by
  interval_cases t
  · have hh := scored_source_4_continuous j k (by simpa [sourceScoreDenominator] using hj) hk bad hbad M q R a I g
      (by convert hlo using 1 <;> norm_num [ScoredParameters.lower])
      (by simpa [ScoredParameters.upper] using hhi) hq0 hqM hR0
      (by simpa [ScoredParameters.coefficient] using hchoice) hcap ha (by simpa using hcount) hpack hRE hka hak
      (by simpa [sourceScoreDenominator,ScoredParameters.coefficient] using hscorelo)
      (by simpa [sourceScoreDenominator,ScoredParameters.coefficient] using hscorehi) hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by simpa only [le_max_iff] using hN)
      (by convert hC using 1 <;> norm_num [ScoredParameters.localMassSlope,ScoredParameters.upper,ScoredParameters.coefficient,
        le_max_iff,le_min_iff,and_assoc])
    convert hh using 1 <;> norm_num

theorem greedy_source_four_continuous (t k bad : ℕ) (ht0 : 4 ≤ t) (ht1 : t ≤ 4)
    (hk : k < t) (hbad : bad ≤ 1) (q a I g : ℝ) (hq0 : 0 ≤ q) (hq1 : q ≤ 1)
    (ha : 1 ≤ a) (hcount : a ≤ (t : ℝ)*q) (hpack : a+q ≤ 2)
    (hka : (k : ℝ)*q ≤ a) (hak : a ≤ ((k : ℝ)+1)*q)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hggap : g+q+a ≤ 2)
    (hgood : t%2=0 → bad=0 → a+q-1 ≤ ((t : ℝ)/2)*q)
    (hgate : 4 ≤ t → t ≤ 25 → q ≤ ScoredParameters.lower t ∨
      ScoredParameters.upper t ≤ q ∨ q+a ≤ 2-ScoredParameters.incomingThreshold t)
    (hN : I ≤ max (24*greedyOldEnvelope q a k)
      ((360/19)*packedSignedMu q a k+(96/19)*((100/57)*a-1))) :
    (415/2)*(a-1)-(704/5)+24*(a-1+g)+I ≤ 4*((t : ℝ)+1)+2*(bad : ℝ) := by
  interval_cases t
  · have hh := greedy_source_4_continuous k hk bad hbad q a I g hq0 hq1 ha
      (by simpa using hcount) hpack hka hak hg0 hghalf hggap
      (by intro hb; convert hgood (by norm_num) hb using 1 <;> norm_num)
      (by convert hgate (by norm_num) (by norm_num) using 1 <;>
        norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold])
      (by simpa only [le_max_iff] using hN)
    convert hh using 1 <;> norm_num

end TSP.Improvements20261105
