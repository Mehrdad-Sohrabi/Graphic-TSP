import TSP.Improvements20261105.GreedyFinitePackingScalar
import TSP.Improvements20261105.GreedyHeadLoads

/-! Actual finite edge sums lie below the continuous packing envelopes. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {I : Type} [DecidableEq I]

theorem greedy_old_actual_envelope (S : Finset I) (z : I → ℝ) (q : ℝ) (k : ℕ)
    (hz : ∀ i ∈ S, 0 ≤ z i) (hcap : ∀ i ∈ S, z i ≤ q) :
    (∑ i ∈ S, incidenceRamp (1/2) (z i)) ≤
      greedyOldEnvelope q (∑ i ∈ S, z i) k := by
  unfold greedyOldEnvelope
  split_ifs with hq
  · apply Finset.sum_nonpos
    intro i hi
    unfold incidenceRamp
    apply max_le <;> linarith only [hcap i hi,hq]
  · have hh := packed_ramp_envelope S z (1/2) q k (by norm_num) hz hcap (by linarith)
    simpa only [packedOldRamp,show (1+2*(1/2) : ℝ)=2 by norm_num] using hh

theorem greedy_mu_actual_envelope (S : Finset I) (z : I → ℝ) (q : ℝ) (k : ℕ)
    (hz : ∀ i ∈ S, 0 ≤ z i) (hcap : ∀ i ∈ S, z i ≤ q) :
    (∑ i ∈ S, incidenceRamp (9/20) (z i))-1/10 ≤
      greedyMuEnvelope q (∑ i ∈ S, z i) k := by
  unfold greedyMuEnvelope
  split_ifs with hq
  · have hh : (∑ i ∈ S, incidenceRamp (9/20) (z i)) ≤ 0 := by
      apply Finset.sum_nonpos
      intro i hi
      unfold incidenceRamp
      apply max_le <;> linarith only [hcap i hi,hq]
    linarith
  · have hh := packed_ramp_envelope S z (9/20) q k (by norm_num) hz hcap (by linarith)
    norm_num only at hh
    have hb := le_max_left ((k : ℝ)*((19/10)*q-9/20)+
      max ((19/10)*((∑ i ∈ S, z i)-k*q)-9/20) 0-1/10) 0
    linarith only [hh,hb]

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem greedy_noncritical_envelope (z : E → ℝ) (s : d.tree.Child) (q : ℝ) (k : ℕ)
    (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e) (hcap : ∀ e ∈ d.backGroup s, z e ≤ q) :
    noncriticalIncidence d z s ≤
      max (24*greedyOldEnvelope q (edgeSum z (d.backGroup s)) k)
        ((360/19)*greedyMuEnvelope q (edgeSum z (d.backGroup s)) k+
          (96/19)*((100/57)*edgeSum z (d.backGroup s)-1)) := by
  have ho := greedy_old_actual_envelope (d.backGroup s) z q k hz hcap
  have hn := greedy_mu_actual_envelope (d.backGroup s) z q k hz hcap
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h3 := min_le_right (((d.backGroup s).card : ℝ)-1)
    (ScoredParameters.massSlope*edgeSum z (d.backGroup s)-1)
  change starIncidenceRamp d (1/2) z s ≤ greedyOldEnvelope q (edgeSum z (d.backGroup s)) k at ho
  have hn' : signedStarIncidence d (9/20) z s ≤ greedyMuEnvelope q (edgeSum z (d.backGroup s)) k := by
    unfold signedStarIncidence starIncidenceRamp edgeSum
    linarith only [hn]
  unfold noncriticalIncidence
  apply max_le_max
  · unfold oldIncidence
    linarith only [h1,ho]
  · unfold mixedNoncriticalIncidence
    change (360/19)*min _ (signedStarIncidence d (9/20) z s)+
      (96/19)*min _ ((100/57)*edgeSum z (d.backGroup s)-1) ≤ _
    unfold ScoredParameters.massSlope at h3
    linarith only [h2,hn',h3]

end TSP.Improvements20261105
