import TSP.Improvements20261105.ExtendedResidualEdgePayment
import TSP.Improvements20261105.UnmatchedHeadRetainedPayment
import TSP.Improvements20261105.UnmatchedResidualFamilyPayment
import TSP.Improvements20261105.UnselectedUnmatchedHeadPayment
import TSP.Improvements20261105.RetainedSelectedResidual
import TSP.Improvements20261105.UnselectedPositiveUnaryResidualPayment
import TSP.Improvements20261105.UnaryUnmatchedForceBudget
import TSP.Improvements20261105.ResidualReceiverForceBudget
import TSP.Improvements20261105.GreedyFreePositiveLoad
import TSP.Improvements20261105.CurrentProjectedUnmatchedHeadCost
import TSP.Improvements20261105.SelectedZeroHeadPayment
import TSP.Improvements20261105.CurrentProjectedKZeroReceiver
import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost
import TSP.Improvements20261105.KOriginOwnership

/-! Unmatched nonroot heads outside protected receivers are paid
with no charge when unselected. Selected projected-zero heads use only
their own original back budget. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_extended_unmatched_residual_payment
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (a : GatedDrops d) (ha : a.Admissible d (fixedGatePlan d x))
    (H : Finset (d).StarIndex)
    (hH : ∀ i ∈ H, i.1 ∉ matchingEndpoints id (unaryNext d) C.matching ∧
      (d).centers i ≠ (d).tree.root ∧ i ∉ a.selectedHighQHeads d x z C)
    (hel : ∀ s, ScoredStar d x s → s ∈ eligible)
    (F : Finset (d).StarIndex)
    (hF : ∀ i ∈ F, i.1 ∉ C.matching ∧ a.head i.1=1 ∧ 1 < edgeSum z ((d).backGroup i.1)) :
    let J := (couponResidualStarPairs d x z F).filter (fun p => p.2 ∈ H)
    (∑ i ∈ H, currentSelectedHeadCost d x z C owner rootStar R eligible T a.head i)+
      24*(∑ i ∈ J.image Prod.fst, actualCouponResidual d x z i) ≤
      (4*∑ i ∈ H, (((d).backGroup i.1).card : ℝ))+
      24*(∑ i ∈ H, retainedSelectedResidual d x z a.head i) := by
  dsimp only
  let J := (couponResidualStarPairs d x z F).filter (fun p => p.2 ∈ H)
  let S := J.image Prod.fst
  let U := J.image Prod.snd
  let cost := currentSelectedHeadCost d x z C owner rootStar R eligible T a.head
  let debt := retainedSelectedResidual d x z a.head
  let budget := fun i : (d).StarIndex => (4 : ℝ)*((d).backGroup i.1).card
  have hU : U ⊆ H := by
    intro i hi
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hi
    exact (Finset.mem_filter.mp hp).2
  have hf : Set.InjOn Prod.fst (J : Set ((d).StarIndex × (d).StarIndex)) := by
    intro p hp q hq he
    exact couponResidualStarPairs_fst_injective d hs x z hx hcap F
      (Finset.mem_filter.mp hp).1 (Finset.mem_filter.mp hq).1 he
  have ht : Set.InjOn Prod.snd (J : Set ((d).StarIndex × (d).StarIndex)) := by
    intro p hp q hq he
    exact couponResidualStarPairs_snd_injective d x z F
      (Finset.mem_filter.mp hp).1 (Finset.mem_filter.mp hq).1 he
  have hrow (p : (d).StarIndex × (d).StarIndex) (hp : p ∈ J) :
      cost p.2+24*actualCouponResidual d x z p.1 ≤ budget p.2+24*debt p.2 := by
    have hh := hF p.1 (Finset.mem_filter.mp (Finset.mem_filter.mp hp).1).2.1
    have htarget := hH p.2 (Finset.mem_filter.mp hp).2
    exact scoredDFS_extended_residual_edge_payment G x z hs hc root hx hn hcap hz hzx hm C owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T a.head p.2 htarget.1 (a.head_binary d ha p.2.1) F p.1 (Finset.mem_filter.mp hp).1 hh.1 hh.2.2
  have hrows := Finset.sum_le_sum hrow
  have hpay : (∑ i ∈ U, cost i)+24*(∑ i ∈ S, actualCouponResidual d x z i) ≤
      (∑ i ∈ U, budget i)+24*(∑ i ∈ U, debt i) := by
    dsimp only [S,U]
    rw [Finset.sum_image (fun p hp q hq he => ht hp hq he),
      Finset.sum_image (fun p hp q hq he => hf hp hq he),
      Finset.sum_image (fun p hp q hq he => ht hp hq he),
      Finset.sum_image (fun p hp q hq he => ht hp hq he)]
    simpa only [Finset.sum_add_distrib,← Finset.mul_sum] using hrows
  have hrest := Finset.sum_le_sum (s := H \ U) (fun i hi => by
    have hh := hH i (Finset.mem_sdiff.mp hi).1
    exact scoredDFS_unmatched_head_retained_payment G x z hs hc root hx hn hcap hz hzx hm C
      owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T a ha i
      hh.1 hh.2.1 (hel i.1) hh.2.2)
  change (∑ i ∈ H \ U, cost i) ≤ ∑ i ∈ H \ U, (budget i+24*debt i) at hrest
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at hrest
  have hpartCost := Finset.sum_sdiff hU (f := cost)
  have hpartBudget := Finset.sum_sdiff hU (f := budget)
  have hpartDebt := Finset.sum_sdiff hU (f := debt)
  have hbudget : (∑ i ∈ H, budget i) = 4*∑ i ∈ H, (((d).backGroup i.1).card : ℝ) := by
    simp only [budget,Finset.mul_sum]
  change (∑ i ∈ H, cost i)+24*(∑ i ∈ S, actualCouponResidual d x z i) ≤
    (4*∑ i ∈ H, (((d).backGroup i.1).card : ℝ))+24*(∑ i ∈ H, debt i)
  linarith only [hpay,hrest,hpartCost,hpartBudget,hpartDebt,hbudget]

end TSP.Improvements20261105
