import TSP.Improvements20261105.StarBackCountBudget
import TSP.Improvements20261105.AllocatedLeafSum
import TSP.Improvements20261105.RemainingMatchingPartition
import TSP.Improvements20261105.AllocatedLeafHeads
import TSP.Improvements20261105.KLeafDisjoint
import TSP.Improvements20261105.MatchingLeafDisjoint
import TSP.Improvements20261105.LargeRemainingLeafOwners
import TSP.Improvements20261105.SolePairLeafDisjoint
import TSP.Improvements20261105.OneExtraBackLeafDisjoint
import TSP.Improvements20261105.TwoBackSingleLeafDisjoint
import TSP.Improvements20261105.TwoOneBackLeafDisjoint
import TSP.Improvements20261105.NoPairLeafOwners

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.global_role_weight_budget (hs : G.IsSimple) (hc : IsTwoVertexConnected G) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P)) (g : d.StarIndex → ℝ) (hg : ∀ i, 0 ≤ g i) :
    (∑ i ∈ pairStarHeads d (a.KLeafPairs d P x z C), g i)+
      (∑ i ∈ pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.largeRemainingLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.solePairLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.oneExtraBackLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackSingleLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackTwoHeadLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.noPairLeafRoots d P x z C), g i)+
      (∑ i ∈ a.selectedHighQHeads d x z C, g i)+
      (∑ i ∈ a.internalUnmatchedHeads d P x z C, g i)+
      (∑ i ∈ pairStarHeads d (a.internalMatchingPairs d P x z C), g i)+
      (∑ i ∈ a.remainingRootHeads d P x z C, g i) ≤ ∑ i : d.StarIndex, g i := by
  let A := a.allocatedLeafHeads d P x z C
  let B := a.selectedHighQHeads d x z C
  let H := a.internalUnmatchedHeads d P x z C
  let U := Finset.univ \ A
  have hd := a.selectedHighQHeads_disjoint_allocated d hs hc x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hB : B ⊆ U := by
    intro i hi
    exact Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun hj => Finset.disjoint_left.mp hd hi hj⟩
  have hH : H ⊆ U \ B := by
    intro i hi
    have hh := (Finset.mem_sdiff.mp (Finset.mem_filter.mp hi).1).2
    exact Finset.mem_sdiff.mpr ⟨Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun hj => hh (Finset.mem_union_left _ hj)⟩,
      fun hj => hh (Finset.mem_union_right _ hj)⟩
  have hp1 := Finset.sum_sdiff (Finset.subset_univ A) (f := g)
  have hp2 := Finset.sum_sdiff hB (f := g)
  have hp3 := Finset.sum_sdiff hH (f := g)
  have hafter : (∑ i ∈ a.afterUnmatchedHeads d P x z C, g i)=
      (∑ i ∈ pairStarHeads d (a.internalMatchingPairs d P x z C), g i)+
      (∑ i ∈ a.remainingRootHeads d P x z C, g i) := by
    rw [a.afterUnmatchedHeads_matching_partition d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan,
      Finset.sum_union (a.internalMatchingPairs_disjoint_root d P x z C)]
  change (∑ i ∈ (U \ B) \ H, g i)=_ at hafter
  have hA := a.allocatedLeafHeads_sum d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan g
  have hpaid : 0 ≤ ∑ i ∈ a.paidLeafHeads d P x, g i := Finset.sum_nonneg (fun i _ => hg i)
  change (∑ i ∈ U, g i)+(∑ i ∈ A, g i)=(∑ i : d.StarIndex, g i) at hp1
  change (∑ i ∈ A, g i)=_ at hA
  change (∑ i ∈ pairStarHeads d (a.KLeafPairs d P x z C), g i)+
      (∑ i ∈ pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.largeRemainingLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.solePairLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.oneExtraBackLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackSingleLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.twoBackTwoHeadLeafRoots d P x z C), g i)+
      (∑ i ∈ a.componentStarUnion d P (a.noPairLeafRoots d P x z C), g i)+
      (∑ i ∈ a.selectedHighQHeads d x z C, g i)+
      (∑ i ∈ a.internalUnmatchedHeads d P x z C, g i)+
      (∑ i ∈ pairStarHeads d (a.internalMatchingPairs d P x z C), g i)+
      (∑ i ∈ a.remainingRootHeads d P x z C, g i) ≤ _
  linarith only [hp1,hp2,hp3,hafter,hA,hpaid]

end TSP.Improvements20261105
