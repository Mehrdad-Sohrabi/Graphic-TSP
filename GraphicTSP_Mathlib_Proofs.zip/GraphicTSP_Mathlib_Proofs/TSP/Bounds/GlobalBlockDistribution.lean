import TSP.Improvements20261105.ClassifiedPairCoupling
import TSP.Improvements20261105.CoherentBlockSelection
import TSP.Improvements20261105.BernoulliEdges
import TSP.Improvements20261105.FiniteMarginalTransport

/-! Assemble one global distribution of original edge sets from the
actual resource matching and all local block choices. Edges with no minor
endpoint are independent. Every original and local-choice marginal is exact. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Classical
open scoped BigOperators
variable {V E J : Type} [Fintype V] [Fintype E] [Fintype J]
  [DecidableEq V] [DecidableEq E] [DecidableEq J]

theorem exists_global_block_distribution {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : ∀ e, 0 ≤ x e) (m : E → ℝ) (hbox : ∀ e, 0 ≤ m e ∧ m e ≤ 1)
    (hinternal : ∀ e ∈ internalResourceEdges d x, m e = x e / 2)
    (v : V → J → ℝ) (P : V → J → Finset E)
    (hv : ∀ u j, 0 ≤ v u j) (hvs : ∀ u, ∑ j, v u j = 1)
    (hP : ∀ u j, P u j ⊆ minorBoundary d x u)
    (hone : ∀ u j, (P u j ∩ internalResourceEdges d x).card ≤ 1)
    (hm : ∀ u e, e ∈ minorBoundary d x u → ∑ j, v u j * incidence (P u j) e = m e) :
    ∃ (K : Type) (_ : Fintype K) (W : K → ℝ) (choice : K → V → J) (S : K → Finset E),
      (∀ k, 0 ≤ W k) ∧ (∑ k, W k = 1) ∧
      (∀ u j, ∑ k, W k * (if choice k u = j then 1 else 0) = v u j) ∧
      (∀ e, ∑ k, W k * incidence (S k) e = m e) ∧
      (∀ k, 0 < W k → ∀ u, S k ∩ minorBoundary d x u = P u (choice k u)) := by
  classical
  obtain ⟨I, hi, w, choice, R, hw, hs, hchoice, hR, hagree⟩ :=
    classified_pair_resource_coupling d hsimple hx v P hv hvs hP hone
      (fun u e he hb => (hm u e hb).trans (hinternal e he))
  letI := hi
  let bweight := bernoulliEdgeWeight m
  have hbnon : ∀ b, 0 ≤ bweight b := bernoulliEdgeWeight_nonneg m hbox
  have hbsum : ∑ b, bweight b = 1 := bernoulliEdgeWeight_sum m
  let W := fun ib : I × (E → Bool) => w ib.1 * bweight ib.2
  let S := fun ib : I × (E → Bool) =>
    blockSelection d x (fun u => P u (choice ib.1 u)) (bernoulliEdgeSet ib.2)
  have hW : ∀ ib, 0 ≤ W ib := fun ib => mul_nonneg (hw ib.1) (hbnon ib.2)
  have hWs : ∑ ib, W ib = 1 := by
    have hh := product_left_weighted_sum w bweight hbsum (fun _ => 1)
    simpa only [mul_one, hs] using hh
  have hlocal : ∀ u j, (∑ ib : I × (E → Bool), W ib * (if choice ib.1 u = j then 1 else 0)) = v u j := by
    intro u j
    dsimp only [W]
    rw [product_left_weighted_sum w bweight hbsum (fun i => if choice i u = j then 1 else 0)]
    exact hchoice u j
  have hpoint : ∀ e, (∑ ib, W ib * incidence (S ib) e) = m e := by
    intro e
    by_cases heS : e ∈ minorBoundary d x (G.src e)
    · have hinc : ∀ ib, incidence (S ib) e = incidence (P (G.src e) (choice ib.1 (G.src e))) e := by
        intro ib
        simp [S, incidence, blockSelection, heS]
      simp_rw [hinc]
      dsimp only [W]
      rw [product_left_weighted_sum w bweight hbsum (fun i => incidence (P (G.src e) (choice i (G.src e))) e)]
      rw [weighted_function_transport w (v (G.src e)) (fun i => choice i (G.src e)) (hchoice (G.src e))
        (fun j => incidence (P (G.src e) j) e)]
      exact hm (G.src e) e heS
    · by_cases heT : e ∈ minorBoundary d x (G.dst e)
      · have hinc : ∀ ib, incidence (S ib) e = incidence (P (G.dst e) (choice ib.1 (G.dst e))) e := by
          intro ib
          simp [S, incidence, blockSelection, heS, heT]
        simp_rw [hinc]
        dsimp only [W]
        rw [product_left_weighted_sum w bweight hbsum (fun i => incidence (P (G.dst e) (choice i (G.dst e))) e)]
        rw [weighted_function_transport w (v (G.dst e)) (fun i => choice i (G.dst e)) (hchoice (G.dst e))
          (fun j => incidence (P (G.dst e) j) e)]
        exact hm (G.dst e) e heT
      · have hinc : ∀ ib, incidence (S ib) e = incidence (bernoulliEdgeSet ib.2) e := by
          intro ib
          simp [S, incidence, blockSelection, heS, heT]
        simp_rw [hinc]
        dsimp only [W]
        rw [product_right_weighted_sum w bweight hs (fun b => incidence (bernoulliEdgeSet b) e)]
        exact bernoulliEdge_marginal m e
  refine ⟨I × (E → Bool), inferInstance, W, fun ib => choice ib.1, S, hW, hWs, hlocal, hpoint, ?_⟩
  intro ib hib u
  have hwi : 0 < w ib.1 := by
    have hne : w ib.1 ≠ 0 := by intro he; simp [W, he] at hib
    exact lt_of_le_of_ne (hw ib.1) (Ne.symm hne)
  have hc := resource_agreement_implies_coherence d x (fun u => P u (choice ib.1 u)) (R ib.1) (hagree ib.1 hwi)
  exact blockSelection_boundary d hsimple x (fun u => P u (choice ib.1 u)) (bernoulliEdgeSet ib.2)
    (fun u => hP u (choice ib.1 u)) hc u

end TSP.Improvements20261105
