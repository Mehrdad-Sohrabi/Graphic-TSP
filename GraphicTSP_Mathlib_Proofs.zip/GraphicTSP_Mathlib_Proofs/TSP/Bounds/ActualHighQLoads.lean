import TSP.Improvements20261105.GreedyHeadLoads
import TSP.Improvements20261105.PairIncomingBudget

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]

theorem scoredDFS_high_q_selected_load (G : Graph V E) (x z : E → ℝ)
    (hs : G.IsSimple) (hc : G.Connected) (root : V)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((scoredDFS G x hs hc root).backGroup s) =
      edgeSum x ((scoredDFS G x hs hc root).backGroup s)-
        fixedRemoval (scoredDFS G x hs hc root) x (allFullOverrideTargets (scoredDFS G x hs hc root) x) s)
    (eligible R : Finset (scoredDFS G x hs hc root).tree.Child)
    (s : (scoredDFS G x hs hc root).tree.Child)
    (hq : 1/2 ≤ x ((scoredDFS G x hs hc root).treeEdge s)) :
    let d := scoredDFS G x hs hc root
    24*(edgeSum z (d.backGroup s)-1)+
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) R s ≤ 48+240/361 := by
  let d := scoredDFS G x hs hc root
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hg := scoredDFS_high_q_greedy G x hs hc root s hq
  have hb := high_q_noncritical_load d z s (x (d.treeEdge s)) hq (fun e _ => hz e)
    (fun e he => (hzx e).trans (hg e he)) (by linarith)
  have hr := refined_fixed_incidence_le_noncritical d x z eligible R s
  change _ ≤ _
  linarith

theorem scoredDFS_high_parent_receiver_load (G : Graph V E) (x z : E → ℝ)
    (hs : G.IsSimple) (hc : G.Connected) (root : V)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((scoredDFS G x hs hc root).backGroup s) =
      edgeSum x ((scoredDFS G x hs hc root).backGroup s)-
        fixedRemoval (scoredDFS G x hs hc root) x (allFullOverrideTargets (scoredDFS G x hs hc root) x) s)
    (eligible R : Finset (scoredDFS G x hs hc root).tree.Child)
    (s v : (scoredDFS G x hs hc root).tree.Child)
    (hp : (scoredDFS G x hs hc root).tree.parent s = (v : V))
    (hq : 1/2 ≤ x ((scoredDFS G x hs hc root).treeEdge v))
    (hpos : 1 < edgeSum z ((scoredDFS G x hs hc root).backGroup s)) :
    let d := scoredDFS G x hs hc root
    24*(edgeSum z (d.backGroup s)-1)+
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) R s ≤
        48*(1-x (d.treeEdge v))+2064/361 := by
  let d := scoredDFS G x hs hc root
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have hsurv : 0 < survivingExcess d x s := by linarith
  have hin := surviving_incoming_complement d hs x hx s v hp hsurv
  have hg := scoredDFS_high_parent_greedy G x hs hc root s v hp hq
  have hb := small_receiver_noncritical_load d z s (x (d.treeEdge s)) (1-x (d.treeEdge v))
    (hx.1 _) (by linarith) (fun e _ => hz e) (fun e he => (hzx e).trans (hg e he))
    hpos.le (by linarith)
  have hr := refined_fixed_incidence_le_noncritical d x z eligible R s
  change _ ≤ _
  linarith

end TSP.Improvements20261105
