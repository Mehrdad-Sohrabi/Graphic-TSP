import TSP.Improvements20261105.FixedProjectionRecipe
import TSP.Improvements20261105.OrdinaryProjectionIntegration

/-! Realize all fixed center choices simultaneously, retain original good
capacities, and apply original half-rank to the actual surviving bad heads. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter08 Chapter10
open Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem exists_fixed_projection_parts {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x₀ x : E → ℝ} (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (hdom : ∀ e, min (x₀ e) 1 ≤ x e) (hn : 2 ≤ Fintype.card V)
    (hpriority : ∀ (v : d.tree.Child) e, e ∈ d.group v → x e = 1 → x (d.treeEdge v) = 1)
    (T : Finset d.tree.Child) (hT : ∀ v ∈ T, FullOverrideAt d x v) :
    ∃ parts : d.tree.Child → E → ℝ,
      (∀ v e, 0 ≤ parts v e ∧ parts v e ≤ x e) ∧
      (∀ v e, e ∉ d.backGroup v → parts v e = x e) ∧
      (∀ v, edgeSum (parts v) (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v) ∧
      ∀ v, SurvivingPositive d x v → PartitionableVertex G x₀ (d.tree.parent v) →
        PartitionableVertex G (parts v) (d.tree.parent v) := by
  have hex : ∀ v : d.tree.Child, ∃ z : E → ℝ,
      (∀ e, 0 ≤ z e ∧ z e ≤ x e) ∧ (∀ e ∉ d.backGroup v, z e = x e) ∧
      edgeSum z (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v ∧
      (SurvivingPositive d x v → PartitionableVertex G x₀ (d.tree.parent v) →
        PartitionableVertex G z (d.tree.parent v)) := by
    intro v
    by_cases hg : SurvivingPositive d x v ∧ PartitionableVertex G x₀ (d.tree.parent v)
    · obtain ⟨z, hz, ho, hgood, hm⟩ := surviving_good_partition_projection d hsimple hx.1 hcap hdom hpriority v hg.1 hg.2
      rw [← fixedRemoval_surviving d hsimple hx hn T v hg.1] at hm
      exact ⟨z, hz, ho, hm, fun _ _ => hgood⟩
    · have hr := fixedRemoval_bounds d hsimple hx hcap hn T hT v
      obtain ⟨z, hz, ho, hm⟩ := exists_remove_mass x (d.backGroup v) hx.1 _ hr.1 hr.2
      exact ⟨z, hz, ho, hm, fun hs hp => (hg ⟨hs, hp⟩).elim⟩
  choose parts hbox hout hmass hgood using hex
  exact ⟨parts, hbox, hout, hmass, hgood⟩

theorem exists_fixed_projection {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x₀ x : E → ℝ} (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (hdom : ∀ e, min (x₀ e) 1 ≤ x e) (hn : 2 ≤ Fintype.card V)
    (hpriority : ∀ (v : d.tree.Child) e, e ∈ d.group v → x e = 1 → x (d.treeEdge v) = 1)
    (T : Finset d.tree.Child) (hT : ∀ v ∈ T, FullOverrideAt d x v) :
    ∃ y : E → ℝ, (∀ e, 0 ≤ y e ∧ y e ≤ x e) ∧ (∀ v, y (d.treeEdge v) = x (d.treeEdge v)) ∧
      (∀ v, edgeSum y (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v) ∧
      edgeSum (fun e => x e - y e) Finset.univ ≤
        2 * (edgeSum x Finset.univ - (Fintype.card V : ℝ)) ∧
      ∀ v, 1 < edgeSum y (d.backGroup v) → PartitionableVertex G x₀ (d.tree.parent v) →
        UnitPartCapacities G y (d.tree.parent v) := by
  obtain ⟨parts, hbox, hout, hmass, hgood⟩ :=
    exists_fixed_projection_parts d hsimple hx hcap hdom hn hpriority T hT
  let y := assembleBackProjection d x parts
  have hm : ∀ v, edgeSum y (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v := by
    intro v
    rw [← hmass v]
    exact Finset.sum_congr rfl (fun e he => assembled_on_backGroup d x parts v e he)
  refine ⟨y, assembled_box d x parts hx.1 hbox, assembled_on_tree d x parts, hm, ?_, ?_⟩
  · exact (assembled_total_removal d x parts (fixedRemoval d x T) hmass).trans_le
      (fixedRemoval_total_budget d hsimple hx hn T hT)
  · intro v hv hg
    rw [hm v] at hv
    have hs := (fixed_projected_positive_iff d hsimple hx hn T v).mp hv
    obtain ⟨F, hF, hleft, hright⟩ := hgood v hs hg
    have hle := assembled_le_local d x parts hx.1 hbox hout v
    exact ⟨F, hF, (Finset.sum_le_sum (fun e _ => hle e)).trans hleft.le,
      (Finset.sum_le_sum (fun e _ => hle e)).trans hright.le⟩

theorem fixed_projection_unclassified_star {G : Graph V E} (d : DFSData G)
    (x y : E → ℝ) (T : Finset d.tree.Child)
    (hprojection : ∀ v, edgeSum y (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v)
    (v : d.tree.Child) (hu : ¬ClassifiedCenter d x (d.tree.parent v)) :
    x (d.treeEdge v) + edgeSum y (d.backGroup v) ≤ 1 := by
  rw [hprojection v, fixedRemoval, if_neg hu, zero_projected_mass]
  have hh := min_le_right (edgeSum x (d.backGroup v)) (1 - x (d.treeEdge v))
  linarith

theorem fixed_projection_target_identity {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x y : E → ℝ) (T : Finset d.tree.Child)
    (hprojection : ∀ v, edgeSum y (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v)
    (u v : d.tree.Child) (hp : d.tree.parent v = u) (hc : childCount d u = 1)
    (hmatch : x (d.treeEdge u) + outgoingBackMass d x u < 1) (hvT : v ∈ T) :
    x (d.treeEdge v) + edgeSum y (d.backGroup v) =
      2 - x (d.treeEdge u) - outgoingBackMass d x u := by
  have hclass := full_override_classified d hsimple x v ⟨u, hp, hc, hmatch⟩
  rw [hprojection v, fixedRemoval, if_pos hclass, if_pos hvT]
  exact full_override_identity d hsimple x u v hp hc

theorem fixed_projected_bad_heads_budget {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x₀ x y : E → ℝ} (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ)
    (hpositive : ∀ e, 0 < x₀ e) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hdom : ∀ e, min (x₀ e) 1 ≤ x e) (hn : 3 ≤ Fintype.card V)
    (hpriority : ∀ (v : d.tree.Child) e, e ∈ d.group v → x e = 1 → x (d.treeEdge v) = 1)
    (T : Finset d.tree.Child)
    (hprojection : ∀ v, edgeSum y (d.backGroup v) = edgeSum x (d.backGroup v) - fixedRemoval d x T v)
    (H : Finset d.tree.Child)
    (hH : ∀ v ∈ H, 1 < edgeSum y (d.backGroup v) ∧ d.tree.parent v ≠ d.tree.root ∧
      ¬PartitionableVertex G x₀ (d.tree.parent v)) :
    2 * d.backEdges.card + H.card + (degreeSlackVertices G x₀).card + 4 ≤ 2 * Fintype.card V := by
  apply surviving_back_budget d hsimple hx₀ hpositive hx hcap hdom hn hpriority H
  intro v hv
  have hh := hH v hv
  have hs := hh.1
  rw [hprojection v] at hs
  exact ⟨(fixed_projected_positive_iff d hsimple hx (by omega) T v).mp hs, hh.2⟩

end TSP.Improvements20261105
