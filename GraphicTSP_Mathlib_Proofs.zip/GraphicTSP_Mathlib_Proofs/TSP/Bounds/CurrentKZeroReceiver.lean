import TSP.Improvements20261105.KZeroReceiverFinance
import TSP.Improvements20261105.TerminalHReceiver

/-! The actual simultaneous construction retains a strictly negative
bound at a projected-zero receiver of an unmatched protected link.
Actual-zero and erased-positive receivers are both included. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_K_zero_receiver_connector (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (R : E ⊕ d.StarIndex → ℝ) (hR : FixedQConnectorValues d x hx hn hcap R)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hl : v ∈ projectionLinks d x)
    (hu : v ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1) :
    pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -48*(1-x (d.treeEdge v)-outgoingBackMass d x v) := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  have hH := fixedHForceTargets_subset d x z (415/2) (704/5) C
  have hT : ∀ s ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d s := by
    intro s hsT
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hsT
    exact (Finset.mem_filter.mp hj).2.1
  have hc := (Finset.mem_filter.mp hl).2.2.2.1
  have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v hc).2 i.1 hv).symm
  have hir : i ≠ rootStar := by
    intro he
    have hnr : d.centers i ≠ d.tree.root := by rw [hv]; exact v.2
    exact hnr (he ▸ hroot)
  have hnoH : v ∉ H := fun hmH => hu (Finset.mem_union_right _ (hH hmH))
  have hforce : forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H v =
      protectedCoverIncrease d x z (415/2) (704/5) 60 C v := by
    rw [forcedCoverIncrease,if_neg hnoH]
  have hp := terminal_P_connector_unary d hs x hx hn hcap owner ho rootStar
    (fixedPositiveTerminalChildren d x) hT _
    (forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C H hH) i hir v hv hc
  rw [forcedCoverIncrease_extension d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C H hH v,hforce] at hp
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  have ht0 : 0 ≤ fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := (tau_nonneg _ _).trans ht
  have hmax : max (starTau d x i) (max (protectedCoverIncrease d x z (415/2) (704/5) 60 C v-
      outgoingBackMass d x v) 0) ≤ fixedProjectionCharge d x (allFullOverrideTargets d x) i.1+
        max (protectedCoverIncrease d x z (415/2) (704/5) 60 C v-outgoingBackMass d x v) 0 := by
    apply max_le
    · linarith [le_max_right (protectedCoverIncrease d x z (415/2) (704/5) 60 C v-outgoingBackMass d x v) 0]
    · linarith
  have hnorm := fixedQ_link_connector d hs x z hx hn hcap hm R hR i v hv hl
  have hxi := degreeExcess_nonnegative G hx hn (d.centers i)
  have hz' : edgeSum z (d.backGroup (unaryNext d v)) ≤ 1 := by rwa [hnext]
  have hfin := protected_zero_receiver_export d hs x z hx hn hcap hm C v hl hu hz'
  change currentGuardedP d x z C owner rootStar (.inr i) ≤ _ at hp
  unfold pqConnectorArm
  linarith

theorem current_K_zero_receiver_max (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hl : v ∈ projectionLinks d x)
    (hu : v ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -48*(1-x (d.treeEdge v)-outgoingBackMass d x v) := by
  have hnr : d.centers i ≠ d.tree.root := by rw [hv]; exact v.2
  have hc := current_K_zero_receiver_connector d hs x z hx hn hcap hm C owner ho rootStar hroot R hR i v hv hl hu hz
  have hd := current_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar
    Y R hY hrep hbacks hloss hterminal hzero i hnr
  have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v (Finset.mem_filter.mp hl).2.2.2.1).2 i.1 hv).symm
  have hz' : edgeSum z (d.backGroup (unaryNext d v)) ≤ 1 := by rwa [hnext]
  have hcov := unmatched_link_zero_receiver_cover d hs x z hx hn hm (415/2) (704/5) C v hl hu hz'
  rw [hnext] at hcov
  have hg := (Finset.mem_filter.mp hl).2.2.2.2
  apply (sub_le_iff_le_add).mpr
  apply max_le <;> linarith

end TSP.Improvements20261105
