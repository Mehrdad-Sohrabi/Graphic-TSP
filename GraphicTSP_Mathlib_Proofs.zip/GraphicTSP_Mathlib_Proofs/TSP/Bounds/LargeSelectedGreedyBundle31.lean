import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105

private theorem greedybundle31_cached_cap_000 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(1/16 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(1/16 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_001 :
    0 ≤ (38/59 : ℝ) ∧ 0 ≤ 2-(38/59 : ℝ) ∧ (2-(38/59 : ℝ))*(59/160 : ℝ) ≤ 1/2 ∧
    0 ≤ (401/590 : ℝ) ∧ 0 ≤ 19/10-(401/590 : ℝ) ∧ (19/10-(401/590 : ℝ))*(59/160 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_002 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(23/248 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(23/248 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_003 :
    0 ≤ (62/111 : ℝ) ∧ 0 ≤ 2-(62/111 : ℝ) ∧ (2-(62/111 : ℝ))*(111/320 : ℝ) ≤ 1/2 ∧
    0 ≤ (223/370 : ℝ) ∧ 0 ≤ 19/10-(223/370 : ℝ) ∧ (19/10-(223/370 : ℝ))*(111/320 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_004 :
    0 ≤ (26/33 : ℝ) ∧ 0 ≤ 2-(26/33 : ℝ) ∧ (2-(26/33 : ℝ))*(33/80 : ℝ) ≤ 1/2 ∧
    0 ≤ (89/110 : ℝ) ∧ 0 ≤ 19/10-(89/110 : ℝ) ∧ (19/10-(89/110 : ℝ))*(33/80 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_005 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(19/124 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(19/124 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_006 :
    0 ≤ (1/1 : ℝ) ∧ 0 ≤ 2-(1/1 : ℝ) ∧ (2-(1/1 : ℝ))*(1/2 : ℝ) ≤ 1/2 ∧
    0 ≤ (1/1 : ℝ) ∧ 0 ≤ 19/10-(1/1 : ℝ) ∧ (19/10-(1/1 : ℝ))*(1/2 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_007 :
    0 ≤ (3/17 : ℝ) ∧ 0 ≤ 2-(3/17 : ℝ) ∧ (2-(3/17 : ℝ))*(17/62 : ℝ) ≤ 1/2 ∧
    0 ≤ (22/85 : ℝ) ∧ 0 ≤ 19/10-(22/85 : ℝ) ∧ (19/10-(22/85 : ℝ))*(17/62 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_008 :
    0 ≤ (33/32 : ℝ) ∧ 0 ≤ 2-(33/32 : ℝ) ∧ (2-(33/32 : ℝ))*(16/31 : ℝ) ≤ 1/2 ∧
    0 ≤ (329/320 : ℝ) ∧ 0 ≤ 19/10-(329/320 : ℝ) ∧ (19/10-(329/320 : ℝ))*(16/31 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_009 :
    0 ≤ (3/2 : ℝ) ∧ 0 ≤ 2-(3/2 : ℝ) ∧ (2-(3/2 : ℝ))*(1/1 : ℝ) ≤ 1/2 ∧
    0 ≤ (29/20 : ℝ) ∧ 0 ≤ 19/10-(29/20 : ℝ) ∧ (19/10-(29/20 : ℝ))*(1/1 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle31_cached_cap_010 :
    0 ≤ (7/5 : ℝ) ∧ 0 ≤ 2-(7/5 : ℝ) ∧ (2-(7/5 : ℝ))*(5/6 : ℝ) ≤ 1/2 ∧
    0 ≤ (34/25 : ℝ) ∧ 0 ≤ 19/10-(34/25 : ℝ) ∧ (19/10-(34/25 : ℝ))*(5/6 : ℝ) ≤ 9/20 := by norm_num

set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_group_25_31_cell_10
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/31 : ℝ) ≤ q) (hqu : q ≤ (1/16 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (1/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle31_cached_cap_000.1 greedybundle31_cached_cap_000.2.1 greedybundle31_cached_cap_000.2.2.1 greedybundle31_cached_cap_000.2.2.2.1 greedybundle31_cached_cap_000.2.2.2.2.1 greedybundle31_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) greedybundle31_cached_cap_001.1 greedybundle31_cached_cap_001.2.1 greedybundle31_cached_cap_001.2.2.1 greedybundle31_cached_cap_001.2.2.2.1 greedybundle31_cached_cap_001.2.2.2.2.1 greedybundle31_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]

theorem large_selected_greedy_group_25_31_cell_11
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/16 : ℝ) ≤ q) (hqu : q ≤ (23/248 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (23/248 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle31_cached_cap_002.1 greedybundle31_cached_cap_002.2.1 greedybundle31_cached_cap_002.2.2.1 greedybundle31_cached_cap_002.2.2.2.1 greedybundle31_cached_cap_002.2.2.2.2.1 greedybundle31_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) greedybundle31_cached_cap_003.1 greedybundle31_cached_cap_003.2.1 greedybundle31_cached_cap_003.2.2.1 greedybundle31_cached_cap_003.2.2.2.1 greedybundle31_cached_cap_003.2.2.2.2.1 greedybundle31_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]

theorem large_selected_greedy_group_25_31_cell_12
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/16 : ℝ) ≤ q) (hqu : q ≤ (23/248 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (23/248 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle31_cached_cap_002.1 greedybundle31_cached_cap_002.2.1 greedybundle31_cached_cap_002.2.2.1 greedybundle31_cached_cap_002.2.2.2.1 greedybundle31_cached_cap_002.2.2.2.2.1 greedybundle31_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) greedybundle31_cached_cap_001.1 greedybundle31_cached_cap_001.2.1 greedybundle31_cached_cap_001.2.2.1 greedybundle31_cached_cap_001.2.2.2.1 greedybundle31_cached_cap_001.2.2.2.2.1 greedybundle31_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]

theorem large_selected_greedy_group_25_31_cell_13
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/31 : ℝ) ≤ q) (hqu : q ≤ (23/248 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (23/248 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle31_cached_cap_002.1 greedybundle31_cached_cap_002.2.1 greedybundle31_cached_cap_002.2.2.1 greedybundle31_cached_cap_002.2.2.2.1 greedybundle31_cached_cap_002.2.2.2.2.1 greedybundle31_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) greedybundle31_cached_cap_004.1 greedybundle31_cached_cap_004.2.1 greedybundle31_cached_cap_004.2.2.1 greedybundle31_cached_cap_004.2.2.2.1 greedybundle31_cached_cap_004.2.2.2.2.1 greedybundle31_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hem,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]

theorem large_selected_greedy_group_25_31_cell_14
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (23/248 : ℝ) ≤ q) (hqu : q ≤ (19/124 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (19/124 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle31_cached_cap_005.1 greedybundle31_cached_cap_005.2.1 greedybundle31_cached_cap_005.2.2.1 greedybundle31_cached_cap_005.2.2.2.1 greedybundle31_cached_cap_005.2.2.2.2.1 greedybundle31_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) greedybundle31_cached_cap_004.1 greedybundle31_cached_cap_004.2.1 greedybundle31_cached_cap_004.2.2.1 greedybundle31_cached_cap_004.2.2.2.1 greedybundle31_cached_cap_004.2.2.2.2.1 greedybundle31_cached_cap_004.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]

theorem large_selected_greedy_group_25_31_cell_15
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/31 : ℝ) ≤ q) (hqu : q ≤ (19/124 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (19/124 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle31_cached_cap_005.1 greedybundle31_cached_cap_005.2.1 greedybundle31_cached_cap_005.2.2.1 greedybundle31_cached_cap_005.2.2.2.1 greedybundle31_cached_cap_005.2.2.2.2.1 greedybundle31_cached_cap_005.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle31_cached_cap_006.1 greedybundle31_cached_cap_006.2.1 greedybundle31_cached_cap_006.2.2.1 greedybundle31_cached_cap_006.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hem,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]

theorem large_selected_greedy_group_25_31_cell_16
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (19/124 : ℝ) ≤ q) (hqu : q ≤ (17/62 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (17/62 : ℝ) (3/17 : ℝ) (22/85 : ℝ) greedybundle31_cached_cap_007.1 greedybundle31_cached_cap_007.2.1 greedybundle31_cached_cap_007.2.2.1 greedybundle31_cached_cap_007.2.2.2.1 greedybundle31_cached_cap_007.2.2.2.2.1 greedybundle31_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle31_cached_cap_006.1 greedybundle31_cached_cap_006.2.1 greedybundle31_cached_cap_006.2.2.1 greedybundle31_cached_cap_006.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]

theorem large_selected_greedy_group_25_31_cell_17
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (17/62 : ℝ) ≤ q) (hqu : q ≤ (16/31 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (16/31 : ℝ) (33/32 : ℝ) (329/320 : ℝ) greedybundle31_cached_cap_008.1 greedybundle31_cached_cap_008.2.1 greedybundle31_cached_cap_008.2.2.1 greedybundle31_cached_cap_008.2.2.2.1 greedybundle31_cached_cap_008.2.2.2.2.1 greedybundle31_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle31_cached_cap_006.1 greedybundle31_cached_cap_006.2.1 greedybundle31_cached_cap_006.2.2.1 greedybundle31_cached_cap_006.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]
  · linarith only [hql,hzl,ho0,hg0,hgap,hH0,hS,hI,hkmin,hmass]

theorem large_selected_greedy_group_25_31_cell_18
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (16/31 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle31_cached_cap_009.1 greedybundle31_cached_cap_009.2.1 greedybundle31_cached_cap_009.2.2.1 greedybundle31_cached_cap_009.2.2.2.1 greedybundle31_cached_cap_009.2.2.2.2.1 greedybundle31_cached_cap_009.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle31_cached_cap_006.1 greedybundle31_cached_cap_006.2.1 greedybundle31_cached_cap_006.2.2.1 greedybundle31_cached_cap_006.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.1 greedybundle31_cached_cap_006.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hL,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hL,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hL,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hL,hmass]

theorem large_selected_greedy_group_25_31_cell_19
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/31 : ℝ) ≤ q) (hqu : q ≤ (17/62 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (17/62 : ℝ) (3/17 : ℝ) (22/85 : ℝ) greedybundle31_cached_cap_007.1 greedybundle31_cached_cap_007.2.1 greedybundle31_cached_cap_007.2.2.1 greedybundle31_cached_cap_007.2.2.2.1 greedybundle31_cached_cap_007.2.2.2.2.1 greedybundle31_cached_cap_007.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle31_cached_cap_010.1 greedybundle31_cached_cap_010.2.1 greedybundle31_cached_cap_010.2.2.1 greedybundle31_cached_cap_010.2.2.2.1 greedybundle31_cached_cap_010.2.2.2.2.1 greedybundle31_cached_cap_010.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hem,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hg0,hgap,hS,hI,hkmin,hR,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_group_25_31_cell_20
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (17/62 : ℝ) ≤ q) (hqu : q ≤ (16/31 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (16/31 : ℝ) (33/32 : ℝ) (329/320 : ℝ) greedybundle31_cached_cap_008.1 greedybundle31_cached_cap_008.2.1 greedybundle31_cached_cap_008.2.2.1 greedybundle31_cached_cap_008.2.2.2.1 greedybundle31_cached_cap_008.2.2.2.2.1 greedybundle31_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle31_cached_cap_010.1 greedybundle31_cached_cap_010.2.1 greedybundle31_cached_cap_010.2.2.1 greedybundle31_cached_cap_010.2.2.2.1 greedybundle31_cached_cap_010.2.2.2.2.1 greedybundle31_cached_cap_010.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]
  · linarith only [hql,hzl,heq,ho0,hgap,hS,hI,hkmin,hR,hmass]

theorem large_selected_greedy_group_25_31_cell_21
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (16/31 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_group_25_31_cell_22
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hql : (1/31 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle31_cached_cap_009.1 greedybundle31_cached_cap_009.2.1 greedybundle31_cached_cap_009.2.2.1 greedybundle31_cached_cap_009.2.2.2.1 greedybundle31_cached_cap_009.2.2.2.2.1 greedybundle31_cached_cap_009.2.2.2.2.2 hqu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle31_cached_cap_009.1 greedybundle31_cached_cap_009.2.1 greedybundle31_cached_cap_009.2.2.1 greedybundle31_cached_cap_009.2.2.2.1 greedybundle31_cached_cap_009.2.2.2.2.1 greedybundle31_cached_cap_009.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hem,ho0,hgap,hS,hI,hsource,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hgap,hS,hI,hsource,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hgap,hS,hI,hsource,hkmin,hR,hmass]
  · linarith only [hzl,hem,ho0,hgap,hS,hI,hsource,hkmin,hR,hmass]

end TSP.Improvements20261105
