import TSP.Improvements20261105.PairIncomingBudget
import TSP.Improvements20261105.ProjectedCoverComponents

/-! A frozen pair has an actual strictly ancestral matching owner in
the same canonical component. Finite descent therefore proves that
every component containing a pair contains a nonfrozen pair. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem frozen_pair_ancestor_owner (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hfr : HSourceFrozen d x z C s) :
    ∃ u ∈ C.matching, d.tree.depth u < d.tree.depth s ∧
      a.headComponent d P u = a.headComponent d P s := by
  obtain ⟨v,hvH,hpar,hunary⟩ := hfr
  obtain ⟨u,hu,he⟩ := Finset.mem_image.mp
    (fixedHForceTargets_subset d x z (415/2) (704/5) C hvH)
  have hl := C.link_subset hu
  have hactive := (projectionLink_active_endpoints d hs x z hx hn hcap hm u hl).2
  rw [he] at hactive
  have hcomp1 := fixed_pair_same_component d hs x z hx hn hcap hm (415/2) (704/5) C
    P hP t ht f hf hb a ha hcan u hu
  rw [he] at hcomp1
  have hcomp2 := canonical_active_unary_same_component d hs P hP t ht f hf hb a ha hcan
    v s hunary hpar hactive
  have hparv := projectionLinks_parent d x u hl
  rw [he] at hparv
  have hds := d.tree.parent_depth s s.2
  have hdv := d.tree.parent_depth v v.2
  rw [hpar] at hds
  rw [hparv] at hdv
  exact ⟨u,hu,by omega,hcomp1.trans hcomp2⟩

theorem matching_component_has_nonfrozen (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsM : s ∈ C.matching) :
    ∃ u ∈ C.matching, a.headComponent d P u = a.headComponent d P s ∧
      ¬HSourceFrozen d x z C u := by
  let M := C.matching.filter (fun u => a.headComponent d P u = a.headComponent d P s)
  have hM : M.Nonempty := ⟨s,Finset.mem_filter.mpr ⟨hsM,rfl⟩⟩
  obtain ⟨u,hu,hmin⟩ := Finset.exists_min_image M (fun v : d.tree.Child => d.tree.depth v) hM
  have hspec := Finset.mem_filter.mp hu
  refine ⟨u,hspec.1,hspec.2,?_⟩
  intro hfr
  obtain ⟨v,hv,hdepth,hcomp⟩ := frozen_pair_ancestor_owner d hs x z hx hn hcap hm C
    P hP t ht f hf hb a ha hcan u hfr
  have hvM : v ∈ M := Finset.mem_filter.mpr ⟨hv,hcomp.trans hspec.2⟩
  exact (not_lt_of_ge (hmin v hvM)) hdepth

end TSP.Improvements20261105
