import TSP.Chapter06.FlowRounding

/-! Finite convex decomposition of a bounded circulation, with all integer
lower and upper bounds retained in every atom. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem circulation_finite_integral_mixture (N : Graph V E) (f : E → ℝ)
    (hf : Balanced N f) (hn : ∀ e, 0 ≤ f e) :
    ∃ (ι : Type) (_ : Fintype ι) (w : ι → ℝ) (g : ι → E → ℝ),
      (∀ i, 0 < w i) ∧ (∑ i, w i = 1) ∧
      (∀ i, Balanced N (g i)) ∧ (∀ i e, ∃ n : ℕ, g i e = n) ∧
      (∀ i e, (⌊f e⌋ : ℤ) ≤ g i e ∧ g i e ≤ (⌈f e⌉ : ℤ)) ∧
      (∀ e, ∑ i, w i * g i e = f e) := by
  choose b hb using transportVector_integral_degrees N f hf
  have hx : transportVector N f ∈ factorPolytope (transportGraph N) b := by
    apply bipartite_factorPolytope (transportGraph N) (Sum.elim (fun _ => false) (fun _ => true))
      (by rintro (e | v) <;> simp [transportGraph]) b (transportVector_box N f) hb
  obtain ⟨ι, hi, w, J, hw, hsum, hJ, hm⟩ :=
    factorPolytope_positive_decomposition (transportGraph N) b hx
  let g : ι → E → ℝ := fun i e => (⌊f e⌋ : ℤ) + incidence (J i) (.inl e)
  have hsupport (i : ι) (e : E ⊕ V) (he : e ∈ J i) : 0 < transportVector N f e := by
    have hh : w i * incidence (J i) e ≤ ∑ j, w j * incidence (J j) e :=
      Finset.single_le_sum (fun j _ => mul_nonneg (hw j).le (incidence_box (J j) e).1)
        (Finset.mem_univ i)
    rw [hm e] at hh
    have hpos : 0 < w i * incidence (J i) e := by simpa [incidence, he] using hw i
    exact hpos.trans_le hh
  have hbalance (i : ι) : Balanced N (g i) := by
    have hdeg : ∀ v, (transportGraph N).degree (incidence (J i)) v =
        (transportGraph N).degree (transportVector N f) v := by
      intro v
      rw [degree_incidence, hJ i v, hb v]
    intro v
    have hl := hdeg (.inl v)
    have hr := hdeg (.inr v)
    rw [transport_degree_left, transport_degree_left] at hl
    rw [transport_degree_right, transport_degree_right] at hr
    simp only [transportVector, Sum.elim_inl, Sum.elim_inr] at hl hr
    rw [arcSum_fraction] at hl hr
    have hfloor (endpoint : E → V) : arcSum endpoint (fun e => ((⌊f e⌋ : ℤ) : ℝ)) v =
        ((∑ e, if endpoint e = v then ⌊f e⌋ else 0 : ℤ) : ℝ) := by simp [arcSum]
    change arcSum N.src (fun e => _ + _) v = arcSum N.dst (fun e => _ + _) v
    rw [arcSum_add, arcSum_add, hfloor, hfloor]
    have hh := hf v
    linarith
  have hint (i : ι) (e : E) : ∃ n : ℕ, g i e = n := by
    have hfl : 0 ≤ ⌊f e⌋ := Int.floor_nonneg.mpr (hn e)
    have hnat : ((⌊f e⌋).toNat : ℝ) = (⌊f e⌋ : ℤ) := by exact_mod_cast Int.toNat_of_nonneg hfl
    by_cases he : Sum.inl e ∈ J i
    · refine ⟨(⌊f e⌋).toNat + 1, ?_⟩
      simp [g, incidence, he, hnat]
    · refine ⟨(⌊f e⌋).toNat, ?_⟩
      simp [g, incidence, he, hnat]
  have hbds (i : ι) (e : E) : (⌊f e⌋ : ℤ) ≤ g i e ∧ g i e ≤ (⌈f e⌉ : ℤ) := by
    refine ⟨by dsimp [g]; have := (incidence_box (J i) (Sum.inl e)).1; linarith, ?_⟩
    by_cases he : Sum.inl e ∈ J i
    · have hp := hsupport i (.inl e) he
      change 0 < flowFraction f e at hp
      have hlt : ((⌊f e⌋ : ℤ) : ℝ) < f e := by
        change 0 < f e - (⌊f e⌋ : ℤ) at hp
        linarith
      have hle := Int.le_ceil (f e)
      have hi : ⌊f e⌋ < ⌈f e⌉ := by exact_mod_cast hlt.trans_le hle
      have hiR : ((⌊f e⌋ : ℤ) : ℝ) + 1 ≤ (⌈f e⌉ : ℤ) := by
        exact_mod_cast (show ⌊f e⌋ + 1 ≤ ⌈f e⌉ by omega)
      simpa [g, incidence, he] using hiR
    · have hh := (Int.floor_le (f e)).trans (Int.le_ceil (f e))
      simpa [g, incidence, he] using hh
  refine ⟨ι, hi, w, g, hw, hsum, hbalance, hint, hbds, ?_⟩
  intro e
  simp only [g, mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hsum, one_mul, hm]
  simp [transportVector, flowFraction]

theorem bounded_circulation_nat_mixture (N : Graph V E) (f : E → ℝ)
    (lower upper : E → ℕ) (hf : Balanced N f)
    (hbox : ∀ e, (lower e : ℝ) ≤ f e ∧ f e ≤ upper e) :
    ∃ (ι : Type) (_ : Fintype ι) (w : ι → ℝ) (g : ι → E → ℕ),
      (∀ i, 0 < w i) ∧ (∑ i, w i = 1) ∧
      (∀ i, Balanced N (fun e => (g i e : ℝ))) ∧
      (∀ i e, lower e ≤ g i e ∧ g i e ≤ upper e) ∧
      (∀ e, ∑ i, w i * (g i e : ℝ) = f e) := by
  have hn : ∀ e, 0 ≤ f e := fun e => (Nat.cast_nonneg _).trans (hbox e).1
  obtain ⟨ι, hi, w, g, hw, hsum, hb, hint, hbounds, hm⟩ := circulation_finite_integral_mixture N f hf hn
  choose gnat hgnat using hint
  refine ⟨ι, hi, w, gnat, hw, hsum, ?_, ?_, ?_⟩
  · intro i
    have hh := hb i
    have heq : g i = fun e => (gnat i e : ℝ) := funext (hgnat i)
    rwa [heq] at hh
  · intro i e
    have hlo : (lower e : ℤ) ≤ ⌊f e⌋ := Int.le_floor.mpr (by simpa using (hbox e).1)
    have hup : ⌈f e⌉ ≤ (upper e : ℤ) := Int.ceil_le.mpr (by simpa using (hbox e).2)
    have hloR : (lower e : ℝ) ≤ (⌊f e⌋ : ℤ) := by exact_mod_cast hlo
    have hupR : ((⌈f e⌉ : ℤ) : ℝ) ≤ upper e := by exact_mod_cast hup
    have hlow := hloR.trans (hbounds i e).1
    have hhigh := (hbounds i e).2.trans hupR
    rw [hgnat] at hlow hhigh
    exact ⟨by exact_mod_cast hlow, by exact_mod_cast hhigh⟩
  · intro e
    simpa only [hgnat] using hm e

end TSP.Improvements20261105
