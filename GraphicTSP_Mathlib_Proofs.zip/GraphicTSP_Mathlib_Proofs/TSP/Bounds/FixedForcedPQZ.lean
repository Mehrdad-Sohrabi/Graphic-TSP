import TSP.Improvements20261105.MatchedHGain
import TSP.Improvements20261105.JointCoordinateCompletion
import TSP.Improvements20261105.FixedGateSelection

/-! Construct P, Q, and the canonical jointly completed Z in that order,
with the actual current constants. The global role-cost bound is not a
premise or a conclusion of this point-construction theorem. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def currentForcedP (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415 / 2) (704 / 5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex) : E ⊕ d.StarIndex → ℝ :=
  generalPoint d owner rootStar x (fun i => forcedCoverIncrease d x z (415 / 2) (704 / 5) 60 24 4 C
    (fixedHForceTargets d x z (415 / 2) (704 / 5) C) i.1)

theorem exists_current_forced_PQZ (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root) :
    ∃ C : ProjectedCoverWitness d x z (415 / 2) (704 / 5),
    ∃ (Y Z : E ⊕ d.StarIndex → ℝ) (a : GatedDrops d),
      let A := currentForcedP d x z C owner rootStar
      let U := pqConnectorArm d x (415 / 2) (704 / 5) A Y
      let W := pqDeficitArm d x (415 / 2) (704 / 5) A Y
      let t := extendStarValue d (fun i => (max (U i) (W i) - W i) / 48)
      A ∈ projectedFrameworkTwo G d.centers owner ∧
      Y ∈ projectedFrameworkTwo G d.centers owner ∧
      Z ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ s, Y (.inl (d.treeEdge s)) = x (d.treeEdge s) / 2 + preliminaryQIncrease d x s) ∧
      (∀ e ∈ d.backEdges, Y (.inl e) = 1 - x e / 2) ∧
      FixedQConnectorValues d x hx hn hcap Y ∧
      a.Admissible d (fixedGatePlan d x) ∧
      (∃ f : GatedArc d → ℝ,
        Chapter06.Balanced (gatedNetwork d (fixedGatePlan d x)) f ∧
        RealFlowBounds (gatedLower d (fixedGatePlan d x)) (gatedAugmentedUpper d (fixedGatePlan d x) t) f ∧
        CanonicalGatedFor d (fixedGatePlan d x) t f (a.potential d (fixedGatePlan d x))) ∧
      edgeSum Z (nonremovableRepresentatives d.stars) = ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 ∧
      (∑ i : d.StarIndex,
        max (U i + 72 * (Z (.inr i) - gatedArmBase d i.1))
          (W i + 72 * ((d.stars i).card - 1 - edgeSum Z (starRepresentatives d.stars i) - gatedArmBase d i.1))) ≤
      (∑ i : d.StarIndex, jointHeadTerm (U i) (W i) (a.head i.1 : ℝ)) +
        48 * a.value d (fixedGatePlan d x) (fun _ => 0) := by
  obtain ⟨C⟩ := exists_fixed_projected_cover d hs x z hx hn hcap hm (415 / 2) (704 / 5)
    (by norm_num) (by norm_num) (by norm_num)
  let A := currentForcedP d x z C owner rootStar
  have hA : A ∈ projectedFrameworkTwo G d.centers owner :=
    forced_P_feasible d hs x z hx hn hcap hm (415 / 2) (704 / 5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C (fixedHForceTargets d x z (415 / 2) (704 / 5) C)
      (fixedHForceTargets_subset d x z (415 / 2) (704 / 5) C) hc owner ho rootStar hroot
  obtain ⟨Y, hY, hr, hb, hconn, _⟩ := exists_preliminary_Q d hs x hx hn hcap owner ho
  obtain ⟨Z, a, hZ, ha, hf, hN, hcost⟩ := exists_joint_coordinate_completion d hs hc
    (fixedGatePlan d x) (fixedGatePlan_valid d x) owner ho
    (pqConnectorArm d x (415 / 2) (704 / 5) A Y) (pqDeficitArm d x (415 / 2) (704 / 5) A Y)
    24 (by norm_num)
  refine ⟨C, Y, Z, a, hA, hY, hZ, hr, hb, hconn, ha, ?_, hN, ?_⟩
  · simpa only [show (2 * (24 : ℝ)) = 48 by norm_num] using hf
  · simpa only [show (3 * (24 : ℝ)) = 72 by norm_num, show (2 * (24 : ℝ)) = 48 by norm_num] using hcost

end TSP.Improvements20261105
