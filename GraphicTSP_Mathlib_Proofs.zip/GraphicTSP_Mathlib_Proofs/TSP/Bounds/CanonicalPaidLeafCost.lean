import TSP.Improvements20261105.GlobalRefinedCost
import TSP.Improvements20261105.TotalCouponPayment
import TSP.Improvements20261105.SelectedHeadSums
import TSP.Improvements20261105.CanonicalLeafCouponCost
import TSP.Improvements20261105.PaidLeafCost

/-! Combine incidence with the exact selected-back mass identity.
Internal mass, penalties and true-cut coverage are kept explicit so
leaf entries are allocated before the remaining coverage reserve is spent. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_paid_leaf_elimination (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (S : Finset d.tree.Child) (hscore : ScoreComparisons d x S)
    (T : Finset d.tree.Child) (hTS : T ⊆ S)
    (hT : ∀ s ∈ T, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (b : d.tree.Child → ℝ) (hbcap : ∀ s, b s ≤ 1)
    (hbout : ∀ s, P.kind s = .outsideGate → b s ≤ outsideBackMass d P (fun e => x e.1) s)
    (q : d.tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, (d.backGroup s).card ≤ 3 → ∀ e ∈ d.backGroup s, z e ≤ q s)
    (hn : 2 ≤ Fintype.card V)
    (hprojection : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hrootStar : d.centers rootStar = d.tree.root)
    (R : E ⊕ d.StarIndex → ℝ)
    (Q : E ⊕ d.StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G d.centers owner)
    (hrep : ∀ c, Q (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Q (.inl e) = 1-x e/2)
    (m : d.StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x (d.treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Q i)
    (hconn : FixedQConnectorValues d x hx hn hcap R)
    (hloss : ∀ i, edgeSum Q (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Q i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
      m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1) :
    let L := a.paidLeafRoots d P x
    let J := a.paidLeafHeads d P x
    let J0 := a.componentStarUnion d P (a.zeroLeafRoots d P x)
    let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
    48*a.value d P (fun _ => 0)+(∑ i : d.StarIndex, cost i)-
      (704/5 : ℝ)*((∑ i ∈ fixedZeroTerminalHeads d x, m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, m i)) ≤
      (∑ s ∈ a.selectedHeads d,
        (24*(edgeSum z (d.backGroup s)-gatedFreeBase d s)+refinedIncidenceCharge d x z S T s-
          24*accountedCoupon d P b s+24*couponResidual d P (fun e => x e.1) b s))+
      24*((a.headfulLeafComponents d P).card-L.card-1-(a.selectedRootHeads d).card)-
      (162/19)*(∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z S r : ℝ))+
      72*(∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s)+
      (244/5)*(edgeSum x Finset.univ-Fintype.card V)-12*Chapter11.totalOverage d x+
      (∑ i ∈ Finset.univ \ J, cost i)-
      (704/5 : ℝ)*((∑ i ∈ fixedZeroTerminalHeads d x \ J0, m i)+
        (∑ i ∈ fixedPositiveTerminalHeads d x \ a.positiveTerminalLeafHeads d P x, m i))+
      a.zeroLeafOwnedError d P x := by
  let L := a.paidLeafRoots d P x
  let J := a.paidLeafHeads d P x
  let J0 := a.componentStarUnion d P (a.zeroLeafRoots d P x)
  let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
  have hledger := canonical_leaf_coupon_cost_ledger d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
    x z hx hcap hz hzx S hscore T hTS hT b hbcap hbout
    (a.paidLeafCuts d P x) (a.paidLeafCuts_subset d P x) q hq hpack hsmall
  rw [a.paidLeafCuts_sum d P x (fun r => 24*(2-componentEntryCoverage d x r)), a.paidLeafCuts_card d P x] at hledger
  have hleaf := a.current_paid_leaf_cost d hs P hP t ht f hf hb ha hcan x z hx hn hcap
    hprojection C owner ho rootStar hrootStar R Q hQ hrep hbacks m hm0 hm hguarded hconn hloss hmpositive
  have hmass := a.zero_guard_mass_partition d P x m (a.zeroLeafRoots d P x)
  have hposmass : (∑ i ∈ fixedPositiveTerminalHeads d x, m i) =
      (∑ i ∈ a.positiveTerminalLeafHeads d P x, m i)+
      (∑ i ∈ fixedPositiveTerminalHeads d x \ a.positiveTerminalLeafHeads d P x, m i) := by
    simpa only [add_comm] using
      (Finset.sum_sdiff (Finset.filter_subset _ _ : a.positiveTerminalLeafHeads d P x ⊆ fixedPositiveTerminalHeads d x) (f := m)).symm
  have hheads : (∑ i : d.StarIndex, cost i) =
      (∑ i ∈ J, cost i)+(∑ i ∈ Finset.univ \ J, cost i) := by
    simpa only [add_comm] using (Finset.sum_sdiff (Finset.subset_univ J) (f := cost)).symm
  dsimp only [L,J,J0,cost] at hheads ⊢
  linarith

end TSP.Improvements20261105
