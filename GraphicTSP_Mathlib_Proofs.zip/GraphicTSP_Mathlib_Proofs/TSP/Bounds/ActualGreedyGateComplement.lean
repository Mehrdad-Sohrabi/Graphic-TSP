import TSP.Improvements20261105.ScoredSuccessorPacking
import TSP.Improvements20261105.PairIncomingBudget

/-! The actual non-scored DFS branch satisfies the continuous gate
complement used by the finite scalar cells. The parent alternative is
proved from the incoming edge and the projection identity. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_unscored_maximum (s : (d).tree.Child) (hnot : ¬ScoredStar d x s) :
    starMaximum d x s = x ((d).treeEdge s) := by
  apply le_antisymm
  · apply finiteMaximum_le x ((d).group s) ((d).group_nonempty s)
    intro e he
    rw [(d).group_eq_insert_backGroup] at he
    rcases Finset.mem_insert.mp he with he | he
    · rw [he]
    · exact scoredDFS_not_scored_greedy G x hs hc root s hnot e he
  · exact le_finiteMaximum x ((d).mem_group s _ |>.mpr ((d).anchor_treeEdge s))

theorem scoredDFS_positive_greedy_gate_complement
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (s : (d).tree.Child) (hnr : (d).tree.parent s ≠ (d).tree.root)
    (hnot : ¬ScoredStar d x s) (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hlo : 4 ≤ ((d).backGroup s).card) (hhi : ((d).backGroup s).card ≤ 25) :
    x ((d).treeEdge s) ≤ ScoredParameters.lower ((d).backGroup s).card ∨
      ScoredParameters.upper ((d).backGroup s).card ≤ x ((d).treeEdge s) ∨
      x ((d).treeEdge s)+edgeSum z ((d).backGroup s) ≤
        2-ScoredParameters.incomingThreshold ((d).backGroup s).card := by
  have hM := scoredDFS_unscored_maximum G x hs hc root s hnot
  by_cases hlow : x ((d).treeEdge s) ≤ ScoredParameters.lower ((d).backGroup s).card
  · exact Or.inl hlow
  by_cases hhigh : ScoredParameters.upper ((d).backGroup s).card ≤ x ((d).treeEdge s)
  · exact Or.inr (Or.inl hhigh)
  have hin : ScoredParameters.incomingThreshold ((d).backGroup s).card < starIncoming d x s := by
    by_contra hh
    apply hnot
    refine ⟨hnr,hlo,hhi,le_of_not_gt hh,?_,?_⟩ <;> rw [hM] <;> linarith
  let v : (d).tree.Child := ⟨(d).tree.parent s,hnr⟩
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have hepos : 0 < survivingExcess d x s := by linarith
  have hp := surviving_incoming_complement d hs x hx s v rfl hepos
  rw [starIncoming_eq_parent d x s v rfl] at hin
  exact Or.inr (Or.inr (by linarith only [he,hp,hin]))

end TSP.Improvements20261105
