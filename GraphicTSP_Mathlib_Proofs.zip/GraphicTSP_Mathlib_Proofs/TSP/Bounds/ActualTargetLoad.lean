import TSP.Improvements20261105.UniversalGreedyLoad
import TSP.Improvements20261105.BoundedBackLoad
import TSP.Improvements20261105.CanonicalHeadLoad

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]

theorem actual_target_load (G : Graph V E) (x z : E → ℝ)
    (hs : G.IsSimple) (hc : G.Connected) (root : V)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((scoredDFS G x hs hc root).backGroup s) =
      edgeSum x ((scoredDFS G x hs hc root).backGroup s)-
        fixedRemoval (scoredDFS G x hs hc root) x (allFullOverrideTargets (scoredDFS G x hs hc root) x) s)
    (P : GatePlan (scoredDFS G x hs hc root))
    (eligible R : Finset (scoredDFS G x hs hc root).tree.Child)
    (b : (scoredDFS G x hs hc root).tree.Child → ℝ) (hb : ∀ s, 0 ≤ b s)
    (i : (scoredDFS G x hs hc root).StarIndex) :
    let d := scoredDFS G x hs hc root
    canonicalHeadLoad d P x z (fixedCriticalHeads d x z eligible) R b i.1 ≤
      54+4*((d.backGroup i.1).card : ℝ) := by
  let d := scoredDFS G x hs hc root
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm i.1
  have hq := hx.1 (d.treeEdge i.1)
  have hr := refined_fixed_incidence_le_noncritical d x z eligible R i.1
  have hu := canonicalHeadLoad_le_uncouponed d P x z hx.1 (fixedCriticalHeads d x z eligible) R b hb i.1
  by_cases hsc : ScoredStar d x i.1
  · have hmax := hsc.2.2.2.2.2.trans (ScoredParameters.upper_bounds _).2
    have hzcap : ∀ e ∈ d.backGroup i.1, z e ≤ 43/100 := by
      intro e he
      exact (hzx e).trans ((le_finiteMaximum x (Finset.mem_sdiff.mp he).1).trans hmax)
    have hload := bounded_back_noncritical_load d z i.1 (fun e _ => hz e) hzcap (by linarith)
    have hcount : (4 : ℝ) ≤ (d.backGroup i.1).card := by exact_mod_cast hsc.2.1
    change _ ≤ _
    linarith
  · have hg := scoredDFS_not_scored_greedy G x hs hc root i.1 hsc
    have hload := universal_greedy_noncritical_load d z i.1 (x (d.treeEdge i.1)) hq
      (fun e _ => hz e) (fun e he => (hzx e).trans (hg e he)) (by linarith)
    have hcount : (1 : ℝ) ≤ (d.backGroup i.1).card := by
      exact_mod_cast Finset.card_pos.mpr i.2
    change _ ≤ _
    linarith

end TSP.Improvements20261105
