import TSP.Improvements20261105.GatedLift

/-! Feasibility and integral primal/dual optima of the actual gated network
for every finite simple two-vertex-connected input graph. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem two_connected_as_k (hs : IsTwoVertexConnected G) : G.IsKVertexConnected 2 := by
  refine ⟨hs.1, ?_⟩
  intro D hD u v hu hv
  by_cases hz : D.card = 0
  · have he : D = ∅ := Finset.card_eq_zero.mp hz
    subst D
    simpa [liveEdges] using hs.2.1.2 u v
  · have ho : D.card = 1 := by omega
    obtain ⟨z, rfl⟩ := Finset.card_eq_one.mp ho
    simpa [liveEdges] using hs.2.2 z u v (by simpa using hu) (by simpa using hv)

theorem gated_lift_feasible (P : GatePlan d) (g : FlowArc d → ℝ)
    (hg : IsFeasibleCirculation d g)
    (hrep : ∀ v : d.tree.Child, ¬(d.backGroup v).Nonempty → 1 ≤ g (.inl (.inr v))) :
    Balanced (gatedNetwork d P) (routeFlow (gatedLiftRoute d P) g) ∧
      OptionalFlowBounds (gatedLower d P) (gatedUpper d P) (routeFlow (gatedLiftRoute d P) g) := by
  have hn : ∀ a, 0 ≤ g a := feasible_flow_nonneg d hg
  have hnew : ∀ a, 0 ≤ routeFlow (gatedLiftRoute d P) g a :=
    routeFlow_nonneg _ _ (gatedLiftRoute_nonnegative d P) hn
  refine ⟨gated_lift_balanced d P g hg.2, ?_⟩
  intro a
  refine ⟨?_, gated_lift_upper d P g a⟩
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · by_cases hv : d.tree.parent v = d.tree.root
    · simpa [gatedLower, hv] using hnew (gatedSuffixArc d v)
    · have hl := hg.1 (.inl (.inl v))
      simp only [flowLowerBound, Sum.elim_inl, if_pos hv] at hl
      have ht := gated_lift_single_lower d P g hn (.inl (.inl v)) (gatedSuffixArc d v)
        (by simp [gatedLiftRoute, gatedConnectorRoute, singleArcFlow])
      simpa [gatedLower, hv] using hl.trans ht
  · by_cases hv : (d.backGroup v).Nonempty
    · simpa [gatedLower, hv] using hnew (gatedRepArc d v)
    · have ht := gated_lift_single_lower d P g hn (.inl (.inr v)) (gatedRepArc d v)
        (by simp [gatedLiftRoute, singleArcFlow])
      simpa [gatedLower, hv] using (hrep v hv).trans ht
  · simpa [gatedLower] using hnew (gatedBackArc d b)
  · simpa [gatedLower] using hnew (gatedTailArc d v)
  · by_cases hh : k = 0 ∧ d.tree.parent v ≠ d.tree.root ∧ ¬P.IsReceiver d v
    · obtain ⟨rfl, hv, hr⟩ := hh
      have hl := hg.1 (.inl (.inl v))
      simp only [flowLowerBound, Sum.elim_inl, if_pos hv] at hl
      have ht := gated_lift_single_lower d P g hn (.inl (.inl v)) (gatedPrefixArc d v)
        (by simp [gatedLiftRoute, gatedConnectorRoute, singleArcFlow])
      simpa [gatedLower, hv, hr] using hl.trans ht
    · simpa [gatedLower, hh] using hnew (.inr (.inr (v, k)))

theorem unit_back_nonremovable_coverage (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (v : d.tree.Child) (hv : ¬(d.backGroup v).Nonempty) :
    1 ≤ weightedBackFlow d (fun _ => 1) (.inl (.inr v)) := by
  have hp : d.tree.parent v ≠ d.tree.root := by
    intro hr
    obtain ⟨i, hi, _⟩ := root_star_exists d hc (twoVertexConnected_min_degree G hs hc _)
    have he : v = i.1 := root_children_unique d hc v i.1 hr hi
    exact hv (he.symm ▸ i.2)
  have hf := weightedBackFlow_feasible d hs (by decide : 2 ≤ 2) (two_connected_as_k hc)
    (fun _ => 1) (by intro b; norm_num)
  have hl := hf.1 (.inl (.inl v))
  simp only [flowLowerBound, Sum.elim_inl, if_pos hp] at hl
  have hg := conservation_at_group d _ hf.2 v
  have hb : 0 ≤ backInflow d (weightedBackFlow d (fun _ => 1)) v := by
    unfold backInflow
    exact Finset.sum_nonneg (fun b _ => by
      split_ifs <;> first | exact weightedBackFlow_nonneg d _ (by intro; norm_num) _ | exact le_rfl)
  linarith

theorem exists_feasible_gated_circulation (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) :
    ∃ f : GatedArc d → ℝ, Balanced (gatedNetwork d P) f ∧
      OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f := by
  have hf := weightedBackFlow_feasible d hs (by decide : 2 ≤ 2) (two_connected_as_k hc)
    (fun _ => 1) (by intro b; norm_num)
  exact ⟨_, gated_lift_feasible d P _ hf (unit_back_nonremovable_coverage d hs hc)⟩

theorem gated_integral_primal_dual (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) :
    ∃ (g : GatedArc d → ℕ) (p : GatedVertex d → ℤ),
      Balanced (gatedNetwork d P) (fun a => (g a : ℝ)) ∧
      OptionalFlowBounds (gatedLower d P) (gatedUpper d P) (fun a => (g a : ℝ)) ∧
      (∀ a, gatedUpper d P a = none →
        p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)) ∧
      optionalDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
        (gatedLower d P) (gatedUpper d P) (fun v => (p v : ℝ)) =
          ∑ v, (g (gatedPaidArc d v) : ℝ) := by
  obtain ⟨g, p, hg, hb, hp, heq, _⟩ := feasible_circulation_integral_primal_dual
    (gatedNetwork d P) (gatedCost d) (gatedLower d P) (gatedUpper d P)
    (exists_feasible_gated_circulation d hs hc P)
  exact ⟨g, p, hg, hb, hp, heq.trans (gated_cost_sum d _)⟩

end TSP.Improvements20261105
