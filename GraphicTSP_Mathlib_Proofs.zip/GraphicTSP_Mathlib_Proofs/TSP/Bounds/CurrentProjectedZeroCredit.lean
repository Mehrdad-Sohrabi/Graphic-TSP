import TSP.Improvements20261105.ProjectedZeroCreditDeficit
import TSP.Improvements20261105.NoLinkUnaryPBaseline

/-! When the actual P connector has no export debit, a projected-zero
head retains its entire Q credit after the common P projection charge. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (x z : E → ℝ) (hx : G.SubtourFeasible x)
variable (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
variable (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
  fixedRemoval d x (allFullOverrideTargets d x) s)
variable (C : ProjectedCoverWitness d x z (415/2) (704/5))
variable (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
variable (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)

include hs hx hn hcap hm hY in
theorem current_projected_zero_credit_max (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1)
    (hPconn : currentGuardedP d x z C owner rootStar (.inr i) ≤
      1/3+2/3*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)
    (hguard : max (R (.inr i)-edgeSum x (d.stars i)/2)
      ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
        -zeroQCredit d x Y i) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*zeroQCredit d x Y i := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  let delta := terminalPIncrease d x (fixedPositiveTerminalChildren d x)
    (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H j.1)
  have hd : AdmissibleAdjustment d x delta := by
    apply terminalPIncrease_admissible d hs x hx hn hcap
    exact forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C H (fixedHForceTargets_subset d x z (415/2) (704/5) C)
  have hdef := guarded_projected_zero_credit_deficit d hs x z hx hn hcap hm Y R hY
    (415/2) (704/5) (by norm_num) (by norm_num) delta hd owner rootStar i hnr hz hguard
  have hq := (le_max_left _ _).trans hguard
  have hconn : pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*zeroQCredit d x Y i := by
    unfold pqConnectorArm
    linarith only [hPconn,hq]
  change pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-_ ≤ _ at hdef
  exact sub_le_iff_le_add.mpr (max_le (sub_le_iff_le_add.mp hconn) (sub_le_iff_le_add.mp hdef))

include hs hx hn hcap hm hY in
theorem current_no_link_zero_credit_max (ho : ValidOwner d.stars owner)
    (hroot : d.centers rootStar = d.tree.root)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hl : v ∉ projectionLinks d x) (hunary : childCount d v=1)
    (hnotH : ¬HSourceFrozen d x z C i.1)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1)
    (hguard : max (R (.inr i)-edgeSum x (d.stars i)/2)
      ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
        -zeroQCredit d x Y i) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*zeroQCredit d x Y i := by
  have hnr : d.centers i ≠ d.tree.root := by rw [hv]; exact v.2
  exact current_projected_zero_credit_max d hs x z hx hn hcap hm C owner rootStar Y R hY i hnr hz
    (current_no_link_unary_P_baseline d hs x z hx hn hcap hm C owner ho rootStar hroot i v hv hl hunary hnotH)
    hguard

include hs hx hn hcap hm hY in
theorem current_branch_zero_credit_max (ho : ValidOwner d.stars owner)
    (hroot : d.centers rootStar = d.tree.root)
    (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root) (hbranch : 2 ≤ childCount d (d.centers i))
    (hz : edgeSum z (d.backGroup i.1) ≤ 1)
    (hguard : max (R (.inr i)-edgeSum x (d.stars i)/2)
      ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
        -zeroQCredit d x Y i) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*zeroQCredit d x Y i := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  let delta := terminalPIncrease d x (fixedPositiveTerminalChildren d x)
    (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H j.1)
  have hd : AdmissibleAdjustment d x delta := by
    apply terminalPIncrease_admissible d hs x hx hn hcap
    exact forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C H (fixedHForceTargets_subset d x z (415/2) (704/5) C)
  have hir : i ≠ rootStar := fun he => hnr (he ▸ hroot)
  have hp := enlarged_connector_many_children d hs owner ho rootStar x hx hcap delta hd i hir hbranch
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  apply current_projected_zero_credit_max d hs x z hx hn hcap hm C owner rootStar Y R hY i hnr hz _ hguard
  change currentGuardedP d x z C owner rootStar (.inr i) ≤ _ at hp
  linarith only [hp,ht]

end TSP.Improvements20261105
