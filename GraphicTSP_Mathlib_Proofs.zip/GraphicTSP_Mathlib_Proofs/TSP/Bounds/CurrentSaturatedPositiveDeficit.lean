import TSP.Improvements20261105.CurrentProjectedDeficitEstimates
import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (x z : E → ℝ) (hx : G.SubtourFeasible x)
variable (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
variable (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
  fixedRemoval d x (allFullOverrideTargets d x) s)
variable (C : ProjectedCoverWitness d x z (415/2) (704/5))
variable (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
variable (R : E ⊕ d.StarIndex → ℝ) (i : d.StarIndex)
variable (hR : (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
  -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)

include hs hx hn hcap hm hR in
theorem current_projected_saturated_positive_deficit (hnr : d.centers i ≠ d.tree.root)
    (hp : 1 < edgeSum z (d.backGroup i.1))
    (hout : survivingExcess d x i.1 ≤ outgoingBackMass d x i.1) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5)*(x (d.treeEdge i.1)+survivingExcess d x i.1) := by
  change d.tree.parent (i.1 : V) ≠ d.tree.root at hnr
  have hb := current_positive_deficit_bound d hs x z hx hn hcap hm C owner rootStar R i hR hp
  have hfree := coveredPIncrease_free_lower d hs x z hx hn hcap hm (415/2) (704/5)
    (by norm_num) (by norm_num) C i.1 hnr
  rw [min_eq_left hout] at hfree
  have hg := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C) i.1
  have heta : preliminaryQIncrease d x i.1=survivingExcess d x i.1 := by
    rw [preliminaryQIncrease,if_neg hnr,min_eq_left hout]
  rw [heta] at hb
  linarith only [hb,hfree,hg]

end TSP.Improvements20261105
