import TSP.Improvements20261105.RealCapacityMinimum

/-! The capacity-one circulation model of a bipartite matching. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {L R E : Type} [Fintype L] [Fintype R] [Fintype E]
  [DecidableEq L] [DecidableEq R] [DecidableEq E]

abbrev MatchingVertex (L R : Type) := L ⊕ (R ⊕ Bool)
abbrev MatchingArc (L R E : Type) := E ⊕ ((L ⊕ R) ⊕ Unit)

def matchingNetwork (left : E → L) (right : E → R) :
    Graph (MatchingVertex L R) (MatchingArc L R E) where
  src := fun a => match a with
    | .inl e => .inl (left e)
    | .inr (.inl (.inl _)) => .inr (.inr false)
    | .inr (.inl (.inr r)) => .inr (.inl r)
    | .inr (.inr _) => .inr (.inr true)
  dst := fun a => match a with
    | .inl e => .inr (.inl (right e))
    | .inr (.inl (.inl l)) => .inl l
    | .inr (.inl (.inr _)) => .inr (.inr true)
    | .inr (.inr _) => .inr (.inr false)

def matchingCapacity : MatchingArc L R E → ℕ
  | .inl _ => 2
  | .inr (.inl _) => 1
  | .inr (.inr _) => Fintype.card L + Fintype.card R + 1

noncomputable def matchingCost (w : E → ℝ) : MatchingArc L R E → ℝ
  | .inl e => -w e
  | .inr _ => 0

theorem matching_left_balance (left : E → L) (right : E → R)
    (f : MatchingArc L R E → ℝ) (hf : Balanced (matchingNetwork left right) f) (l : L) :
    (∑ e, if left e = l then f (.inl e) else 0) = f (.inr (.inl (.inl l))) := by
  simpa [arcSum, matchingNetwork, Fintype.sum_sum_type] using hf (.inl l)

theorem matching_right_balance (left : E → L) (right : E → R)
    (f : MatchingArc L R E → ℝ) (hf : Balanced (matchingNetwork left right) f) (r : R) :
    (∑ e, if right e = r then f (.inl e) else 0) = f (.inr (.inl (.inr r))) := by
  simpa [arcSum, matchingNetwork, Fintype.sum_sum_type] using (hf (.inr (.inl r))).symm

theorem matching_source_balance (left : E → L) (right : E → R)
    (f : MatchingArc L R E → ℝ) (hf : Balanced (matchingNetwork left right) f) :
    (∑ l, f (.inr (.inl (.inl l)))) = f (.inr (.inr ())) := by
  simpa [arcSum, matchingNetwork, Fintype.sum_sum_type] using hf (.inr (.inr false))

theorem matching_edge_le_one (left : E → L) (right : E → R)
    (f : MatchingArc L R E → ℝ) (hf : Balanced (matchingNetwork left right) f)
    (hb : ∀ a, 0 ≤ f a ∧ f a ≤ matchingCapacity a) (e : E) : f (.inl e) ≤ 1 := by
  have hs := matching_left_balance left right f hf (left e)
  have hle : f (.inl e) ≤ ∑ a, if left a = left e then f (.inl a) else 0 := by
    have hh := Finset.single_le_sum (s := Finset.univ)
      (f := fun a => if left a = left e then f (.inl a) else 0)
      (fun a _ => by dsimp only; split_ifs; exact (hb _).1; exact le_rfl) (Finset.mem_univ e)
    simpa using hh
  rw [hs] at hle
  exact hle.trans (by simpa [matchingCapacity] using (hb (.inr (.inl (.inl (left e))))).2)

theorem matching_return_lt_capacity (left : E → L) (right : E → R)
    (f : MatchingArc L R E → ℝ) (hf : Balanced (matchingNetwork left right) f)
    (hb : ∀ a, 0 ≤ f a ∧ f a ≤ matchingCapacity a) :
    f (.inr (.inr ())) < matchingCapacity (.inr (.inr ()) : MatchingArc L R E) := by
  have hs := matching_source_balance left right f hf
  have hle : (∑ l, f (.inr (.inl (.inl l)))) ≤ (Fintype.card L : ℝ) := by
    calc
      _ ≤ ∑ _ : L, (1 : ℝ) := Finset.sum_le_sum (fun l _ => by
        simpa [matchingCapacity] using (hb (.inr (.inl (.inl l)))).2)
      _ = _ := by simp
  rw [hs] at hle
  simp only [matchingCapacity, Nat.cast_add, Nat.cast_one]
  have hR := Nat.cast_nonneg (α := ℝ) (Fintype.card R)
  linarith

theorem matching_cost_sum (w : E → ℝ) (f : MatchingArc L R E → ℝ) :
    (∑ a, matchingCost w a * f a) = -(∑ e, w e * f (.inl e)) := by
  simp [matchingCost, Fintype.sum_sum_type, Finset.sum_neg_distrib]

end TSP.Improvements20261105
