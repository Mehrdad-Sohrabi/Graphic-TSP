import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost
import TSP.Improvements20261105.HighQGroupOwnership

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_branch_source_max (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (hi : HighQGroupOwner d x z C i.1) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ 0 := by
  have hnr : d.centers i ≠ d.tree.root := (Finset.mem_filter.mp hi.2.1).2.1
  have hu : childCount d (d.centers i) ≠ 1 := by
    change childCount d (d.tree.parent i.1) ≠ 1
    have hh := hi.1
    omega
  have hh := current_projected_guarded_max_cover d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero i hnr
  have hc : currentIncomingForceCharge d x z C i=0 := by
    simp only [currentIncomingForceCharge,dif_pos hnr,if_neg hu]
  rw [hc,add_zero,C.unmatched_floor i.1 hi.2.2] at hh
  exact hh.trans (fixedCoverFloor_nonpositive d hs x z hx hcap (704/5) (by norm_num) i.1)

end TSP.Improvements20261105
