import TSP.Improvements20261105.RaisedStarDeficits
import TSP.Improvements20261105.CoveredPExport

/-! The actual P/Q deficit arm uses the same common projection charge as
the connector arm. There is no second removal reserve. -/
namespace TSP.Improvements20261105
open Graph Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem coveredPQ_deficit (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y : E ⊕ d.StarIndex → ℝ)
    (hr : ∀ s, Y (.inl (d.treeEdge s)) = x (d.treeEdge s) / 2 + preliminaryQIncrease d x s)
    (hb : ∀ e ∈ d.backEdges, Y (.inl e) = 1 - x e / 2)
    (i : d.StarIndex) (hi : d.centers i ≠ d.tree.root) :
    (3 * P / 2) * ((d.stars i).card - 1 -
      edgeSum (generalPoint d owner rootStar x (fun j => coveredPIncrease d x P Q C.cover j.1))
        (starRepresentatives d.stars i) - 1 / 3) +
      Q * ((d.stars i).card - 1 - edgeSum Y (starRepresentatives d.stars i) - edgeSum x (d.stars i) / 2) -
      P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 := by
  have hp := generalP_deficit d owner rootStar x (fun j => coveredPIncrease d x P Q C.cover j.1) i
  rw [coveredPIncrease_extension d hs x z hx hn hcap hm P Q hP hQ C i.1] at hp
  have hq := raisedQ_deficit d x (preliminaryQIncrease d x) Y hr hb i
  have hpP := congrArg (fun r : ℝ => P * r) hp
  have hqQ := congrArg (fun r : ℝ => Q * r) hq
  dsimp only at hpP hqQ
  have hraw := coveredPIncrease_deficit d hs x z hx hn hcap hm P Q hP hQ C i.1 hi
  rw [hm] at hraw
  have hrem : fixedRemoval d x (allFullOverrideTargets d x) i.1 ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := le_max_right _ _
  have hremP := mul_le_mul_of_nonneg_left hrem hP.le
  nlinarith

end TSP.Improvements20261105
