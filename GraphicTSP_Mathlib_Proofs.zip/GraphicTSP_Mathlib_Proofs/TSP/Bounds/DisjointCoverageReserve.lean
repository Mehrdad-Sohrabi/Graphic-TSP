import TSP.Improvements20261105.GatedDeficitBudget
import TSP.Improvements20261105.GatedDonorResources

/-! Active optional gate prefixes and true cuts have disjoint connector
owners. Their combined deficiency costs only one copy of LP excess. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def GatedDrops.ActiveGate (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) : Prop :=
  P.IsReceiver d v ∧ 0 < a.pref v

noncomputable def GatedDrops.activeGateDeficit (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) : ℝ :=
  ∑ v : d.tree.Child, if a.ActiveGate d P v then max (1 - edgeSum x (deletedSubtreeCut d v)) 0 else 0

theorem activeGate_not_root {P : GatePlan d} (hP : P.RespectsTree d) (a : GatedDrops d)
    (v : d.tree.Child) (hv : a.ActiveGate d P v) : d.tree.parent v ≠ d.tree.root := by
  obtain ⟨s, hs, hr⟩ := hv.1
  have hh := hP s hs
  rw [hr] at hh
  exact fun he => s.2 (hh.symm.trans he)

theorem canonical_activeGate_not_trueCut (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (v : d.tree.Child) (hv : a.ActiveGate d P v) : expandedConnectorChild d v ∉ a.trueCuts d P := by
  have hrec := canonical_gate_receiver_selected d hs hc P hP t f hf hb (a.potential d P) hcan
    v hv.1 (by simpa using hv.2)
  simp only [GatedDrops.potential_headSelector] at hrec
  have hpaid := ha.paid v
  rw [hrec, if_pos hv.1] at hpaid
  have hsuf : a.suffix v = 0 := by have hn := ha.suffix_nonneg v; omega
  simp [GatedDrops.trueCuts, GatedDrops.trueRoleWeight, hv.1, hsuf]

theorem canonical_disjoint_coverage_deficits (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) :
    a.trueDeficit d P (fun b => x b.1) + a.activeGateDeficit d P x ≤
      ∑ u ∈ Finset.univ.erase d.tree.root, vertexDeficit d x u := by
  let C (w : (expandedTree d).Child) : ℝ :=
    if w ∈ a.trueCuts d P then max (1 - a.cutCoverage d (fun b => x b.1) w) 0 else 0
  have hc (v : d.tree.Child) : C (expandedConnectorChild d v) +
      (if a.ActiveGate d P v then max (1 - edgeSum x (deletedSubtreeCut d v)) 0 else 0) ≤
      if d.tree.parent v = d.tree.root then (0 : ℝ) else max (1 - edgeSum x (deletedSubtreeCut d v)) 0 := by
    by_cases hv : a.ActiveGate d P v
    · have hn := canonical_activeGate_not_trueCut d hs hc P hP t f hf hb a ha hcan v hv
      simp [C, hn, hv, activeGate_not_root d hP a v hv]
    · rw [if_neg hv, add_zero]
      by_cases hr : d.tree.parent v = d.tree.root
      · have hn : expandedConnectorChild d v ∉ a.trueCuts d P := by
          simp [GatedDrops.trueCuts, GatedDrops.trueRoleWeight, hr]
        simp [C, hn, hr]
      · rw [if_neg hr]
        by_cases hm : expandedConnectorChild d v ∈ a.trueCuts d P
        · simp [C, hm, a.connector_cutCoverage d x v]
        · simp only [C, if_neg hm]
          exact le_max_right _ _
  have hr (v : d.tree.Child) : C (expandedRepresentativeChild d v) = 0 := by
    by_cases hm : expandedRepresentativeChild d v ∈ a.trueCuts d P
    · simp only [C, if_pos hm]
      apply max_eq_right
      linarith [a.true_representative_coverage_ge_one d P hx hcap v hm]
    · simp [C, hm]
  have he : a.trueDeficit d P (fun b => x b.1) =
      ∑ v : d.tree.Child, (C (expandedConnectorChild d v) + C (expandedRepresentativeChild d v)) := by
    have hh : a.trueDeficit d P (fun b => x b.1) = ∑ w : (expandedTree d).Child, C w := by
      simp [GatedDrops.trueDeficit, C]
    rw [hh, ← (expandedTreeRoles d).sum_comp, Fintype.sum_sum_type, ← Finset.sum_add_distrib]
    rfl
  rw [he, ← nonroot_connector_deficit_sum]
  simp_rw [hr, add_zero]
  unfold GatedDrops.activeGateDeficit
  rw [← Finset.sum_add_distrib]
  exact Finset.sum_le_sum (fun v _ => hc v)

theorem GatedDrops.neg_coverageExcess_le_trueDeficit (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) : -a.coverageExcess d P x ≤ a.trueDeficit d P x := by
  simp only [coverageExcess, trueDeficit, ← Finset.sum_neg_distrib]
  apply Finset.sum_le_sum
  intro w _
  have h := le_max_left (1 - a.cutCoverage d x w) 0
  linarith

theorem canonical_shared_coverage_reserve (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) :
    a.activeGateDeficit d P x - a.coverageExcess d P (fun b => x b.1) ≤
      edgeSum x Finset.univ - Fintype.card V - totalOverage d x / 2 := by
  have h1 := canonical_disjoint_coverage_deficits d hs hc P hP t f hf hb a ha hcan hx hcap
  have h2 := a.neg_coverageExcess_le_trueDeficit d P (fun b => x b.1)
  have h3 := total_deficit_bound d hs hc hx hcap
  linarith

end TSP.Improvements20261105
