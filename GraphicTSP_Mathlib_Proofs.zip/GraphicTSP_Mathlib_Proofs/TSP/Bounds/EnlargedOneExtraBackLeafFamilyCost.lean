import TSP.Improvements20261105.EnlargedOneExtraBackLeafCost
import TSP.Improvements20261105.OneExtraBackLeafOwners

/-! Actual nonfrozen matching pairs, in the actual scored DFS and
simultaneous guarded construction, pay their source-complement fee
and retain the surplus 61/5 using their original source back count. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem enlarged_scoredDFS_one_extra_back_leaf_family_cost
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hYfeasible : Y ∈ projectedFrameworkTwo G (d).centers owner)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
 :
    let L := a.oneExtraBackLeafRoots d P x z C
    (∑ i ∈ a.componentStarUnion d P L, guardedNormalizedHeadCost d x z C owner rootStar R a i)+
      (∑ r ∈ L, 24*(2-componentEntryCoverage d x r)) ≤
        4*(∑ i ∈ a.componentStarUnion d P L, (((d).backGroup i.1).card : ℝ))+
          ∑ r ∈ L, a.componentOwnedError d P x r := by
  let L := a.oneExtraBackLeafRoots d P x z C
  have hlocal (r : FlowVertex d) (hr : r ∈ L) :
      (∑ i ∈ a.actualComponentStars d P r, guardedNormalizedHeadCost d x z C owner rootStar R a i)+
        24*(2-componentEntryCoverage d x r) ≤
          4*(∑ i ∈ a.actualComponentStars d P r, (((d).backGroup i.1).card : ℝ))+
            a.componentOwnedError d P x r := by
    have hspec := Finset.mem_filter.mp hr
    obtain ⟨s,hsL,he⟩ := Finset.mem_image.mp hspec.1
    have hnotK : r ∉ a.KLeafRoots d P x z C := by
      intro hK
      exact hspec.2.2.1 (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_right _ hK))))
    have hp := enlarged_scoredDFS_one_extra_back_leaf_cost G x z hs hc root hx hn hcap hm C owner ho rootStar hroot
      Y R hY hYfeasible hR hrep hbacks hloss hterminal hzero P hP t ht f hf hb a ha hcan s
      (he.symm ▸ hspec.2.1) hsL (he.symm ▸ hnotK) (he.symm ▸ hspec.2.2.2.1) (he.symm ▸ hspec.2.2.2.2)
    simp only [he] at hp
    linarith only [hp]
  have hsum := Finset.sum_le_sum hlocal
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at hsum
  rw [a.component_star_sum d P L _,a.component_star_sum d P L _] at hsum
  dsimp only
  rw [← Finset.mul_sum]
  exact hsum

end TSP.Improvements20261105
