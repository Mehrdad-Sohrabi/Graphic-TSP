import TSP.Improvements20261105.LargeSelectedGreedySourcePairPayment
import TSP.Improvements20261105.LargeSelectedScoredSourcePairPayment
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_selected_large_greedy_positive_pair_payment
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (ν : (d).tree.Child → ℤ)
    (i j : (d).StarIndex) (hi : i.1 ∈ C.matching) (hj : j.1 = unaryNext d i.1)

    (hsel : ν i.1=1) (hjsel : ν j.1=1)
    (hcount5 : 5 ≤ ((d).backGroup i.1).card)
    (hnotT : ¬ScoredStar d x j.1)
    (hraw : ScoredStar d x i.1 →
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T i.1 ≤ rawCriticalIncidence d x z i.1)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup i.1).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent i.1))
    (htargetcount : 3 ≤ ((d).backGroup j.1).card)
    (hpositive : 1 < edgeSum z ((d).backGroup j.1))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge i.1)-survivingExcess d x i.1) (1/2)) 
    (hsource : (415/2 : ℝ)*(survivingExcess d x i.1-outgoingBackMass d x i.1)-(704/5)+
      24*survivingExcess d x i.1+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T i.1+24*δ ≤
      4*((((d).backGroup i.1).card : ℝ)+1)+2*(bad : ℝ))
    :
    currentSelectedHeadCost d x z C owner rootStar R eligible T ν i+
      currentSelectedHeadCost d x z C owner rootStar R eligible T ν j-24*retainedSelectedResidual d x z ν j+24*δ-162/19 ≤
      4*((((d).backGroup i.1).card : ℝ)+((d).backGroup j.1).card)+2*(bad : ℝ) := by
  by_cases hsc : ScoredStar d x i.1
  · exact scoredDFS_large_scored_source_pair_payment G x z hs hc root hx hn hcap hz hzx htree hm C owner ho rootStar hroot Y R hY hR
      hrep hbacks hloss hterminal hzero eligible T ν i j hi hj hsel hjsel hcount5 hsc (hraw hsc) hnotT
      bad hbad hgood htargetcount hpositive δ hδ0 hδ hsource
  · exact scoredDFS_large_greedy_source_pair_payment G x z hs hc root hx hn hcap hz hzx htree hm C owner ho rootStar hroot Y R hY hR
      hrep hbacks hloss hterminal hzero eligible T ν i j hi hj hsel hjsel hcount5 hsc hnotT
      bad hbad hgood htargetcount hpositive δ hδ0 hδ hsource

end TSP.Improvements20261105
