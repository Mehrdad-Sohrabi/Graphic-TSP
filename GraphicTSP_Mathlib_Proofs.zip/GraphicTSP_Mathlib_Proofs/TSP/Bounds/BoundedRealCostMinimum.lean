import TSP.Improvements20261105.RealCapacityMinimum
import TSP.Improvements20261105.CirculationMinimum

/-! Arbitrary real costs with finite integral capacities. Zero is feasible;
compactness and proved circulation rounding give an integral optimum. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem exists_minimum_bounded_integral_circulation (N : Graph V E)
    (cost : E → ℝ) (upper : E → ℕ) :
    ∃ g : E → ℕ, Balanced N (fun e => (g e : ℝ)) ∧
      (∀ e, g e ≤ upper e) ∧
      ∀ f : E → ℝ, Balanced N f → (∀ e, 0 ≤ f e ∧ f e ≤ upper e) →
        (∑ e, cost e * (g e : ℝ)) ≤ ∑ e, cost e * f e := by
  let K : Set (E → ℝ) := Set.Icc (fun _ => 0) (fun e => (upper e : ℝ)) ∩
    {f | Balanced N f}
  have hK : IsCompact K := isCompact_Icc.inter_right (isClosed_balanced N)
  have hne : K.Nonempty := by
    refine ⟨fun _ => 0, ⟨?_, ?_⟩, ?_⟩
    · intro e; exact le_rfl
    · intro e; exact Nat.cast_nonneg _
    · intro v; simp [arcSum]
  obtain ⟨f, hf, hmin⟩ := hK.exists_isMinOn hne (continuous_flow_cost cost).continuousOn
  have hb : OptionalFlowBounds (fun _ => 0) (fun e => some (upper e)) f := by
    intro e
    refine ⟨by simpa using hf.1.1 e, ?_⟩
    intro u hu
    have he : upper e = u := Option.some.inj hu
    simpa [← he] using hf.1.2 e
  obtain ⟨g, hg, hgb, hcost⟩ := optional_circulation_rounding N cost
    (fun _ => 0) (fun e => some (upper e)) f hf.2 hb
  refine ⟨g, hg, ?_, ?_⟩
  · intro e
    have h : (g e : ℝ) ≤ (upper e : ℝ) := (hgb e).2 (upper e) rfl
    exact_mod_cast h
  · intro h hh hhb
    apply hcost.trans
    apply hmin
    exact ⟨⟨fun e => (hhb e).1, fun e => (hhb e).2⟩, hh⟩

end TSP.Improvements20261105
