import TSP.Improvements20261105.FullFloorCover
import TSP.Chapter05.DFSData

/-! Apply the full-floor cover to actual parent-child links of the DFS tree. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem full_floor_tree_links (links : Finset d.tree.Child)
    (next : d.tree.Child → d.tree.Child)
    (hpar : ∀ s ∈ links, d.tree.parent (next s) = (s : V))
    (floor ell : d.tree.Child → ℝ) :
    ∃ M : Finset d.tree.Child, ∃ z : d.tree.Child → ℝ,
      M ⊆ links ∧
      (∀ s ∈ M, ∀ t ∈ M, ∀ a, (a = s ∨ a = next s) → (a = t ∨ a = next t) → s = t) ∧
      (∀ s ∈ M, 0 < ell s - floor s - floor (next s)) ∧
      (∀ a, floor a ≤ z a) ∧
      (∀ s ∈ links, ell s ≤ z s + z (next s)) ∧
      (∑ a, z a) = (∑ a, floor a) + ∑ s ∈ M, (ell s - floor s - floor (next s)) := by
  let A : {s // s ∈ links} → d.tree.Child := Subtype.val
  let B : {s // s ∈ links} → d.tree.Child := fun s => next s.1
  let P : d.tree.Child → Prop := fun s => d.tree.depth s % 2 = 0
  have hP : ∀ s, P (A s) ↔ ¬P (B s) := by
    intro s
    have hd := d.tree.parent_depth (next s.1) (next s.1).2
    rw [hpar s.1 s.2] at hd
    dsimp [P, A, B]
    omega
  obtain ⟨M, z, hdis, hpos, hfloor, hcover, hsum⟩ :=
    full_floor_cover A B P hP floor (fun s => ell s.1)
  let M' : Finset d.tree.Child := M.image Subtype.val
  have hm (s : d.tree.Child) (hs : s ∈ M') : ∃ t ∈ M, t.1 = s := Finset.mem_image.mp hs
  refine ⟨M', z, ?_, ?_, ?_, hfloor, ?_, ?_⟩
  · intro s hs
    obtain ⟨t, ht, rfl⟩ := hm s hs
    exact t.2
  · intro s hs t ht a has hat
    obtain ⟨u, hu, rfl⟩ := hm s hs
    obtain ⟨v, hv, rfl⟩ := hm t ht
    exact congrArg Subtype.val (hdis u hu v hv a has hat)
  · intro s hs
    obtain ⟨t, ht, rfl⟩ := hm s hs
    exact hpos t ht
  · intro s hs
    exact hcover ⟨s, hs⟩
  · rw [hsum]
    congr 1
    rw [Finset.sum_image (fun _ _ _ _ h => Subtype.ext h)]

end TSP.Improvements20261105
