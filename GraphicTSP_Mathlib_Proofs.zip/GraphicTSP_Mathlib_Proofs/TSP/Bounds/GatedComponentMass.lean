import TSP.Improvements20261105.GatedComponentLedger

/-! The exact selected-back mass identity, valid for arbitrary real back
weights. Coverage and internal mass are defined on the actual DFS paths. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.backPathCuts_empty_iff_same {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    a.backPathCuts d P b = ∅ ↔
      a.component d P (.inr (d.anchor b.1)) = a.component d P (.inl (d.lower b.1)) := by
  constructor
  · exact a.component_back_path_zero d P b
  · intro hsame
    by_contra hn
    have hpos := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr hn)
    have hle := a.backPathCuts_card_le_one d ha b
    have hcard : (a.backPathCuts d P b).card = 1 := by omega
    obtain ⟨w, hw, hbefore, hafter⟩ := (expandedTree d).cutsOnPath_card_one_decomposition (a.trueCuts d P) hcard
    have hne := (expandedTree d).cutComponentRoot_cut_ne_parent (a.trueCuts d P) w hw
    rw [(expandedTree d).cutComponentRoot_cut (a.trueCuts d P) w hw] at hne
    exact hne (hafter.symm.trans (hsame.symm.trans hbefore.symm))

theorem GatedDrops.back_cut_indicator_identity {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    ((a.backPathCuts d P b).card : ℝ) = (a.head (d.anchor b.1) : ℝ) -
      (if a.head (d.anchor b.1) = 1 ∧
        a.component d P (.inr (d.anchor b.1)) = a.component d P (.inl (d.lower b.1)) then 1 else 0) := by
  by_cases hsame : a.component d P (.inr (d.anchor b.1)) = a.component d P (.inl (d.lower b.1))
  · have hz := (a.backPathCuts_empty_iff_same d ha b).mpr hsame
    rcases a.head_binary d ha (d.anchor b.1) with hh | hh <;> simp [hz, hh, hsame]
  · have hn : (a.backPathCuts d P b).Nonempty :=
      Finset.nonempty_iff_ne_empty.mpr (fun hz => hsame ((a.backPathCuts_empty_iff_same d ha b).mp hz))
    have hh := a.crossing_back_selected d ha b hn
    have hcard : (a.backPathCuts d P b).card = 1 := by
      have hlo := Finset.card_pos.mpr hn
      have hhi := a.backPathCuts_card_le_one d ha b
      omega
    simp [hcard, hh, hsame]

noncomputable def GatedDrops.cutCoverage (a : GatedDrops d) (x : BackEdge d → ℝ)
    (w : (expandedTree d).Child) : ℝ := ∑ b : BackEdge d, if onExpandedBackPath d b w then x b else 0

noncomputable def GatedDrops.coverageExcess (P : GatePlan d) (a : GatedDrops d) (x : BackEdge d → ℝ) : ℝ :=
  ∑ w ∈ a.trueCuts d P, (a.cutCoverage d x w - 1)

noncomputable def GatedDrops.internalSelectedBackMass (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) : ℝ :=
  ∑ b : BackEdge d, if a.head (d.anchor b.1) = 1 ∧
    a.component d P (.inr (d.anchor b.1)) = a.component d P (.inl (d.lower b.1)) then x b else 0

noncomputable def ownBackMass (x : BackEdge d → ℝ) (v : d.tree.Child) : ℝ :=
  ∑ b : BackEdge d, if d.anchor b.1 = v then x b else 0

theorem weighted_ownBackMass (x : BackEdge d → ℝ) (h : d.tree.Child → ℝ) :
    (∑ v : d.tree.Child, h v * ownBackMass d x v) = ∑ b : BackEdge d, x b * h (d.anchor b.1) := by
  simp only [ownBackMass, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b _
  rw [Finset.sum_eq_single (d.anchor b.1)]
  · simp [mul_comm]
  · intro v _ hv
    simp [Ne.symm hv]
  · simp

theorem GatedDrops.total_cutCoverage (P : GatePlan d) (a : GatedDrops d) (x : BackEdge d → ℝ) :
    (∑ w ∈ a.trueCuts d P, a.cutCoverage d x w) =
      ∑ b : BackEdge d, x b * ((a.backPathCuts d P b).card : ℝ) := by
  unfold GatedDrops.cutCoverage
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b _
  rw [← Finset.sum_filter]
  have hset : (a.trueCuts d P).filter (onExpandedBackPath d b) = a.backPathCuts d P b := by
    ext w
    simp only [Finset.mem_filter, GatedDrops.backPathCuts, RootedTree.cutsOnPath, onExpandedBackPath]
  rw [hset]
  simp [mul_comm]

theorem GatedDrops.coverage_mass_identity {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (x : BackEdge d → ℝ) :
    (∑ w ∈ a.trueCuts d P, a.cutCoverage d x w) =
      (∑ v : d.tree.Child, (a.head v : ℝ) * ownBackMass d x v) -
        a.internalSelectedBackMass d P x := by
  rw [a.total_cutCoverage, weighted_ownBackMass]
  unfold GatedDrops.internalSelectedBackMass
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro b _
  rw [a.back_cut_indicator_identity d ha b]
  split_ifs <;> ring

theorem GatedDrops.exact_selected_mass_ledger (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P) (x : BackEdge d → ℝ) :
    a.value d P (fun _ => 0) + a.coverageExcess d P x =
      (∑ v : d.tree.Child, (a.head v : ℝ) * (ownBackMass d x v - gatedFreeBase d v)) -
      a.internalSelectedBackMass d P x - ∑ v : d.tree.Child, (a.penalty d P v : ℝ) := by
  have hr : (∑ v : d.tree.Child, (a.reward d P v : ℝ)) = ((a.trueCuts d P).card : ℝ) := by
    exact_mod_cast a.trueCuts_reward_card d hs hc ha
  have he : a.coverageExcess d P x = (∑ w ∈ a.trueCuts d P, a.cutCoverage d x w) -
      ((a.trueCuts d P).card : ℝ) := by simp [GatedDrops.coverageExcess, Finset.sum_sub_distrib]
  simp only [GatedDrops.value, add_zero, Finset.sum_sub_distrib]
  rw [hr, he, a.coverage_mass_identity d ha x]
  simp only [mul_sub, Finset.sum_sub_distrib]
  have hm : (∑ v : d.tree.Child, (gatedFreeBase d v : ℝ) * (a.head v : ℝ)) =
      ∑ v : d.tree.Child, (a.head v : ℝ) * (gatedFreeBase d v : ℝ) := by
    apply Finset.sum_congr rfl
    intro v _
    ring
  rw [hm]
  ring

end TSP.Improvements20261105
