import TSP.Improvements20261105.GeneralPairPaymentInterface
import TSP.Improvements20261105.BothSelectedRawIncidence
import TSP.Improvements20261105.MatchingTargetMassIdentity

/-! Read the local scalar inputs directly from an actual context pair. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

noncomputable def GeneralPairPaymentContext.pairDebt
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root) (p : (d).StarIndex × (d).StarIndex) : ℝ :=
  extendedResidualIncomingDebt d x z K.a.head
    (K.a.internalUnmatchedHeads d (fixedGatePlan d x) x z K.C)
    (K.a.internalMatchingTargets d (fixedGatePlan d x) x z K.C) p.1

structure GeneralPairLocalData (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (p : (d).StarIndex × (d).StarIndex) : Prop where
  source : p.1.1 ∈ K.C.matching
  target : p.2.1=unaryNext d p.1.1
  parent : (d).tree.parent p.2.1=(p.1.1 : V)
  source_binary : K.a.head p.1.1=0 ∨ K.a.head p.1.1=1
  target_binary : K.a.head p.2.1=0 ∨ K.a.head p.2.1=1
  source_positive : 1 < edgeSum z ((d).backGroup p.1.1)
  source_count : 2 ≤ ((d).backGroup p.1.1).card
  target_count : 1 ≤ ((d).backGroup p.2.1).card
  bad_le_one : originalMatchingBadLabel d x₀ p.1.1 ≤ 1
  good_parts : originalMatchingBadLabel d x₀ p.1.1=0 → UnitPartCapacities G z ((d).tree.parent p.1.1)
  debt_nonneg : 0 ≤ K.pairDebt G x₀ x z hs hconnected root p
  debt_cap : K.pairDebt G x₀ x z hs hconnected root p ≤
    min (1-x ((d).treeEdge p.1.1)-survivingExcess d x p.1.1) (1/2)
  source_nonroot : (d).centers p.1≠(d).tree.root
  target_nonroot : (d).centers p.2≠(d).tree.root
  mass_identity : x ((d).treeEdge p.1.1)+outgoingBackMass d x p.1.1+
    x ((d).treeEdge p.2.1)+edgeSum z ((d).backGroup p.2.1)=2

theorem GeneralPairPaymentContext.local_pair_data
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (p : (d).StarIndex × (d).StarIndex)
    (hp : p ∈ K.a.internalMatchingPairs d (fixedGatePlan d x) x z K.C) :
    GeneralPairLocalData G x₀ x z hs hconnected root K p := by
  have hn : 2 ≤ Fintype.card V := by have hh := K.hc.1; omega
  have hp' := (Finset.mem_filter.mp hp).1
  have hpair := (Finset.mem_filter.mp hp').2
  have hi := hpair.1
  have hj := hpair.2.symm
  have hpositive := projectionLink_source_positive d hs x z K.hx hn K.hprojection p.1.1 (K.C.link_subset hi)
  have hcard : 2 ≤ ((d).backGroup p.1.1).card := by
    have hmass := Finset.sum_le_sum (s := (d).backGroup p.1.1)
      (fun e _ => (K.hzx e).trans (K.hcap e))
    simp only [Finset.sum_const,nsmul_eq_mul,mul_one] at hmass
    change edgeSum z ((d).backGroup p.1.1) ≤ (((d).backGroup p.1.1).card : ℝ) at hmass
    have hh : (1 : ℝ) < (((d).backGroup p.1.1).card : ℝ) := hpositive.trans_le hmass
    have hhN : 1 < ((d).backGroup p.1.1).card := by exact_mod_cast hh
    omega
  have hnr := fixedMatchingStarPair_nonroot d x z K.C p hp'
  exact {
    source := hi, target := hj,
    parent := by rw [hj]; exact projectionLinks_parent d x p.1.1 (K.C.link_subset hi),
    source_binary := K.a.head_binary d K.ha p.1.1,
    target_binary := K.a.head_binary d K.ha p.2.1,
    source_positive := hpositive, source_count := hcard,
    target_count := Finset.card_pos.mpr p.2.2,
    bad_le_one := originalMatchingBadLabel_le_one d x₀ p.1.1,
    good_parts := fun hgood => originalMatchingBadLabel_unit_parts d hs x₀ x z K.hx hn
      K.hprojection K.hparts K.C p.1.1 hi hgood,
    debt_nonneg := extendedResidualIncomingDebt_nonnegative d x z K.a.head _ _ p.1,
    debt_cap := extendedResidualIncomingDebt_matching_cap d hs x z K.hx hn K.hcap K.hprojection K.C K.a.head _ _ p.1 hi,
    source_nonroot := hnr.1, target_nonroot := hnr.2,
    mass_identity := matching_target_mass_identity d hs x z K.hprojection K.C p.1.1 p.2.1 hi hj }

theorem GeneralPairPaymentContext.both_selected_raw_incidence
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (p : (d).StarIndex × (d).StarIndex)
    (hp : p ∈ K.a.internalMatchingPairs d (fixedGatePlan d x) x z K.C)
    (hsi : K.a.head p.1.1=1) (hsj : K.a.head p.2.1=1) :
    (ScoredStar d x p.1.1 →
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z (generalEligibleHeads d x))
        (generalRawCriticalHeads d x z K.a) p.1.1 ≤ rawCriticalIncidence d x z p.1.1) ∧
    (ScoredStar d x p.2.1 →
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z (generalEligibleHeads d x))
        (generalRawCriticalHeads d x z K.a) p.2.1 ≤ rawCriticalIncidence d x z p.2.1) := by
  have hh := K.local_pair_data G x₀ x z hs hconnected root p hp
  have hn : 2 ≤ Fintype.card V := by have hh := K.hc.1; omega
  have hmass (s : (d).tree.Child) : edgeSum z ((d).backGroup s) ≤ 2 := by
    have hp := fixed_projection_star_pack d hs K.hx K.hcap hn (allFullOverrideTargets d x) K.hprojection s
    have hq := K.hx.1 ((d).treeEdge s)
    linarith only [hp,hq]
  have hr := canonical_both_selected_pair_raw_incidence d (fixedGatePlan d x) (fixedGatePlan_tree d x)
    K.t K.ht K.f K.hf K.hb K.a K.ha K.hcan x z K.C (generalEligibleHeads d x)
    (generalRawCriticalHeads d x z K.a) (fun s hs hcard => Finset.mem_filter.mpr ⟨hs,hcard⟩)
    p.1 p.2 hh.source hh.target hsi hsj (hmass p.1.1) (hmass p.2.1)
  exact ⟨fun hs => hr.1 (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hs⟩),
    fun hs => hr.2 (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hs⟩)⟩

end TSP.Improvements20261105
