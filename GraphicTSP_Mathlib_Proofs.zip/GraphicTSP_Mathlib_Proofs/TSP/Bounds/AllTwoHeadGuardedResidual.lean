import TSP.Improvements20261105.PrefixZeroNonpositive
import TSP.Improvements20261105.TwoHeadGuardedResidual
import TSP.Improvements20261105.OneRelevantGeometricResidual
import TSP.Improvements20261105.UncrossedSourceCoverage
import TSP.Improvements20261105.ActualZeroLeafCost

/-! Actual guarded head costs in the two-relevant one-back case.
Every local cut, no-force statement, and unary floor is proved from the
actual graph and the simultaneous guarded construction. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (P : GatePlan d) (hP : P.RespectsTree d)
variable (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
variable (hf : Chapter06.Balanced (gatedNetwork d P) f)
variable (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
variable (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

include hs hP ht hf hb ha hcan in
theorem GatedDrops.two_one_back_guarded_residual (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eta : d.tree.Child → ℝ) (heta : ∀ c, eta c ≠ 0 → SurvivingPositive d x c)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : Y ∈ projectedFrameworkTwo G d.centers owner)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+eta c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hguard : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (r : FlowVertex d) (hr : r ≠ .inl d.tree.root)
    (hmarker : r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P))
    (hout : a.componentOutgoingCuts d P r = ∅)
    (s : d.tree.Child) (hl : s ∈ projectionLinks d x) (hscomp : a.component d P (.inr s) = r)
    (u v : d.StarIndex) (hne : u ≠ v)
    (hI : a.sourceOtherLeafStars d P r s = {u,v})
    (huone : (d.backGroup u.1).card = 1) (hvone : (d.backGroup v.1).card = 1)
    (hgu : ∀ e ∈ d.backGroup u.1, x e ≤ x (d.treeEdge u.1))
    (hgv : ∀ e ∈ d.backGroup v.1, x e ≤ x (d.treeEdge v.1))
    (hcostu : guardedNormalizedHeadCost d x z C owner rootStar R a u ≤ 0)
    (hcostv : guardedNormalizedHeadCost d x z C owner rootStar R a v ≤ 0) :
    24*(2-max (componentEntryCoverage d x r) 1)+
      guardedNormalizedHeadCost d x z C owner rootStar R a u+
      guardedNormalizedHeadCost d x z C owner rootStar R a v ≤
        24*(1-x (d.treeEdge s)-survivingExcess d x s)+18+a.componentOwnedError d P x r := by
  have hprefix := a.two_one_back_zero_prefix d x hcap P r s hl u v hI huone hvone
  have hfloor (i : d.StarIndex) (hi : i ∈ ({u,v} : Finset d.StarIndex))
      (his : d.tree.Ancestor i.1 s) (hunary : childCount d (d.centers i)=1) :
      guardedNormalizedHeadCost d x z C owner rootStar R a i ≤ -(704/5 : ℝ)*
        max (x (d.treeEdge i.1)+edgeSum x (d.backGroup i.1)-1-degreeExcess G x (d.centers i)/2) 0 := by
    have hiI : i ∈ a.sourceOtherLeafStars d P r s := hI.symm ▸ hi
    have hicomp := (Finset.mem_filter.mp (Finset.mem_filter.mp hiI).1).2
    have hdi := a.extra_head_depth_lt_source d P r s i hiI his
    have hizero : edgeSum x (d.backGroup i.1) ≤ 1 := by
      simp only [Finset.mem_insert,Finset.mem_singleton] at hi
      rcases hi with hi | hi
      · rw [hi]; exact one_back_mass_le_one d x hcap u.1 huone
      · rw [hi]; exact one_back_mass_le_one d x hcap v.1 hvone
    have hinr := a.nonroot_component_head_center d P r hr i hicomp
    exact a.prefix_zero_unary_guarded_floor d hs P hP t ht f hf hb ha hcan
      x z hx hn hcap hm C eta heta owner ho rootStar hroot Y R hY hrep hbacks hguard
      r i hicomp (d.tree.depth s) hprefix hdi ⟨d.centers i,hinr⟩ rfl hunary hizero
  have hIrev : a.sourceOtherLeafStars d P r s = {v,u} := by rw [hI,Finset.pair_comm]
  by_cases hus : d.tree.Ancestor u.1 s
  · by_cases hvs : d.tree.Ancestor v.1 s
    · rcases two_source_ancestors_ordered d s u.1 v.1 hus hvs with huv | hvu
      · exact a.two_relevant_one_back_guarded_residual d hs P hP t ht f hf hb ha hcan
          x z hx hn hcap hm C eta heta owner ho rootStar hroot Y R hY hrep hbacks hguard
          r hr hmarker hout s hl u v hne hI huv hvs huone hvone hgu hgv
      · have hh := a.two_relevant_one_back_guarded_residual d hs P hP t ht f hf hb ha hcan
          x z hx hn hcap hm C eta heta owner ho rootStar hroot Y R hY hrep hbacks hguard
          r hr hmarker hout s hl v u hne.symm hIrev hvu hus hvone huone hgv hgu
        linarith only [hh]
    · have hh := a.one_relevant_one_back_geometric_residual d hs x hx hn hcap P r hr hmarker hout
        s hl hscomp u v hI hus hvs huone hgu _ _ hcostu hcostv
        (hfloor u (Finset.mem_insert_self _ _) hus)
      linarith only [hh]
  · by_cases hvs : d.tree.Ancestor v.1 s
    · have hh := a.one_relevant_one_back_geometric_residual d hs x hx hn hcap P r hr hmarker hout
        s hl hscomp v u hIrev hvs hus hvone hgv _ _ hcostv hcostu
        (hfloor v (Finset.mem_insert_of_mem (Finset.mem_singleton_self _)) hvs)
      linarith only [hh]
    · have huncrossed : ∀ i ∈ a.sourceOtherLeafStars d P r s, ∀ e ∈ d.backGroup i.1,
          e ∉ G.cut (subtreeVertices d ⟨d.tree.parent s,(Finset.mem_filter.mp hl).2.1⟩) := by
        intro i hi e he hcross
        have hh := crossing_back_owner_above_source d s i.1 (Finset.mem_filter.mp hl).2.1 e he hcross
        rw [hI,Finset.mem_insert,Finset.mem_singleton] at hi
        rcases hi with hi | hi
        · exact hus (hi ▸ hh)
        · exact hvs (hi ▸ hh)
      have hc := a.uncrossed_source_coverage d hs x hx P r hr hmarker hout s hl hscomp huncrossed
      have herr := a.componentOwnedError_nonnegative d P x hx hn r
      have hF := le_max_left (componentEntryCoverage d x r) (1 : ℝ)
      linarith only [hc,herr,hF,hcostu,hcostv]

end TSP.Improvements20261105
