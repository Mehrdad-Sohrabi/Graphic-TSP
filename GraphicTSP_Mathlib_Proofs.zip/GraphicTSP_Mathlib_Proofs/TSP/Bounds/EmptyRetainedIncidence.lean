import TSP.Improvements20261105.SingletonLeafRamp

/-! Complete the signed parent incidence when all chosen leaves are
removed by count-arm exclusions. The actual singleton parent is excluded
explicitly and will be paid by component pruning. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem headCenters_sparse (hs : G.IsSimple) (x : E → ℝ)
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x e)
    (Y : Finset d.tree.Child) (hY : 2 ≤ Y.card) :
    (G.internalEdges (headCenters d Y)).card + 3 ≤ 2 * Y.card := by
  have hc : (headCenters d Y).card ≤ Y.card := Finset.card_image_le
  by_cases hn : 2 ≤ (headCenters d Y).card
  · have hh := extreme_induced_support_sparsity G hx hpositive (headCenters d Y) hn
    omega
  · have hh := internal_edges_card_le G hs (headCenters d Y)
    have hsmall : (headCenters d Y).card = 0 ∨ (headCenters d Y).card = 1 := by omega
    have hchoose : (headCenters d Y).card.choose 2 = 0 := by
      rcases hsmall with hsmall | hsmall <;> rw [hsmall] <;> decide
    rw [hchoose] at hh
    omega

theorem signed_incidence_sum_lower (mu : ℝ) (z : E → ℝ) (Y : Finset d.tree.Child) :
    -(1 - 2 * mu) * Y.card ≤ ∑ s ∈ Y, signedStarIncidence d mu z s := by
  have hn : 0 ≤ ∑ s ∈ Y, starIncidenceRamp d mu z s :=
    Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => le_max_right _ _))
  simp only [signedStarIncidence, Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul]
  nlinarith

theorem excluded_signed_incidence_empty_many (hs : G.IsSimple) (x : E → ℝ)
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x e)
    (L : Finset V) (H X : Finset d.tree.Child) (hXH : X ⊆ H)
    (hX : ∀ s ∈ X, (d.backGroup s).card = 2)
    (hY : 2 ≤ (H \ X).card) (hret : retainedLeaves d L X = ∅)
    (mu beta : ℝ) (hmu : 0 ≤ mu) (hbeta : beta ≤ 3 * mu - 1)
    (z : E → ℝ) (delta : V → ℝ) (hd : ∀ v ∈ L, 0 ≤ delta v) :
    1 + (L.card : ℝ) - H.card ≤ (∑ s ∈ H \ X, signedStarIncidence d mu z s) + X.card -
      beta - mu * (G.internalEdges (headCenters d (H \ X))).card + 2 * (∑ v ∈ L, delta v) := by
  have hlN := count_two_retainedLeaves_loss d L X hX
  rw [hret, Finset.card_empty, zero_add] at hlN
  have hl : (L.card : ℝ) ≤ 2 * (X.card : ℝ) := by exact_mod_cast hlN
  have hc : ((H \ X).card : ℝ) + X.card = (H.card : ℝ) := by
    exact_mod_cast Finset.card_sdiff_add_card_eq_card hXH
  have he : ((G.internalEdges (headCenters d (H \ X))).card : ℝ) + 3 ≤ 2 * ((H \ X).card : ℝ) := by
    exact_mod_cast headCenters_sparse d hs x hx hpositive (H \ X) hY
  have he' := mul_le_mul_of_nonneg_left he hmu
  have hj := signed_incidence_sum_lower d mu z (H \ X)
  have hd0 : 0 ≤ ∑ v ∈ L, delta v := Finset.sum_nonneg hd
  nlinarith

theorem singleton_center_edges_zero (hs : G.IsSimple) (s : d.tree.Child) :
    (G.internalEdges (headCenters d {s})).card = 0 := by
  have hh := internal_edges_card_le G hs (headCenters d {s})
  have hchoose : (headCenters d {s}).card.choose 2 = 0 := by simp [headCenters]
  rw [hchoose] at hh
  omega

theorem excluded_signed_incidence_empty_singleton (hs : G.IsSimple)
    (L : Finset V) (H X : Finset d.tree.Child) (hXH : X ⊆ H)
    (hX : ∀ s ∈ X, (d.backGroup s).card = 2)
    (s : d.tree.Child) (hY : H \ X = {s}) (hret : retainedLeaves d L X = ∅)
    (hh : LeafHeadsIn d L H) (hnonex : 0 < L.card ∨ 2 ≤ H.card)
    (mu beta : ℝ) (hmu : 0 ≤ mu) (hmu1 : mu ≤ 1 / 2)
    (hbeta1 : beta ≤ 2 * mu) (hbeta2 : beta ≤ (4 * mu - 1) / 3)
    (z : E → ℝ) (hz : ∀ e, 0 ≤ z e) (delta : V → ℝ) (hd : ∀ v ∈ L, 0 ≤ delta v)
    (hmass : ∀ v ∈ L, 1 - delta v ≤ ∑ e ∈ d.backEdges, if d.lower e = v then z e else 0)
    (hmX : ∀ t ∈ X, edgeSum z (d.backGroup t) ≤ 4 / 3) :
    1 + (L.card : ℝ) - H.card ≤ (∑ t ∈ H \ X, signedStarIncidence d mu z t) + X.card -
      beta - mu * (G.internalEdges (headCenters d (H \ X))).card + 2 * (∑ v ∈ L, delta v) := by
  have hH : H = insert s X := by
    have he := Finset.sdiff_union_of_subset hXH
    rw [hY] at he
    simpa using he.symm
  have hcN := Finset.card_sdiff_add_card_eq_card hXH
  rw [hY, Finset.card_singleton] at hcN
  have hc : (1 : ℝ) + X.card = (H.card : ℝ) := by exact_mod_cast hcN
  have hlN := count_two_retainedLeaves_loss d L X hX
  rw [hret, Finset.card_empty, zero_add] at hlN
  have hj := signed_incidence_sum_lower d mu z {s}
  simp only [Finset.card_singleton, Nat.cast_one, mul_one, Finset.sum_singleton] at hj
  have hd0 : 0 ≤ ∑ v ∈ L, delta v := Finset.sum_nonneg hd
  rw [hY, Finset.sum_singleton, singleton_center_edges_zero d hs s, Nat.cast_zero, mul_zero, sub_zero]
  by_cases hlt : L.card < 2 * X.card
  · have hlt' : (L.card : ℝ) + 1 ≤ 2 * (X.card : ℝ) := by exact_mod_cast hlt
    linarith
  · have hEqN : L.card = 2 * X.card := by omega
    have hEq : (L.card : ℝ) = 2 * (X.card : ℝ) := by exact_mod_cast hEqN
    have hXposN : 1 ≤ X.card := by omega
    have hXpos : (1 : ℝ) ≤ X.card := by exact_mod_cast hXposN
    have hmXsum : (∑ t ∈ X, edgeSum z (d.backGroup t)) ≤ (4 / 3 : ℝ) * X.card := by
      have hh := Finset.sum_le_sum hmX
      simpa [mul_comm] using hh
    have hr := singleton_leaf_ramp_bound d hs L X s (hH ▸ hh) mu hmu z hz delta hmass
    have hmX' := mul_le_mul_of_nonneg_left hmXsum (show 0 ≤ 1 + 2 * mu by linarith)
    have hd' := mul_le_mul_of_nonneg_right (show 1 + 2 * mu ≤ 2 by linarith) hd0
    have hscale := mul_le_mul_of_nonneg_left hXpos (show 0 ≤ 2 * (1 - mu) / 3 by linarith)
    unfold signedStarIncidence
    nlinarith

end TSP.Improvements20261105
