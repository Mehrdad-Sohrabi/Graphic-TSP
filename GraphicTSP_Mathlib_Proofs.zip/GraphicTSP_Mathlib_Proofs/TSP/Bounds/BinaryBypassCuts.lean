import TSP.Improvements20261105.CoveredTreeCuts

/-! Simultaneous deletion on a union of fundamental cycles. Every deleted
tree edge has two own returns and either an outgoing return or two returns
in distinct child directions. No sequential deletion assumption is used. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def OwnReturn (v : d.tree.Child) (b : E) : Prop :=
  d.upper b = d.tree.parent v ∧ d.tree.Ancestor v (d.lower b)

def BypassWitness (B : Finset E) (v : d.tree.Child) : Prop :=
  (∃ b ∈ B, BackCovers d b v ∧ d.lower b = (v : V)) ∨
  (∃ c₁ c₂ : d.tree.Child, c₁ ≠ c₂ ∧ d.tree.parent c₁ = (v : V) ∧
    d.tree.parent c₂ = (v : V) ∧
    (∃ b ∈ B, BackCovers d b v ∧ d.tree.Ancestor c₁ (d.lower b)) ∧
    (∃ b ∈ B, BackCovers d b v ∧ d.tree.Ancestor c₂ (d.lower b)))

noncomputable def binaryRetained (B : Finset E) (R : Finset d.tree.Child) : Finset E :=
  B ∪ (Finset.univ.filter (fun v : d.tree.Child => BackCovered d B v ∧ v ∉ R)).image d.treeEdge

theorem ownReturn_covers (v : d.tree.Child) (b : E) (hb : OwnReturn d v b) :
    BackCovers d b v := by
  refine ⟨hb.2, ?_⟩
  rw [hb.1]
  have hd := d.tree.parent_depth v v.2
  omega

theorem terminal_ownReturn_crosses (B : Finset E) (U : Finset V)
    (v : d.tree.Child) (hv : CoveredTerminal d B U v)
    (b : E) (hb : b ∈ B) (ho : OwnReturn d v b) : b ∈ G.cut U := by
  have hl := covered_terminal_lower_side d B U v hv b hb (ownReturn_covers d v b ho)
  rw [dfs_cut_iff, ho.1]
  have hc := hv.1.2
  unfold RootedTree.Crosses at hc
  tauto

theorem branch_return_spare (U : Finset V) (B : Finset E) (v z c : d.tree.Child)
    (hz : ∀ a, CoveredTerminal d B U a → a = z)
    (hparent : d.tree.parent c = (v : V)) (hspare : ¬d.tree.Ancestor c z)
    (b : E) (hb : b ∈ B) (hc : BackCovers d b v)
    (hl : d.tree.Ancestor c (d.lower b)) : d.lower b ∈ U ↔ (v : V) ∈ U := by
  apply covered_spare_lower_side d B U v z hz b hb hc
  intro w hw hne hwz
  have hlt : d.tree.depth v < d.tree.depth w := by
    have hle := d.tree.ancestor_depth_le hw.1
    by_contra hn
    exact hne (d.tree.ancestors_eq_of_depth_eq (.refl) hw.1 (by omega))
  have hd := d.tree.parent_depth c c.2
  rw [hparent] at hd
  have hcw := d.tree.common_ancestor_of_depth_le hl hw.2 (by omega)
  exact hspare (hwz.trans hcw)

theorem shallowest_bypass_crosses (B : Finset E) (U : Finset V)
    (v z : d.tree.Child) (hv : CoveredCrosses d B U v)
    (hmin : ∀ w, CoveredCrosses d B U w → d.tree.depth v ≤ d.tree.depth w)
    (hz : ∀ a, CoveredTerminal d B U a → a = z)
    (hw : BypassWitness d B v) : ∃ b ∈ B, b ∈ G.cut U := by
  have finish (b : E) (hb : b ∈ B) (hc : BackCovers d b v)
      (hl : d.lower b ∈ U ↔ (v : V) ∈ U) : b ∈ G.cut U := by
    have hu := covered_shallowest_upper_side d B U v hmin b hb hc
    have hx := hv.2
    unfold RootedTree.Crosses at hx
    rw [dfs_cut_iff d U b]
    tauto
  rcases hw with ⟨b, hb, hc, hl⟩ | ⟨c₁, c₂, hne, hp₁, hp₂, h₁, h₂⟩
  · exact ⟨b, hb, finish b hb hc (by rw [hl])⟩
  · have hs : ¬d.tree.Ancestor c₁ z ∨ ¬d.tree.Ancestor c₂ z := by
      by_cases h₁z : d.tree.Ancestor c₁ z
      · exact Or.inr (fun h₂z => hne (d.tree.child_below_unique c₁ c₂ ⟨hp₁, h₁z⟩ ⟨hp₂, h₂z⟩))
      · exact Or.inl h₁z
    rcases hs with hs | hs
    · obtain ⟨b, hb, hc, hl⟩ := h₁
      exact ⟨b, hb, finish b hb hc (branch_return_spare d U B v z c₁ hz hp₁ hs b hb hc hl)⟩
    · obtain ⟨b, hb, hc, hl⟩ := h₂
      exact ⟨b, hb, finish b hb hc (branch_return_spare d U B v z c₂ hz hp₂ hs b hb hc hl)⟩

theorem binaryRetained_cut_not_singleton (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child)
    (hown : ∀ v ∈ R, ∃ b₁ ∈ B, ∃ b₂ ∈ B,
      b₁ ≠ b₂ ∧ OwnReturn d v b₁ ∧ OwnReturn d v b₂)
    (hwitness : ∀ v ∈ R, BypassWitness d B v) (U : Finset V) :
    (binaryRetained d B R ∩ G.cut U).card ≠ 1 := by
  intro hone
  obtain ⟨f, hf⟩ := Finset.card_eq_one.mp hone
  have unique (e : E) (he : e ∈ binaryRetained d B R) (hc : e ∈ G.cut U) : e = f := by
    have hh : e ∈ ({f} : Finset E) := hf ▸ Finset.mem_inter.mpr ⟨he, hc⟩
    exact Finset.mem_singleton.mp hh
  have back_mem (b : E) (hb : b ∈ B) : b ∈ binaryRetained d B R := Finset.mem_union_left _ hb
  have retain_mem (v : d.tree.Child) (hv : BackCovered d B v) (hr : v ∉ R) :
      d.treeEdge v ∈ binaryRetained d B R :=
    Finset.mem_union_right _ (Finset.mem_image.mpr
      ⟨v, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hv, hr⟩, rfl⟩)
  have terminal_retained (v : d.tree.Child) (hv : CoveredTerminal d B U v) : v ∉ R := by
    intro hr
    obtain ⟨b₁, hb₁, b₂, hb₂, hne, ho₁, ho₂⟩ := hown v hr
    exact hne ((unique b₁ (back_mem b₁ hb₁)
      (terminal_ownReturn_crosses d B U v hv b₁ hb₁ ho₁)).trans
      (unique b₂ (back_mem b₂ hb₂) (terminal_ownReturn_crosses d B U v hv b₂ hb₂ ho₂)).symm)
  have hfc : f ∈ binaryRetained d B R ∩ G.cut U := by rw [hf]; simp
  have hC : ∃ v : d.tree.Child, CoveredCrosses d B U v := by
    rcases Finset.mem_union.mp (Finset.mem_inter.mp hfc).1 with hb | ht
    · exact selected_back_crossing_has_covered_crossing d B U f hb (Finset.mem_inter.mp hfc).2
    · obtain ⟨v, hv, heq⟩ := Finset.mem_image.mp ht
      refine ⟨v, (Finset.mem_filter.mp hv).2.1, ?_⟩
      rw [← dfs_tree_cut_iff, heq]
      exact (Finset.mem_inter.mp hfc).2
  obtain ⟨v, hv⟩ := hC
  obtain ⟨z, hz, _⟩ := covered_terminal_exists d B U v hv
  have hzf : d.treeEdge z = f := unique _ (retain_mem z hz.1.1 (terminal_retained z hz))
    ((dfs_tree_cut_iff d U z).mpr hz.1.2)
  have only_terminal (a : d.tree.Child) (ha : CoveredTerminal d B U a) : a = z := by
    have hh := unique _ (retain_mem a ha.1.1 (terminal_retained a ha))
      ((dfs_tree_cut_iff d U a).mpr ha.1.2)
    exact d.treeEdge_injective (hh.trans hzf.symm)
  let C := Finset.univ.filter (CoveredCrosses d B U)
  have hCne : C.Nonempty := ⟨z, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hz.1⟩⟩
  obtain ⟨s, hs, hmin⟩ := Finset.exists_min_image C (fun a => d.tree.depth a) hCne
  have hsc : CoveredCrosses d B U s := (Finset.mem_filter.mp hs).2
  have hsm : ∀ w, CoveredCrosses d B U w → d.tree.depth s ≤ d.tree.depth w :=
    fun w hw => hmin w (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hw⟩)
  have hbcut : ∃ b ∈ B, b ∈ G.cut U := by
    by_cases hsz : s = z
    · obtain ⟨b, hb, hc⟩ := hsc.1
      have hl := covered_terminal_lower_side d B U s (hsz.symm ▸ hz) b hb hc
      have hu := covered_shallowest_upper_side d B U s hsm b hb hc
      have hcross := hsc.2
      unfold RootedTree.Crosses at hcross
      exact ⟨b, hb, (dfs_cut_iff d U b).mpr (by tauto)⟩
    · have hsr : s ∈ R := by
        by_contra hn
        have hh := unique _ (retain_mem s hsc.1 hn) ((dfs_tree_cut_iff d U s).mpr hsc.2)
        exact hsz (d.treeEdge_injective (hh.trans hzf.symm))
      exact shallowest_bypass_crosses d B U s z hsc hsm only_terminal (hwitness s hsr)
  obtain ⟨b, hb, hc⟩ := hbcut
  have hbf := unique b (back_mem b hb) hc
  have hbt : b ∈ d.treeEdges := by
    rw [hbf, ← hzf]
    exact Finset.mem_image.mpr ⟨z, Finset.mem_univ _, rfl⟩
  exact (Finset.mem_sdiff.mp (hB hb)).2 hbt

end TSP.Improvements20261105
