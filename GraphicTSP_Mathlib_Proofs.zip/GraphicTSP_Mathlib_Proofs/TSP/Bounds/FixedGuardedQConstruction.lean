import TSP.Improvements20261105.FixedMixedGuardPoint
import TSP.Improvements20261105.NormalizedFixedQ

/-! Construct the endpoint Q and its simultaneous guards directly from
the capped original subtour vector. No feasible-Q or event premise remains. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem exists_fixed_guarded_Q (hs : G.IsSimple) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner) :
    ∃ (Y R : E ⊕ d.StarIndex → ℝ) (m : d.StarIndex → ℝ),
      Y ∈ projectedFrameworkTwo G d.centers owner ∧
      R ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
        fixedQIncrease d x (fixedPositiveTerminalChildren d x) c) ∧
      (∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2) ∧
      (∀ i, R (.inr i) = Y (.inr i)) ∧
      FixedQConnectorValues d x hx hn hcap R ∧
      (∀ i ∈ fixedZeroTerminalHeads d x ∪ fixedPositiveTerminalHeads d x, 0 ≤ m i) ∧
      (∀ i ∈ fixedZeroTerminalHeads d x,
        (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
          max (x (d.treeEdge i.1)-zeroGuardCapacity d x Y i) 0) 0 ≤ m i) ∧
      (∀ i ∈ fixedPositiveTerminalHeads d x,
        m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1) ∧
      edgeSum R (nonremovableRepresentatives d.stars) ≤ edgeSum Y (nonremovableRepresentatives d.stars)-
        ((∑ i ∈ fixedZeroTerminalHeads d x, m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, m i)) ∧
      (∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
        (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
        2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0)) ∧
      (∀ i, edgeSum x (d.backGroup i.1) ≤ 1 →
        max (R (.inr i)-edgeSum x (d.stars i)/2)
          ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
            -zeroQCredit d x Y i) ∧
      (∀ i ∈ fixedPositiveTerminalHeads d x,
        (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
          -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1) := by
  have hterm := fixedPositiveTerminalChildren_admissible d x
  obtain ⟨Y, hY, hr, hb, hc, hu⟩ := fixed_free_Q_exists d hs hx hn hcap owner ho
    (fixedPositiveTerminalChildren d x) hterm
  have ht := (fixedQIncrease_admissible d hs hx hn hcap (fixedPositiveTerminalChildren d x) hterm).2.2.1
  obtain ⟨R, m, hR, heq, hm, hmz, hmp, hsave, hloss, hzero, hpos, _⟩ :=
    exists_fixed_mixed_guard_point d hs x hx hn hcap owner ho Y hY
      (fixedQIncrease d x (fixedPositiveTerminalChildren d x)) ht hr hb
      (fixed_positive_Q_increase_full d x)
  have hconn : FixedQConnectorValues d x hx hn hcap R :=
    ⟨fun i => (heq i.1).trans (hc i), fun i hi => (heq i).trans_le (hu i hi)⟩
  exact ⟨Y, R, m, hY, hR, hr, hb, heq, hconn, hm, hmz, hmp, hsave, hloss, hzero, hpos⟩

end TSP.Improvements20261105
