import Mathlib.Tactic

/-! Exact independent cap minimization over a finite family. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Classical
open scoped BigOperators
variable {I : Type} [DecidableEq I]

theorem finite_cap_selection (S : Finset I) (f g : I → ℝ) (A : ℝ)
    (h : ∀ X ⊆ S, A ≤ (∑ i ∈ X, f i) + ∑ i ∈ S \ X, g i) :
    A ≤ ∑ i ∈ S, min (f i) (g i) := by
  let X := S.filter (fun i => f i ≤ g i)
  have hh := h X (Finset.filter_subset _ _)
  have he : (∑ i ∈ X, f i) + (∑ i ∈ S \ X, g i) = ∑ i ∈ S, min (f i) (g i) := by
    have hset : S \ X = S.filter (fun i => ¬f i ≤ g i) := by
      ext i
      simp only [X, Finset.mem_sdiff, Finset.mem_filter]
      tauto
    rw [hset]
    simp only [X, Finset.sum_filter, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    by_cases hi : f i ≤ g i
    · simp [hi, min_eq_left hi]
    · simp [hi, min_eq_right (le_of_not_ge hi)]
  rwa [he] at hh

theorem retained_cap_selection (H C : Finset I) (hCH : C ⊆ H)
    (f p : I → ℝ) (K error : ℝ)
    (h : ∀ X ⊆ H \ C, K ≤ (∑ i ∈ X, f i) + (∑ i ∈ H \ X, p i) + error) :
    K ≤ (∑ i ∈ C, p i) + (∑ i ∈ H \ C, min (f i) (p i)) + error := by
  have hh : K - (∑ i ∈ C, p i) - error ≤ ∑ i ∈ H \ C, min (f i) (p i) := by
    apply finite_cap_selection (H \ C) f p
    intro X hX
    have he : H \ X = C ∪ ((H \ C) \ X) := by
      ext i
      have hin : i ∈ X → i ∈ H ∧ i ∉ C := fun hi => Finset.mem_sdiff.mp (hX hi)
      have hc : i ∈ C → i ∈ H := fun hi => hCH hi
      simp only [Finset.mem_sdiff, Finset.mem_union]
      tauto
    have hd : Disjoint C ((H \ C) \ X) := by
      apply Finset.disjoint_left.mpr
      intro i hi hj
      exact (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp hj).1).2 hi
    have hb := h X hX
    rw [he, Finset.sum_union hd] at hb
    linarith
  linarith

end TSP.Improvements20261105
