import TSP.Improvements20261105.PackedRampEnvelope

/-! The old-ramp packing expression satisfies the inequalities used in
the greedy finite-cell rows throughout the continuous packing domain. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators

noncomputable def packedOldRamp (q a : ℝ) (k : ℕ) : ℝ :=
  (k : ℝ)*(2*q-1/2)+max (2*(a-k*q)-1/2) 0

theorem greedy_packed_old_rows (q a : ℝ) (k : ℕ)
    (hq : 1/4 ≤ q) (hq1 : q ≤ 1) (ha : 1 ≤ a) (hpack : a+q ≤ 2)
    (hlo : (k : ℝ)*q ≤ a) (hhi : a ≤ ((k : ℝ)+1)*q) :
    0 ≤ packedOldRamp q a k ∧ packedOldRamp q a k ≤ 5/3 ∧
      packedOldRamp q a k ≤ a-1+2*q := by
  have hk0 : (0 : ℝ) ≤ k := Nat.cast_nonneg _
  have hkq := mul_le_mul_of_nonneg_left hq hk0
  have hkR : (k : ℝ) ≤ 7 := by linarith
  have hk : k ≤ 7 := by exact_mod_cast hkR
  have hnon : 0 ≤ packedOldRamp q a k :=
    add_nonneg (mul_nonneg hk0 (by linarith)) (le_max_right _ _)
  refine ⟨hnon,?_⟩
  by_cases hh : 0 ≤ 2*(a-k*q)-1/2
  · rw [packedOldRamp,max_eq_left hh]
    interval_cases he : k <;> norm_num only [he,Nat.cast_ofNat,Nat.cast_zero,zero_mul] at hlo hhi hh ⊢ <;>
      constructor <;> linarith only [hq,hq1,ha,hpack,hlo,hhi,hh]
  · rw [packedOldRamp,max_eq_right (le_of_not_ge hh)]
    interval_cases he : k <;> norm_num only [he,Nat.cast_ofNat,Nat.cast_zero,zero_mul,add_zero] at hlo hhi hh ⊢ <;>
      constructor <;> linarith only [hq,hq1,ha,hpack,hlo,hhi,hh]

end TSP.Improvements20261105
