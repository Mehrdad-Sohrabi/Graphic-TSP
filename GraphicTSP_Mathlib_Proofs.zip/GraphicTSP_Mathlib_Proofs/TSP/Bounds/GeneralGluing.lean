import TSP.PositiveBlockReduction
import TSP.DegreeTwoTour
import TSP.Manuscript20261105.SubtourRatio

/-! Preservation of an additive saving under support restriction and block
gluing. The improved block estimate remains an explicit premise here. -/
namespace TSP.Improvements20261105
open Graph Chapter06
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem two_vertex_affine_tour (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected)
    (hn : Fintype.card V = 2) {C saving : ℝ} (hC : 1 ≤ C)
    (hsaving : saving ≤ 2 * (C - 1)) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP - saving := by
  refine ⟨fun _ => 2, doubledGraph_isTour G hc, ?_⟩
  have hcard := simple_edge_card_le_one G hs hn.le
  have hlen : (tourLength (fun _ : E => 2) : ℝ) ≤ 2 := by
    simp only [tourLength, Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
      Nat.cast_mul, Nat.cast_ofNat]
    exact mul_le_of_le_one_left (by norm_num) (by exact_mod_cast hcard)
  have hlp := subtourLP_ge_card G hc hn.ge
  rw [hn] at hlp
  have hm := mul_le_mul_of_nonneg_left hlp (show 0 ≤ C by linarith)
  norm_num at hm
  linarith

theorem articulation_affine_tour (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected)
    (A : Finset V) (r : V) (hA : G.AttachedAt A r) {C saving : ℝ}
    (hsaving : 0 ≤ saving)
    (hleft : ∃ c : G.insideEdges A → ℕ, (G.inducedSubgraph A).IsTour c ∧
      (tourLength c : ℝ) ≤ C * (G.inducedSubgraph A).subtourLP - saving)
    (hright : ∃ c : G.insideEdges (otherPiece A r) → ℕ,
      (G.inducedSubgraph (otherPiece A r)).IsTour c ∧
      (tourLength c : ℝ) ≤ C * (G.inducedSubgraph (otherPiece A r)).subtourLP - saving) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP - saving := by
  obtain ⟨c, hct, hlen⟩ := hleft
  obtain ⟨c', hct', hlen'⟩ := hright
  refine ⟨gluePieceTours G A (otherPiece A r) c c',
    gluePieceTours_isTour G A (otherPiece A r) r hA.1 (Finset.mem_insert_self _ _)
      (pieces_union A r) hct hct', ?_⟩
  rw [gluePieceTours_length, Nat.cast_add]
  have hlp := articulation_subtourLP_add G hs hc A r hA
  rw [← hlp, mul_add]
  linarith

/-- An affine bound with a nonnegative saving survives the actual support and
articulation recursion, provided the doubled bridge also satisfies it. -/
theorem affine_tour_of_positive_extreme_blocks (C saving : ℝ) (hC : 1 ≤ C)
    (hsaving : 0 ≤ saving) (hbridge : saving ≤ 2 * (C - 1))
    (hblock : ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), G.IsSimple → IsTwoVertexConnected G →
      ∀ x : E → ℝ, x ∈ G.subtourPolytope.extremePoints ℝ → (∀ e, 0 < x e) →
        edgeSum x Finset.univ = G.subtourLP →
        ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP - saving) :
    ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), G.IsSimple → G.Connected → 2 ≤ Fintype.card V →
        ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP - saving := by
  have claim : ∀ n : ℕ, ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), Fintype.card V + Fintype.card E = n → G.IsSimple → G.Connected →
      2 ≤ Fintype.card V →
        ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ C * G.subtourLP - saving := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro V E _ _ _ _ G hn hs hc hsize
      by_cases hsmall : Fintype.card V ≤ 2
      · exact two_vertex_affine_tour G hs hc (by omega) hC hbridge
      · obtain ⟨x, hx, ho⟩ := exists_optimal_extreme_subtour G hc
        by_cases hp : ∀ e, 0 < x e
        · by_cases htwo : IsTwoVertexConnected G
          · exact hblock V E G hs htwo x hx hp ho
          · obtain ⟨r, A, hA, hsizeA, hltA, hsizeB, hltB⟩ :=
              exists_articulation_split G hc (by omega) htwo
            have heA : (G.insideEdges A).card ≤ Fintype.card E := by
              simpa using Finset.card_le_card (Finset.subset_univ (G.insideEdges A))
            have heB : (G.insideEdges (otherPiece A r)).card ≤ Fintype.card E := by
              simpa using Finset.card_le_card (Finset.subset_univ (G.insideEdges (otherPiece A r)))
            have hleft := ih (A.card + (G.insideEdges A).card) (by omega)
              A (G.insideEdges A) (G.inducedSubgraph A) (by simp)
              (induced_simple G hs A) (attached_connected G A r hA hx.1) (by simpa)
            have hright := ih ((otherPiece A r).card + (G.insideEdges (otherPiece A r)).card) (by omega)
              (otherPiece A r) (G.insideEdges (otherPiece A r)) (G.inducedSubgraph (otherPiece A r)) (by simp)
              (induced_simple G hs _) (attached_connected G _ r (otherPiece_attached G A r hA) hx.1) (by simpa)
            exact articulation_affine_tour G hs hc A r hA hsaving hleft hright
        · have hne : positiveSupport x ≠ Finset.univ := by
            intro heq
            apply hp
            intro e
            have h : e ∈ positiveSupport x := heq ▸ Finset.mem_univ e
            exact (Finset.mem_filter.mp h).2
          have hlt : (positiveSupport x).card < Fintype.card E := by
            simpa using Finset.card_lt_card
              (Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_univ _, hne⟩)
          have hcon : (G.restrictTo (positiveSupport x)).Connected := by
            rw [Connected, restrict_connected, includeEdges_univ]
            exact positiveSupport_connected G hc.1 hx.1
          obtain ⟨c, hct, hlen⟩ := ih (Fintype.card V + (positiveSupport x).card) (by omega)
            V (positiveSupport x) (G.restrictTo (positiveSupport x)) (by simp)
            (restrict_simple G hs _) hcon hsize
          refine ⟨extendMultiplicity (positiveSupport x) c, extendMultiplicity_isTour G _ c hct, ?_⟩
          rw [extendMultiplicity_length]
          rwa [positiveSupport_optimal G hc hx.1 ho] at hlen
  intro V E _ _ _ _ G hs hc hn
  exact claim _ V E G rfl hs hc hn

theorem degree_two_improved_affine_tour (G : Graph V E) (hc : G.Connected)
    (hn : 3 ≤ Fintype.card V) (hdegree : ∀ v, G.intDegree Finset.univ v = 2) :
    ∃ c : E → ℕ, G.IsTour c ∧
      (tourLength c : ℝ) ≤ (14524 * G.subtourLP - 8166) / 10481 := by
  obtain ⟨hc', hlen⟩ := degree_two_unit_tour G hc hdegree
  refine ⟨fun _ => 1, hc', ?_⟩
  rw [hlen]
  have hlp := subtourLP_ge_card G hc (by omega)
  have hnR : (3 : ℝ) ≤ Fintype.card V := by exact_mod_cast hn
  linarith

/-- The bridge determines the connected additive saving 8086/10481. This is
a reduction theorem; it does not assert the as-yet-unproved improved block bound. -/
theorem improved_general_tour_of_block_bound
    (hblock : ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (G : Graph V E), G.IsSimple → IsTwoVertexConnected G →
      ∀ x : E → ℝ, x ∈ G.subtourPolytope.extremePoints ℝ → (∀ e, 0 < x e) →
        edgeSum x Finset.univ = G.subtourLP →
        ∃ c : E → ℕ, G.IsTour c ∧
          (tourLength c : ℝ) ≤ (14524 * G.subtourLP - 8166) / 10481)
    (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected) (hn : 2 ≤ Fintype.card V) :
    ∃ c : E → ℕ, G.IsTour c ∧
      (tourLength c : ℝ) ≤ (14524 * G.subtourLP - 8086) / 10481 := by
  have hb : ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (H : Graph V E), H.IsSimple → IsTwoVertexConnected H →
      ∀ x : E → ℝ, x ∈ H.subtourPolytope.extremePoints ℝ → (∀ e, 0 < x e) →
        edgeSum x Finset.univ = H.subtourLP →
        ∃ c : E → ℕ, H.IsTour c ∧
          (tourLength c : ℝ) ≤ (14524 / 10481 : ℝ) * H.subtourLP - 8086 / 10481 := by
    intro V E _ _ _ _ H hH htwo x hx hp ho
    obtain ⟨c, hct, hlen⟩ := hblock V E H hH htwo x hx hp ho
    exact ⟨c, hct, by linarith⟩
  obtain ⟨c, hct, hlen⟩ := affine_tour_of_positive_extreme_blocks
    (14524 / 10481) (8086 / 10481) (by norm_num) (by norm_num) (by norm_num)
    hb V E G hs hc hn
  exact ⟨c, hct, by linarith⟩

end TSP.Improvements20261105
