import TSP.Improvements20261105.GeneralEndpointReductions
import TSP.Improvements20261105.GeneralContextSmallPairs
import TSP.Improvements20261105.GeneralContextUnselected
import TSP.Improvements20261105.GeneralContextSelectedFour
import TSP.Improvements20261105.GeneralContextExtremeTargets
import TSP.Improvements20261105.GeneralContextPositiveTwo
import TSP.Improvements20261105.GeneralContextZeroTargets
import TSP.Improvements20261105.GeneralContextPositiveGreedy
import TSP.Improvements20261105.ScoredPositiveTargetPayment

/-! Exhaustive case assembly. The imported local inequalities must all be
proved before this file compiles; no local payment claim is a hypothesis. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators

theorem all_general_pair_payments : AllGeneralPairPayments := by
  intro V E _ _ _ _ G x₀ x z hs hc root K
  intro p hp
  change K.PairPayment G x₀ x z hs hc root p
  let d := scoredDFS G x hs hc root
  have hd := K.local_pair_data G x₀ x z hs hc root p hp
  by_cases hsmall : (d.backGroup p.1.1).card ≤ 3
  · exact K.small_pair_payment G x₀ x z hs hc root p hp hsmall
  have ht4 : 4 ≤ (d.backGroup p.1.1).card := by omega
  rcases hd.source_binary with hsi | hsi
  · exact K.unselected_source_payment G x₀ x z hs hc root p hp hsi ht4
  by_cases hfour : (d.backGroup p.1.1).card=4
  · exact K.selected_four_payment G x₀ x z hs hc root p hp hsi hfour
  have ht5 : 5 ≤ (d.backGroup p.1.1).card := by omega
  rcases hd.target_binary with hsj | hsj
  · exact K.extreme_target_payment G x₀ x z hs hc root p hp hsi (Or.inl hsj)
  by_cases hr1 : (d.backGroup p.2.1).card=1
  · exact K.extreme_target_payment G x₀ x z hs hc root p hp hsi (Or.inr (Or.inl hr1))
  have hr2 : 2 ≤ (d.backGroup p.2.1).card := by
    have hh : 1 ≤ (d.backGroup p.2.1).card := hd.target_count
    omega
  by_cases hr15 : 15 ≤ (d.backGroup p.2.1).card
  · exact K.extreme_target_payment G x₀ x z hs hc root p hp hsi (Or.inr (Or.inr hr15))
  by_cases hpositive : 1 < edgeSum z (d.backGroup p.2.1)
  · by_cases hrEq2 : (d.backGroup p.2.1).card=2
    · exact K.positive_two_target_payment G x₀ x z hs hc root p hp hsi hsj ht5 hrEq2 hpositive
    have hr3 : 3 ≤ (d.backGroup p.2.1).card := by omega
    by_cases hscored : ScoredStar d x p.2.1
    · exact K.scored_positive_target_payment G x₀ x z hs hc root p hp hsi hsj ht5 hr3 hpositive hscored
    · exact K.positive_greedy_target_payment G x₀ x z hs hc root p hp hsi hsj ht5 hr3 hpositive hscored
  · exact K.zero_target_payment G x₀ x z hs hc root p hp hsi hsj ht5 hr2 (le_of_not_gt hpositive)

end TSP.Improvements20261105
