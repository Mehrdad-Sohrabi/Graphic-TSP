import TSP.Improvements20261105.EliminateNetworkVertex

/-! A constructive difference-constraint alternative by vertex elimination.
If every nonnegative circulation has nonnegative integer cost, an integer
potential satisfies every arc constraint. No LP duality is assumed. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators

theorem integer_potential_of_nonnegative_circulations :
    ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (N : Graph V E) (c : E → ℤ),
      (∀ f : E → ℝ, (∀ e, 0 ≤ f e) → Balanced N f → 0 ≤ ∑ e, (c e : ℝ) * f e) →
      ∃ p : V → ℤ, ∀ e, p (N.dst e) - p (N.src e) ≤ c e := by
  have claim : ∀ n : ℕ, ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
      (N : Graph V E) (c : E → ℤ), Fintype.card V = n →
      (∀ f : E → ℝ, (∀ e, 0 ≤ f e) → Balanced N f → 0 ≤ ∑ e, (c e : ℝ) * f e) →
      ∃ p : V → ℤ, ∀ e, p (N.dst e) - p (N.src e) ≤ c e := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro V E _ _ _ _ N c hn hN
      by_cases hne : Nonempty V
      · let v₀ : V := Classical.choice hne
        have hlt : Fintype.card (AwayVertex v₀) < n := by
          rw [← hn]
          exact Fintype.card_subtype_lt (x := v₀) (by simp)
        obtain ⟨q, hq⟩ := ih _ hlt (AwayVertex v₀) (EliminationArc N v₀)
          (eliminatedNetwork N v₀) (eliminatedCost N v₀ c) rfl
          (eliminated_nonnegative_circulations N v₀ c hN)
        apply extend_eliminated_potential N v₀ c _ q hq
        intro e he
        exact_mod_cast loop_cost_nonnegative N (fun e => (c e : ℝ)) hN e he
      · refine ⟨fun _ => 0, ?_⟩
        intro e
        exact (hne ⟨N.src e⟩).elim
  intro V E _ _ _ _ N c hN
  exact claim _ V E N c rfl hN

end TSP.Improvements20261105
