import TSP.Improvements20261105.GlobalBlockDistribution
import TSP.Improvements20261105.ClassifiedMinorLift
import TSP.Improvements20261105.IntervalPairConstruction

/-! Exact representative and connector marginals in the classified lift.
The agreement needed below is required only on positive-weight atoms. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter05 Classical
open scoped BigOperators
variable {V E A J : Type} [Fintype V] [Fintype E] [Fintype A] [Fintype J]
  [DecidableEq V] [DecidableEq E] [DecidableEq J]

theorem classified_anchor_incidences {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) (i : ClassifiedStarIndex d x) :
    anchorIncidences G (partialStars d x) (partialCenter d x) (partialMain d hx hn hcap) i =
      if partialMain d hx hn hcap (partialCenter d x i) = some i
      then minorBoundary d x (partialCenter d x i) else partialStars d x i := by
  unfold anchorIncidences
  split_ifs with hi
  · have hh := (partialMain_head d hx hn hcap i).mp hi
    have hu : ClassifiedCenter d x (partialCenter d x i) := i.2
    rw [minorBoundary, dif_pos hu]
    change G.cut {partialCenter d x i} \ d.group i.1.1 = _
    rw [hh]
  · rfl

theorem classified_anchor_incidences_subset {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) (i : ClassifiedStarIndex d x) :
    anchorIncidences G (partialStars d x) (partialCenter d x) (partialMain d hx hn hcap) i ⊆
      minorBoundary d x (partialCenter d x i) := by
  rw [classified_anchor_incidences d hx hn hcap i]
  split_ifs with hi
  · exact Finset.Subset.refl _
  · exact light_group_subset_minorBoundary d hsimple x (partialCenter d x i) i.2 i.1.1 rfl
      (fun hh => hi ((partialMain_head d hx hn hcap i).mpr hh))

theorem classified_anchor_capacity_eq_mass {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) (i : ClassifiedStarIndex d x) :
    classifiedCapacity d hx hn hcap (Sum.inr i) =
      edgeSum x (anchorIncidences G (partialStars d x) (partialCenter d x)
        (partialMain d hx hn hcap) i) := by
  rw [classified_anchor_capacity d hsimple hx hn hcap i,
    classified_anchor_incidences d hx hn hcap i]
  split_ifs <;> rfl

theorem classified_lift_representative {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) (w : A → ℝ) (S : A → Finset E) (e : E) :
    classifiedLiftMixture d hx hn hcap w S (Sum.inl e) =
      ∑ a, w a * incidence (S a) e := by
  apply Finset.sum_congr rfl
  intro a _
  simp [classifiedMinorLift, minorParityLift, incidence]

theorem intersection_from_boundary {S P B L : Finset E} (hSP : S ∩ B = P) (hL : L ⊆ B) :
    S ∩ L = P ∩ L := by
  rw [← hSP, Finset.inter_assoc, Finset.inter_eq_right.mpr hL]

theorem classified_lift_connector_marginal {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (w : A → ℝ) (choice : A → V → J) (S : A → Finset E)
    (v : V → J → ℝ) (P : V → J → Finset E)
    (hw : ∀ a, 0 ≤ w a)
    (hchoice : ∀ u j, ∑ a, w a * (if choice a u = j then 1 else 0) = v u j)
    (hag : ∀ a, 0 < w a → ∀ u, S a ∩ minorBoundary d x u = P u (choice a u))
    (i : ClassifiedStarIndex d x) :
    classifiedLiftMixture d hx hn hcap w S (Sum.inr i) =
      ∑ j, v (partialCenter d x i) j *
        (if Odd (P (partialCenter d x i) j ∩
          anchorIncidences G (partialStars d x) (partialCenter d x)
            (partialMain d hx hn hcap) i).card then 1 else 0) := by
  let L := anchorIncidences G (partialStars d x) (partialCenter d x)
    (partialMain d hx hn hcap) i
  have hpoint : ∀ a, w a * incidence (classifiedMinorLift d hx hn hcap (S a)) (Sum.inr i) =
      w a * (if Odd (P (partialCenter d x i) (choice a (partialCenter d x i)) ∩ L).card then 1 else 0) := by
    intro a
    by_cases hz : w a = 0
    · simp [hz]
    · have hp : 0 < w a := lt_of_le_of_ne (hw a) (Ne.symm hz)
      have he := intersection_from_boundary (hag a hp (partialCenter d x i))
        (classified_anchor_incidences_subset d hsimple hx hn hcap i)
      change S a ∩ L = _ at he
      simp only [classifiedMinorLift, minorParityLift, incidence, Finset.mem_filter,
        Finset.mem_univ, true_and, Sum.elim_inr]
      change w a * (if Odd (S a ∩ L).card then 1 else 0) = _
      rw [he]
  unfold classifiedLiftMixture
  simp_rw [hpoint]
  exact weighted_function_transport w (v (partialCenter d x i))
    (fun a => choice a (partialCenter d x i)) (hchoice (partialCenter d x i))
    (fun j => if Odd (P (partialCenter d x i) j ∩ L).card then 1 else 0)

end TSP.Improvements20261105
