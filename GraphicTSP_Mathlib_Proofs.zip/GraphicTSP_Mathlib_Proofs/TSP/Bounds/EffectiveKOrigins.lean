import TSP.Improvements20261105.ProtectedCoverPayment
import TSP.Improvements20261105.FixedProjectionPacking
import TSP.Improvements20261105.FixedForceConstants

/-! Effective K origins really own at least three original back edges
under the fixed scored DFS rule. Their centers are not unary. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]

theorem current_two_back_K_numerator (E q eta : ℝ)
    (hE : E ≤ 1 - q) (hpack : E ≤ 2 * q - 1) (heta : 0 ≤ eta) :
    (415 / 2 : ℝ) * E - (704 / 5 : ℝ) * (q + eta) + 60 * min q (1 - q) ≤ 0 := by
  have hh := min_le_right q (1 - q)
  by_cases hq : q ≤ 2 / 3
  · linarith
  · linarith

theorem effective_K_origin_nonunary {G : Graph V E} (d : DFSData G)
    (hs : G.IsSimple) (x z : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child)
    (heff : coveredPIncrease d x P Q C.cover s < protectedCoverIncrease d x z P Q K C s) :
    d.tree.parent s ≠ d.tree.root ∧ 2 ≤ childCount d (d.tree.parent s) := by
  have hp : ProtectedHead d x z P Q C s := by
    by_contra h
    simpa [protectedCoverIncrease, h] using heff
  refine ⟨hp.1, ?_⟩
  have hcount : 0 < childCount d (d.tree.parent s) := by
    apply Finset.card_pos.mpr
    exact ⟨s, Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩⟩
  by_contra hn2
  have hc : childCount d (d.tree.parent s) = 1 := by omega
  have hdeg := tree_degree_eq d (d.tree.parent s)
  rw [if_neg hp.1, hc] at hdeg
  have hev : Even (G.intDegree d.treeEdges (d.tree.parent s)) := by rw [hdeg]; norm_num
  have hsame := protected_even_unchanged d hs x z hx hn hcap hm P Q K hP hQ hK hKQ C s hev
  rw [hsame] at heff
  exact (lt_irrefl _ heff)

theorem effective_K_origin_three_backs (G : Graph V E) (x z : E → ℝ)
    (hs : G.IsSimple) (hc : G.Connected) (root : V) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((scoredDFS G x hs hc root).backGroup s) =
      edgeSum x ((scoredDFS G x hs hc root).backGroup s) -
      fixedRemoval (scoredDFS G x hs hc root) x (allFullOverrideTargets (scoredDFS G x hs hc root) x) s)
    (C : ProjectedCoverWitness (scoredDFS G x hs hc root) x z (415 / 2) (704 / 5))
    (s : (scoredDFS G x hs hc root).tree.Child)
    (heff : coveredPIncrease (scoredDFS G x hs hc root) x (415 / 2) (704 / 5) C.cover s <
      protectedCoverIncrease (scoredDFS G x hs hc root) x z (415 / 2) (704 / 5) 60 C s) :
    3 ≤ ((scoredDFS G x hs hc root).backGroup s).card := by
  classical
  let d := scoredDFS G x hs hc root
  change 3 ≤ (d.backGroup s).card
  change coveredPIncrease d x (415 / 2) (704 / 5) C.cover s <
    protectedCoverIncrease d x z (415 / 2) (704 / 5) 60 C s at heff
  have hp : ProtectedHead d x z (415 / 2) (704 / 5) C s := by
    by_contra h
    simpa [protectedCoverIncrease, h] using heff
  by_contra hthree
  have ht : (d.backGroup s).card ≤ 2 := by omega
  have hsum : edgeSum x (d.backGroup s) ≤ ((d.backGroup s).card : ℝ) * x (d.treeEdge s) := by
    calc
      _ ≤ ∑ e ∈ d.backGroup s, x (d.treeEdge s) := Finset.sum_le_sum (fun e he =>
        scoredDFS_small_back_greedy G x hs hc root s (by change (d.backGroup s).card ≤ 3; omega) e he)
      _ = _ := by simp
  have hcard : ((d.backGroup s).card : ℝ) ≤ 2 := by exact_mod_cast ht
  have hsum2 := hsum.trans (mul_le_mul_of_nonneg_right hcard (hx.1 _))
  have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent s)
  have hpos := (lt_max_iff.mp hp.2.1).resolve_right (lt_irrefl _)
  have heq : survivingExcess d x s = edgeSum x (d.backGroup s) - 1 - degreeExcess G x (d.tree.parent s) :=
    max_eq_left hpos.le
  have hpack : survivingExcess d x s ≤ 2 * x (d.treeEdge s) - 1 := by rw [heq]; linarith
  have hnum := current_two_back_K_numerator (survivingExcess d x s) (x (d.treeEdge s))
    (preliminaryQIncrease d x s) (survivingExcess_bounds d hs hx hcap s).2 hpack
    (preliminaryQIncrease_bounds d hs hx hcap s).1
  have hdiv := div_nonpos_of_nonpos_of_nonneg hnum (show (0 : ℝ) ≤ 415 / 2 by norm_num)
  have hbase := (coveredPIncrease_bounds d hs x z hx hn hcap hm (415 / 2) (704 / 5)
    (by norm_num) (by norm_num) C s).1
  have hsame : protectedCoverIncrease d x z (415 / 2) (704 / 5) 60 C s =
      coveredPIncrease d x (415 / 2) (704 / 5) C.cover s := by
    rw [protectedCoverIncrease, if_pos hp, protectedIncrease, max_eq_left hdiv, max_eq_left hbase]
  change coveredPIncrease d x (415 / 2) (704 / 5) C.cover s <
    protectedCoverIncrease d x z (415 / 2) (704 / 5) 60 C s at heff
  rw [hsame] at heff
  exact lt_irrefl _ heff

end TSP.Improvements20261105
