import TSP.Improvements20261105.ProjectedExcessLinks

/-! A fully projected heavy star is the actual unique classified main
star, and its projected mass determines the normalized connector bound. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem full_removal_heavy_classified (x z : E → ℝ) (s : d.tree.Child)
    (hm : edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) - degreeExcess G x (d.tree.parent s))
    (hheavy : 1 < x (d.treeEdge s) + edgeSum z (d.backGroup s)) :
    ClassifiedCenter d x (d.tree.parent s) := by
  refine ⟨s, Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩, ?_⟩
  have hgroup := group_mass_eq_tree_add_backs d x s
  unfold degreeExcess at hm
  linarith

theorem full_removal_heavy_main (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : d.StarIndex)
    (hm : edgeSum z (d.backGroup i.1) = edgeSum x (d.backGroup i.1) - degreeExcess G x (d.centers i))
    (hheavy : 1 < x (d.treeEdge i.1) + edgeSum z (d.backGroup i.1))
    (hu : ClassifiedCenter d x (d.centers i)) :
    partialMain d hx hn hcap (d.centers i) = some (⟨i, hu⟩ : ClassifiedStarIndex d x) := by
  apply (partialMain_head d hx hn hcap ⟨i, hu⟩).mpr
  have hh := classifiedHead_spec d x (d.centers i) hu
  apply classified_head_unique d hs hx hn (d.centers i) i.1 _ rfl hh.1 _ hh.2
  have hgroup := group_mass_eq_tree_add_backs d x i.1
  unfold degreeExcess at hm
  change edgeSum x (G.cut {d.centers i}) - edgeSum x (d.group i.1) < 1
  linarith

theorem surviving_full_removal_identity (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) - fixedRemoval d x T s)
    (s : d.tree.Child) (hp : 1 < edgeSum z (d.backGroup s)) :
    edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) - degreeExcess G x (d.tree.parent s) := by
  have hs' := hp
  rw [hm] at hs'
  have hv := (fixed_projected_positive_iff d hs hx hn T s).mp hs'
  rw [hm, fixedRemoval_surviving d hs hx hn T s hv]

theorem override_full_removal_identity (hs : G.IsSimple) (x z : E → ℝ)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (s : d.tree.Child) (ht : s ∈ allFullOverrideTargets d x) :
    edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) - degreeExcess G x (d.tree.parent s) := by
  have hu := full_override_classified d hs x s (allFullOverrideTargets_valid d x s ht)
  rw [hm, fixedRemoval, if_pos hu, if_pos ht]

theorem override_projected_heavy (hs : G.IsSimple) (x z : E → ℝ)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (s : d.tree.Child) (ht : s ∈ allFullOverrideTargets d x) :
    1 < x (d.treeEdge s) + edgeSum z (d.backGroup s) := by
  obtain ⟨u, hpar, hunary, hmatch⟩ := allFullOverrideTargets_valid d x s ht
  have hid := full_override_identity d hs x u s hpar hunary
  have hp := override_full_removal_identity d hs x z hm s ht
  rw [← hp] at hid
  linarith

end TSP.Improvements20261105
