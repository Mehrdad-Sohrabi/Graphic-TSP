import TSP.Improvements20261105.CurrentKZeroReceiver
import TSP.Improvements20261105.CurrentProjectedGuardedDeficits
import TSP.Improvements20261105.KZeroReceiverFinance
import TSP.Improvements20261105.TerminalHReceiver

/-! The actual simultaneous construction retains a strictly negative
bound at a projected-zero receiver of an unmatched protected link.
Actual-zero and erased-positive receivers are both included. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_K_zero_receiver_max (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hl : v ∈ projectionLinks d x)
    (hu : v ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -48*(1-x (d.treeEdge v)-outgoingBackMass d x v) := by
  have hnr : d.centers i ≠ d.tree.root := by rw [hv]; exact v.2
  have hc := current_K_zero_receiver_connector d hs x z hx hn hcap hm C owner ho rootStar hroot R hR i v hv hl hu hz
  have hd := current_projected_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar
    Y R hY hrep hbacks hloss hterminal hzero i hnr
  have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v (Finset.mem_filter.mp hl).2.2.2.1).2 i.1 hv).symm
  have hz' : edgeSum z (d.backGroup (unaryNext d v)) ≤ 1 := by rwa [hnext]
  have hcov := unmatched_link_zero_receiver_cover d hs x z hx hn hm (415/2) (704/5) C v hl hu hz'
  rw [hnext] at hcov
  have hg := (Finset.mem_filter.mp hl).2.2.2.2
  apply (sub_le_iff_le_add).mpr
  apply max_le <;> linarith

end TSP.Improvements20261105
