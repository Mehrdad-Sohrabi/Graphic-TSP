import TSP.Improvements20261105.ClassifiedExpansion
import TSP.Improvements20261105.MinorParityLift
import TSP.Improvements20261105.MinorCutMixtures

/-! Minor parity and cut assembly in the actual classified DFS expansion.
The remaining Q marginal construction must establish the explicit
half-capacity box premise of the last theorem. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter05 Classical
open scoped BigOperators
variable {V E A : Type} [Fintype V] [Fintype E] [Fintype A]
  [DecidableEq V] [DecidableEq E]

noncomputable def classifiedMajorSet {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) :
    Finset (V ⊕ ClassifiedStarIndex d x) := Finset.univ.image (classifiedMajor d hx hn hcap)

noncomputable def classifiedMinorLift {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (J : Finset E) : Finset (E ⊕ ClassifiedStarIndex d x) :=
  minorParityLift G (partialStars d x) (partialCenter d x) (partialMain d hx hn hcap) J

theorem classified_minor_lift_even {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (J : Finset E) (v : V ⊕ ClassifiedStarIndex d x) (hv : v ∉ classifiedMajorSet d hx hn hcap) :
    Even ((classifiedExpansion d x).intDegree (classifiedMinorLift d hx hn hcap J) v) := by
  apply minorParityLift_even_off_majors G (partialStars d x) (partialCenter d x) (partialOwner d x)
    hsimple.1 (fun i e he => d.group_incident i.1.1 e he) (partialOwner_valid d x)
    (fun i => group_subset_center_cut d hsimple i.1.1) (partialMain d hx hn hcap)
    (partialMain_center d hx hn hcap) J v
  intro h
  obtain ⟨u, hu⟩ := h
  exact hv (Finset.mem_image.mpr ⟨u, Finset.mem_univ _, hu⟩)

noncomputable def classifiedLiftMixture {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (w : A → ℝ) (J : A → Finset E) (e : E ⊕ ClassifiedStarIndex d x) : ℝ :=
  ∑ i, w i * incidence (classifiedMinorLift d hx hn hcap (J i)) e

theorem classified_lift_mixture_blossom_of_box {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (T : Finset (V ⊕ ClassifiedStarIndex d x)) (hT : T ⊆ classifiedMajorSet d hx hn hcap)
    (hTeven : Even T.card) (w : A → ℝ) (J : A → Finset E)
    (hw : ∀ i, 0 ≤ w i) (hs : ∑ i, w i = 1)
    (hbox : ∀ e, classifiedCapacity d hx hn hcap e / 2 ≤ classifiedLiftMixture d hx hn hcap w J e ∧
      classifiedLiftMixture d hx hn hcap w J e ≤ 1 - classifiedCapacity d hx hn hcap e / 2) :
    BlossomConstraints (classifiedExpansion d x) (targetParity T) (classifiedLiftMixture d hx hn hcap w J) := by
  apply shielded_minor_mixture_blossom (classifiedExpansion d x) (classifiedMajorSet d hx hn hcap)
    T hT hTeven (classifiedCapacity d hx hn hcap) (classifiedLiftMixture d hx hn hcap w J) hbox
    (w := w) (J := fun i => classifiedMinorLift d hx hn hcap (J i))
  · intro U hl hr
    obtain ⟨u, hu, huU⟩ := hl
    obtain ⟨v, hv, hvU⟩ := hr
    obtain ⟨u', _, rfl⟩ := Finset.mem_image.mp hu
    obtain ⟨v', _, rfl⟩ := Finset.mem_image.mp hv
    exact classified_major_cut_shield d hx hn hcap U ⟨u', huU⟩ ⟨v', hvU⟩
  · exact hw
  · exact hs
  · intro e; rfl
  · intro i _ v hv
    exact classified_minor_lift_even d hsimple hx hn hcap (J i) v hv

end TSP.Improvements20261105
