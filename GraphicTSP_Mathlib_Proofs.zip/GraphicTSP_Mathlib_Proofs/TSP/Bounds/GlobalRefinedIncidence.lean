import TSP.Improvements20261105.CanonicalRefinedIncidence
import TSP.Improvements20261105.GlobalCanonicalIncidence
import TSP.Improvements20261105.GatedComponentSums

/-! Sum the actual parent bounds with disjoint head and deficit owners.
The induced-center adjacency credit is retained for later matching roles. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_global_refined_incidence (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : Finset d.tree.Child) (hscore : ScoreComparisons d x C)
    (R : Finset d.tree.Child) (hRC : R ⊆ C)
    (hR : ∀ s ∈ R, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (q : d.tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, (d.backGroup s).card ≤ 3 → ∀ e ∈ d.backGroup s, z e ≤ q s) :
    24 * a.value d P (fun _ => 0) ≤
      (∑ s ∈ a.selectedHeads d, refinedIncidenceCharge d x z C R s) +
      24 * ((a.headfulLeafComponents d P).card - 1 - (a.selectedRootHeads d).card -
        ∑ s : d.tree.Child, (a.penalty d P s : ℝ)) -
      (162 / 19) * (∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z C r : ℝ)) +
      48 * (∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s) +
      (124 / 5) * (edgeSum x Finset.univ - Fintype.card V) := by
  let err (r : a.Component d P) : ℝ :=
    -(162 / 19) * a.incidenceEdgeCount d P z C r +
      48 * (∑ s ∈ a.componentHeads d P r, ownProjectionLoss d x z s) +
      (124 / 5) * a.outgoingDeficit d P (fun b => x b.1) r
  have hi := canonical_dual_incidence_sum d hs hc P hP t ht f hf hb a ha hcan
    24 (refinedIncidenceCharge d x z C R) err (by
      intro r hr
      have h := canonical_refined_parent_incidence d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
        r hr x z hx hcap hz hzx C hscore R hRC hR q (fun s _ => hq s) (fun s _ => hpack s) (fun s _ => hsmall s)
      dsimp [err, GatedDrops.incidenceEdgeCount]
      linarith)
  have he : (∑ r ∈ a.internalComponents d P, err r) =
      -(162 / 19) * (∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z C r : ℝ)) +
      48 * (∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s) +
      (124 / 5) * (∑ r ∈ a.internalComponents d P, a.outgoingDeficit d P (fun b => x b.1) r) := by
    dsimp [err]
    simp only [Finset.sum_add_distrib, ← Finset.mul_sum]
    rw [canonical_internal_head_charge_sum d hs hc P hP t ht f hf hb a ha hcan]
  rw [he] at hi
  have hdef := a.outgoingDeficit_subset_bound d hs hc P hx hcap (a.internalComponents d P)
  linarith

end TSP.Improvements20261105
