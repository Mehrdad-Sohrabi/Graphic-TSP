import TSP.Improvements20261105.ActualFourScoredSourceLoad
import TSP.Improvements20261105.ActualFourGreedySourceLoad
import TSP.Improvements20261105.LargeAnySourceLoad
import TSP.Improvements20261105.ProjectedMatchingWeights
import TSP.Improvements20261105.GoodPartitionMassBound
import TSP.Improvements20261105.ScoredUniformNetLoad

/-! Continuous source estimates instantiated with the actual star weights,
fixed incidence charge and original unit-part capacities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_four_matching_source_load
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eligible T : Finset (d).tree.Child) (heligible : ∀ s, ScoredStar d x s → s ∈ eligible)
    (s : (d).tree.Child) (hsM : s ∈ C.matching) (hcount : ((d).backGroup s).card=4)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  have hl := C.link_subset hsM
  have hpositive := projectionLink_source_positive d hs x z hx hn hm s hl
  have hout := C.source_excess s hsM
  by_cases hsc : ScoredStar d x s
  · exact scoredDFS_four_scored_source_load G x z hs hc root hx hn hcap hz hzx htree hm
      eligible T s hsc (heligible s hsc) hpositive hout.le hcount bad hbad hgood δ hδ0 hδ
  · exact scoredDFS_four_greedy_source_load G x z hs hc root hx hn hcap hz hzx htree hm
      eligible T s (Finset.mem_filter.mp hl).2.1 hsc hpositive hcount bad hbad hgood δ hδ0 hδ

end TSP.Improvements20261105
