import TSP.Improvements20261105.AdaptiveDFS

/-! One common decision snapshot for every eventual DFS star. All its edges
were simultaneously eligible for the actual state-dependent choice. -/
namespace TSP.Improvements20261105.AdaptiveDFS
open Graph Chapter05 Chapter05.GreedySearch
variable {V E W : Type} [Fintype V] [Fintype E] [DecidableEq V]
  [LinearOrder E] [LinearOrder W]

def DescendantOrUnseen (root : V) (s : State V E) (c w : V) : Prop :=
  (w ∈ s.seen ∧ Ancestor root s c w) ∨ (w ∉ s.seen ∧ c ∈ s.stack)

structure EntrySnapshot (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (s : State V E) (c : V) where
  state : State V E
  parent : V
  edge : E
  tail : List V
  valid : Invariants G root state
  head : state.stack = parent :: tail
  choice : pickEdge G (score state parent) state.seen parent = some edge
  child : otherEndpoint G parent edge = c
  parent_eq : s.parent c = parent
  entering_eq : s.entering c = some edge
  seen_subset : state.seen ⊆ s.seen
  entering_stable : ∀ w ∈ state.seen, s.entering w = state.entering w
  fresh_descendants : ∀ w ∈ s.seen, Ancestor root s c w → w ∉ state.seen
  ancestors : ∀ a, Ancestor root state a parent ↔ Ancestor root s a parent
  candidates : ∀ f w,
    ((G.src f = s.parent c ∧ G.dst f = w) ∨ (G.dst f = s.parent c ∧ G.src f = w)) →
    DescendantOrUnseen root s c w → f ∈ eligibleEdges G state.seen parent

def EntryInvariant (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (s : State V E) : Prop :=
  ∀ c ∈ s.seen, c ≠ root → Nonempty (EntrySnapshot G score root s c)

theorem initial_entries (G : Graph V E) (score : State V E → V → E → W) (root : V) :
    EntryInvariant G score root (initial root) := by
  intro c hc hn
  exact (hn (Finset.mem_singleton.mp hc)).elim

theorem push_entries (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (s : State V E) (u : V) (tail : List V) (e : E)
    (hstack : s.stack = u :: tail) (hinv : Invariants G root s)
    (hw : EntryInvariant G score root s)
    (he : pickEdge G (score s u) s.seen u = some e) :
    EntryInvariant G score root (push G s u e) := by
  obtain ⟨hc, ht, hp, hcomp⟩ := hinv
  have hem := pickEdge_mem G (score s u) s.seen u he
  have hfresh := otherEndpoint_fresh G s.seen u hem
  have hu := hc.1 u (by rw [hstack]; exact List.mem_cons_self)
  intro c hcnew hnr
  by_cases hcv : c = otherEndpoint G u e
  · subst c
    refine ⟨{
      state := s, parent := u, edge := e, tail := tail,
      valid := ⟨hc, ht, hp, hcomp⟩, head := hstack, choice := he, child := rfl,
      parent_eq := by simp only [push, Function.update_self],
      entering_eq := by simp only [push, Function.update_self],
      seen_subset := Finset.subset_insert _ _,
      entering_stable := ?_,
      fresh_descendants := ?_,
      ancestors := fun a => (ancestor_push_old G root s ht u e hem hu).symm,
      candidates := ?_ }⟩
    · intro w hw
      have hn : w ≠ otherEndpoint G u e := fun h => hfresh (h ▸ hw)
      simp only [push, Function.update_of_ne hn]
    · intro w _ hanc hwold
      have hold := (ancestor_push_old G root s ht u e hem hwold).mp hanc
      exact hfresh (ancestor_seen G root s ht hwold hold)
    · intro f w hfw hcond
      have hwfresh : w ∉ s.seen := by
        rcases hcond with ⟨hwnew, hanc⟩ | ⟨hwn, hactive⟩
        · intro hwold
          have hold := (ancestor_push_old G root s ht u e hem hwold).mp hanc
          exact hfresh (ancestor_seen G root s ht hwold hold)
        · exact fun hwo => hwn (Finset.mem_insert_of_mem hwo)
      have hfw' : (G.src f = u ∧ G.dst f = w) ∨ (G.dst f = u ∧ G.src f = w) := by
        simpa only [push, Function.update_self] using hfw
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_univ _, ?_⟩
      rcases hfw' with h | h
      · exact Or.inl ⟨h.1, h.2 ▸ hwfresh⟩
      · exact Or.inr ⟨h.1, h.2 ▸ hwfresh⟩
  · have hcold := Finset.mem_of_mem_insert_of_ne hcnew hcv
    obtain ⟨snap⟩ := hw c hcold hnr
    have hparent : snap.parent ∈ s.seen := snap.parent_eq ▸ ht.parent_seen c hcold
    refine ⟨{
      state := snap.state, parent := snap.parent, edge := snap.edge, tail := snap.tail,
      valid := snap.valid, head := snap.head, choice := snap.choice, child := snap.child,
      parent_eq := by simpa only [push, Function.update_of_ne hcv] using snap.parent_eq,
      entering_eq := by simpa only [push, Function.update_of_ne hcv] using snap.entering_eq,
      seen_subset := snap.seen_subset.trans (Finset.subset_insert _ _),
      entering_stable := ?_,
      fresh_descendants := ?_,
      ancestors := fun a => (snap.ancestors a).trans
        (ancestor_push_old G root s ht u e hem hparent).symm,
      candidates := ?_ }⟩
    · intro w hw
      have hn : w ≠ otherEndpoint G u e := fun h => hfresh (h ▸ snap.seen_subset hw)
      simpa only [push, Function.update_of_ne hn] using snap.entering_stable w hw
    · intro w hwnew hanc hwstate
      have hwold := snap.seen_subset hwstate
      exact snap.fresh_descendants w hwold
        ((ancestor_push_old G root s ht u e hem hwold).mp hanc) hwstate
    · intro f w hfw hcond
      have hfw' : (G.src f = s.parent c ∧ G.dst f = w) ∨
          (G.dst f = s.parent c ∧ G.src f = w) := by
        simpa only [push, Function.update_of_ne hcv] using hfw
      apply snap.candidates f w hfw'
      rcases hcond with ⟨hwnew, hanc⟩ | ⟨hwn, hactive⟩
      · by_cases hwv : w = otherEndpoint G u e
        · subst w
          have hcu := (ancestor_push_new G root s ht u e hu hem c).mp hanc
          exact Or.inr ⟨hfresh,
            (stackPath_ancestors root s hp hstack c).mp (hcu.resolve_left hcv)⟩
        · have hwold := Finset.mem_of_mem_insert_of_ne hwnew hwv
          exact Or.inl ⟨hwold, (ancestor_push_old G root s ht u e hem hwold).mp hanc⟩
      · exact Or.inr ⟨fun hwo => hwn (Finset.mem_insert_of_mem hwo),
          (List.mem_cons.mp hactive).resolve_left hcv⟩

theorem pop_entries (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (s : State V E) (u : V) (tail : List V) (hs : s.stack = u :: tail)
    (hw : EntryInvariant G score root s) :
    EntryInvariant G score root {s with stack := tail} := by
  intro c hc hn
  obtain ⟨snap⟩ := hw c hc hn
  refine ⟨{
    state := snap.state, parent := snap.parent, edge := snap.edge, tail := snap.tail,
    valid := snap.valid, head := snap.head, choice := snap.choice, child := snap.child,
    parent_eq := snap.parent_eq, entering_eq := snap.entering_eq,
    seen_subset := snap.seen_subset, fresh_descendants := snap.fresh_descendants,
    entering_stable := snap.entering_stable,
    ancestors := snap.ancestors, candidates := ?_ }⟩
  intro f w hfw hcond
  apply snap.candidates f w hfw
  rcases hcond with hh | ⟨hwn, ha⟩
  · exact Or.inl hh
  · exact Or.inr ⟨hwn, by rw [hs]; exact List.mem_cons_of_mem _ ha⟩

theorem run_entries (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (s : State V E) (hinv : Invariants G root s)
    (hw : EntryInvariant G score root s) :
    EntryInvariant G score root (run G score s) := by
  induction s using run.induct G score with
  | case1 s hs => simpa only [run_of_nil G score s hs] using hw
  | case2 s u tail hs he ih =>
    rw [run_of_none G score s u tail hs he]
    obtain ⟨hc, ht, hp, hcomp⟩ := hinv
    exact ih ⟨pop_closed G s u tail hs hc ((pickEdge_none G (score s u) s.seen u).mp he),
      pop_tree G root s tail ht, pop_stack root s u tail hs hp, pop_comparable G root s tail hcomp⟩
      (pop_entries G score root s u tail hs hw)
  | case3 s u tail hs e he ih =>
    rw [run_of_some G score s u tail hs e he]
    have hu := hinv.1.1 u (by rw [hs]; exact List.mem_cons_self)
    have hem := pickEdge_mem G (score s u) s.seen u he
    exact ih ⟨push_closed G s u e hinv.1, push_tree G root s u e hinv.2.1 hu hem,
      push_stack G root s u tail e hs hinv.1 hinv.2.1 hinv.2.2.1 hem,
      push_comparable G root s u tail e hs hinv.1 hinv.2.1 hinv.2.2.1 hinv.2.2.2 hem⟩
      (push_entries G score root s u tail e hs hinv hw he)

theorem searchDFS_entry_snapshot (G : Graph V E) (score : State V E → V → E → W)
    (hsimple : G.IsSimple) (hconn : G.Connected) (root : V)
    (v : (searchDFS G score hsimple hconn root).tree.Child) :
    Nonempty (EntrySnapshot G score root (run G score (initial root)) v) := by
  have hw := run_entries G score root (initial root) (initial_invariants G root)
    (initial_entries G score root)
  exact hw v (by rw [run_initial_spanning G score hconn root]; exact Finset.mem_univ _) v.2

theorem searchDFS_group_snapshot (G : Graph V E) (score : State V E → V → E → W)
    (hsimple : G.IsSimple) (hconn : G.Connected) (root : V)
    (v : (searchDFS G score hsimple hconn root).tree.Child) :
    ∃ (s : State V E) (tail : List V), Invariants G root s ∧
      s.stack = (searchDFS G score hsimple hconn root).tree.parent v :: tail ∧
      pickEdge G (score s ((searchDFS G score hsimple hconn root).tree.parent v)) s.seen
        ((searchDFS G score hsimple hconn root).tree.parent v) =
          some ((searchDFS G score hsimple hconn root).treeEdge v) ∧
      (∀ e ∈ (searchDFS G score hsimple hconn root).group v,
        e ∈ eligibleEdges G s.seen ((searchDFS G score hsimple hconn root).tree.parent v)) ∧
      (∀ a, Ancestor root s a ((searchDFS G score hsimple hconn root).tree.parent v) ↔
        (searchDFS G score hsimple hconn root).tree.Ancestor a
          ((searchDFS G score hsimple hconn root).tree.parent v)) := by
  let final := run G score (initial root)
  let hi := run_invariants G score root _ (initial_invariants G root)
  let hall := run_initial_spanning G score hconn root
  let d := searchDFS G score hsimple hconn root
  have hw := run_entries G score root (initial root) (initial_invariants G root)
    (initial_entries G score root)
  obtain ⟨snap⟩ := hw v (by rw [hall]; exact Finset.mem_univ _) v.2
  have henter : final.entering v = some (d.treeEdge v) :=
    (chosenTreeEdge_spec G root final hi.2.1 hall v).1
  have hedge : snap.edge = d.treeEdge v := Option.some.inj (snap.entering_eq.symm.trans henter)
  have hparent : snap.parent = d.tree.parent v := snap.parent_eq.symm
  refine ⟨snap.state, snap.tail, snap.valid, ?_, ?_, ?_, ?_⟩
  · simpa only [hparent] using snap.head
  · simpa only [hparent, hedge] using snap.choice
  · intro e he
    have hgroup := (d.mem_group_iff v e).mp he
    rw [← hparent]
    apply snap.candidates e (d.lower e)
    · rcases d.oriented e with hor | hor
      · exact Or.inl ⟨hor.1.trans hgroup.1, hor.2⟩
      · exact Or.inr ⟨hor.2.trans hgroup.1, hor.1⟩
    · exact Or.inl ⟨by rw [hall]; exact Finset.mem_univ _, hgroup.2⟩
  · intro a
    simpa only [hparent] using snap.ancestors a

theorem searchDFS_common_score_bound (G : Graph V E) (score : State V E → V → E → W)
    (hsimple : G.IsSimple) (hconn : G.Connected) (root : V)
    (v : (searchDFS G score hsimple hconn root).tree.Child) :
    ∃ s : State V E, Invariants G root s ∧
      ∀ e ∈ (searchDFS G score hsimple hconn root).group v,
        score s ((searchDFS G score hsimple hconn root).tree.parent v) e ≤
          score s ((searchDFS G score hsimple hconn root).tree.parent v)
            ((searchDFS G score hsimple hconn root).treeEdge v) := by
  obtain ⟨s, tail, hs, hhead, hchoice, hcandidates, hancestors⟩ :=
    searchDFS_group_snapshot G score hsimple hconn root v
  refine ⟨s, hs, ?_⟩
  intro e he
  exact pickEdge_max G _ s.seen _ hchoice (hcandidates e he)

end TSP.Improvements20261105.AdaptiveDFS
