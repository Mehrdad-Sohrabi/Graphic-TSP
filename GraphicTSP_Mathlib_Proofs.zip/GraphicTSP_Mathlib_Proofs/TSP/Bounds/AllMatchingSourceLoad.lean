import TSP.Improvements20261105.ActualScoredSourceLoad
import TSP.Improvements20261105.ActualGreedySourceLoad
import TSP.Improvements20261105.GreedySourceUniformTail
import TSP.Improvements20261105.ScoredLargeAnalyticSource
import TSP.Improvements20261105.ProjectedMatchingWeights
import TSP.Improvements20261105.GoodPartitionMassBound
import TSP.Improvements20261105.ScoredUniformNetLoad

/-! Continuous source estimates instantiated with the actual star weights,
fixed incidence charge and original unit-part capacities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_all_matching_source_load_uncouponed
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eligible T : Finset (d).tree.Child) (heligible : ∀ s, ScoredStar d x s → s ∈ eligible)
    (s : (d).tree.Child) (hsM : s ∈ C.matching)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      24*survivingExcess d x s+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  have hl := C.link_subset hsM
  have hpositive := projectionLink_source_positive d hs x z hx hn hm s hl
  have hout := C.source_excess s hsM
  by_cases hsc : ScoredStar d x s
  · by_cases hn18 : ((d).backGroup s).card ≤ 18
    · exact scoredDFS_small_scored_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx htree hm
        eligible T s hsc (heligible s hsc) hpositive hout.le hn18 bad hbad hgood δ hδ0 hδ
    · have hh := scoredDFS_large_scored_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx hm
        eligible T s hsc hpositive (by omega) δ hδ0 hδ
      have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg _
      linarith only [hh,hb]
  · by_cases hn19 : ((d).backGroup s).card ≤ 19
    · exact scoredDFS_small_greedy_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx htree hm
        eligible T s (Finset.mem_filter.mp hl).2.1 hsc hpositive hn19 bad hbad hgood δ hδ0 hδ
    · have hh := scoredDFS_large_greedy_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx hm
        eligible T s hsc hpositive (by omega) δ hδ0 hδ
      have hb : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg _
      linarith only [hh,hb]

theorem scoredDFS_all_matching_source_load
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eligible T : Finset (d).tree.Child) (heligible : ∀ s, ScoredStar d x s → s ∈ eligible)
    (s : (d).tree.Child) (hsM : s ∈ C.matching)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  have hu := scoredDFS_all_matching_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx htree hm C
    eligible T heligible s hsM bad hbad hgood δ hδ0 hδ
  have hl := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun c => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz c) s
  have hp := projectionLink_source_positive d hs x z hx hn hm s (C.link_subset hsM)
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  linarith only [hu,hl,he]

end TSP.Improvements20261105
