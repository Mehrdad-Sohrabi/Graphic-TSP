import TSP.Improvements20261105.HighQGroupOwnership

/-! Distinct actual owners sum their local payments over disjoint stars. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem highQGroup_sum_bound (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (F : Finset d.tree.Child) (hF : ∀ s ∈ F, HighQGroupOwner d x z C s)
    (cost : d.StarIndex → ℝ)
    (hloc : ∀ s ∈ F, (∑ i ∈ highQGroupStars d x z C s, cost i) ≤
      4*(∑ i ∈ highQGroupStars d x z C s, ((d.backGroup i.1).card:ℝ))) :
    (∑ i ∈ F.biUnion (highQGroupStars d x z C), cost i) ≤
      4*(∑ i ∈ F.biUnion (highQGroupStars d x z C), ((d.backGroup i.1).card:ℝ)) := by
  have hd := fun s hs t ht hne => highQGroupStars_disjoint d x z C s t (hF s hs) (hF t ht) hne
  rw [Finset.sum_biUnion hd,Finset.sum_biUnion hd,Finset.mul_sum]
  exact Finset.sum_le_sum hloc

end TSP.Improvements20261105
