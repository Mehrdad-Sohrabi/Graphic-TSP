import TSP.Improvements20261105.LeafErrorOwners
import TSP.Improvements20261105.ZeroLeafGeometricPayment

/-! Entering deficits share one budget per outside center. At unary
centers there is only one incoming leaf direction, so its conservative
guard error also spends that center's excess at most once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem child_parent_fiber_sum (C : Finset d.tree.Child) (f : d.tree.Child → ℝ) :
    (∑ u ∈ C.image (fun c : d.tree.Child => d.tree.parent c),
      ∑ c ∈ C.filter (fun c : d.tree.Child => d.tree.parent c = u), f c) = ∑ c ∈ C, f c := by
  simp only [Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c hc
  simp [Finset.mem_image_of_mem (fun c : d.tree.Child => d.tree.parent c) hc]

theorem GatedDrops.entering_subset_error_budget (hs : G.IsSimple)
    (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (C : Finset d.tree.Child)
    (hC : ∀ c ∈ C, expandedConnectorChild d c ∈ a.trueCuts d P) :
    (∑ c ∈ C, (enteringStarDeficit d x c+
      if childCount d (d.tree.parent c) = 1 then degreeExcess G x (d.tree.parent c) else 0)) ≤
      2*(∑ u ∈ a.enteringConnectorCenters d P, degreeExcess G x u) := by
  let U := C.image (fun c : d.tree.Child => d.tree.parent c)
  have hsub : U ⊆ a.enteringConnectorCenters d P := by
    intro u hu
    obtain ⟨c, hc, rfl⟩ := Finset.mem_image.mp hu
    exact Finset.mem_image.mpr ⟨c, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hC c hc⟩, rfl⟩
  have hfiber (u : V) (hu : u ∈ U) :
      (∑ c ∈ C.filter (fun c : d.tree.Child => d.tree.parent c = u),
        (enteringStarDeficit d x c+if childCount d (d.tree.parent c) = 1 then degreeExcess G x (d.tree.parent c) else 0)) ≤
          2*degreeExcess G x u := by
    have hcsub : C.filter (fun c : d.tree.Child => d.tree.parent c = u) ⊆ childSet d u := by
      intro c hc
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hc).2⟩
    have hk := a.entering_center_deficit_payment d hs P x hx u (hsub hu)
    have hk' : (∑ c ∈ C.filter (fun c : d.tree.Child => d.tree.parent c = u), enteringStarDeficit d x c) ≤ degreeExcess G x u := by
      apply le_trans (Finset.sum_le_sum_of_subset_of_nonneg hcsub (fun c _ _ => le_max_right _ _))
      exact hk
    have he := degreeExcess_nonnegative G hx hn u
    have huni : (∑ c ∈ C.filter (fun c : d.tree.Child => d.tree.parent c = u),
        if childCount d (d.tree.parent c) = 1 then degreeExcess G x (d.tree.parent c) else 0) ≤ degreeExcess G x u := by
      have hloc (c : d.tree.Child) (hc : c ∈ C.filter (fun c : d.tree.Child => d.tree.parent c = u)) :
          (if childCount d (d.tree.parent c) = 1 then degreeExcess G x (d.tree.parent c) else 0) =
          (if childCount d u = 1 then degreeExcess G x u else 0) := by
        rw [(Finset.mem_filter.mp hc).2]
      rw [Finset.sum_congr rfl hloc]
      by_cases hu1 : childCount d u = 1
      · rw [if_pos hu1]
        have hh := Finset.sum_le_sum_of_subset_of_nonneg (f := fun _ : d.tree.Child => degreeExcess G x u)
          hcsub (fun _ _ _ => he)
        have hc1 : (childSet d u).card = 1 := hu1
        simpa only [Finset.sum_const, hc1, Nat.cast_one, nsmul_eq_mul, one_mul] using hh
      · simp only [if_neg hu1, Finset.sum_const_zero]
        exact he
    rw [Finset.sum_add_distrib]
    linarith
  have hsum := Finset.sum_le_sum hfiber
  rw [child_parent_fiber_sum, ← Finset.mul_sum] at hsum
  have htotal := Finset.sum_le_sum_of_subset_of_nonneg hsub
    (fun u _ _ => degreeExcess_nonnegative G hx hn u)
  linarith

end TSP.Improvements20261105
