import TSP.Improvements20261105.GatedBypassPayment
import TSP.Improvements20261105.DisjointCoverageReserve

/-! A bounded branch coupon is paid either by its actual dependency mass
or its penalty. Only an active prefix may use a connector deficit. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators

theorem bounded_gate_switch_payment (k : ℤ) (hk : 0 ≤ k) (b F : ℝ) (hb : b ≤ 1) (hF : 0 ≤ F) :
    b ≤ (k : ℝ) * F + 2 * (max (1-k) 0 : ℤ) + (if 0 < k then max (1-F) 0 else 0) := by
  by_cases h : 0 < k
  · have hkR : (1 : ℝ) ≤ k := by exact_mod_cast (show 1 ≤ k by omega)
    have hpR : (0 : ℝ) ≤ (max (1-k) 0 : ℤ) := by exact_mod_cast le_max_right _ _
    have hd := le_max_left (1-F) 0
    rw [if_pos h]
    nlinarith
  · have hk0 : k = 0 := by omega
    subst k
    norm_num
    linarith

theorem bounded_outside_switch_payment (k l : ℤ) (hk : 0 ≤ k) (hl : 0 ≤ l)
    (b A F : ℝ) (hb : b ≤ 1) (hbA : b ≤ A) (hA : 0 ≤ A) (hF : 0 ≤ F) :
    b ≤ (k : ℝ) * A + (l : ℝ) * F + 2 * (max (1-k-l) 0 : ℤ) +
      (if 0 < l then max (1-F) 0 else 0) := by
  by_cases h : 0 < k
  · have hkR : (1 : ℝ) ≤ k := by exact_mod_cast (show 1 ≤ k by omega)
    have hlR : (0 : ℝ) ≤ l := by exact_mod_cast hl
    have hpR : (0 : ℝ) ≤ (max (1-k-l) 0 : ℤ) := by exact_mod_cast le_max_right _ _
    have hd : (0 : ℝ) ≤ if 0 < l then max (1-F) 0 else 0 := by split_ifs <;> positivity
    nlinarith
  · have hk0 : k = 0 := by omega
    subst k
    simpa using bounded_gate_switch_payment l hl b F hb hF

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.donorDeficit (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (s : d.tree.Child) : ℝ :=
  if P.UsesGate d s ∧ 0 < a.pref (P.receiver s) then max (1 - gateBackMass d x (P.receiver s)) 0 else 0

noncomputable def payableCoupon (P : GatePlan d) (x : BackEdge d → ℝ)
    (b : d.tree.Child → ℝ) (s : d.tree.Child) : ℝ :=
  match P.kind s with
  | .disabled => 0
  | .outgoing => min (b s) (tailBackMass d x s)
  | _ => b s

theorem GatedDrops.donorDeficit_nonneg (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (s : d.tree.Child) : 0 ≤ a.donorDeficit d P x s := by
  unfold donorDeficit
  split_ifs <;> positivity

theorem selected_coupon_payment {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P)
    (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) (b : d.tree.Child → ℝ)
    (s : d.tree.Child) (hsel : a.head s = 1) (hrep : a.representative s = 0)
    (hcap : b s ≤ 1) (houtside : P.kind s = .outsideGate → b s ≤ outsideBackMass d P x s) :
    payableCoupon d P x b s ≤ a.donorResource d P x s + 2 * (a.penalty d P s : ℝ) +
      a.donorDeficit d P x s := by
  have hres := a.donorResource_nonneg d ha x hx s
  have ho := tailBackMass_nonneg d x hx (s : V)
  have hF := gateBackMass_nonneg d x hx (P.receiver s)
  have hA := outsideBackMass_nonneg d P x hx s
  have ht : (0 : ℝ) ≤ a.tail s := by exact_mod_cast ha.tail_nonneg _
  have hp : (0 : ℝ) ≤ a.pref (P.receiver s) := by exact_mod_cast ha.pref_nonneg _
  have hout : (0 : ℝ) ≤ a.outside s := by exact_mod_cast ha.outside_nonneg _
  have hdef := a.donorDeficit_nonneg d P x s
  cases hk : P.kind s with
  | disabled =>
    simp only [payableCoupon, GatedDrops.penalty, hk]
    norm_num
    linarith
  | outgoing =>
    have h := selected_bypass_payment d ha x hx s hsel hrep
    have hm : min (b s) (tailBackMass d x s) ≤ min (tailBackMass d x s) 2 :=
      le_min (min_le_right _ _) ((min_le_left _ _).trans (by linarith))
    simp only [bypassMassClaim, payableCoupon, hk] at *
    linarith
  | twoDirections =>
    simp only [payableCoupon, GatedDrops.penalty, hk, hsel, hrep]
    norm_num
    linarith
  | sharedGate =>
    have h := bounded_gate_switch_payment (a.pref (P.receiver s)) (ha.pref_nonneg _) (b s) _ hcap hF
    have hpi : (max (1-a.pref (P.receiver s)) 0 : ℤ) ≤ max (max (1-a.tail s) (1-a.pref (P.receiver s))) 0 :=
      max_le_max (le_max_right _ _) le_rfl
    have hpiR : ((max (1-a.pref (P.receiver s)) 0 : ℤ) : ℝ) ≤
        (max (max (1-a.tail s) (1-a.pref (P.receiver s))) 0 : ℤ) := by exact_mod_cast hpi
    rw [a.donorResource_formula]
    simp only [payableCoupon, GatedDrops.penalty, GatedDrops.donorDeficit, hk, hsel, hrep,
      sub_zero, GatePlan.UsesGate, true_or, if_true, true_and]
    nlinarith
  | outsideGate =>
    have h := bounded_outside_switch_payment (a.outside s) (a.pref (P.receiver s))
      (ha.outside_nonneg _) (ha.pref_nonneg _) (b s) _ _ hcap (houtside hk) hA hF
    rw [a.donorResource_formula]
    simp only [payableCoupon, GatedDrops.penalty, GatedDrops.donorDeficit, hk, hsel, hrep,
      sub_zero, GatePlan.UsesGate, or_true, if_true, true_and]
    nlinarith

theorem GatedDrops.donorDeficit_sum (P : GatePlan d) (hP : P.RespectsTree d) (a : GatedDrops d)
    (x : E → ℝ) :
    (∑ s : d.tree.Child, a.donorDeficit d P (fun b => x b.1) s) = a.activeGateDeficit d P x := by
  have h := gate_owner_sum d P hP (fun r => if 0 < a.pref r then max (1 - edgeSum x (deletedSubtreeCut d r)) 0 else 0)
  unfold donorDeficit activeGateDeficit
  simp_rw [gateBackMass_original]
  calc
    _ = ∑ s : d.tree.Child, if P.UsesGate d s then
        (if 0 < a.pref (P.receiver s) then max (1 - edgeSum x (deletedSubtreeCut d (P.receiver s))) 0 else 0) else 0 := by
      apply Finset.sum_congr rfl
      intro s _
      by_cases h1 : P.UsesGate d s <;> by_cases h2 : 0 < a.pref (P.receiver s) <;> simp [h1, h2]
    _ = _ := h
    _ = _ := by
      apply Finset.sum_congr rfl
      intro s _
      by_cases h1 : P.IsReceiver d s <;> by_cases h2 : 0 < a.pref s <;> simp [ActiveGate, h1, h2]

end TSP.Improvements20261105
