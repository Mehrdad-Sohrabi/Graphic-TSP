import TSP.Improvements20261105.BinaryRepairPoint
import TSP.Chapter10.RepairProjection

/-! Apply the simultaneous binary cut theorem to the actual expanded DFS
graph and project away inactive star vertices. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def OriginalBypassWitness (B : Finset E) (v : d.tree.Child) : Prop :=
  (∃ b ∈ B, d.lower b = (v : V)) ∨
  (∃ c₁ c₂ : d.tree.Child, c₁ ≠ c₂ ∧ d.tree.parent c₁ = (v : V) ∧
    d.tree.parent c₂ = (v : V) ∧
    (∃ b ∈ B, d.tree.Ancestor c₁ (d.lower b) ∧ d.tree.depth (d.upper b) < d.tree.depth v) ∧
    (∃ b ∈ B, d.tree.Ancestor c₂ (d.lower b) ∧ d.tree.depth (d.upper b) < d.tree.depth v))

noncomputable def expandedChosenBacks (B : Finset E) : Finset (E ⊕ d.tree.Child) :=
  B.map Function.Embedding.inl

noncomputable def expandedDeletedReps (R : Finset d.tree.Child) : Finset (expandedTree d).Child :=
  R.image (originalNode d)

noncomputable def expandedBinaryPoint (B : Finset E) (R : Finset d.tree.Child) :
    (E ⊕ d.tree.Child) → ℝ :=
  binaryRepairPoint (binaryRetained (expandedDFS d) (expandedChosenBacks d B) (expandedDeletedReps d R))

theorem expandedChosenBacks_subset (B : Finset E) (hB : B ⊆ d.backEdges) :
    expandedChosenBacks d B ⊆ (expandedDFS d).backEdges := by
  intro e he
  refine Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, ?_⟩
  intro ht
  obtain ⟨w, _, heq⟩ := Finset.mem_image.mp ht
  apply expanded_tree_edge_not_back_map d w B hB
  change (expandedDFS d).treeEdge w ∈ expandedChosenBacks d B
  rw [heq]
  exact he

theorem expanded_ownReturn (v : d.tree.Child) (b : E) (hb : b ∈ d.backGroup v) :
    OwnReturn (expandedDFS d) (originalNode d v) (Sum.inl b) := by
  have hg := (Finset.mem_sdiff.mp hb).1
  have ha := (d.mem_group v b).mp hg
  have hl := ((d.mem_group_iff v b).mp hg).2
  constructor
  · change Sum.inr (d.anchor b) = (expandedTree d).parent (Sum.inl (v : V))
    simp [expandedTree, expandedParent, ha, v.2]
  · exact expanded_original_ancestor d hl

theorem expanded_return_covers (v : d.tree.Child) (b : E)
    (hl : d.tree.Ancestor v (d.lower b))
    (hu : d.tree.depth (d.upper b) < d.tree.depth v) :
    BackCovers (expandedDFS d) (Sum.inl b) (originalNode d v) :=
  ⟨expanded_original_ancestor d hl, anchor_shallower_of_upper_depth d b v hu⟩

theorem original_bypass_lifts (B : Finset E) (v : d.tree.Child)
    (hw : OriginalBypassWitness d B v) :
    BypassWitness (expandedDFS d) (expandedChosenBacks d B) (originalNode d v) := by
  rcases hw with ⟨b, hb, hl⟩ | ⟨c₁, c₂, hne, hp₁, hp₂, h₁, h₂⟩
  · left
    refine ⟨Sum.inl b, Finset.mem_map.mpr ⟨b, hb, rfl⟩, ?_, ?_⟩
    · refine ⟨?_, outgoing_anchor_shallower d v hl⟩
      change (expandedTree d).Ancestor (Sum.inl (v : V)) (Sum.inl (d.lower b))
      rw [hl]
      exact .refl
    · change Sum.inl (d.lower b) = Sum.inl (v : V)
      rw [hl]
  · right
    refine ⟨auxiliaryNode d c₁, auxiliaryNode d c₂, ?_, ?_, ?_, ?_, ?_⟩
    · intro heq
      have hh := congrArg Subtype.val heq
      exact hne (Sum.inr.inj hh)
    · change Sum.inl (d.tree.parent c₁) = Sum.inl (v : V)
      rw [hp₁]
    · change Sum.inl (d.tree.parent c₂) = Sum.inl (v : V)
      rw [hp₂]
    · obtain ⟨b, hb, hl, hu⟩ := h₁
      refine ⟨Sum.inl b, Finset.mem_map.mpr ⟨b, hb, rfl⟩, ?_, expanded_auxiliary_ancestor d c₁ hl⟩
      apply expanded_return_covers d v b _ hu
      exact hl.trans (Relation.ReflTransGen.single ⟨c₁.2, hp₁⟩)
    · obtain ⟨b, hb, hl, hu⟩ := h₂
      refine ⟨Sum.inl b, Finset.mem_map.mpr ⟨b, hb, rfl⟩, ?_, expanded_auxiliary_ancestor d c₂ hl⟩
      apply expanded_return_covers d v b _ hu
      exact hl.trans (Relation.ReflTransGen.single ⟨c₂.2, hp₂⟩)

theorem expandedBinaryPoint_feasible (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child)
    (hown : ∀ v ∈ R, 2 ≤ (B ∩ d.backGroup v).card)
    (hwitness : ∀ v ∈ R, OriginalBypassWitness d B v) :
    expandedBinaryPoint d B R ∈ joinPolytope (allGroupGraph d)
      ((allGroupGraph d).oddVertices Finset.univ) ((allGroupGraph d).intDegree Finset.univ) := by
  apply bypassed_binary_point_feasible (expandedDFS d) _ (expandedChosenBacks_subset d B hB)
  · intro w hw
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hw
    have hc := hown v hv
    obtain ⟨b₁, hb₁, b₂, hb₂, hne⟩ := Finset.one_lt_card.mp (by omega : 1 < (B ∩ d.backGroup v).card)
    refine ⟨Sum.inl b₁, Finset.mem_map.mpr ⟨b₁, (Finset.mem_inter.mp hb₁).1, rfl⟩,
      Sum.inl b₂, Finset.mem_map.mpr ⟨b₂, (Finset.mem_inter.mp hb₂).1, rfl⟩,
      fun h => hne (Sum.inl.inj h), expanded_ownReturn d v b₁ (Finset.mem_inter.mp hb₁).2,
      expanded_ownReturn d v b₂ (Finset.mem_inter.mp hb₂).2⟩
  · intro w hw
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hw
    exact original_bypass_lifts d B v (hwitness v hv)

noncomputable def binaryNonloopPoint (B : Finset E) (R : Finset d.tree.Child) :
    (E ⊕ d.StarIndex) → ℝ :=
  restrictStarsVector (fun v : d.tree.Child => (d.backGroup v).Nonempty) (expandedBinaryPoint d B R)

theorem binaryNonloopPoint_feasible (hsimple : G.IsSimple)
    (owner : E → Option d.StarIndex) (howner : ValidOwner d.stars owner)
    (B : Finset E) (hB : B ⊆ d.backEdges) (R : Finset d.tree.Child)
    (hown : ∀ v ∈ R, 2 ≤ (B ∩ d.backGroup v).card)
    (hwitness : ∀ v ∈ R, OriginalBypassWitness d B v) :
    binaryNonloopPoint d B R ∈ projectedFrameworkTwo G d.centers owner := by
  have hfull := expandedBinaryPoint_feasible d B hB R hown hwitness
  have hproject := restricted_star_join_polytope (fun v : d.tree.Child => (d.backGroup v).Nonempty)
    G d.group (fun v => d.tree.parent v) (allGroupOwner d) owner hsimple.1
    (fun v e he => d.group_incident v e he) (allGroupOwner_valid d) howner
  rw [projectedFrameworkTwo_eq_oddJoinPolytope]
  change binaryNonloopPoint d B R ∈
    joinPolytope (auxiliaryGraph G (fun i : d.StarIndex => d.tree.parent i.1) owner)
      ((auxiliaryGraph G (fun i : d.StarIndex => d.tree.parent i.1) owner).oddVertices Finset.univ)
      ((auxiliaryGraph G (fun i : d.StarIndex => d.tree.parent i.1) owner).intDegree Finset.univ)
  rw [← hproject]
  exact ⟨expandedBinaryPoint d B R, hfull, rfl⟩

end TSP.Improvements20261105
