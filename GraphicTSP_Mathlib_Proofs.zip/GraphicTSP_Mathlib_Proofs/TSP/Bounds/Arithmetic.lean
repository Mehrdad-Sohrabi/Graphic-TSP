import Mathlib.Tactic

/-! Exact arithmetic in the recovered improvements. These scalar statements
are separate from the still-required graph constructions and coverage proofs. -/
namespace TSP.Improvements20261105

/-- The old and new quartic certificate bounds interpolate with weights 2/7,5/7. -/
theorem quartic_envelope {n delta bound : ℝ}
    (hold : bound ≤ 13 / 10 * n - 7 / 10 - delta / 20)
    (hnew : bound ≤ 32 / 25 * n - 8 / 25 + delta / 50) :
    bound ≤ (9 * n - 3) / 7 := by
  linarith

theorem quartic_rho_envelope {n rho bound : ℝ}
    (hold : bound ≤ 5 / 4 * n - 1 / 2 + rho / 4)
    (hnew : bound ≤ 13 / 10 * n - 2 / 5 - rho / 10) :
    bound ≤ (9 * n - 3) / 7 := by
  linarith

theorem quartic_new_cost_bound {n delta f sigma c d a1 t bound : ℝ}
    (hf : 0 ≤ f) (hsigma : 0 ≤ sigma) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (ha1 : 0 ≤ a1) (ht : 0 ≤ t)
    (hdelta : 3 * f + 2 * sigma + 2 * c + 4 * d + a1 ≤ delta)
    (hbound : bound ≤ 32 / 25 * n - 8 / 25 + 3 / 50 * f + 1 / 25 * sigma +
      1 / 25 * c + 2 / 25 * d + 1 / 50 * a1 - 1 / 5 * t) :
    bound ≤ 32 / 25 * n - 8 / 25 + delta / 50 := by
  linarith

/-- Substitution into the physical identity in general_value_transport_post_near.md. -/
theorem general_block_normalization {n L A bound : ℝ}
    (hrole : A ≤ 4 * (n - 3) + (3279 / 5) * (L - n))
    (hphysical : (10481 / 30) * bound ≤
      (4 * (10481 / 30) / 3 + (704 / 5) / 9) * n +
      (704 / 5) * (L - n) / 3 -
      2 * ((415 / 2) + (704 / 5) + 2 * 24) / 3 + (2 / 3) * A) :
    bound ≤ (14524 * L - 8166) / 10481 := by
  linarith

theorem improved_ratio_lt_manuscript :
    (14524 / 10481 : ℝ) < 89 / 64 := by norm_num

theorem improved_quartic_ratio_lt_manuscript :
    (9 / 7 : ℝ) < 13 / 10 := by norm_num

/-- All 72 transported certificate scopes need at least this exact extra margin. -/
theorem transported_pair_debit :
    (2 * (1 / 2) + (1 / 19) * (4 * (100 / 57) - 2 + 1 / 10 + 9 / 20) : ℝ) =
      28007 / 21660 := by norm_num

theorem transported_pair_margin_positive :
    (0 : ℝ) < 16937876 / 11561025 := by norm_num

end TSP.Improvements20261105
