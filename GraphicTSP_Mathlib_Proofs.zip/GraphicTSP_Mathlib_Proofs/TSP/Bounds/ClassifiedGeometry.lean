import TSP.Improvements20261105.UnclassifiedProjection
import TSP.Chapter10.LPRepairCost

/-! The classified center and its unique heavy star are determined by the
actual capped vector, before any point or load selector is chosen. -/
namespace TSP.Improvements20261105
open Graph Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def classifiedHead {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (u : V) (hu : ClassifiedCenter d x u) : d.tree.Child := Classical.choose hu

theorem classifiedHead_spec {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (u : V) (hu : ClassifiedCenter d x u) :
    d.tree.parent (classifiedHead d x u hu) = u ∧
      edgeSum x (G.cut {u}) - edgeSum x (d.group (classifiedHead d x u hu)) < 1 := by
  have hh := Classical.choose_spec hu
  exact ⟨(Finset.mem_filter.mp hh.1).2, hh.2⟩

theorem classified_head_unique {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (u : V) (v w : d.tree.Child) (hv : d.tree.parent v = u) (hw : d.tree.parent w = u)
    (hvheavy : edgeSum x (G.cut {u}) - edgeSum x (d.group v) < 1)
    (hwheavy : edgeSum x (G.cut {u}) - edgeSum x (d.group w) < 1) : v = w := by
  by_contra hne
  have hsub : d.group v ∪ d.group w ⊆ G.cut {u} := by
    intro e he
    rcases Finset.mem_union.mp he with he | he
    · simpa [hv] using group_subset_center_cut d hsimple v he
    · simpa [hw] using group_subset_center_cut d hsimple w he
  have hsum : edgeSum x (d.group v) + edgeSum x (d.group w) ≤ edgeSum x (G.cut {u}) := by
    simp only [edgeSum]
    rw [← Finset.sum_union (d.groups_disjoint v w hne)]
    exact Finset.sum_le_sum_of_subset_of_nonneg hsub (fun e _ _ => hx.1 e)
  have hdeg := degreeExcess_nonnegative G hx hn u
  unfold degreeExcess at hdeg
  linarith

theorem classified_head_back_nonempty {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) (u : V) (hu : ClassifiedCenter d x u) :
    (d.backGroup (classifiedHead d x u hu)).Nonempty := by
  have hh := classifiedHead_spec d x u hu
  have hdeg := degreeExcess_nonnegative G hx hn u
  have hmass := group_mass_eq_tree_add_backs d x (classifiedHead d x u hu)
  have hq := hcap (d.treeEdge (classifiedHead d x u hu))
  by_contra hnone
  have he := Finset.not_nonempty_iff_eq_empty.mp hnone
  rw [he] at hmass
  simp only [edgeSum, Finset.sum_empty, add_zero] at hmass
  change edgeSum x (d.group (classifiedHead d x u hu)) = x (d.treeEdge (classifiedHead d x u hu)) at hmass
  unfold degreeExcess at hdeg
  linarith

noncomputable def classifiedStar {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) (u : V) (hu : ClassifiedCenter d x u) : d.StarIndex :=
  ⟨classifiedHead d x u hu, classified_head_back_nonempty d hx hn hcap u hu⟩

noncomputable def minorBoundary {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (u : V) : Finset E :=
  if hu : ClassifiedCenter d x u then G.cut {u} \ d.group (classifiedHead d x u hu) else ∅

theorem minorBoundary_subset_cut {G : Graph V E} (d : DFSData G) (x : E → ℝ) (u : V) :
    minorBoundary d x u ⊆ G.cut {u} := by
  unfold minorBoundary
  split_ifs
  · exact Finset.sdiff_subset
  · exact Finset.empty_subset _

theorem minorBoundary_mass {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (u : V) (hu : ClassifiedCenter d x u) :
    edgeSum x (minorBoundary d x u) =
      edgeSum x (G.cut {u}) - edgeSum x (d.group (classifiedHead d x u hu)) := by
  have hh := classifiedHead_spec d x u hu
  have hsub : d.group (classifiedHead d x u hu) ⊆ G.cut {u} := by
    simpa only [hh.1] using group_subset_center_cut d hsimple (classifiedHead d x u hu)
  have hs := Finset.sum_sdiff (f := x) hsub
  rw [minorBoundary, dif_pos hu]
  change edgeSum x (G.cut {u} \ d.group (classifiedHead d x u hu)) = _
  change edgeSum x (G.cut {u} \ d.group (classifiedHead d x u hu)) +
    edgeSum x (d.group (classifiedHead d x u hu)) = edgeSum x (G.cut {u}) at hs
  linarith

theorem minorBoundary_mass_lt_one {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (u : V) : edgeSum x (minorBoundary d x u) < 1 := by
  by_cases hu : ClassifiedCenter d x u
  · rw [minorBoundary_mass d hsimple x u hu]
    exact (classifiedHead_spec d x u hu).2
  · simp [minorBoundary, hu, edgeSum]

theorem light_group_subset_minorBoundary {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) (x : E → ℝ) (u : V) (hu : ClassifiedCenter d x u)
    (w : d.tree.Child) (hw : d.tree.parent w = u) (hne : w ≠ classifiedHead d x u hu) :
    d.group w ⊆ minorBoundary d x u := by
  rw [minorBoundary, dif_pos hu]
  intro e he
  refine Finset.mem_sdiff.mpr ⟨?_, ?_⟩
  · simpa [hw] using group_subset_center_cut d hsimple w he
  · exact Finset.disjoint_left.mp (d.groups_disjoint w _ hne) he

theorem light_group_mass_lt_one {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : ∀ e, 0 ≤ x e) (u : V) (hu : ClassifiedCenter d x u)
    (w : d.tree.Child) (hw : d.tree.parent w = u) (hne : w ≠ classifiedHead d x u hu) :
    edgeSum x (d.group w) < 1 := by
  apply lt_of_le_of_lt _ (minorBoundary_mass_lt_one d hsimple x u)
  exact Finset.sum_le_sum_of_subset_of_nonneg
    (light_group_subset_minorBoundary d hsimple x u hu w hw hne) (fun e _ _ => hx e)

theorem root_classified {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (hconn : IsTwoVertexConnected G) (x : E → ℝ)
    (i : d.StarIndex) (hi : d.centers i = d.tree.root) :
    ClassifiedCenter d x d.tree.root := by
  refine ⟨i.1, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hi⟩, ?_⟩
  have he := root_star_eq_cut d hsimple hconn i hi
  change d.group i.1 = G.cut {d.tree.root} at he
  rw [he]
  norm_num

end TSP.Improvements20261105
