import TSP.Improvements20261105.FixedProjectionIntegration
import TSP.Improvements20261105.ScoredSuccessorPacking

/-! The small-source half-cardinality inequality follows from actual unit
part capacities. Its good/bad label is the original graph partition label. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter08 Chapter10 Classical
open scoped BigOperators

variable {I : Type} [DecidableEq I]
theorem two_part_card_mass_bound (S F : Finset I) (z : I → ℝ) (M : ℝ) (k : ℕ)
    (hF : F ⊆ S) (hM : 0 ≤ M) (hcap : ∀ i ∈ S, z i ≤ M)
    (hleft : (∑ i ∈ F, z i) ≤ 1) (hright : (∑ i ∈ S \ F, z i) ≤ 1)
    (hcount : S.card ≤ 2*k+1) : (∑ i ∈ S, z i) ≤ 1+(k : ℝ)*M := by
  have hb (A : Finset I) (hA : A ⊆ S) (hk : A.card ≤ k) : (∑ i ∈ A, z i) ≤ (k : ℝ)*M := by
    have hh := Finset.sum_le_sum (s := A) (fun i hi => hcap i (hA hi))
    have hc : (A.card : ℝ) ≤ k := by exact_mod_cast hk
    have hm := mul_le_mul_of_nonneg_right hc hM
    simp only [Finset.sum_const,nsmul_eq_mul] at hh
    linarith only [hh,hm]
  have hid := Finset.sum_sdiff hF (f := z)
  by_cases hl : F.card ≤ k
  · have hh := hb F hF hl
    linarith only [hh,hright,hid]
  · have hc := Finset.card_sdiff_add_card_eq_card hF
    have hh := hb (S \ F) Finset.sdiff_subset (by omega)
    linarith only [hh,hleft,hid]

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem unitPartCapacities_star_even_bound (hs : G.IsSimple) (x z : E → ℝ)
    (hx : ∀ e, 0 ≤ x e) (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z (d.treeEdge s)=x (d.treeEdge s))
    (s : d.tree.Child) (hg : UnitPartCapacities G z (d.tree.parent s)) (k : ℕ)
    (hcount : (d.backGroup s).card=2*k) :
    x (d.treeEdge s)+edgeSum z (d.backGroup s) ≤ 1+(k : ℝ)*starMaximum d x s := by
  obtain ⟨F,hF,hleft,hright⟩ := hg
  let S := d.group s
  have hS : S ⊆ G.cut {d.tree.parent s} := group_subset_center_cut d hs s
  have hM : 0 ≤ starMaximum d x s :=
    (hx (d.treeEdge s)).trans (le_finiteMaximum x ((d.mem_group s _).mpr (d.anchor_treeEdge s)))
  have hcap (e : E) (he : e ∈ S) : z e ≤ starMaximum d x s := (hzx e).trans (le_finiteMaximum x he)
  have hL : edgeSum z (S ∩ F) ≤ 1 :=
    (Finset.sum_le_sum_of_subset_of_nonneg Finset.inter_subset_right (fun e _ _ => hz e)).trans hleft
  have hR : edgeSum z (S \ (S ∩ F)) ≤ 1 := by
    have hsub : S \ (S ∩ F) ⊆ G.cut {d.tree.parent s} \ F := by
      intro e he
      have hh := Finset.mem_sdiff.mp he
      exact Finset.mem_sdiff.mpr ⟨hS hh.1,fun hf => hh.2 (Finset.mem_inter.mpr ⟨hh.1,hf⟩)⟩
    exact (Finset.sum_le_sum_of_subset_of_nonneg hsub (fun e _ _ => hz e)).trans hright
  have hcard : S.card=2*k+1 := by
    change (d.group s).card=_
    rw [d.group_eq_insert_backGroup,Finset.card_insert_of_not_mem (by simp [DFSData.backGroup]),hcount]
  have hh := two_part_card_mass_bound S (S ∩ F) z (starMaximum d x s) k
    Finset.inter_subset_left hM hcap hL hR hcard.le
  change edgeSum z (d.group s) ≤ _ at hh
  rw [group_mass_eq_tree_add_backs,htree] at hh
  exact hh

end TSP.Improvements20261105
