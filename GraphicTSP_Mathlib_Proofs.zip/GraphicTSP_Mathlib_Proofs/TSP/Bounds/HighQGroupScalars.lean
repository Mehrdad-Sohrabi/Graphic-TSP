import Mathlib.Tactic

namespace TSP.Improvements20261105
set_option autoImplicit false

theorem high_q_positive_financing (t q : ℝ) (ht : 0 ≤ t) (hq : 0 ≤ q)
    (hpack : 1 ≤ t*q) :
    (19632/361 : ℝ) ≤ 8+4*t+(704/5)*q := by
  have htpos : 0 < t := by nlinarith
  by_contra h
  have hh : 4*t+(704/5)*q < (19632/361 : ℝ)-8 := by linarith
  have hm := mul_lt_mul_of_pos_right hh htpos
  nlinarith [sq_nonneg (2*t-((19632/361 : ℝ)-8)/4)]

theorem high_q_positive_selector (q h : ℝ) (ns nw : ℤ)
    (hs : ns=0 ∨ ns=1) (hw : nw=0 ∨ nw=1) (hh0 : 0 ≤ h) (hh1 : h ≤ 1/2) :
    -(704/5)*q+60*h*(1-(ns:ℝ)-(nw:ℝ))+(ns:ℝ)*(48+240/361)+
      (nw:ℝ)*(48*h+2064/361) ≤ (19632/361 : ℝ)-(704/5)*q := by
  rcases hs with rfl | rfl <;> rcases hw with rfl | rfl <;> norm_num <;> linarith

theorem high_q_positive_group_scalar (ts tw q h : ℝ) (ns nw : ℤ)
    (hs : ns=0 ∨ ns=1) (hw : nw=0 ∨ nw=1) (hh0 : 0 ≤ h) (hh1 : h ≤ 1/2)
    (hts : 2 ≤ ts) (htw : 0 ≤ tw) (hq : 0 ≤ q) (hpack : 1 ≤ tw*q) :
    -(704/5)*q+60*h*(1-(ns:ℝ)-(nw:ℝ))+(ns:ℝ)*(48+240/361)+
      (nw:ℝ)*(48*h+2064/361) ≤ 4*(ts+tw) := by
  have ha := high_q_positive_selector q h ns nw hs hw hh0 hh1
  have hb := high_q_positive_financing tw q htw hq hpack
  linarith

end TSP.Improvements20261105
