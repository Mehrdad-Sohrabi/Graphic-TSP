import TSP.Chapter10.LaminarCounting

/-! Counting marked leaves and nontight children in the actual laminar tree. -/
namespace TSP.Chapter10.LaminarSystem
open Classical
open scoped BigOperators
variable {V : Type} [Fintype V] [DecidableEq V] (L : LaminarSystem V)

theorem binary_singleton_sibling {A : Finset V} (hA : A ∈ L.family) (hcard : 2 ≤ A.card)
    (hd : (L.children A).card = 2) (v : V) (hv : ({v} : Finset V) ∈ L.children A) :
    A.erase v ∈ L.children A := by
  have hr : ((L.children A).erase {v}).card = 1 := by
    have hh := Finset.card_erase_add_one hv
    omega
  obtain ⟨B, hB⟩ := Finset.card_eq_one.mp hr
  have hb : B ∈ (L.children A).erase {v} := by rw [hB]; simp
  have hbm := (Finset.mem_erase.mp hb).2
  have hne : ({v} : Finset V) ≠ B := Ne.symm (Finset.mem_erase.mp hb).1
  have hdis := L.children_disjoint hv hbm hne
  have hnv : v ∉ B := by simpa using hdis
  have hch : L.children A = insert {v} {B} := by
    rw [← hB, Finset.insert_erase hv]
  have hcover := L.children_cover hA hcard
  rw [hch] at hcover
  have heq : insert v B = A := by simpa using hcover
  have herase : A.erase v = B := by rw [← heq]; simp [hnv]
  rwa [herase]

theorem child_inter_card (A : Finset V) (S : Finset (Finset V)) :
    (L.children A ∩ S).card = ∑ B ∈ S, if B ∈ L.children A then (1 : ℕ) else 0 := by
  rw [← Finset.card_filter]
  congr 1
  ext B
  simp [and_comm]

theorem internal_child_inter_sum (S : Finset (Finset V)) :
    (∑ A ∈ L.internalNodes, (L.children A ∩ S).card) =
      ∑ A ∈ L.family, (L.children A ∩ S).card := by
  rw [internalNodes, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro A hA
  by_cases hi : 2 ≤ A.card
  · exact if_pos hi
  · have hpos := Finset.card_pos.mpr (L.nonempty A hA)
    have hone : A.card = 1 := by omega
    obtain ⟨v, rfl⟩ := Finset.card_eq_one.mp hone
    rw [L.singleton_children_empty]
    simp

theorem child_inter_sum (S : Finset (Finset V)) (hS : S ⊆ L.family) :
    (∑ A ∈ L.internalNodes, (L.children A ∩ S).card) =
      ∑ B ∈ S, if B = L.top then (0 : ℕ) else 1 := by
  rw [L.internal_child_inter_sum]
  simp_rw [L.child_inter_card]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl (fun B hB => L.parent_indicator_sum (hS hB))

theorem child_inter_sum_le (S : Finset (Finset V)) (hS : S ⊆ L.family) :
    (∑ A ∈ L.internalNodes, (L.children A ∩ S).card) ≤ S.card := by
  rw [L.child_inter_sum S hS]
  calc
    _ ≤ ∑ _B ∈ S, (1 : ℕ) := Finset.sum_le_sum (fun B _ => by split_ifs <;> omega)
    _ = S.card := by simp

theorem child_inter_sum_eq (S : Finset (Finset V)) (hS : S ⊆ L.family)
    (htop : L.top ∉ S) : (∑ A ∈ L.internalNodes, (L.children A ∩ S).card) = S.card := by
  rw [L.child_inter_sum S hS]
  have hh : ∀ B ∈ S, B ≠ L.top := by intro B hB he; subst B; exact htop hB
  simp only [Finset.sum_congr rfl (fun B hB => if_neg (hh B hB)), Finset.sum_const,
    nsmul_eq_mul, mul_one]
  simp

theorem marked_bound_of_local (M S : Finset (Finset V)) (hM : M ⊆ L.family)
    (hS : S ⊆ L.family) (htop : L.top ∉ M)
    (hlocal : ∀ A ∈ L.internalNodes,
      (L.children A ∩ M).card ≤ 2 * ((L.children A).card - 2) + (L.children A ∩ S).card) :
    M.card ≤ 2 * L.deficiency + S.card := by
  have hs := Finset.sum_le_sum hlocal
  rw [L.child_inter_sum_eq M hM htop, Finset.sum_add_distrib, ← Finset.mul_sum] at hs
  have hslack := L.child_inter_sum_le S hS
  change M.card ≤ 2 * L.deficiency + _ at hs
  omega

end TSP.Chapter10.LaminarSystem
