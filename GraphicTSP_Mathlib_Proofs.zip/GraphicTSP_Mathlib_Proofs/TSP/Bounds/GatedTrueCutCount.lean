import TSP.Improvements20261105.GatedTrueCuts

/-! The lower-bound reward equals the number of actual deleted tree
edges. This uses the graph-derived binary drop bounds. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem root_group_nonempty (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (v : d.tree.Child) (hv : d.tree.parent v = d.tree.root) : (d.backGroup v).Nonempty := by
  obtain ⟨s, hsroot, _⟩ := root_star_exists d hc (twoVertexConnected_min_degree G hs hc _)
  have he := root_children_unique d hc v s.1 hv hsroot
  rw [he]
  exact s.2

theorem GatedDrops.trueRoleWeight_binary (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P)
    (w : d.tree.Child ⊕ d.tree.Child) : a.trueRoleWeight d P w = 0 ∨ a.trueRoleWeight d P w = 1 := by
  have hp := a.potential_feasible d P ha
  cases w with
  | inl v =>
    by_cases hroot : d.tree.parent v = d.tree.root
    · simp [trueRoleWeight, hroot]
    · have hh := gated_nonroot_split_drop_bounds d hs hc hp v hroot
      simp only [GatedDrops.potential_prefix, GatedDrops.potential_suffix,
        GatedDrops.potential_representative] at hh
      by_cases hr : P.IsReceiver d v <;> simp only [trueRoleWeight, if_neg hroot, hr, if_true, if_false] <;> omega
  | inr v =>
    by_cases hactive : (d.backGroup v).Nonempty
    · simp [trueRoleWeight, hactive]
    · have hroot : d.tree.parent v ≠ d.tree.root := fun h => hactive (root_group_nonempty d hs hc v h)
      have hh := gated_nonroot_split_drop_bounds d hs hc hp v hroot
      simp only [GatedDrops.potential_prefix, GatedDrops.potential_suffix,
        GatedDrops.potential_representative] at hh
      simp only [trueRoleWeight, if_neg hactive]
      omega

theorem GatedDrops.trueCutWeight_binary (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P)
    (w : (expandedTree d).Child) : a.trueCutWeight d P w = 0 ∨ a.trueCutWeight d P w = 1 :=
  a.trueRoleWeight_binary d hs hc ha _

theorem GatedDrops.trueCuts_reward_card (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P) :
    (∑ v : d.tree.Child, a.reward d P v) = ((a.trueCuts d P).card : ℤ) := by
  have he : (∑ w : (expandedTree d).Child, a.trueCutWeight d P w) =
      ∑ w : d.tree.Child ⊕ d.tree.Child, a.trueRoleWeight d P w := by
    rw [← (expandedTreeRoles d).sum_comp]
    simp [trueCutWeight]
  rw [← a.trueRoleWeight_reward, ← he]
  calc
    _ = ∑ w : (expandedTree d).Child, if w ∈ a.trueCuts d P then (1 : ℤ) else 0 := by
      apply Finset.sum_congr rfl
      intro w _
      rcases a.trueCutWeight_binary d hs hc ha w with hz | hz <;> simp [trueCuts, hz]
    _ = _ := by simp

theorem GatedDrops.true_component_count (P : GatePlan d) (a : GatedDrops d) :
    Fintype.card ((expandedTree d).CutComponent (a.trueCuts d P)) = (a.trueCuts d P).card + 1 :=
  (expandedTree d).cutComponent_card (a.trueCuts d P)

end TSP.Improvements20261105
