import TSP.Improvements20261105.GatedProjection

/-! Local balances in the actual directed gated network. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 1000000
open Graph Chapter05 Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

@[simp] theorem bypassSource_ne_aux (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassSource d P s ≠ gatedAux d v := by
  unfold gatedBypassSource
  split_ifs <;> simp

@[simp] theorem bypassTarget_ne_aux (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassTarget d P s ≠ gatedAux d v := by
  cases hk : P.kind s <;> simp [gatedBypassTarget, hk]

@[simp] theorem bypassSource_ne_collector (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassSource d P s ≠ gatedCollector d v := by
  unfold gatedBypassSource
  split_ifs <;> simp

@[simp] theorem bypassTarget_collector_iff (P : GatePlan d) (s v : d.tree.Child) :
    gatedBypassTarget d P s = gatedCollector d v ↔ P.kind s = .sharedGate ∧ s = v := by
  cases hk : P.kind s <;> simp [gatedBypassTarget, hk]

theorem gated_balance_aux (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) (v : d.tree.Child) :
    f (gatedRepArc d v) + f (gatedReverseArc d v) =
      f (gatedSuffixArc d v) + f (gatedFreeArc d v) := by
  have hh := hf (gatedAux d v)
  simpa [arcSum, gatedNetwork, gatedExtraSrc, gatedExtraDst, Fintype.sum_sum_type,
    Fintype.sum_prod_type, Fin.sum_univ_succ, ite_eq_iff] using hh

theorem gated_balance_collector (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) (v : d.tree.Child) :
    f (gatedExitTailArc d v) + f (gatedExitGateArc d v) =
      if P.kind v = .sharedGate then f (gatedBypassArc d v) else 0 := by
  have hh := hf (gatedCollector d v)
  simp [arcSum, gatedNetwork, gatedExtraSrc, gatedExtraDst, Fintype.sum_sum_type,
    Fintype.sum_prod_type, Fin.sum_univ_succ, ite_eq_iff, ite_and, Finset.sum_add_distrib,
    add_assoc, add_comm, add_left_comm] at hh
  rw [Finset.sum_eq_single v] at hh
  · simpa using hh
  · intro x _ hx
    simp [hx]
  · simp

theorem gated_nonnegative (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (a : GatedArc d) :
    0 ≤ f a := (Nat.cast_nonneg _).trans (hb a).1

theorem gated_disabled_exits (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : P.kind v ≠ .sharedGate) :
    f (gatedExitTailArc d v) = 0 ∧ f (gatedExitGateArc d v) = 0 := by
  have ht := (hb (gatedExitTailArc d v)).2 0 (by simp [gatedUpper, hv])
  have hg := (hb (gatedExitGateArc d v)).2 0 (by simp [gatedUpper, hv])
  norm_num at ht hg
  exact ⟨le_antisymm ht (gated_nonnegative d P f hb _),
    le_antisymm hg (gated_nonnegative d P f hb _)⟩

theorem gated_effective_bypass_eq (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) : gatedEffectiveBypass d P f v = f (gatedBypassArc d v) := by
  by_cases hv : P.kind v = .sharedGate
  · have hh := gated_balance_collector d P f hf v
    simpa [gatedEffectiveBypass, hv] using hh
  · obtain ⟨ht, hg⟩ := gated_disabled_exits d P f hb v hv
    simp [gatedEffectiveBypass, hv, ht, hg]

theorem gated_bypass_box (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    0 ≤ f (gatedBypassArc d v) ∧ f (gatedBypassArc d v) ≤ 1 := by
  refine ⟨gated_nonnegative d P f hb _, ?_⟩
  have hh := (hb (gatedBypassArc d v)).2 (if P.kind v = .disabled then 0 else 1)
    (by simp [gatedUpper])
  split_ifs at hh <;> norm_num at hh ⊢ <;> linarith

theorem gated_free_capacity (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    f (gatedFreeArc d v) ≤ if d.tree.parent v = d.tree.root then (2 : ℝ) else 1 := by
  have hh := (hb (gatedFreeArc d v)).2 (if d.tree.parent v = d.tree.root then 2 else 1)
    (by simp [gatedUpper])
  split_ifs at hh ⊢ <;> simpa using hh

end TSP.Improvements20261105
