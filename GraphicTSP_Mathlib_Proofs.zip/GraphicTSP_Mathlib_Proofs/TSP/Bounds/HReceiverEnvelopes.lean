import TSP.Improvements20261105.MatchedHGain

/-! A simultaneous H force has one unary receiving connector. Its new
raw envelope is at most the old cover or the explicit negative H slack. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem fixedQ_unary_override_connector (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hunary : childCount d v = 1)
    (hy : x (d.treeEdge v) + outgoingBackMass d x v < 1) :
    Y (.inr i) - edgeSum x (d.stars i) / 2 =
      -(1 - x (d.treeEdge v) - outgoingBackMass d x v) - degreeExcess G x (d.centers i) / 2 := by
  have ht : i.1 ∈ allFullOverrideTargets d x := Finset.mem_filter.mpr
    ⟨Finset.mem_univ _, v, hv, hunary, hy⟩
  have hfull := override_full_removal_identity d hs x z hm i.1 ht
  have hnorm := fixedQ_full_removal_connector d hs x z hx hn hcap Y hY i hfull
    (override_projected_heavy d hs x z hm i.1 ht)
  have hev : Even (G.intDegree d.treeEdges (d.centers i)) := by
    rw [hv, tree_degree_eq, if_neg v.2, hunary]
    norm_num
  rw [if_pos hev] at hnorm
  have hid := full_override_identity d hs x v i.1 hv hunary
  change x (d.treeEdge i.1) + (edgeSum x (d.backGroup i.1) - degreeExcess G x (d.centers i)) = _ at hid
  change edgeSum z (d.backGroup i.1) = edgeSum x (d.backGroup i.1) - degreeExcess G x (d.centers i) at hfull
  linarith

theorem H_forced_unary_export_bound (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K D B : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hD : 0 ≤ D) (hDQ : D ≤ Q) (hQP : Q ≤ P) (hB : 0 ≤ B)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d))
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hunary : childCount d v = 1) (hvH : v ∈ H) :
    P * max (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0 +
      Q * (Y (.inr i) - edgeSum x (d.stars i) / 2) ≤
      max (C.cover i.1) (-targetForceSlack d x D B v) := by
  have hcov := covered_unary_export_Q d hs x z hx hn hcap hm P Q hP hQ C Y hY i v hv hunary
  rw [forcedCoverIncrease_target d x z P Q K D B C H hH v hvH]
  by_cases hforce : targetForceThreshold d x P Q D B v ≤ coveredPIncrease d x P Q C.cover v
  · rw [max_eq_left hforce]
    exact hcov.trans (le_max_left _ _)
  · rw [max_eq_right (le_of_not_ge hforce)]
    by_cases hexport : outgoingBackMass d x v < targetForceThreshold d x P Q D B v
    · have ht := target_force_bounds P Q D B (x (d.treeEdge v))
        (min (x (d.treeEdge v)) (1 - x (d.treeEdge v))) (edgeSum x (d.backGroup v))
        hP hDQ hQP hD hQ hB (hcap _) (min_le_right _ _)
        (matched_target_available d hs x z hx hn hm P Q C v (hH hvH)).le
      change _ ∧ targetForceThreshold d x P Q D B v ≤ _ at ht
      have hcapT := ht.2.trans (min_le_right _ _)
      have hy : x (d.treeEdge v) + outgoingBackMass d x v < 1 := by linarith
      have hnorm := fixedQ_unary_override_connector d hs x z hx hn hcap hm Y hY i v hv hunary hy
      have hxi := degreeExcess_nonnegative G hx hn (d.centers i)
      have hq : Y (.inr i) - edgeSum x (d.stars i) / 2 ≤
          -(1 - x (d.treeEdge v) - outgoingBackMass d x v) := by linarith
      have hmul := mul_le_mul_of_nonneg_left hq hQ
      have hident : P * targetForceThreshold d x P Q D B v =
          Q * (1 - x (d.treeEdge v)) - targetForceSlack d x D B v := by
        unfold targetForceThreshold targetForceSlack
        field_simp
      have ho : 0 ≤ outgoingBackMass d x v := Finset.sum_nonneg (fun e _ => hx.1 e)
      have hPQ := mul_nonneg (sub_nonneg.mpr hQP) ho
      rw [max_eq_left (by linarith : 0 ≤ targetForceThreshold d x P Q D B v - outgoingBackMass d x v)]
      apply le_trans _ (le_max_right _ _)
      nlinarith
    · rw [max_eq_right (by linarith : targetForceThreshold d x P Q D B v - outgoingBackMass d x v ≤ 0)]
      have hfloor := (fixedQ_connector_floor_bound d hs x z hx hn hcap hm Y hY Q hQ i).trans (C.floor_bound i.1)
      simpa using hfloor.trans (le_max_left _ _)

theorem H_forced_PQ_connector (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K D B : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (hD : 0 ≤ D) (hDQ : D ≤ Q) (hQP : Q ≤ P) (hB : 0 ≤ B)
    (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner) (rootStar : d.StarIndex)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (hi : i ≠ rootStar) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hunary : childCount d v = 1) (hvH : v ∈ H) :
    pqConnectorArm d x P Q (generalPoint d owner rootStar x
      (fun j => forcedCoverIncrease d x z P Q K D B C H j.1)) Y i -
      P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
      max (C.cover i.1) (-targetForceSlack d x D B v) := by
  have hp := enlarged_connector_one_child d hs owner ho rootStar x hx hcap _
    (forcedCoverIncrease_admissible d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ hD hDQ hQP hB C H hH)
    i hi v hv hunary
  rw [forcedCoverIncrease_extension d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H hH v] at hp
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  have ht0 : 0 ≤ fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := (tau_nonneg _ _).trans ht
  have hE0 := le_max_right (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0
  have hmax : max (starTau d x i) (max (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
      max (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0 :=
    max_le (by linarith) (by linarith)
  have hp' : (3 / 2 : ℝ) * (generalPoint d owner rootStar x
      (fun j => forcedCoverIncrease d x z P Q K D B C H j.1) (.inr i) - 1 / 3) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
      max (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0 := by linarith
  have hb := H_forced_unary_export_bound d hs x z hx hn hcap hm P Q K D B hP hQ hD hDQ hQP hB
    C H hH Y hY i v hv hunary hvH
  unfold pqConnectorArm
  nlinarith [mul_le_mul_of_nonneg_left hp' hP.le]

end TSP.Improvements20261105
