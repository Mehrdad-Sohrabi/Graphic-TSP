import TSP.Improvements20261105.RootedPathCharges
import TSP.Improvements20261105.OriginalJoinGauge
import TSP.Improvements20261105.FixedQIncreases

/-! Inside an actual head-free terminal subtree, all original Q
marginals, after the tree-parity gauge, are exactly half the LP vector. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

 theorem surviving_backGroup_nonempty (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (c : d.tree.Child) (hp : SurvivingPositive d x c) :
    (d.backGroup c).Nonempty := by
  by_contra h
  have hh := Finset.not_nonempty_iff_eq_empty.mp h
  have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent c)
  unfold SurvivingPositive at hp
  rw [hh] at hp
  simp only [edgeSum, Finset.sum_empty] at hp
  linarith

 theorem headfree_increase_zero (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (a : d.tree.Child) (ha : HeadFreeBelow d a)
    (t : d.tree.Child → ℝ) (ht : ∀ c, t c ≠ 0 → SurvivingPositive d x c)
    (c : d.tree.Child) (hc : d.tree.Ancestor a (d.tree.parent c)) : t c = 0 := by
  by_contra h
  exact ha ⟨c, surviving_backGroup_nonempty d x hx hn c (ht c h)⟩ hc

 theorem headfree_incident_Q_marginal (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (a : d.tree.Child) (ha : HeadFreeBelow d a)
    (t : d.tree.Child → ℝ) (ht : ∀ c, t c ≠ 0 → SurvivingPositive d x c)
    (Q : E ⊕ d.StarIndex → ℝ)
    (hr : ∀ c, Q (.inl (d.treeEdge c)) = x (d.treeEdge c)/2 + t c)
    (hb : ∀ e ∈ d.backEdges, Q (.inl e) = 1-x e/2)
    (v : d.tree.Child) (hv : v ∈ strictSubtreeChildren d a)
    (e : E) (he : e ∈ G.cut {(v : V)}) :
    (if e ∈ d.treeEdges then Q (.inl e) else 1-Q (.inl e)) = x e/2 := by
  obtain ⟨_, hva, hne⟩ := Finset.mem_filter.mp hv
  by_cases htree : e ∈ d.treeEdges
  · obtain ⟨c, _, rfl⟩ := Finset.mem_image.mp htree
    have hparent : d.tree.Ancestor a (d.tree.parent c) := by
      have hor := d.oriented (d.treeEdge c)
      rw [d.treeEdge_upper, d.treeEdge_lower] at hor
      have hor' : d.tree.parent c = (v : V) ∨ (c : V) = v := by
        rcases hor with h | h <;> simp [Graph.cut, h.1, h.2] at he <;> tauto
      rcases hor' with h | h
      · rwa [h]
      · have hcv : c = v := Subtype.ext h
        rw [hcv]
        exact d.tree.ancestor_parent_of_ne hva (fun h => hne (Subtype.ext h))
    rw [if_pos htree, hr,
      headfree_increase_zero d x hx hn a ha t ht c hparent, add_zero]
  · rw [if_neg htree, hb e (Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, htree⟩)]
    ring

end TSP.Improvements20261105
