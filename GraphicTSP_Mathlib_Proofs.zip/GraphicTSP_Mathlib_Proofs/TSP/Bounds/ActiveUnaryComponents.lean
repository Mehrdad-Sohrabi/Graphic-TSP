import TSP.Improvements20261105.CanonicalCommonCut

/-! Every active unary link lies in one canonical component, even when
neither endpoint is selected. Crossing a true cut would force selection. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_active_no_common_true_cut
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hactive : (d.backGroup s).Nonempty) (w : (expandedTree d).Child) :
    ¬∀ b ∈ ownBackEdges d s, w ∈ a.backPathCuts d P b := by
  intro hw
  have hB : (ownBackEdges d s).Nonempty := by
    apply Finset.card_pos.mp
    rw [ownBackEdges_card]
    exact Finset.card_pos.mpr hactive
  obtain ⟨b, hb'⟩ := hB
  have hsel := a.crossing_back_selected d ha b ⟨w, hw b hb'⟩
  have hanchor := (Finset.mem_filter.mp hb').2
  rw [hanchor] at hsel
  exact canonical_no_common_true_cut d P hP t ht f hf hb a ha hcan s hsel w hw

theorem canonical_active_center_same_head
    (P : GatePlan d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hactive : (d.backGroup s).Nonempty) :
    a.component d P (.inl (s : V)) = a.component d P (.inr s) := by
  have hz : a.representative s = 0 := by
    simpa only [GatedDrops.potential_representative] using
      gated_optimal_active_representative_zero d P t ht f hf hb (a.potential d P)
        hcan.1.1 hcan.1.2 s hactive
  apply a.component_uncut_representative d P s
  simp [GatedDrops.trueRoleWeight, hz]

theorem canonical_active_unary_connector_uncut (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s u : d.tree.Child) (hunary : childCount d s = 1) (hpar : d.tree.parent u = (s : V))
    (hactive : (d.backGroup s).Nonempty) : expandedConnectorChild d u ∉ a.trueCuts d P := by
  intro hw
  apply canonical_active_no_common_true_cut d P hP t ht f hf hb a ha hcan s hactive (expandedConnectorChild d u)
  intro b hb'
  exact Finset.mem_filter.mpr ⟨hw, (expanded_connector_back_path d b u).mpr
    (unary_own_back_crosses_connector d hs s u hunary hpar b hb')⟩

theorem canonical_active_unary_same_component (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s u : d.tree.Child) (hunary : childCount d s = 1) (hpar : d.tree.parent u = (s : V))
    (hactive : (d.backGroup s).Nonempty) : a.headComponent d P s = a.headComponent d P u := by
  have huncut := canonical_active_unary_connector_uncut d hs P hP t ht f hf hb a ha hcan s u hunary hpar hactive
  have hsame := (expandedTree d).cutComponentRoot_uncut (a.trueCuts d P) (expandedConnectorChild d u) huncut
  change a.component d P (.inr u) = a.component d P (.inl (d.tree.parent u)) at hsame
  rw [hpar] at hsame
  have hsrep := canonical_active_center_same_head d P t ht f hf hb a hcan s hactive
  exact Subtype.ext (hsrep.symm.trans hsame.symm)

end TSP.Improvements20261105
