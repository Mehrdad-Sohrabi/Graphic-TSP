import TSP.Improvements20261105.LargeSelectedGreedyNetTarget

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_positive_greedy_target_net_42
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s)=edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hnot : ¬ScoredStar d x s) (hpositive : 1 < edgeSum z ((d).backGroup s)) :
    24*(edgeSum z ((d).backGroup s)-1)+
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s-
      24*projectedOutgoingCoupon d x z s ≤ 42 := by
  have hinc := refined_fixed_incidence_le_noncritical d x z eligible T s
  have hcapz (e : E) (he : e ∈ (d).backGroup s) : z e ≤ x ((d).treeEdge s) :=
    (hzx e).trans (scoredDFS_not_scored_greedy G x hs hc root s hnot e he)
  have hIall (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
      (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20)
      (hU : x ((d).treeEdge s) ≤ U) :=
    hinc.trans (noncritical_uniform_linear_envelope d z s U A B hA hAd hAU hB hBd hBU
      (fun e _ => hz e) (fun e he => (hcapz e he).trans hU))
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hh := positive_greedy_net_target_42 (x ((d).treeEdge s)) (edgeSum z ((d).backGroup s))
    (refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s)
    (hx.1 _) (hcap _) hpositive.le (by linarith only [hpack]) hIall
  have hcoupon : min (x ((d).treeEdge s)) (1-x ((d).treeEdge s)) ≤ projectedOutgoingCoupon d x z s := by
    rw [projectedOutgoingCoupon,if_pos hpositive,projectedOutgoingCoupon_positive_base d x z s hpositive]
    exact le_max_left _ _
  linarith only [hh,hcoupon]

end TSP.Improvements20261105
