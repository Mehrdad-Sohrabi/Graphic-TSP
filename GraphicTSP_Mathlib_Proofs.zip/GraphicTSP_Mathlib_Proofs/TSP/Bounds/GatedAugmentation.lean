import TSP.Improvements20261105.GatedFreeNormalization
import TSP.Improvements20261105.RealCapacityDual
import TSP.Improvements20261105.RealCapacityRounding

/-! Free-head capacities may be enlarged by arbitrary nonnegative real
amounts. All other capacities, lower bounds and graph geometry stay fixed. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedAugmentedUpper (P : GatePlan d) (t : d.tree.Child → ℝ)
    (a : GatedArc d) : Option ℝ :=
  match a with
  | .inr (.inr (v, k)) =>
      if k = 1 then some ((gatedFreeBase d v : ℝ) + t v)
      else (gatedUpper d P a).map Nat.cast
  | _ => (gatedUpper d P a).map Nat.cast

def GatedLooseBounds (P : GatePlan d) (f : GatedArc d → ℝ) : Prop :=
  (∀ a, (gatedLower d P a : ℝ) ≤ f a) ∧
  (∀ a, (∀ v, a ≠ gatedFreeArc d v) → ∀ u, gatedUpper d P a = some u → f a ≤ u)

@[simp] theorem gatedAugmentedUpper_free (P : GatePlan d) (t : d.tree.Child → ℝ)
    (v : d.tree.Child) : gatedAugmentedUpper d P t (gatedFreeArc d v) =
      some ((gatedFreeBase d v : ℝ) + t v) := by simp [gatedAugmentedUpper]

theorem gatedAugmentedUpper_off_free (P : GatePlan d) (t : d.tree.Child → ℝ)
    (a : GatedArc d) (ha : ∀ v, a ≠ gatedFreeArc d v) :
    gatedAugmentedUpper d P t a = (gatedUpper d P a).map Nat.cast := by
  rcases a with a | (v | ⟨v, k⟩)
  · rfl
  · rfl
  · have hk : k ≠ 1 := by intro h; subst k; exact ha v rfl
    simp [gatedAugmentedUpper, hk]

theorem gatedAugmentedUpper_none (P : GatePlan d) (t : d.tree.Child → ℝ)
    (a : GatedArc d) : gatedAugmentedUpper d P t a = none ↔ gatedUpper d P a = none := by
  by_cases ha : ∃ v, a = gatedFreeArc d v
  · obtain ⟨v, rfl⟩ := ha
    simp [gatedUpper]
  · push_neg at ha
    rw [gatedAugmentedUpper_off_free d P t a ha]
    simp

theorem gated_original_to_augmented (P : GatePlan d) (t : d.tree.Child → ℝ)
    (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) :
    RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f := by
  intro a
  refine ⟨(hb a).1, ?_⟩
  intro u hu
  by_cases ha : ∃ v, a = gatedFreeArc d v
  · obtain ⟨v, rfl⟩ := ha
    have he := Option.some.inj ((gatedAugmentedUpper_free d P t v).symm.trans hu)
    have hc := gated_free_capacity d P f hb v
    have hc' : f (gatedFreeArc d v) ≤ (gatedFreeBase d v : ℝ) := by
      simpa [gatedFreeBase] using hc
    rw [← he]
    linarith [ht v]
  · push_neg at ha
    rw [gatedAugmentedUpper_off_free d P t a ha] at hu
    cases he : gatedUpper d P a with
    | none => simp [he] at hu
    | some n =>
      have hn : (n : ℝ) = u := by simpa [he] using hu
      simpa only [hn] using (hb a).2 n he

theorem gated_augmented_loose (P : GatePlan d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f) :
    GatedLooseBounds d P f := by
  refine ⟨fun a => (hb a).1, ?_⟩
  intro a ha u hu
  apply (hb a).2 (u : ℝ)
  simp [gatedAugmentedUpper_off_free d P t a ha, hu]

theorem gated_rounded_augmented_loose (P : GatePlan d) (t : d.tree.Child → ℝ)
    (g : GatedArc d → ℕ)
    (hb : OptionalFlowBounds (gatedLower d P)
      (fun a => (gatedAugmentedUpper d P t a).map Nat.ceil) (fun a => (g a : ℝ))) :
    GatedLooseBounds d P (fun a => (g a : ℝ)) := by
  refine ⟨fun a => (hb a).1, ?_⟩
  intro a ha u hu
  apply (hb a).2 u
  simp [gatedAugmentedUpper_off_free d P t a ha, hu]

theorem gated_loose_normalized (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f) (hb : GatedLooseBounds d P f) :
    Chapter06.Balanced (gatedNetwork d P) (normalizeGatedFree d P f) ∧
      OptionalFlowBounds (gatedLower d P) (gatedUpper d P) (normalizeGatedFree d P f) :=
  normalizeGatedFree_feasible d P f hf hb.1 hb.2

theorem normalizeGatedFree_backVector (P : GatePlan d) (f : GatedArc d → ℝ) :
    gatedBackVector d (normalizeGatedFree d P f) = gatedBackVector d f := by
  funext e
  unfold gatedBackVector
  split_ifs <;> first | exact normalizeGatedFree_back d P f _ | rfl

theorem normalizeGatedFree_positiveBacks (P : GatePlan d) (f : GatedArc d → ℝ) :
    gatedPositiveBacks d (normalizeGatedFree d P f) = gatedPositiveBacks d f := by
  simp only [gatedPositiveBacks, normalizeGatedFree_backVector]

theorem gated_loose_connector_payment (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : GatedLooseBounds d P f) (v : d.tree.Child)
    (hv : d.tree.parent v ≠ d.tree.root) :
    1 - (∑ b ∈ deletedSubtreeCut d v, gatedBackVector d f b) ≤ f (gatedPaidArc d v) := by
  have hl := hb.1 (gatedSuffixArc d v)
  simp only [gatedLower, Sum.elim_inl, if_neg hv, Nat.cast_one] at hl
  rw [gated_foreign_coverage d P hP f hf v] at hl
  linarith

theorem gated_loose_head_payment (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : GatedLooseBounds d P f) (v : d.tree.Child) :
    (∑ b ∈ d.backGroup v, gatedBackVector d f b) - f (gatedBypassArc d v) -
      (gatedFreeBase d v : ℝ) ≤ f (gatedPaidArc d v) + gatedFreeExcess d f v := by
  obtain ⟨hn, hnb⟩ := gated_loose_normalized d P f hf hb
  have hh := gated_head_payment d P hP _ hn hnb v
  simpa only [normalizeGatedFree_backVector, normalizeGatedFree_bypass,
    normalizeGatedFree_paid, gatedFreeBase, Nat.cast_ite, Nat.cast_ofNat, Nat.cast_one] using hh

theorem exists_augmented_gated_primal_dual (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) :
    ∃ (f : GatedArc d → ℝ) (p : GatedVertex d → ℤ),
      Chapter06.Balanced (gatedNetwork d P) f ∧
      RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f ∧
      (∀ a, gatedUpper d P a = none →
        p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)) ∧
      realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
        (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
          ∑ v : d.tree.Child, f (gatedPaidArc d v) := by
  obtain ⟨f₀, hf₀, hb₀⟩ := exists_feasible_gated_circulation d hs hc P
  obtain ⟨f, p, hf, hb, hp, he⟩ := feasible_real_capacity_primal_integral_dual
    (gatedNetwork d P) (gatedCost d) (gatedLower d P) (gatedAugmentedUpper d P t)
    ⟨f₀, hf₀, gated_original_to_augmented d P t ht f₀ hb₀⟩
  refine ⟨f, p, hf, hb, ?_, ?_⟩
  · intro a ha
    exact hp a ((gatedAugmentedUpper_none d P t a).mpr ha)
  · exact he.1.trans (by simpa using gated_cost_sum d f)

end TSP.Improvements20261105
