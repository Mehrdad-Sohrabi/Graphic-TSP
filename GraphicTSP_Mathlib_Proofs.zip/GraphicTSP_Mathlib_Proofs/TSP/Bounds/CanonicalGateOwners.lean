import TSP.Improvements20261105.GateOwnerPenalty
import TSP.Improvements20261105.CanonicalGateReceivers

/-! Positive gated prefixes have selected owners as well as selected
receivers, by an actual subtree-potential exchange. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem gated_optimal_of_improvement (P : GatePlan d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p q : GatedVertex d → ℤ) (hp : GatedOptimalFor d P t f p)
    (hq : GatedDualFeasible d P q)
    (hbetter : realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) ≤
      realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
        (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (q v : ℝ))) :
    GatedOptimalFor d P t f q := by
  refine ⟨hq, ?_⟩
  have hweak := real_capacity_circulation_weak_duality (gatedNetwork d P)
    (fun a => (gatedCost d a : ℤ)) (gatedLower d P) (gatedAugmentedUpper d P t) f hf hb
    (fun v => (q v : ℝ)) (by
      intro a ha
      dsimp only
      exact_mod_cast hq a ((gatedAugmentedUpper_none d P t a).mp ha))
  simp only [Int.cast_natCast] at hweak
  rw [gated_cost_sum d f] at hweak
  rw [hp.2] at hbetter
  exact le_antisymm hweak hbetter

theorem eraseGatePrefix_dual_nondecreasing (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (r : d.tree.Child) (hr : P.IsReceiver d r) (hpre : gatedPrefixDrop d p r = 1)
    (howner : ∀ v, P.UsesGate d v → P.receiver v = r → gatedHeadSelector d p v = 0) :
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) ≤
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t)
      (fun v => (eraseGatePrefix d P p r v : ℝ)) := by
  rw [gated_augmented_dual_formula, gated_augmented_dual_formula]
  apply Finset.sum_le_sum
  intro v _
  rw [eraseGatePrefix_reward d P p r hr, eraseGatePrefix_head]
  linarith [eraseGatePrefix_penalty_le d P hP p hp r hpre howner v]

theorem eraseGatePrefix_count (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (hr : P.IsReceiver d r) (hpre : gatedPrefixDrop d p r = 1) :
    gatedPrefixCount d P (eraseGatePrefix d P p r) + 1 = gatedPrefixCount d P p := by
  let S := Finset.univ.filter (fun v : d.tree.Child => P.IsReceiver d v ∧ 0 < gatedPrefixDrop d p v)
  have hm : r ∈ S := by simp [S, hr, hpre]
  have he : Finset.univ.filter (fun v : d.tree.Child =>
      P.IsReceiver d v ∧ 0 < gatedPrefixDrop d (eraseGatePrefix d P p r) v) = S.erase r := by
    ext v
    by_cases hv : v = r
    · subst v
      simp [S, eraseGatePrefix_prefix, hpre]
    · simp [S, eraseGatePrefix_prefix, hv]
  unfold gatedPrefixCount
  rw [he]
  exact Finset.card_erase_add_one hm

theorem canonical_gate_owner_selected (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : CanonicalGatedFor d P t f p)
    (s : d.tree.Child) (hsuse : P.UsesGate d s) (hpre : 0 < gatedPrefixDrop d p (P.receiver s)) :
    gatedHeadSelector d p s = 1 := by
  let r := P.receiver s
  have hr : P.IsReceiver d r := ⟨s, hsuse, rfl⟩
  have hfeas := hp.1.1
  have hroot := gate_receiver_nonroot d P hP r hr
  have hbox := gated_nonroot_split_drop_bounds d hs hc hfeas r hroot
  have hpre' : gatedPrefixDrop d p r = 1 := by change 0 < gatedPrefixDrop d p r at hpre; omega
  by_contra hn
  have hhead : gatedHeadSelector d p s = 0 := by
    have hh := gated_head_selector_binary d P p hfeas s
    omega
  have howner : ∀ v, P.UsesGate d v → P.receiver v = r → gatedHeadSelector d p v = 0 := by
    intro v hv he
    have heq : v = s := gate_receiver_unique d P hP v s hv hsuse he
    simpa only [heq] using hhead
  let q := eraseGatePrefix d P p r
  have hq := eraseGatePrefix_feasible d P p hfeas r hpre'
  have hbetter := eraseGatePrefix_dual_nondecreasing d P hP t p hfeas r hr hpre' howner
  have hopt := gated_optimal_of_improvement d P t f hf hb p q hp.1 hq hbetter
  have hmin := hp.2.1 q hopt
  have hcount := eraseGatePrefix_count d P p r hr hpre'
  dsimp only [q] at hmin
  omega

end TSP.Improvements20261105
