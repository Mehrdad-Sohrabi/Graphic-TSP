import TSP.NewmanSupport

/-! The stronger original-to-capped coordinate relation used by the recovered
general improvement. Extremality remains a property of the original vector. -/
namespace TSP.Improvements20261105
open Graph Chapter06
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem capExchange_min_monotone {x : E → ℝ} {e f : E}
    (hef : e ≠ f) (he : 1 < x e) (g : E) :
    min (x g) 1 ≤ min (capExchange x e f g) 1 := by
  by_cases hge : g = e
  · subst g
    rw [capExchange_source x hef, min_self]
    exact min_le_right _ _
  · by_cases hgf : g = f
    · subst g
      rw [capExchange_target x hef]
      exact min_le_min_right 1 (by linarith)
    · rw [capExchange_other x hge hgf]

/-- Capping preserves positivity and optimum value, and dominates the original
coordinatewise minimum with one. All exchanges are proved feasible in Lean. -/
theorem exists_dominating_capped_optimum (G : Graph V E)
    (htwo : ∀ A : Finset V, A.Nonempty → Aᶜ.Nonempty → 2 ≤ (G.cut A).card)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hpositive : ∀ e, 0 < x e)
    (hopt : edgeSum x Finset.univ = G.subtourLP) :
    ∃ y : E → ℝ, G.SubtourFeasible y ∧ (∀ e, 0 < y e ∧ y e ≤ 1) ∧
      edgeSum y Finset.univ = G.subtourLP ∧ ∀ e, min (x e) 1 ≤ y e := by
  have claim : ∀ k : ℕ, ∀ x : E → ℝ, (overCapEdges x).card = k →
      G.SubtourFeasible x → (∀ e, 0 < x e) → edgeSum x Finset.univ = G.subtourLP →
      ∃ y : E → ℝ, G.SubtourFeasible y ∧ (∀ e, 0 < y e ∧ y e ≤ 1) ∧
        edgeSum y Finset.univ = G.subtourLP ∧ ∀ e, min (x e) 1 ≤ y e := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro x hk hx hp ho
      by_cases hn : (overCapEdges x).Nonempty
      · obtain ⟨e, he⟩ := hn
        have hxe := (Finset.mem_filter.mp he).2
        obtain ⟨A, heA, hA⟩ := optimal_positive_edge_tight G hx ho e (hp e)
        have hnon := shore_nontrivial_of_cut_mem G heA
        obtain ⟨f, hfA, hfe⟩ := Finset.exists_ne_of_one_lt_card
          (show 1 < (G.cut A).card by have h := htwo A hnon.1 hnon.2; omega) e
        have hz := capExchange_feasible G hx hA heA hfA (Ne.symm hfe) hxe
        have hcap := capExchange_target_le_one G hx.1 hA heA hfA (Ne.symm hfe)
        have hid := capExchange_preserves_objective_support (Ne.symm hfe) hxe (hp f)
        have hlt := capExchange_overCap_decreases (Ne.symm hfe) hxe hcap
        rw [hk] at hlt
        obtain ⟨y, hy, hyp, hyo, hdom⟩ :=
          ih _ hlt _ rfl hz (fun g => (hid.2 g).mpr (hp g)) (hid.1.trans ho)
        exact ⟨y, hy, hyp, hyo, fun g => (capExchange_min_monotone (Ne.symm hfe) hxe g).trans (hdom g)⟩
      · refine ⟨x, hx, fun e => ⟨hp e, ?_⟩, ho, fun e => min_le_left _ _⟩
        by_contra he
        exact hn ⟨e, Finset.mem_filter.mpr ⟨Finset.mem_univ _, lt_of_not_ge he⟩⟩
  exact claim _ x rfl hx hpositive hopt

/-- Sparse support is inherited from the original extreme optimum; the capped
optimum has the same support and the monotonicity required for projection. -/
theorem dominating_capped_sparse_optimum (G : Graph V E) (hsimple : G.IsSimple)
    (hconn : IsTwoVertexConnected G) {x : E → ℝ}
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x e)
    (hopt : edgeSum x Finset.univ = G.subtourLP) :
    ∃ y : E → ℝ, G.SubtourFeasible y ∧ (∀ e, 0 < y e ∧ y e ≤ 1) ∧
      edgeSum y Finset.univ = G.subtourLP ∧ (∀ e, min (x e) 1 ≤ y e) ∧
        Fintype.card E ≤ 2 * Fintype.card V - 3 := by
  obtain ⟨y, hy, hp, ho, hdom⟩ := exists_dominating_capped_optimum G
    (two_vertex_connected_cut_card G hsimple hconn) hx.1 hpositive hopt
  obtain ⟨root⟩ := hconn.2.1.1
  exact ⟨y, hy, hp, ho, hdom, Chapter10.general_extreme_support_sparsity G hx hpositive
    (by have hn := hconn.1; omega) root⟩

theorem original_le_capped_of_original_le_one {x y : E → ℝ}
    (hdom : ∀ e, min (x e) 1 ≤ y e) (e : E) (he : x e ≤ 1) : x e ≤ y e := by
  simpa only [min_eq_left he] using hdom e

theorem capped_eq_one_of_original_ge_one {x y : E → ℝ}
    (hdom : ∀ e, min (x e) 1 ≤ y e) (hcap : ∀ e, y e ≤ 1)
    (e : E) (he : 1 ≤ x e) : y e = 1 := by
  apply le_antisymm (hcap e)
  simpa only [min_eq_right he] using hdom e

end TSP.Improvements20261105
