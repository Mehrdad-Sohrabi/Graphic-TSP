import TSP.Improvements20261105.GlobalRefinedCost
import TSP.Improvements20261105.TotalCouponPayment
import TSP.Improvements20261105.SelectedHeadSums
import TSP.Improvements20261105.LeafCoverageAllocation

/-! Combine incidence with the exact selected-back mass identity.
Internal mass, penalties and true-cut coverage are kept explicit so
leaf entries are allocated before the remaining coverage reserve is spent. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_leaf_coupon_cost_ledger (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : Finset d.tree.Child) (hscore : ScoreComparisons d x C)
    (R : Finset d.tree.Child) (hRC : R ⊆ C)
    (hR : ∀ s ∈ R, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (b : d.tree.Child → ℝ) (hbcap : ∀ s, b s ≤ 1)
    (hbout : ∀ s, P.kind s = .outsideGate → b s ≤ outsideBackMass d P (fun e => x e.1) s)
    (W : Finset (expandedTree d).Child) (hW : W ⊆ a.trueCuts d P)
    (q : d.tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, (d.backGroup s).card ≤ 3 → ∀ e ∈ d.backGroup s, z e ≤ q s) :
    48 * a.value d P (fun _ => 0) ≤
      (∑ s ∈ a.selectedHeads d,
        (24 * (edgeSum z (d.backGroup s) - gatedFreeBase d s) + refinedIncidenceCharge d x z C R s -
          24 * accountedCoupon d P b s + 24 * couponResidual d P (fun e => x e.1) b s)) +
      (∑ w ∈ W, 24*(2-componentEntryCoverage d x (w : FlowVertex d))) +
      24 * ((a.headfulLeafComponents d P).card - W.card - 1 - (a.selectedRootHeads d).card) -
      (162 / 19) * (∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z C r : ℝ)) +
      72 * (∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s) +
      (244 / 5) * (edgeSum x Finset.univ - Fintype.card V) - 12 * Chapter11.totalOverage d x := by
  have hcost := canonical_global_refined_cost_ledger d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
    x z hx hcap hz hzx C hscore R hRC hR q hq hpack hsmall
  have hpay := canonical_total_coupon_payment d P hP t ht f hf hb a ha hcan x hx.1 b hbcap hbout
  have hcov := canonical_leaf_allocated_coverage d hs hc P hP t f hf hb a ha hcan hx hcap W hW
    ((a.headfulLeafComponents d P).card - 1 - (a.selectedRootHeads d).card)
  have hsplit : (∑ s ∈ a.selectedHeads d, accountedCoupon d P b s) =
      (∑ s ∈ a.selectedHeads d, payableCoupon d P (fun e => x e.1) b s) +
      ∑ s ∈ a.selectedHeads d, couponResidual d P (fun e => x e.1) b s := by
    simp_rw [coupon_payment_split d P (fun e => x e.1) b]
    exact Finset.sum_add_distrib
  simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum]
  simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum] at hcost hcov
  linarith

end TSP.Improvements20261105
