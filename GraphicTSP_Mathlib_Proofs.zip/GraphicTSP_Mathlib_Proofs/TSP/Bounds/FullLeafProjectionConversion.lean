import TSP.Improvements20261105.LeafProjectionConversion
import TSP.Improvements20261105.ProjectedCoverComponents
import TSP.Improvements20261105.ZeroLeafGlobalBudget
import TSP.Improvements20261105.SelectedHeadSums

/-! Actual leaf heads are unselected in the canonical solution. Their
full 72-times erased-mass conversion and the selected projection term
share one original back-group reserve. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
variable (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
variable (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
variable (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
variable (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

include hs hc hP ht hf hb ha hcan in
theorem GatedDrops.selected_leaf_full_projection_conversion (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (L : Finset (FlowVertex d))
    (hL : L ⊆ (a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d)))
    (J : Finset d.StarIndex) (hJ : J ⊆ a.componentStarUnion d P L) :
    72*(∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s)+
      72*(∑ i ∈ J, fixedRemoval d x (allFullOverrideTargets d x) i.1) ≤
        144*(edgeSum x Finset.univ-Fintype.card V) := by
  have hid (s : d.tree.Child) : ownProjectionLoss d x z s =
      fixedRemoval d x (allFullOverrideTargets d x) s := by
    unfold ownProjectionLoss
    rw [hm]
    ring
  simp_rw [hid]
  have hnon (s : d.tree.Child) : 0 ≤ fixedRemoval d x (allFullOverrideTargets d x) s :=
    (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) s).1
  have hdis := a.actual_leaf_heads_disjoint_selected d hs hc P hP t ht f hf hb ha hcan L hL J hJ
  have hsum : (∑ s ∈ J.image Subtype.val, fixedRemoval d x (allFullOverrideTargets d x) s) =
      ∑ i ∈ J, fixedRemoval d x (allFullOverrideTargets d x) i.1 :=
    Finset.sum_image (fun i _ j _ h => Subtype.ext h)
  have hsub := Finset.sum_le_sum_of_subset_of_nonneg
    (Finset.subset_univ ((a.selectedHeads d) ∪ J.image Subtype.val))
    (fun s _ _ => hnon s)
  rw [Finset.sum_union hdis.symm,hsum] at hsub
  have hjnon : 0 ≤ ∑ i ∈ J, fixedRemoval d x (allFullOverrideTargets d x) i.1 :=
    Finset.sum_nonneg (fun i _ => hnon i.1)
  have htotal := fixedRemoval_total_budget d hs hx hn (allFullOverrideTargets d x)
    (allFullOverrideTargets_valid d x)
  linarith only [hsub,hjnon,htotal]

end TSP.Improvements20261105
