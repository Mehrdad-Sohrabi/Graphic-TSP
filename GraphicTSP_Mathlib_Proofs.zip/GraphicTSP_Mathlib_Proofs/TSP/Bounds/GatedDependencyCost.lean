import TSP.Improvements20261105.GatedBackDependencyDeletion
import TSP.Improvements20261105.GatedDropExchangeBound

/-! Deleting a union of back-path dependencies costs at most the sum of
their individual path budgets. Overlaps are charged only once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators

theorem exists_indicator_le_sum {A : Type} (B : Finset A) (P : A → Prop) [DecidablePred P]
    (H : Prop) (hH : H ↔ ∃ b ∈ B, P b) (w : ℝ) (hw : 0 ≤ w) :
    (if H then w else 0) ≤ ∑ b ∈ B, if P b then w else 0 := by
  by_cases h : H
  · rw [if_pos h]
    obtain ⟨b, hb, hp⟩ := hH.mp h
    calc
      w = (if P b then w else 0) := by simp [hp]
      _ ≤ _ := Finset.single_le_sum (s := B) (f := fun c => if P c then w else 0)
        (fun c _ => by dsimp only; split_ifs <;> linarith) hb
  · rw [if_neg h]
    exact Finset.sum_nonneg (fun b _ => by split_ifs <;> linarith)

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.pathCost_indicator (a : GatedDrops d) (b : BackEdge d) :
    a.pathCost d b = ∑ v : d.tree.Child,
      ((if backConnectorPath d b v then ((a.pref v + a.suffix v : ℤ) : ℝ) else 0) +
      (if backRepresentativePath d b v then (a.representative v : ℝ) else 0)) := by
  apply Finset.sum_congr rfl
  intro v _
  simp only [backCycle, Sum.elim_inl, Sum.elim_inr, backConnectorPath, backRepresentativePath]
  split_ifs <;> simp

theorem GatedDrops.eraseBackDependencies_cost (a : GatedDrops d)
    (B : Finset (BackEdge d)) (S : Finset d.tree.Child) :
    a.deletionCost d (a.eraseBackDependencies d B S) =
      (∑ v : d.tree.Child,
        ((if backsCoverConnector d B v then ((a.pref v + a.suffix v : ℤ) : ℝ) else 0) +
        (if backsCoverRepresentative d B v then (a.representative v : ℝ) else 0))) +
      ∑ v : V, if backsUseTail d B v then (a.tail v : ℝ) else 0 := by
  unfold GatedDrops.deletionCost
  congr 1
  · apply Finset.sum_congr rfl
    intro v _
    simp only [eraseBackDependencies]
    split_ifs <;> push_cast <;> ring
  · apply Finset.sum_congr rfl
    intro v _
    simp only [eraseBackDependencies]
    split_ifs <;> simp

theorem GatedDrops.eraseBackDependencies_cost_le {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (B : Finset (BackEdge d)) (S : Finset d.tree.Child) :
    a.deletionCost d (a.eraseBackDependencies d B S) ≤
      ∑ b ∈ B, (a.pathCost d b + (a.tail (d.lower b.1) : ℝ)) := by
  rw [a.eraseBackDependencies_cost]
  calc
    _ ≤ (∑ v : d.tree.Child, ∑ b ∈ B,
        ((if backConnectorPath d b v then ((a.pref v + a.suffix v : ℤ) : ℝ) else 0) +
        (if backRepresentativePath d b v then (a.representative v : ℝ) else 0))) +
      ∑ v : V, ∑ b ∈ B, if d.lower b.1 = v then (a.tail v : ℝ) else 0 := by
      apply add_le_add
      · apply Finset.sum_le_sum
        intro v _
        rw [Finset.sum_add_distrib]
        apply add_le_add
        · exact exists_indicator_le_sum B (fun b => backConnectorPath d b v) (backsCoverConnector d B v) Iff.rfl ((a.pref v + a.suffix v : ℤ) : ℝ)
            (by exact_mod_cast add_nonneg (ha.pref_nonneg v) (ha.suffix_nonneg v))
        · exact exists_indicator_le_sum B (fun b => backRepresentativePath d b v) (backsCoverRepresentative d B v) Iff.rfl (a.representative v : ℝ)
            (by exact_mod_cast ha.representative_nonneg v)
      · apply Finset.sum_le_sum
        intro v _
        exact exists_indicator_le_sum B (fun b => d.lower b.1 = v) (backsUseTail d B v) Iff.rfl (a.tail v : ℝ)
          (by exact_mod_cast ha.tail_nonneg v)
    _ = _ := by
      rw [Finset.sum_comm, Finset.sum_comm (s := Finset.univ) (t := B), ← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro b _
      rw [← a.pathCost_indicator d b]
      simp

end TSP.Improvements20261105
