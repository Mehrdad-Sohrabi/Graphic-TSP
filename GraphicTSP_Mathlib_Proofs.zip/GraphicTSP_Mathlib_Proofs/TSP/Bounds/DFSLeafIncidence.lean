import TSP.Improvements20261105.InducedSupportSparsity
import TSP.Improvements20261105.GatedEmptyLeafGeometry

/-! The edges from actual original DFS leaves to a set of star centers
are a disjoint part of the induced original support. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def leafBacks (L : Finset V) : Finset E := d.backEdges.filter (fun e => d.lower e ∈ L)
noncomputable def headCenters (H : Finset d.tree.Child) : Finset V := H.image (fun s : d.tree.Child => d.tree.parent s)

def AreDFSLeaves (L : Finset V) : Prop := ∀ v ∈ L, ∀ c : d.tree.Child, d.tree.parent c ≠ v
def LeafHeadsIn (L : Finset V) (H : Finset d.tree.Child) : Prop :=
  ∀ e ∈ leafBacks d L, d.anchor e ∈ H

theorem leaves_disjoint_centers (L : Finset V) (hL : AreDFSLeaves d L)
    (H : Finset d.tree.Child) : Disjoint L (headCenters d H) := by
  apply Finset.disjoint_left.mpr
  intro v hv hc
  obtain ⟨s, _, hs⟩ := Finset.mem_image.mp hc
  exact hL v hv s hs

theorem leafBacks_internal (L : Finset V) (H : Finset d.tree.Child) (hh : LeafHeadsIn d L H) :
    leafBacks d L ⊆ G.internalEdges (L ∪ headCenters d H) := by
  intro e he
  have hl := (Finset.mem_filter.mp he).2
  have hu : d.upper e ∈ headCenters d H :=
    Finset.mem_image.mpr ⟨d.anchor e, hh e he, (d.anchor_spec e).1⟩
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_univ _, ?_⟩
  rcases d.oriented e with ho | ho
  · exact ⟨ho.1 ▸ Finset.mem_union_right L hu, ho.2 ▸ Finset.mem_union_left _ hl⟩
  · exact ⟨ho.1 ▸ Finset.mem_union_left _ hl, ho.2 ▸ Finset.mem_union_right L hu⟩

theorem leafBacks_disjoint_center_edges (L : Finset V) (hL : AreDFSLeaves d L)
    (H : Finset d.tree.Child) : Disjoint (leafBacks d L) (G.internalEdges (headCenters d H)) := by
  apply Finset.disjoint_left.mpr
  intro e he hc
  have hl := (Finset.mem_filter.mp he).2
  have hec := (Finset.mem_filter.mp hc).2
  have hlow : d.lower e ∈ headCenters d H := by
    rcases d.oriented e with ho | ho
    · exact ho.2 ▸ hec.2
    · exact ho.1 ▸ hec.1
  exact Finset.disjoint_left.mp (leaves_disjoint_centers d L hL H) hl hlow

theorem leafBacks_sparse (x : E → ℝ) (hx : x ∈ G.subtourPolytope.extremePoints ℝ)
    (hpositive : ∀ e, 0 < x e) (L : Finset V) (hL : AreDFSLeaves d L) (hLn : L.Nonempty)
    (H : Finset d.tree.Child) (hHn : H.Nonempty) (hh : LeafHeadsIn d L H) :
    (leafBacks d L).card + (G.internalEdges (headCenters d H)).card + 3 ≤ 2 * (L.card + H.card) := by
  have hc : (headCenters d H).Nonempty := Finset.image_nonempty.mpr hHn
  have hd := leaves_disjoint_centers d L hL H
  have hunion : (L ∪ headCenters d H).card = L.card + (headCenters d H).card := Finset.card_union_of_disjoint hd
  have hlo := Finset.card_pos.mpr hLn
  have hco := Finset.card_pos.mpr hc
  have hW : 2 ≤ (L ∪ headCenters d H).card := by omega
  have hs := extreme_induced_support_sparsity G hx hpositive (L ∪ headCenters d H) hW
  have hsub : leafBacks d L ∪ G.internalEdges (headCenters d H) ⊆ G.internalEdges (L ∪ headCenters d H) := by
    intro e he
    rcases Finset.mem_union.mp he with he | he
    · exact leafBacks_internal d L H hh he
    · have hc := (Finset.mem_filter.mp he).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, Finset.mem_union_right _ hc.1, Finset.mem_union_right _ hc.2⟩
  have hcount := Finset.card_le_card hsub
  rw [Finset.card_union_of_disjoint (leafBacks_disjoint_center_edges d L hL H)] at hcount
  have hcent : (headCenters d H).card ≤ H.card := Finset.card_image_le
  omega

theorem leafBacks_mass_sum (x : E → ℝ) (L : Finset V) :
    edgeSum x (leafBacks d L) = ∑ v ∈ L, (∑ e ∈ d.backEdges, if d.lower e = v then x e else 0) := by
  simp only [leafBacks, edgeSum, Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  simp

theorem own_back_group_filter (v : d.tree.Child) :
    d.backGroup v = d.backEdges.filter (fun e => d.anchor e = v) := by
  ext e
  constructor
  · intro he
    exact Finset.mem_filter.mpr ⟨((d.mem_backGroup_iff v e).mp he).1,
      (d.mem_group v e).mp (Finset.mem_sdiff.mp he).1⟩
  · intro he
    have hh := Finset.mem_filter.mp he
    have ha := d.anchor_spec e
    rw [hh.2] at ha
    exact (d.mem_backGroup_iff v e).mpr ⟨hh.1, ha.1.symm, ha.2⟩

theorem sum_own_back_groups (x : E → ℝ) (H : Finset d.tree.Child) :
    (∑ v ∈ H, edgeSum x (d.backGroup v)) =
      ∑ e ∈ d.backEdges, if d.anchor e ∈ H then x e else 0 := by
  simp_rw [own_back_group_filter]
  simp only [edgeSum, Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  simp

theorem leafBacks_mass_le_heads (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (L : Finset V) (H : Finset d.tree.Child) (hh : LeafHeadsIn d L H) :
    edgeSum x (leafBacks d L) ≤ ∑ v ∈ H, edgeSum x (d.backGroup v) := by
  rw [sum_own_back_groups]
  simp only [edgeSum, leafBacks, Finset.sum_filter]
  apply Finset.sum_le_sum
  intro e he
  by_cases hl : d.lower e ∈ L
  · have ha := hh e (Finset.mem_filter.mpr ⟨he, hl⟩)
    simp [hl, ha]
  · simp only [if_neg hl]
    split_ifs
    · exact hx e
    · exact le_rfl

end TSP.Improvements20261105
