import TSP.Improvements20261105.FixedZeroGuardPoint
import TSP.Improvements20261105.FixedQIncreases

/-! Positive terminal guards are fixed from the original subtour vector.
Their family is disjoint from the fixed eligible zero family. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def fixedPositiveTerminalHeads (x : E → ℝ) : Finset d.StarIndex :=
  Finset.univ.filter (fun i => HeadFreeBelow d i.1 ∧ SurvivingPositive d x i.1 ∧
    d.centers i ≠ d.tree.root)

noncomputable def fixedPositiveTerminalBacks (x : E → ℝ) : Finset (BackEdge d) :=
  (fixedPositiveTerminalHeads d x).image (fixedOwnBack d)

noncomputable def fixedPositiveTerminalChildren (x : E → ℝ) : Finset d.tree.Child :=
  (fixedPositiveTerminalHeads d x).image Subtype.val

theorem fixedPositiveTerminalChildren_admissible (x : E → ℝ)
    (c : d.tree.Child) (hc : c ∈ fixedPositiveTerminalChildren d x) :
    SurvivingPositive d x c ∧ ∀ i : d.StarIndex, d.centers i ≠ (c : V) := by
  obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp hc
  have hs := (Finset.mem_filter.mp hj).2
  refine ⟨hs.2.1, ?_⟩
  intro i he
  apply hs.1 i
  rw [he]
  exact .refl

theorem fixedPositiveTerminalBacks_headfree (x : E → ℝ) (b : BackEdge d)
    (hb : b ∈ fixedPositiveTerminalBacks d x) : HeadFreeBelow d (d.anchor b.1) := by
  obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
  rw [fixedOwnBack_anchor]
  exact (Finset.mem_filter.mp hi).2.1

theorem fixedPositiveTerminalBacks_positive (x : E → ℝ) (b : BackEdge d)
    (hb : b ∈ fixedPositiveTerminalBacks d x) : SurvivingPositive d x (d.anchor b.1) := by
  obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
  rw [fixedOwnBack_anchor]
  exact (Finset.mem_filter.mp hi).2.2.1

theorem fixed_terminal_families_disjoint (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) : Disjoint (fixedZeroTerminalBacks d x) (fixedPositiveTerminalBacks d x) := by
  apply Finset.disjoint_left.mpr
  intro b hz hp
  have hzero := fixedZeroTerminalBacks_zero d x b hz
  have hpos := fixedPositiveTerminalBacks_positive d x b hp
  have hex := degreeExcess_nonnegative G hx hn (d.tree.parent (d.anchor b.1))
  unfold SurvivingPositive at hpos
  linarith

theorem fixed_terminal_union_headfree (x : E → ℝ) (b : BackEdge d)
    (hb : b ∈ fixedZeroTerminalBacks d x ∪ fixedPositiveTerminalBacks d x) :
    HeadFreeBelow d (d.anchor b.1) := by
  rcases Finset.mem_union.mp hb with hz | hp
  · exact fixedZeroTerminalBacks_headfree d x b hz
  · exact fixedPositiveTerminalBacks_headfree d x b hp

theorem fixed_terminal_union_distinct (x : E → ℝ) (b c : BackEdge d)
    (hb : b ∈ fixedZeroTerminalBacks d x ∪ fixedPositiveTerminalBacks d x)
    (hc : c ∈ fixedZeroTerminalBacks d x ∪ fixedPositiveTerminalBacks d x)
    (hne : b ≠ c) : d.anchor b.1 ≠ d.anchor c.1 := by
  have hpre (a : BackEdge d)
      (ha : a ∈ fixedZeroTerminalBacks d x ∪ fixedPositiveTerminalBacks d x) :
      ∃ i : d.StarIndex, fixedOwnBack d i = a := by
    rcases Finset.mem_union.mp ha with hz | hp
    · obtain ⟨i, _, he⟩ := Finset.mem_image.mp hz
      exact ⟨i, he⟩
    · obtain ⟨i, _, he⟩ := Finset.mem_image.mp hp
      exact ⟨i, he⟩
  obtain ⟨i, rfl⟩ := hpre b hb
  obtain ⟨j, rfl⟩ := hpre c hc
  rw [fixedOwnBack_anchor, fixedOwnBack_anchor]
  intro he
  exact hne (congrArg (fixedOwnBack d) (Subtype.ext he))

theorem fixed_terminal_back_fiber (H : Finset d.StarIndex) (w : d.StarIndex → ℝ) (i : d.StarIndex) :
    (∑ b ∈ H.image (fixedOwnBack d), if d.anchor b.1 = i.1 then w (ownBackStar d b) else 0) =
      if i ∈ H then w i else 0 := by
  rw [Finset.sum_image (fun j _ l _ h => fixedOwnBack_injective d h)]
  simp only [fixedOwnBack_anchor, ownBackStar_fixed]
  by_cases hi : i ∈ H
  · rw [if_pos hi, Finset.sum_eq_single i]
    · simp
    · intro j _ hji
      have hn : j.1 ≠ i.1 := fun h => hji (Subtype.ext h)
      simp [hn]
    · exact fun hn => (hn hi).elim
  · rw [if_neg hi]
    apply Finset.sum_eq_zero
    intro j hj
    have hn : j.1 ≠ i.1 := fun h => hi ((Subtype.ext h : j = i) ▸ hj)
    simp [hn]

theorem fixed_positive_Q_increase_full (x : E → ℝ) (i : d.StarIndex)
    (hi : i ∈ fixedPositiveTerminalHeads d x) :
    fixedQIncrease d x (fixedPositiveTerminalChildren d x) i.1 = 1-x (d.treeEdge i.1) := by
  have hm : i.1 ∈ fixedPositiveTerminalChildren d x := Finset.mem_image.mpr ⟨i, hi, rfl⟩
  simp only [fixedQIncrease, if_pos hm]

end TSP.Improvements20261105
