import TSP.Improvements20261105.ExpandedBinaryBypass

/-! Each of the four graph gadgets supplies the simultaneous-cut witness.
Coverage always refers to a selected original back edge. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def SelectedForeignCover (B : Finset E) (c : d.tree.Child) : Prop :=
  (B ∩ deletedSubtreeCut d c).Nonempty

def SelectedTreeCover (B : Finset E) (c : d.tree.Child) : Prop :=
  (B ∩ G.cut (subtreeVertices d c)).Nonempty

theorem nonremovable_selected_cover_foreign (B : Finset E) (hB : B ⊆ d.backEdges)
    (c : d.tree.Child) (hinactive : ¬(d.backGroup c).Nonempty)
    (hcover : SelectedTreeCover d B c) : SelectedForeignCover d B c := by
  obtain ⟨b, hb⟩ := hcover
  have hbb := (Finset.mem_inter.mp hb).1
  have hbc := (Finset.mem_inter.mp hb).2
  rw [subtree_cut_partition] at hbc
  rcases Finset.mem_union.mp hbc with hg | hf
  · have hnot : b ≠ d.treeEdge c := by
      intro heq
      have ht : b ∈ d.treeEdges := heq ▸ Finset.mem_image.mpr ⟨c, Finset.mem_univ _, rfl⟩
      exact (Finset.mem_sdiff.mp (hB hbb)).2 ht
    exact (hinactive ⟨b, Finset.mem_sdiff.mpr ⟨hg, by simpa using hnot⟩⟩).elim
  · exact ⟨b, Finset.mem_inter.mpr ⟨hbb, hf⟩⟩

theorem two_foreign_directions_bypass (B : Finset E) (v c₁ c₂ : d.tree.Child)
    (hne : c₁ ≠ c₂) (hp₁ : d.tree.parent c₁ = (v : V))
    (hp₂ : d.tree.parent c₂ = (v : V))
    (hc₁ : SelectedForeignCover d B c₁) (hc₂ : SelectedForeignCover d B c₂) :
    OriginalBypassWitness d B v := by
  right
  refine ⟨c₁, c₂, hne, hp₁, hp₂, ?_, ?_⟩
  · obtain ⟨b, hb⟩ := hc₁
    have hh := (deletedSubtreeCut_iff d c₁ b).mp (Finset.mem_inter.mp hb).2
    rw [hp₁] at hh
    exact ⟨b, (Finset.mem_inter.mp hb).1, hh⟩
  · obtain ⟨b, hb⟩ := hc₂
    have hh := (deletedSubtreeCut_iff d c₂ b).mp (Finset.mem_inter.mp hb).2
    rw [hp₂] at hh
    exact ⟨b, (Finset.mem_inter.mp hb).1, hh⟩

theorem outgoing_bypass_gadget (B : Finset E) (v : d.tree.Child)
    (h : ∃ b ∈ B, d.lower b = (v : V)) : OriginalBypassWitness d B v := Or.inl h

theorem two_nonremovable_bypass_gadget (B : Finset E) (hB : B ⊆ d.backEdges)
    (v c₁ c₂ : d.tree.Child) (hne : c₁ ≠ c₂)
    (hp₁ : d.tree.parent c₁ = (v : V)) (hp₂ : d.tree.parent c₂ = (v : V))
    (hi₁ : ¬(d.backGroup c₁).Nonempty) (hi₂ : ¬(d.backGroup c₂).Nonempty)
    (hc₁ : SelectedTreeCover d B c₁) (hc₂ : SelectedTreeCover d B c₂) :
    OriginalBypassWitness d B v :=
  two_foreign_directions_bypass d B v c₁ c₂ hne hp₁ hp₂
    (nonremovable_selected_cover_foreign d B hB c₁ hi₁ hc₁)
    (nonremovable_selected_cover_foreign d B hB c₂ hi₂ hc₂)

theorem nonremovable_foreign_bypass_gadget (B : Finset E) (hB : B ⊆ d.backEdges)
    (v c R : d.tree.Child) (hne : c ≠ R)
    (hpc : d.tree.parent c = (v : V)) (hpR : d.tree.parent R = (v : V))
    (hic : ¬(d.backGroup c).Nonempty)
    (hcc : SelectedTreeCover d B c) (hcR : SelectedForeignCover d B R) :
    OriginalBypassWitness d B v :=
  two_foreign_directions_bypass d B v c R hne hpc hpR
    (nonremovable_selected_cover_foreign d B hB c hic hcc) hcR

theorem own_other_foreign_bypass_gadget (B : Finset E)
    (v c R : d.tree.Child) (hne : c ≠ R)
    (hpc : d.tree.parent c = (v : V)) (hpR : d.tree.parent R = (v : V))
    (b : E) (hb : b ∈ B) (hown : b ∈ d.backGroup v)
    (hc : d.tree.Ancestor c (d.lower b)) (hcR : SelectedForeignCover d B R) :
    OriginalBypassWitness d B v := by
  apply two_foreign_directions_bypass d B v c R hne hpc hpR _ hcR
  refine ⟨b, Finset.mem_inter.mpr ⟨hb, (deletedSubtreeCut_iff d c b).mpr ⟨hc, ?_⟩⟩⟩
  have hh := ((d.mem_group_iff v b).mp (Finset.mem_sdiff.mp hown).1).1
  rw [hpc, hh]
  have hd := d.tree.parent_depth v v.2
  omega

end TSP.Improvements20261105
