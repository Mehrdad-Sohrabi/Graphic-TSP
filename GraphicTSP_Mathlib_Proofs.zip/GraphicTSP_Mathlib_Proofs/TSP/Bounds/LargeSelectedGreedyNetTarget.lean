import TSP.Improvements20261105.UniformRampLinearEnvelope
import TSP.Improvements20261105.SelectedPositiveTargetNetPairCost

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators

theorem positive_greedy_net_target_42 (q a I : ℝ)
    (hq : 0 ≤ q) (hqunit : q ≤ 1) (ha : 1 ≤ a) (hpack : a+q ≤ 2)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1))) :
    24*(a-1)+I-24*min q (1-q) ≤ 42 := by
  by_cases hq0 : q ≤ (1/20 : ℝ)
  · have hI := hIall (1/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq0
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq0]
  by_cases hq1 : q ≤ (1/10 : ℝ)
  · have hI := hIall (1/10 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq1
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq0,hq1]
  by_cases hq2 : q ≤ (3/20 : ℝ)
  · have hI := hIall (3/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq2
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq1,hq2]
  by_cases hq3 : q ≤ (1/5 : ℝ)
  · have hI := hIall (1/5 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq3
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq2,hq3]
  by_cases hq4 : q ≤ (1/4 : ℝ)
  · have hI := hIall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq4
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq3,hq4]
  by_cases hq5 : q ≤ (3/10 : ℝ)
  · have hI := hIall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq5
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq4,hq5]
  by_cases hq6 : q ≤ (7/20 : ℝ)
  · have hI := hIall (7/20 : ℝ) (4/7 : ℝ) (43/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq6
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq5,hq6]
  by_cases hq7 : q ≤ (2/5 : ℝ)
  · have hI := hIall (2/5 : ℝ) (3/4 : ℝ) (31/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq7
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq6,hq7]
  by_cases hq8 : q ≤ (9/20 : ℝ)
  · have hI := hIall (9/20 : ℝ) (8/9 : ℝ) (9/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq8
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq7,hq8]
  by_cases hq9 : q ≤ (1/2 : ℝ)
  · have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq9
    rw [min_eq_left (by linarith : q ≤ 1-q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq8,hq9]
  by_cases hq10 : q ≤ (11/20 : ℝ)
  · have hI := hIall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq10
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq9,hq10]
  by_cases hq11 : q ≤ (3/5 : ℝ)
  · have hI := hIall (3/5 : ℝ) (7/6 : ℝ) (23/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq11
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq10,hq11]
  by_cases hq12 : q ≤ (13/20 : ℝ)
  · have hI := hIall (13/20 : ℝ) (16/13 : ℝ) (157/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq12
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq11,hq12]
  by_cases hq13 : q ≤ (7/10 : ℝ)
  · have hI := hIall (7/10 : ℝ) (9/7 : ℝ) (44/35 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq13
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq12,hq13]
  by_cases hq14 : q ≤ (3/4 : ℝ)
  · have hI := hIall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq14
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq13,hq14]
  by_cases hq15 : q ≤ (4/5 : ℝ)
  · have hI := hIall (4/5 : ℝ) (11/8 : ℝ) (107/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq15
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq14,hq15]
  by_cases hq16 : q ≤ (17/20 : ℝ)
  · have hI := hIall (17/20 : ℝ) (24/17 : ℝ) (233/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq16
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq15,hq16]
  by_cases hq17 : q ≤ (9/10 : ℝ)
  · have hI := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq17
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq16,hq17]
  by_cases hq18 : q ≤ (19/20 : ℝ)
  · have hI := hIall (19/20 : ℝ) (28/19 : ℝ) (271/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hq18
    rw [min_eq_right (by linarith : 1-q ≤ q)]
    rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq17,hq18]
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by simpa using hqunit)
  rw [min_eq_right (by linarith : 1-q ≤ q)]
  rcases le_max_iff.mp hI with hI | hI <;> linarith only [hq,hqunit,ha,hpack,hI,hq18]

end TSP.Improvements20261105
