import TSP.Improvements20261105.LeafCoverageAllocation

/-! The zero-leaf family and its entering cuts are defined from the
actual canonical component partition. Their roots, cuts and heads have
injective ownership, including the original-vertex entry case. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.zeroLeafRoots (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    Finset (FlowVertex d) :=
  ((expandedTree d).cutComponentRoots (a.trueCuts d P)).filter (fun r =>
    r ≠ .inl d.tree.root ∧ a.componentOutgoingCuts d P r = ∅ ∧
      (a.actualComponentHeads d P r).Nonempty ∧
      ∀ c ∈ a.actualComponentHeads d P r, edgeSum x (d.backGroup c) ≤ 1)

noncomputable def GatedDrops.zeroLeafEntryCuts (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    Finset (expandedTree d).Child :=
  (a.trueCuts d P).filter (fun w => (w : FlowVertex d) ∈ a.zeroLeafRoots d P x)

theorem GatedDrops.zeroLeafRoot_spec (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ)
    (r : FlowVertex d) (hr : r ∈ a.zeroLeafRoots d P x) :
    r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P) ∧
    r ≠ .inl d.tree.root ∧ a.componentOutgoingCuts d P r = ∅ ∧
    (a.actualComponentHeads d P r).Nonempty ∧
    ∀ c ∈ a.actualComponentHeads d P r, edgeSum x (d.backGroup c) ≤ 1 :=
  Finset.mem_filter.mp hr

theorem GatedDrops.zeroLeafEntryCuts_subset (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    a.zeroLeafEntryCuts d P x ⊆ a.trueCuts d P := Finset.filter_subset _ _

theorem GatedDrops.zeroLeafEntryCuts_image (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    (a.zeroLeafEntryCuts d P x).image (fun w : (expandedTree d).Child => (w : FlowVertex d)) =
      a.zeroLeafRoots d P x := by
  ext r
  constructor
  · intro hr
    obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hr
    exact (Finset.mem_filter.mp hw).2
  · intro hr
    have hh := a.zeroLeafRoot_spec d P x r hr
    rcases Finset.mem_insert.mp hh.1 with hroot | hcut
    · exact (hh.2.1 hroot).elim
    · obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hcut
      exact Finset.mem_image.mpr ⟨w,Finset.mem_filter.mpr ⟨hw,hr⟩,rfl⟩

theorem GatedDrops.zeroLeafEntryCuts_card (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    (a.zeroLeafEntryCuts d P x).card = (a.zeroLeafRoots d P x).card := by
  rw [← a.zeroLeafEntryCuts_image d P x]
  exact (Finset.card_image_iff.mpr (fun w _ v _ h => Subtype.ext h)).symm

theorem GatedDrops.zeroLeafEntryCuts_sum (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ)
    (f : FlowVertex d → ℝ) :
    (∑ w ∈ a.zeroLeafEntryCuts d P x, f (w : FlowVertex d)) =
      ∑ r ∈ a.zeroLeafRoots d P x, f r := by
  rw [← a.zeroLeafEntryCuts_image d P x,
    Finset.sum_image (fun w _ v _ h => Subtype.ext h)]

theorem GatedDrops.zeroLeafRoots_headful_subset (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    a.zeroLeafRoots d P x ⊆ (a.headfulLeafComponents d P).image
      (fun r : a.Component d P => (r : FlowVertex d)) := by
  intro r hr
  have hh := a.zeroLeafRoot_spec d P x r hr
  refine Finset.mem_image.mpr ⟨⟨r,hh.1⟩,?_,rfl⟩
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,
    (by rw [hh.2.2.1]; exact Finset.not_nonempty_empty),hh.2.2.2.1⟩

theorem GatedDrops.zeroLeafRoots_card_le_headful (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) :
    (a.zeroLeafRoots d P x).card ≤ (a.headfulLeafComponents d P).card := by
  have h := Finset.card_le_card (a.zeroLeafRoots_headful_subset d P x)
  have he : ((a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d))).card =
      (a.headfulLeafComponents d P).card := Finset.card_image_iff.mpr (fun w _ v _ h => Subtype.ext h)
  rwa [he] at h

end TSP.Improvements20261105
