import TSP.Improvements20261105.GatedComponentChildren

/-! Sum parentwise inequalities over the actual internal components.
Selected heads and empty children are each counted exactly once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_heads_outside_internal (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : r ∉ a.internalComponents d P) : a.componentHeads d P r = ∅ := by
  have hn : ¬(a.componentOutgoingCuts d P r).Nonempty := by
    intro hh
    exact hr (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hh⟩)
  exact canonical_leaf_component_headless d hs hc P hP t ht f hf hb a ha hcan r
    (Finset.not_nonempty_iff_eq_empty.mp hn)

theorem canonical_internal_head_charge_sum (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (q : d.tree.Child → ℝ) :
    (∑ r ∈ a.internalComponents d P, ∑ s ∈ a.componentHeads d P r, q s) =
      ∑ s ∈ a.selectedHeads d, q s := by
  rw [← a.head_charge_fiber_sum d P q]
  apply Finset.sum_subset (Finset.subset_univ _)
  intro r _ hr
  rw [canonical_heads_outside_internal d hs hc P hP t ht f hf hb a ha hcan r hr]
  exact Finset.sum_empty

theorem canonical_internal_head_count_sum (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P)) :
    (∑ r ∈ a.internalComponents d P, ((a.componentHeads d P r).card : ℝ)) = (a.selectedHeads d).card := by
  simpa only [Finset.sum_const, nsmul_eq_mul, mul_one] using
    canonical_internal_head_charge_sum d hs hc P hP t ht f hf hb a ha hcan (fun _ => 1)

theorem canonical_component_incidence_sum (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (D : ℝ) (q : d.tree.Child → ℝ) (err : a.Component d P → ℝ)
    (hlocal : ∀ r ∈ a.internalComponents d P,
      D * (1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card) ≤
        (∑ s ∈ a.componentHeads d P r, q s) + err r) :
    D * (((a.internalComponents d P).card : ℝ) + (a.emptyLeafComponents d P).card - (a.selectedHeads d).card) ≤
      (∑ s ∈ a.selectedHeads d, q s) + ∑ r ∈ a.internalComponents d P, err r := by
  have hh := Finset.sum_le_sum hlocal
  simp only [← Finset.mul_sum, Finset.sum_sub_distrib, Finset.sum_add_distrib,
    Finset.sum_const, nsmul_eq_mul, mul_one] at hh
  have he : (∑ r ∈ a.internalComponents d P, ((a.componentEmptyChildren d hs hc P r).card : ℝ)) =
      (a.emptyLeafComponents d P).card := by exact_mod_cast a.internal_empty_child_sum d hs hc P
  rw [he, canonical_internal_head_count_sum d hs hc P hP t ht f hf hb a ha hcan,
    canonical_internal_head_charge_sum d hs hc P hP t ht f hf hb a ha hcan q] at hh
  exact hh

theorem canonical_dual_incidence_sum (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (D : ℝ) (q : d.tree.Child → ℝ) (err : a.Component d P → ℝ)
    (hlocal : ∀ r ∈ a.internalComponents d P,
      D * (1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card) ≤
        (∑ s ∈ a.componentHeads d P r, q s) + err r) :
    D * a.value d P (fun _ => 0) ≤ (∑ s ∈ a.selectedHeads d, q s) +
      D * ((a.headfulLeafComponents d P).card - 1 - (a.selectedRootHeads d).card -
        ∑ s : d.tree.Child, (a.penalty d P s : ℝ)) + ∑ r ∈ a.internalComponents d P, err r := by
  have hh := canonical_component_incidence_sum d hs hc P hP t ht f hf hb a ha hcan D q err hlocal
  have he := a.component_dual_ledger d hs hc ha
  rw [he]
  nlinarith

end TSP.Improvements20261105
