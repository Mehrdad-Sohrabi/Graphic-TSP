import TSP.Improvements20261105.GuardFromFiniteEvent

/-! Explicit finite mixtures retain enough information to compose
edge-disjoint guards without assuming their events are independent. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Classical
open scoped BigOperators symmDiff
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

structure JoinMixture (G : Graph V E) (T : Finset V) where
  Index : Type
  finiteIndex : Fintype Index
  weights : Index → ℝ
  atoms : Index → Finset E
  nonnegative : ∀ i, 0 ≤ weights i
  total : @Finset.sum Index ℝ _ (@Finset.univ Index finiteIndex) weights = 1
  joins : ∀ i, G.IsJoin T (atoms i)

attribute [instance] JoinMixture.finiteIndex

noncomputable def JoinMixture.point {G : Graph V E} {T : Finset V} (M : JoinMixture G T) : E → ℝ :=
  fun e => ∑ i, M.weights i * incidence (M.atoms i) e

noncomputable def JoinMixture.eventMass {G : Graph V E} {T : Finset V} (M : JoinMixture G T) (N : Finset E) : ℝ :=
  ∑ i, M.weights i * (if N ⊆ M.atoms i then (1 : ℝ) else 0)

 theorem JoinMixture.feasible {G : Graph V E} {T : Finset V} (M : JoinMixture G T) :
    M.point ∈ joinPolytope G T (G.intDegree Finset.univ) := by
  apply mem_convexHull_iff_exists_fintype.mpr
  refine ⟨M.Index, M.finiteIndex, M.weights, fun i => incidence (M.atoms i), M.nonnegative, M.total, ?_, ?_⟩
  · intro i
    exact ⟨M.atoms i, rfl, M.joins i, fun v => selected_degree_le_graph_degree G (M.atoms i) v⟩
  · ext e
    simp [JoinMixture.point, Finset.sum_apply, Pi.smul_apply, smul_eq_mul]

 theorem JoinMixture.eventMass_filter {G : Graph V E} {T : Finset V} (M : JoinMixture G T) (N : Finset E) :
    M.eventMass N = ∑ i ∈ Finset.univ.filter (fun i => N ⊆ M.atoms i), M.weights i := by
  simp only [JoinMixture.eventMass, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro i _
  split_ifs <;> simp

noncomputable def JoinMixture.thin {G : Graph V E} {T : Finset V} (M : JoinMixture G T)
    (C : Finset E) (hC : ∀ v, Even (G.intDegree C v))
    (r : M.Index → ℝ) (hr : ∀ i, 0 ≤ r i ∧ r i ≤ M.weights i) : JoinMixture G T where
  Index := M.Index ⊕ M.Index
  finiteIndex := inferInstance
  weights := Sum.elim (fun i => M.weights i - r i) r
  atoms := Sum.elim M.atoms (fun i => M.atoms i ∆ C)
  nonnegative := by intro i; cases i with
    | inl i => exact sub_nonneg.mpr (hr i).2
    | inr i => exact (hr i).1
  total := by
    simp only [Fintype.sum_sum_type, Sum.elim_inl, Sum.elim_inr, Finset.sum_sub_distrib]
    linarith [M.total]
  joins := by intro i; cases i with
    | inl i => exact M.joins i
    | inr i => exact even_toggle_join G T _ C (M.joins i) hC

 theorem JoinMixture.thin_point {G : Graph V E} {T : Finset V} (M : JoinMixture G T)
    (C : Finset E) (hC : ∀ v, Even (G.intDegree C v))
    (r : M.Index → ℝ) (hr : ∀ i, 0 ≤ r i ∧ r i ≤ M.weights i) :
    (M.thin C hC r hr).point = thinnedCyclePoint M.weights M.atoms C r := by
  ext e
  simp [JoinMixture.point, JoinMixture.thin, thinnedCyclePoint, Fintype.sum_sum_type,
    Finset.sum_add_distrib]

 theorem subset_symmDiff_of_disjoint (N C J : Finset E) (hNC : Disjoint N C) :
    N ⊆ J ∆ C ↔ N ⊆ J := by
  constructor
  · intro h e he
    have hn : e ∉ C := fun hc => Finset.disjoint_left.mp hNC he hc
    simpa [Finset.mem_symmDiff, hn] using h he
  · intro h e he
    have hn : e ∉ C := fun hc => Finset.disjoint_left.mp hNC he hc
    simpa [Finset.mem_symmDiff, hn] using h he

 theorem JoinMixture.thin_preserves_event {G : Graph V E} {T : Finset V} (M : JoinMixture G T)
    (C : Finset E) (hC : ∀ v, Even (G.intDegree C v))
    (r : M.Index → ℝ) (hr : ∀ i, 0 ≤ r i ∧ r i ≤ M.weights i)
    (N : Finset E) (hNC : Disjoint N C) :
    (M.thin C hC r hr).eventMass N = M.eventMass N := by
  simp only [JoinMixture.eventMass, JoinMixture.thin, Fintype.sum_sum_type,
    Sum.elim_inl, Sum.elim_inr, subset_symmDiff_of_disjoint N C _ hNC]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  ring

 theorem JoinMixture.guard {G : Graph V E} {T : Finset V} (M : JoinMixture G T)
    (C N : Finset E) (hC : ∀ v, Even (G.intDegree C v)) (hNC : N ⊆ C)
    (m : ℝ) (hm : 0 ≤ m) (hevent : m ≤ M.eventMass N) :
    ∃ R : JoinMixture G T,
      (∀ e ∉ C, R.point e = M.point e) ∧
      (∀ e ∈ N, R.point e = M.point e - m) ∧
      (∀ S : Finset E, edgeSum M.point S - edgeSum R.point S ≤ ((S ∩ C).card : ℝ)*m) ∧
      (∀ S : Finset E, Disjoint S C → R.eventMass S = M.eventMass S) := by
  rw [M.eventMass_filter] at hevent
  obtain ⟨r, hr, hoff, hsum⟩ := finite_event_thinning M.weights (Finset.univ.filter (fun i => N ⊆ M.atoms i))
    m M.nonnegative hm hevent
  have hselected : ∀ i, r i ≠ 0 → N ⊆ M.atoms i := by
    intro i hi
    by_contra hn
    exact hi (hoff i (by simpa using hn))
  refine ⟨M.thin C hC r hr, ?_, ?_, ?_, fun S hS => M.thin_preserves_event C hC r hr S hS⟩
  · intro e he
    rw [M.thin_point, thinnedCyclePoint_outside _ _ _ _ e he]
    rfl
  · intro e he
    rw [M.thin_point, thinnedCyclePoint_selected _ _ _ _ e (hNC he) (fun i hi => hselected i hi he), hsum]
    rfl
  · intro S
    rw [M.thin_point]
    simpa only [hsum, JoinMixture.point] using thinnedCyclePoint_set_loss M.weights M.atoms C S r (fun i => (hr i).1)

end TSP.Improvements20261105
