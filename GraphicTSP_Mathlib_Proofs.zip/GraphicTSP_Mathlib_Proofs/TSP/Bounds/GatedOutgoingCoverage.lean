import TSP.Improvements20261105.GatedComponentMass

/-! Outgoing true-cut coverage is paid by selected heads in that same
component. A back is counted at most once, by the actual path constraints. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.outgoingCoverage (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (r : FlowVertex d) : ℝ :=
  ∑ w ∈ a.componentOutgoingCuts d P r, a.cutCoverage d x w

noncomputable def GatedDrops.outgoingDeficit (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (r : FlowVertex d) : ℝ :=
  ∑ w ∈ a.componentOutgoingCuts d P r, max (1 - a.cutCoverage d x w) 0

theorem GatedDrops.outgoing_back_path_subset (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (b : BackEdge d) :
    (a.componentOutgoingCuts d P r).filter (onExpandedBackPath d b) ⊆ a.backPathCuts d P b := by
  intro w hw
  have hh := Finset.mem_filter.mp hw
  exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp hh.1).1, hh.2⟩

theorem GatedDrops.outgoing_back_path_head {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (r : FlowVertex d) (b : BackEdge d)
    (w : (expandedTree d).Child) (hw : w ∈ a.componentOutgoingCuts d P r)
    (hp : onExpandedBackPath d b w) : d.anchor b.1 ∈ a.componentHeads d P r := by
  have hwm := Finset.mem_filter.mp hw
  have hpath : w ∈ a.backPathCuts d P b := Finset.mem_filter.mpr ⟨hwm.1, hp⟩
  have hh := a.crossing_back_selected d ha b ⟨w, hpath⟩
  have hparent := a.parent_component_of_back_cut d ha b w hpath
  exact (a.mem_componentHeads d P r _).mpr ⟨hh, hparent.symm.trans hwm.2⟩

theorem GatedDrops.outgoing_back_path_card {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (r : FlowVertex d) (b : BackEdge d) :
    (((a.componentOutgoingCuts d P r).filter (onExpandedBackPath d b)).card : ℝ) ≤
      if d.anchor b.1 ∈ a.componentHeads d P r then 1 else 0 := by
  by_cases hh : d.anchor b.1 ∈ a.componentHeads d P r
  · rw [if_pos hh]
    exact_mod_cast (Finset.card_le_card (a.outgoing_back_path_subset d P r b)).trans
      (a.backPathCuts_card_le_one d ha b)
  · rw [if_neg hh]
    have he : (a.componentOutgoingCuts d P r).filter (onExpandedBackPath d b) = ∅ := by
      apply Finset.eq_empty_iff_forall_not_mem.mpr
      intro w hw
      have hm := Finset.mem_filter.mp hw
      exact hh (a.outgoing_back_path_head d ha r b w hm.1 hm.2)
    simp [he]

theorem ownBackMass_set_sum (x : BackEdge d → ℝ) (H : Finset d.tree.Child) :
    (∑ s ∈ H, ownBackMass d x s) = ∑ b : BackEdge d, if d.anchor b.1 ∈ H then x b else 0 := by
  simp only [ownBackMass]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b _
  simp

theorem GatedDrops.outgoingCoverage_le_head_mass {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) (r : FlowVertex d) :
    a.outgoingCoverage d P x r ≤ ∑ s ∈ a.componentHeads d P r, ownBackMass d x s := by
  rw [ownBackMass_set_sum]
  simp only [outgoingCoverage, cutCoverage]
  rw [Finset.sum_comm]
  apply Finset.sum_le_sum
  intro b _
  rw [← Finset.sum_filter]
  simp only [Finset.sum_const, nsmul_eq_mul]
  have hh := mul_le_mul_of_nonneg_right (a.outgoing_back_path_card d ha r b) (hx b)
  split_ifs at hh ⊢ <;> simpa using hh

theorem GatedDrops.outgoingDeficit_nonneg (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (r : FlowVertex d) : 0 ≤ a.outgoingDeficit d P x r :=
  Finset.sum_nonneg (fun _ _ => le_max_right _ _)

theorem GatedDrops.outgoingDeficit_covers (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (r : FlowVertex d) :
    ((a.componentOutgoingCuts d P r).card : ℝ) ≤
      a.outgoingCoverage d P x r + a.outgoingDeficit d P x r := by
  have hh := Finset.sum_le_sum (s := a.componentOutgoingCuts d P r)
    (fun w _ => le_max_left (1 - a.cutCoverage d x w) 0)
  simpa only [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul, mul_one,
    sub_le_iff_le_add, add_comm] using hh

theorem canonical_singleton_parent_mass_shortfall (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : FlowVertex d) (s : d.tree.Child) (hheads : a.componentHeads d P r = {s})
    (x z : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) :
    2 - ownBackMass d z s ≤ (ownBackMass d x s - ownBackMass d z s) + a.outgoingDeficit d P x r := by
  have hn : (a.componentHeads d P r).Nonempty := by rw [hheads]; simp
  have hp := canonical_component_pruning d hs hc P hP t ht f hf hb a ha hcan r hn
  have hg := a.componentRemovalGain_ge_heads d P t ht r
  rw [hheads, Finset.card_singleton, Nat.cast_one] at hg
  have hk : 2 ≤ (a.componentOutgoingCuts d P r).card := by
    have hh : (1 : ℝ) < (a.componentOutgoingCuts d P r).card := lt_of_le_of_lt hg hp
    exact_mod_cast hh
  have hk' : (2 : ℝ) ≤ (a.componentOutgoingCuts d P r).card := by exact_mod_cast hk
  have hcov := a.outgoingCoverage_le_head_mass d ha x hx r
  rw [hheads, Finset.sum_singleton] at hcov
  have hdef := a.outgoingDeficit_covers d P x r
  linarith

end TSP.Improvements20261105
