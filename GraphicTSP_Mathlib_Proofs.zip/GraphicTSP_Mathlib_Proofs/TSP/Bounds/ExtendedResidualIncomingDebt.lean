import TSP.Improvements20261105.ExtendedResidualMassBalance
import TSP.Improvements20261105.MatchingResidualIncomingBudget
import TSP.Improvements20261105.MatchingUniformLargePayment

/-! Incoming debt at an actual matching source is the sum of its real
residual edges. Injectivity shows that at most one such edge contributes. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def extendedResidualIncomingDebt (x z : E → ℝ)
    (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) (i : d.StarIndex) : ℝ :=
  ∑ p ∈ (extendedResidualOutside d x z ν H M).filter (fun p => p.2=i), actualCouponResidual d x z p.1

theorem extendedResidualIncomingDebt_nonnegative (x z : E → ℝ)
    (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) (i : d.StarIndex) : 0 ≤ extendedResidualIncomingDebt d x z ν H M i :=
  Finset.sum_nonneg (fun p _ => actualCouponResidual_nonnegative d x z p.1)

theorem extendedResidualIncomingDebt_eq_edge (x z : E → ℝ)
    (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ extendedResidualOutside d x z ν H M) :
    extendedResidualIncomingDebt d x z ν H M p.2=actualCouponResidual d x z p.1 := by
  unfold extendedResidualIncomingDebt
  apply Finset.sum_eq_single p
  · intro q hq hne
    have he := couponResidualStarPairs_snd_injective d x z (extendedResidualDonors d x z ν H M)
      (Finset.mem_filter.mp (Finset.mem_filter.mp hq).1).1 (Finset.mem_filter.mp hp).1
      (Finset.mem_filter.mp hq).2
    exact (hne he).elim
  · intro hn
    exact (hn (Finset.mem_filter.mpr ⟨hp,rfl⟩)).elim

theorem extendedResidualIncomingDebt_matching_cap (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) (i : d.StarIndex) (hi : i.1 ∈ C.matching) :
    extendedResidualIncomingDebt d x z ν H M i ≤ min (1-x (d.treeEdge i.1)-survivingExcess d x i.1) (1/2) := by
  by_cases hex : ∃ p ∈ extendedResidualOutside d x z ν H M, p.2=i
  · obtain ⟨p,hp,rfl⟩ := hex
    rw [extendedResidualIncomingDebt_eq_edge d x z ν H M p hp]
    exact actual_matching_source_residual_cap d hs x z hx hn hcap hm C _ p (Finset.mem_filter.mp hp).1 hi
  · have hz : extendedResidualIncomingDebt d x z ν H M i=0 := by
      apply Finset.sum_eq_zero
      intro p hp
      have hh := Finset.mem_filter.mp hp
      exact (hex ⟨p,hh.1,hh.2⟩).elim
    rw [hz]
    have hb := (survivingExcess_bounds d hs hx hcap i.1).2
    exact le_min (by linarith only [hb]) (by norm_num)

theorem extendedResidualIncomingDebt_sum (x z : E → ℝ)
    (ν : d.tree.Child → ℤ)
    (H M U : Finset d.StarIndex)
    (hU : ∀ p ∈ extendedResidualOutside d x z ν H M, p.2 ∈ U) :
    (∑ i ∈ U, extendedResidualIncomingDebt d x z ν H M i)=
      ∑ p ∈ extendedResidualOutside d x z ν H M, actualCouponResidual d x z p.1 := by
  simp only [extendedResidualIncomingDebt,Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro p hp
  simpa [hU p hp, eq_comm] using Finset.sum_ite_eq' U p.2 (fun _ => actualCouponResidual d x z p.1)

end TSP.Improvements20261105
