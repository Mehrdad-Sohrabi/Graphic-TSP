import TSP.Improvements20261105.DisjointCycleGuards

/-! Exact accounting of marginal savings on a common edge set for a
family of disjoint guards. Each cycle intersection is counted once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Classical
open scoped BigOperators
variable {E A : Type} [DecidableEq E] [DecidableEq A]

 theorem disjoint_guard_savings (F : Finset A) (C N : A → Finset E) (B : Finset E)
    (m : A → ℝ) (Q R : E → ℝ)
    (hinter : ∀ a ∈ F, C a ∩ B = N a)
    (hdis : ∀ a ∈ F, ∀ b ∈ F, a ≠ b → Disjoint (C a) (C b))
    (hout : ∀ e, (∀ a ∈ F, e ∉ C a) → R e = Q e)
    (hpath : ∀ a ∈ F, ∀ e ∈ N a, R e = Q e - m a) :
    edgeSum R B = edgeSum Q B - ∑ a ∈ F, (((N a).card : ℝ)*m a) := by
  have hNC : ∀ a ∈ F, N a ⊆ C a := by
    intro a ha
    rw [← hinter a ha]
    exact Finset.inter_subset_left
  have hNB : ∀ a ∈ F, N a ⊆ B := by
    intro a ha
    rw [← hinter a ha]
    exact Finset.inter_subset_right
  have hlocal (e : E) (he : e ∈ B) : Q e - R e = ∑ a ∈ F, (if e ∈ N a then m a else 0) := by
    by_cases hex : ∃ a ∈ F, e ∈ N a
    · obtain ⟨a, ha, heN⟩ := hex
      rw [Finset.sum_eq_single a, if_pos heN, hpath a ha e heN]
      · ring
      · intro b hb hba
        have hbN : e ∉ N b := by
          intro hbe
          exact Finset.disjoint_left.mp (hdis b hb a ha hba) (hNC b hb hbe) (hNC a ha heN)
        exact if_neg hbN
      · exact fun hn => False.elim (hn ha)
    · have hnot : ∀ a ∈ F, e ∉ N a := by
        intro a ha hn; exact hex ⟨a, ha, hn⟩
      have hCnot : ∀ a ∈ F, e ∉ C a := by
        intro a ha hc
        have hi := Finset.mem_inter.mpr ⟨hc, he⟩
        rw [hinter a ha] at hi
        exact hnot a ha hi
      rw [hout e hCnot, sub_self]
      exact (Finset.sum_eq_zero (fun a ha => if_neg (hnot a ha))).symm
  have hd : edgeSum Q B - edgeSum R B = ∑ a ∈ F, (((N a).card : ℝ)*m a) := by
    rw [edgeSum, edgeSum, ← Finset.sum_sub_distrib]
    rw [Finset.sum_congr rfl hlocal, Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro a ha
    have hf : B.filter (fun e => e ∈ N a) = N a := by
      ext e
      simp only [Finset.mem_filter]
      exact ⟨And.right, fun hn => ⟨hNB a ha hn, hn⟩⟩
    rw [← Finset.sum_filter, hf]
    simp
  linarith

 theorem disjoint_guard_savings_at_least (F : Finset A) (N : A → Finset E)
    (B : Finset E) (m : A → ℝ) (Q R : E → ℝ)
    (hN : ∀ a ∈ F, (N a).Nonempty) (hm : ∀ a ∈ F, 0 ≤ m a)
    (heq : edgeSum R B = edgeSum Q B - ∑ a ∈ F, (((N a).card : ℝ)*m a)) :
    edgeSum R B ≤ edgeSum Q B - ∑ a ∈ F, m a := by
  have hsum : (∑ a ∈ F, m a) ≤ ∑ a ∈ F, (((N a).card : ℝ)*m a) := by
    apply Finset.sum_le_sum
    intro a ha
    have hc : (1 : ℝ) ≤ ((N a).card : ℝ) := by exact_mod_cast Finset.card_pos.mpr (hN a ha)
    nlinarith [hm a ha]
  linarith

end TSP.Improvements20261105
