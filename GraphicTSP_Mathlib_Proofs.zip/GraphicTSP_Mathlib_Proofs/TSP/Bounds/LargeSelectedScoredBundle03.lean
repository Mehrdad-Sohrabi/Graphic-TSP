import TSP.Improvements20261105.LargeSelectedGreedyScoredSourceEnvelope
import TSP.Improvements20261105.LargeSelectedScoredT7R4CapPointwise
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_30
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (19703/64000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (19703/64000 : ℝ) (86357/197030 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (64164215683/443987402:ℝ)*hMl + (48/1:ℝ)*hzl + (96006239443/887974804:ℝ)*hR0 + (463/2:ℝ)*hRo + (64164215683/443987402:ℝ)*hchoice + (88248532387/443987402:ℝ)*hg0 + (98904230035/443987402:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (68099838083/443987402:ℝ)*hMl + (20528/361:ℝ)*hzl + (99941861843/887974804:ℝ)*hR0 + (173543/722:ℝ)*hRo + (68099838083/443987402:ℝ)*hchoice + (88248532387/443987402:ℝ)*hg0 + (98904230035/443987402:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_31
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (19703/64000 : ℝ) ≤ M) (hMu : M ≤ (13919/44800 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (13919/44800 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (45407406859/313650746:ℝ)*hMl + (48/1:ℝ)*hzl + (67743512539/627301492:ℝ)*hR0 + (463/2:ℝ)*hRo + (45407406859/313650746:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (915566119121/5959364174:ℝ)*hMl + (20528/361:ℝ)*hzl + (1339952127041/11918728348:ℝ)*hR0 + (173543/722:ℝ)*hRo + (915566119121/5959364174:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_32
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (13919/44800 : ℝ))
    (hzl : (13/2560 : ℝ) ≤ z) (hzu : z ≤ (13/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (13919/44800 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/1280 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (45407406859/313650746:ℝ)*hMl + (48/1:ℝ)*hzl + (67743512539/627301492:ℝ)*hR0 + (463/2:ℝ)*hRo + (45407406859/313650746:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (915566119121/5959364174:ℝ)*hMl + (20528/361:ℝ)*hzl + (1339952127041/11918728348:ℝ)*hR0 + (173543/722:ℝ)*hRo + (915566119121/5959364174:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_33
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (13919/44800 : ℝ) ≤ M) (hMu : M ≤ (140459/448000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (140459/448000 : ℝ) (652721/1404590 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (458998627399/3165103106:ℝ)*hMl + (48/1:ℝ)*hzl + (682826574679/6330206212:ℝ)*hR0 + (463/2:ℝ)*hRo + (458998627399/3165103106:ℝ)*hchoice + (630691214311/3165103106:ℝ)*hg0 + (706653688855/3165103106:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (9254043917381/60136959014:ℝ)*hMl + (20528/361:ℝ)*hzl + (13506774915701/120273918028:ℝ)*hR0 + (173543/722:ℝ)*hRo + (9254043917381/60136959014:ℝ)*hchoice + (630691214311/3165103106:ℝ)*hg0 + (706653688855/3165103106:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_34
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (140459/448000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (14497599569/99803086:ℝ)*hMl + (48/1:ℝ)*hzl + (21506813249/199606172:ℝ)*hR0 + (463/2:ℝ)*hRo + (14497599569/99803086:ℝ)*hchoice + (19911467441/99803086:ℝ)*hg0 + (22306741505/99803086:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (292263332611/1896258634:ℝ)*hMl + (20528/361:ℝ)*hzl + (425438392531/3792517268:ℝ)*hR0 + (173543/722:ℝ)*hRo + (292263332611/1896258634:ℝ)*hchoice + (19911467441/99803086:ℝ)*hg0 + (22306741505/99803086:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_35
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (13919/44800 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/2560 : ℝ) ≤ z) (hzu : z ≤ (13/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (13/1280 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hMl + (48/1:ℝ)*hzl + (12/1:ℝ)*hR0 + (24/1:ℝ)*hRo + (24/1:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (11864/361:ℝ)*hMl + (20528/361:ℝ)*hzl + (5932/361:ℝ)*hR0 + (11864/361:ℝ)*hRo + (11864/361:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_36
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/1280 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hMl + (48/1:ℝ)*hzl + (12/1:ℝ)*hR0 + (24/1:ℝ)*hRo + (24/1:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (11864/361:ℝ)*hMl + (20528/361:ℝ)*hzl + (5932/361:ℝ)*hR0 + (11864/361:ℝ)*hRo + (11864/361:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_37
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/640 : ℝ) ≤ z) (hzu : z ≤ (13/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (13/320 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hMl + (48/1:ℝ)*hzl + (12/1:ℝ)*hR0 + (24/1:ℝ)*hRo + (24/1:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (11864/361:ℝ)*hMl + (20528/361:ℝ)*hzl + (5932/361:ℝ)*hR0 + (11864/361:ℝ)*hRo + (11864/361:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_38
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/320 : ℝ) ≤ z) (hzu : z ≤ (13/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (560880112/35772329:ℝ)*hR0 + (998226556/35772329:ℝ)*hRo + (477875218584/21212991097:ℝ)*hchoice + (79645869764/21212991097:ℝ)*hem + (16156992/35772329:ℝ)*hgap + (1/1:ℝ)*hH0 + (673208/35772329:ℝ)*hC + (1/1:ℝ)*hI + (35099121/35772329:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (831785206096/38741432307:ℝ)*hR0 + (1480369982548/38741432307:ℝ)*hRo + (236229649720024/7657889786017:ℝ)*hchoice + (118114824860012/22973669358051:ℝ)*hem + (420365248/679674251:ℝ)*hgap + (1/1:ℝ)*hH0 + (52545656/2039022753:ℝ)*hC + (1/1:ℝ)*hI + (1986477097/2039022753:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_39
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/160 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (560880112/35772329:ℝ)*hR0 + (998226556/35772329:ℝ)*hRo + (477875218584/21212991097:ℝ)*hchoice + (79645869764/21212991097:ℝ)*hem + (16156992/35772329:ℝ)*hgap + (1/1:ℝ)*hH0 + (673208/35772329:ℝ)*hC + (1/1:ℝ)*hI + (35099121/35772329:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (831785206096/38741432307:ℝ)*hR0 + (1480369982548/38741432307:ℝ)*hRo + (236229649720024/7657889786017:ℝ)*hchoice + (118114824860012/22973669358051:ℝ)*hem + (420365248/679674251:ℝ)*hgap + (1/1:ℝ)*hH0 + (52545656/2039022753:ℝ)*hC + (1/1:ℝ)*hI + (1986477097/2039022753:ℝ)*hsource + (11864/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_40
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hMl + (48/1:ℝ)*hzl + (12/1:ℝ)*hR0 + (24/1:ℝ)*hRo + (24/1:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (11864/361:ℝ)*hMl + (20528/361:ℝ)*hzl + (5932/361:ℝ)*hR0 + (11864/361:ℝ)*hRo + (11864/361:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_41
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (560880112/35772329:ℝ)*hR0 + (998226556/35772329:ℝ)*hRo + (477875218584/21212991097:ℝ)*hchoice + (79645869764/21212991097:ℝ)*hem + (16156992/35772329:ℝ)*hgap + (1/1:ℝ)*hH0 + (673208/35772329:ℝ)*hC + (1/1:ℝ)*hI + (35099121/35772329:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (857607263560/38741432307:ℝ)*hR0 + (19842248366890/503638619991:ℝ)*hRo + (3166321552467820/99552567218221:ℝ)*hchoice + (1583160776233910/298657701654663:ℝ)*hem + (5634396640/8835765263:ℝ)*hgap + (1/1:ℝ)*hH0 + (704299580/26507295789:ℝ)*hC + (1/1:ℝ)*hI + (25802996209/26507295789:ℝ)*hsource + (159020/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_42
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (7589/28000 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (7589/28000 : ℝ) (18191/75890 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2274072975/1874483:ℝ)*hMu + (768/13:ℝ)*hzl + (6322944/146471:ℝ)*hqM + (56084969/292942:ℝ)*hR0 + (6307/26:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (42938402009/35615177:ℝ)*hMu + (312692/4693:ℝ)*hzl + (99117644/2782949:ℝ)*hqM + (1107650995/5565898:ℝ)*hR0 + (2347715/9386:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_43
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (91/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (91/320 : ℝ) (22/91 : ℝ) (289/910 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4896/91:ℝ)*hzl + (4875342512/250406303:ℝ)*hR0 + (112799600828/3255281939:ℝ)*hRo + (53999899699992/1930382189827:ℝ)*hchoice + (8999983283332/1930382189827:ℝ)*hem + (1825740096/3255281939:ℝ)*hgap + (1/1:ℝ)*hH0 + (76072504/3255281939:ℝ)*hC + (1/1:ℝ)*hI + (3179209435/3255281939:ℝ)*hsource + (2712/91:ℝ)*hmass
  · linear_combination (2065724/32851:ℝ)*hzl + (6888578529400/271190026149:ℝ)*hR0 + (159379347497350/3525470339937:ℝ)*hRo + (25432917362389300/696867970527547:ℝ)*hchoice + (12716458681194650/2090603911582641:ℝ)*hem + (45257293600/61850356841:ℝ)*hgap + (1/1:ℝ)*hH0 + (5657161700/185551070523:ℝ)*hC + (1/1:ℝ)*hI + (179893908823/185551070523:ℝ)*hsource + (1277300/32851:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_44
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (91/320 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (819747856/35772329:ℝ)*hR0 + (18966304564/465040277:ℝ)*hRo + (9079629153096/275768884261:ℝ)*hchoice + (1513271525516/275768884261:ℝ)*hem + (306982848/465040277:ℝ)*hgap + (1/1:ℝ)*hH0 + (12790952/465040277:ℝ)*hC + (1/1:ℝ)*hI + (452249325/465040277:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (1078939184680/38741432307:ℝ)*hR0 + (24963150599170/503638619991:ℝ)*hRo + (3983488176246460/99552567218221:ℝ)*hchoice + (1991744088123230/298657701654663:ℝ)*hem + (7088525920/8835765263:ℝ)*hgap + (1/1:ℝ)*hH0 + (886065740/26507295789:ℝ)*hC + (1/1:ℝ)*hI + (25621230049/26507295789:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_45
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hMl + (48/1:ℝ)*hzl + (12/1:ℝ)*hR0 + (24/1:ℝ)*hRo + (24/1:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (159020/4693:ℝ)*hMl + (271652/4693:ℝ)*hzl + (79510/4693:ℝ)*hR0 + (159020/4693:ℝ)*hRo + (159020/4693:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (159020/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_46
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (91/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (91/320 : ℝ) (22/91 : ℝ) (289/910 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2712/91:ℝ)*hMl + (4896/91:ℝ)*hzl + (1356/91:ℝ)*hR0 + (2712/91:ℝ)*hRo + (2712/91:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2712/91:ℝ)*hmass
  · linear_combination (1277300/32851:ℝ)*hMl + (2065724/32851:ℝ)*hzl + (638650/32851:ℝ)*hR0 + (1277300/32851:ℝ)*hRo + (1277300/32851:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1277300/32851:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_47
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (91/320 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (456/13:ℝ)*hMl + (768/13:ℝ)*hzl + (228/13:ℝ)*hR0 + (456/13:ℝ)*hRo + (456/13:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (200060/4693:ℝ)*hMl + (312692/4693:ℝ)*hzl + (100030/4693:ℝ)*hR0 + (200060/4693:ℝ)*hRo + (200060/4693:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_48
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (456/13:ℝ)*hMl + (768/13:ℝ)*hzl + (228/13:ℝ)*hR0 + (456/13:ℝ)*hRo + (456/13:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (200060/4693:ℝ)*hMl + (312692/4693:ℝ)*hzl + (100030/4693:ℝ)*hR0 + (200060/4693:ℝ)*hRo + (200060/4693:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_49
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (7589/28000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (7589/28000 : ℝ) (18191/75890 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1911792985/1586101:ℝ)*hMu + (736/11:ℝ)*hzl + (4379488/123937:ℝ)*hqM + (49397903/247874:ℝ)*hR0 + (5509/22:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (36164788783/30135919:ℝ)*hMu + (286684/3971:ℝ)*hzl + (70764388/2354803:ℝ)*hqM + (963451925/4709606:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_50
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3744/59:ℝ)*hzl + (16499785366/129059609:ℝ)*hR0 + (29141/118:ℝ)*hRo + (10406660871387/76532348137:ℝ)*hchoice + (3468886957129/153064696274:ℝ)*hem + (22555122315/129059609:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (322301777330/2452132571:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (205559364913305/1454114614603:ℝ)*hchoice + (68519788304435/2908229229206:ℝ)*hem + (426345860141/2452132571:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_51
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_52
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (42782152176/393495619:ℝ)*hR0 + (82734716412/393495619:ℝ)*hRo + (28142294374296/233342902067:ℝ)*hchoice + (4690382395716/233342902067:ℝ)*hem + (38082030144/1967478095:ℝ)*hgap + (1586751256/1967478095:ℝ)*hC + (1/1:ℝ)*hI + (380726839/1967478095:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (15934846593480/142051918459:ℝ)*hR0 + (30740181747954/142051918459:ℝ)*hRo + (10577270147772564/84236787646187:ℝ)*hchoice + (1762878357962094/84236787646187:ℝ)*hem + (727276806816/37382083805:ℝ)*hgap + (30303200284/37382083805:ℝ)*hC + (1/1:ℝ)*hI + (7078883521/37382083805:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_53
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (12024783392/107316987:ℝ)*hR0 + (23199248648/107316987:ℝ)*hRo + (2659757868272/21212991097:ℝ)*hchoice + (1329878934136/63638973291:ℝ)*hem + (3479138944/178861645:ℝ)*hgap + (434892368/536584935:ℝ)*hC + (1/1:ℝ)*hI + (101692567/536584935:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (1479139394592/12913810769:ℝ)*hR0 + (2848874576520/12913810769:ℝ)*hRo + (987570769645008/7657889786017:ℝ)*hchoice + (164595128274168/7657889786017:ℝ)*hem + (66347412096/3398371255:ℝ)*hgap + (2764475504/3398371255:ℝ)*hC + (1/1:ℝ)*hI + (633895751/3398371255:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_54
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_55
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (65905362029448/509285465513:ℝ)*hMl + (5509/22:ℝ)*hzl + (44170111150020/509285465513:ℝ)*hR0 + (95191563799944/509285465513:ℝ)*hRo + (65905362029448/509285465513:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (24763552360829532/183852053050193:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (16431268459256622/183852053050193:ℝ)*hR0 + (35335871199978588/183852053050193:ℝ)*hRo + (24763552360829532/183852053050193:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_56
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_57
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2697361975368/20732808833:ℝ)*hMl + (5509/22:ℝ)*hzl + (76618102140/901426471:ℝ)*hR0 + (3837073900104/20732808833:ℝ)*hRo + (2697361975368/20732808833:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1013305872361212/7484543988713:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (28519095725874/325414956031:ℝ)*hR0 + (1424741877190908/7484543988713:ℝ)*hRo + (1013305872361212/7484543988713:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_58
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_59
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (5776369856/50701605:ℝ)*hR0 + (11289993008/50701605:ℝ)*hRo + (1364520811424/10022017255:ℝ)*hchoice + (682260405712/30066051765:ℝ)*hem + (322682624/16900535:ℝ)*hgap + (40335328/50701605:ℝ)*hC + (1/1:ℝ)*hI + (10366277/50701605:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (699179431728/6101093135:ℝ)*hR0 + (1365860001324/6101093135:ℝ)*hRo + (496105281620856/3617948229055:ℝ)*hchoice + (82684213603476/3617948229055:ℝ)*hem + (1227407808/64222033:ℝ)*hgap + (51141992/64222033:ℝ)*hC + (1/1:ℝ)*hI + (13080041/64222033:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_60
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r3_cap_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (923761951/13821032:ℝ)*hR0 + (244025068/1727629:ℝ)*hRo + (67264875475/1091861528:ℝ)*hchoice + (9609267925/1091861528:ℝ)*hem + (156983814/8638145:ℝ)*hgap + (511/8:ℝ)*htarget + (26163969/34552580:ℝ)*hC + (1/1:ℝ)*hI + (8388611/34552580:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (8555528274847/124734813800:ℝ)*hR0 + (90128219596/623674069:ℝ)*hRo + (329487259463887/5124106150904:ℝ)*hchoice + (47069608494841/5124106150904:ℝ)*hem + (2990370546/164124755:ℝ)*hgap + (187223/2888:ℝ)*htarget + (498395091/656499020:ℝ)*hC + (1/1:ℝ)*hI + (158103929/656499020:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (470073792103/1839683630:ℝ)*hzu + (3816928896/183968363:ℝ)*hR0 + (10889594496/183968363:ℝ)*hRo + (15165815808/919841815:ℝ)*hgap + (116410309768/919841815:ℝ)*htarget + (631908992/919841815:ℝ)*hC + (1/1:ℝ)*hI + (287932823/919841815:ℝ)*hsource + (1/1:ℝ)*hR + (-15334628672/183968363:ℝ)*hmass
  · linear_combination (180059208900247/664125790430:ℝ)*hzu + (3816928896/183968363:ℝ)*hR0 + (10889594496/183968363:ℝ)*hRo + (15165815808/919841815:ℝ)*hgap + (43751216818092/332062895215:ℝ)*htarget + (631908992/919841815:ℝ)*hC + (1/1:ℝ)*hI + (287932823/919841815:ℝ)*hsource + (1/1:ℝ)*hR + (-15334628672/183968363:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (647/2000 : ℝ) (3293/6470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2713293103625/40757085256:ℝ)*hMl + (563000496723/10189271314:ℝ)*hR0 + (5254571667977/40757085256:ℝ)*hRo + (2713293103625/40757085256:ℝ)*hchoice + (426620992512/25473178285:ℝ)*hgap + (511/8:ℝ)*htarget + (17775874688/25473178285:ℝ)*hC + (1/1:ℝ)*hI + (7697303597/25473178285:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (1021560122392817/14713307777416:ℝ)*hMl + (5207263418877651/91958173608850:ℝ)*hR0 + (1938961684123889/14713307777416:ℝ)*hRo + (1021560122392817/14713307777416:ℝ)*hchoice + (426620992512/25473178285:ℝ)*hgap + (187223/2888:ℝ)*htarget + (17775874688/25473178285:ℝ)*hC + (1/1:ℝ)*hI + (7697303597/25473178285:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1065952075753/16189215944:ℝ)*hMl + (5297167120059/101182599650:ℝ)*hR0 + (2024236391401/16189215944:ℝ)*hRo + (1065952075753/16189215944:ℝ)*hchoice + (15165815808/919841815:ℝ)*hgap + (5573/88:ℝ)*htarget + (631908992/919841815:ℝ)*hC + (1/1:ℝ)*hI + (287932823/919841815:ℝ)*hsource + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (404284326127465/5844306955784:ℝ)*hMl + (394140842136639/7305383694730:ℝ)*hR0 + (750224964076393/5844306955784:ℝ)*hRo + (404284326127465/5844306955784:ℝ)*hchoice + (15165815808/919841815:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (631908992/919841815:ℝ)*hC + (1/1:ℝ)*hI + (287932823/919841815:ℝ)*hsource + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24165110096/183968363:ℝ)*hMl + (511/2:ℝ)*hzl + (385404543552/4599209075:ℝ)*hR0 + (35054704592/183968363:ℝ)*hRo + (24165110096/183968363:ℝ)*hchoice + (15165815808/919841815:ℝ)*hgap + (631908992/919841815:ℝ)*hC + (1/1:ℝ)*hI + (287932823/919841815:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (8976745212144/66412579043:ℝ)*hMl + (187223/722:ℝ)*hzl + (142168725832128/1660314476075:ℝ)*hR0 + (12907888825200/66412579043:ℝ)*hRo + (8976745212144/66412579043:ℝ)*hchoice + (15165815808/919841815:ℝ)*hgap + (631908992/919841815:ℝ)*hC + (1/1:ℝ)*hI + (287932823/919841815:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hzl + (3460852058/33175175:ℝ)*hR0 + (285729820/1327007:ℝ)*hRo + (13606341686/104833553:ℝ)*hchoice + (1943763098/104833553:ℝ)*hem + (123800352/6635035:ℝ)*hgap + (5158348/6635035:ℝ)*hC + (1/1:ℝ)*hI + (1476687/6635035:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (1264486360917/11976238175:ℝ)*hR0 + (104278228158/479049527:ℝ)*hRo + (64819107659607/491983864229:ℝ)*hchoice + (9259872522801/491983864229:ℝ)*hem + (2356341168/126065665:ℝ)*hgap + (98180882/126065665:ℝ)*hC + (1/1:ℝ)*hI + (27884783/126065665:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (17667595168/165875875:ℝ)*hR0 + (1455799616/6635035:ℝ)*hRo + (907592223328/6814180945:ℝ)*hchoice + (129656031904/6814180945:ℝ)*hem + (24835584/1327007:ℝ)*hgap + (1034816/1327007:ℝ)*hC + (1/1:ℝ)*hI + (292191/1327007:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (6415627200792/59881190875:ℝ)*hR0 + (528355248144/2395247635:ℝ)*hRo + (330041211821832/2459919321145:ℝ)*hchoice + (47148744545976/2459919321145:ℝ)*hem + (2361438336/126065665:ℝ)*hgap + (98393264/126065665:ℝ)*hC + (1/1:ℝ)*hI + (27672401/126065665:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t7_r3_cap_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (1/4 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (46/125 : ℝ) (59/92 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1/1 : ℝ) (1417918/45125 : ℝ) large_selected_scored_t7_r4_cap_point_linear_16 hBu
  have hCaffine := hAffine (1/1 : ℝ) (402468/19513 : ℝ) (133626/19513 : ℝ) large_selected_scored_t7_r4_cap_point_affine_16 hBu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (89816599643/90229282:ℝ)*hzu + (109928000/3470357:ℝ)*hRo + (1476565019/6940714:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19029413599/90229282:ℝ)*htarget + (4518145/10411071:ℝ)*hS + (5892926/10411071:ℝ)*hC + (1/1:ℝ)*hI + (-1220342155/6940714:ℝ)*hmass
  · linear_combination (33407819139187/32572770802:ℝ)*hzu + (109928000/3470357:ℝ)*hRo + (1476565019/6940714:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7115624976255/32572770802:ℝ)*htarget + (4518145/10411071:ℝ)*hS + (5892926/10411071:ℝ)*hC + (1/1:ℝ)*hI + (-1220342155/6940714:ℝ)*hmass
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource

theorem large_selected_scored_t7_r4_cap_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (77/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (77/320 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_0 hBu
  have hCaffine := hAffine (77/320 : ℝ) (-20774769/1502501 : ℝ) (4325025/1248832 : ℝ) large_selected_scored_t7_r4_cap_point_affine_0 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2795049341/2146430:ℝ)*hBu + (1/1:ℝ)*hCaffine + (575281/2750:ℝ)*hR0 + (26073/110:ℝ)*hRo + (581988377/429286:ℝ)*hchoice + (581988377/3005002:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (52933500071/40782170:ℝ)*hBu + (1/1:ℝ)*hCaffine + (209691289/992750:ℝ)*hR0 + (9580257/39710:ℝ)*hRo + (581988377/429286:ℝ)*hchoice + (581988377/3005002:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (469/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (469/2000 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (149477865/429286:ℝ)*hBl + (1875093178/1073215:ℝ)*hMu + (575281/1430:ℝ)*hqM + (26073/110:ℝ)*hRo + (7497895/39026:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (2906401515/8156434:ℝ)*hBl + (35706356878/20391085:ℝ)*hMu + (209691289/516230:ℝ)*hqM + (9580257/39710:ℝ)*hRo + (7497895/39026:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (785220/19513:ℝ)*hMu + (38865246/55537:ℝ)*hzu + (785220/19513:ℝ)*hqM + (84000/1501:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (20986623/111074:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-454915/3002:ℝ)*hmass
  · linear_combination (785220/19513:ℝ)*hMu + (767472490/1055203:ℝ)*hzu + (785220/19513:ℝ)*hqM + (84000/1501:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (413262245/2110406:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-454915/3002:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (393/1600 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1621/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (393/1600 : ℝ) (89/1310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1621/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_1 hBu
  have hCaffine := hAffine (1621/6400 : ℝ) (-284207097/31630573 : ℝ) (14324565/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_1 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2071692767/1468510:ℝ)*hMu + (327273312/5756335:ℝ)*hqM + (157903717/885590:ℝ)*hR0 + (138217/590:ℝ)*hRo + (988805261/5112406:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (39221885677/27901690:ℝ)*hMu + (5668328912/109370365:ℝ)*hqM + (3084765087/16826210:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (988805261/5112406:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (393/1600 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1621/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1621/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_1 hBu
  have hCaffine := hAffine (1621/6400 : ℝ) (-284207097/31630573 : ℝ) (14324565/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_1 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (55945848862253/557184709000:ℝ)*hR0 + (225302/1145:ℝ)*hRo + (53691556646147/289736048680:ℝ)*hchoice + (7670222378021/289736048680:ℝ)*hem + (1810367012083/57947209736:ℝ)*hg0 + (3201100045747/57947209736:ℝ)*hgap + (112651/2290:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-24571/2290:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (43732295092447/423460378840:ℝ)*hR0 + (16701470/82669:ℝ)*hRo + (209093233883765/1100996984984:ℝ)*hchoice + (29870461983395/1100996984984:ℝ)*hem + (168366781413309/5504984924920:ℝ)*hg0 + (300486419611389/5504984924920:ℝ)*hgap + (8350735/165338:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-904695/165338:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (393/1600 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1621/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1621/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_1 hBu
  have hCaffine := hAffine (1621/6400 : ℝ) (-284207097/31630573 : ℝ) (14324565/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_1 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (29141/118:ℝ)*hzl + (7336200700619/57421655600:ℝ)*hR0 + (29141/118:ℝ)*hRo + (6844515111581/29859260912:ℝ)*hchoice + (977787873083/29859260912:ℝ)*hem + (3727666650897/149296304560:ℝ)*hg0 + (7310777960337/149296304560:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (10787605/42598:ℝ)*hzl + (28624908224837/218202291280:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (133165440614815/567325957328:ℝ)*hchoice + (19023634373545/567325957328:ℝ)*hem + (68597342442203/2836629786640:ℝ)*hg0 + (136676457321563/2836629786640:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (393/1600 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (393/1600 : ℝ) (89/1310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (789518585/2302534:ℝ)*hBl + (1322381572442/754079885:ℝ)*hMu + (3066049/7670:ℝ)*hqM + (138217/590:ℝ)*hRo + (988805261/5112406:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (15423825435/43748146:ℝ)*hBl + (25191741125102/14327517815:ℝ)*hMu + (1119693481/2768870:ℝ)*hqM + (50967153/212990:ℝ)*hRo + (988805261/5112406:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_8
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (393/1600 : ℝ) ≤ M) (hMu : M ≤ (4019/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4019/16000 : ℝ) (4361/40190 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (93076270/343729:ℝ)*hBl + (15350518609956/89794045315:ℝ)*hMu + (15350518609956/89794045315:ℝ)*hqM + (225302/1145:ℝ)*hRo + (41863321169/784227470:ℝ)*hg0 + (60684780449/784227470:ℝ)*hgap + (112651/2290:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-24571/2290:ℝ)*hmass
  · linear_combination (23848303250/84901063:ℝ)*hBl + (59988051869820/341217372197:ℝ)*hMu + (59988051869820/341217372197:ℝ)*hqM + (16701470/82669:ℝ)*hRo + (41863321169/784227470:ℝ)*hg0 + (60684780449/784227470:ℝ)*hgap + (8350735/165338:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-904695/165338:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_9
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4019/16000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4406796014/44001815:ℝ)*hBl + (94594284/1071125:ℝ)*hR0 + (442778/2255:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (221389/4510:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-50269/4510:ℝ)*hmass
  · linear_combination (17645138354/167206897:ℝ)*hBl + (369966324/4070275:ℝ)*hR0 + (32844242/162811:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (16422121/325622:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1878081/325622:ℝ)*hmass

end TSP.Improvements20261105
