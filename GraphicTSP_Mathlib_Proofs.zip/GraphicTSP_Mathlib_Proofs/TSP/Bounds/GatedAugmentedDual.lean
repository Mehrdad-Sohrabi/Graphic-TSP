import TSP.Improvements20261105.GatedAugmentation

/-! Enlarging a free head subtracts precisely its capacity increase times
the head selector from the dual. Integral feasible potentials have binary
head selectors, proved from actual reverse, tree and paid arcs. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def gatedHeadSelector (p : GatedVertex d → ℤ) (v : d.tree.Child) : ℤ :=
  p (gatedAux d v) - p (gatedHead d v)

theorem gated_head_selector_binary (P : GatePlan d) (p : GatedVertex d → ℤ)
    (hp : ∀ a, gatedUpper d P a = none →
      p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ))
    (v : d.tree.Child) : gatedHeadSelector d p v = 0 ∨ gatedHeadSelector d p v = 1 := by
  have hr := hp (gatedReverseArc d v) (by simp [gatedUpper])
  have hs := hp (gatedSuffixArc d v) (by simp [gatedUpper])
  have ht := hp (gatedPrefixArc d v) (by simp [gatedUpper])
  have hc := hp (gatedPaidArc d v) (by simp [gatedUpper])
  simp only [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, Sum.elim_inl,
    Sum.elim_inr, Nat.cast_zero, Nat.cast_ite, Nat.cast_one] at hr hs ht hc
  norm_num at hr hs ht hc
  unfold gatedHeadSelector
  split_ifs at hc <;> omega

theorem gated_augmented_dual_shift (P : GatePlan d) (t : d.tree.Child → ℝ)
    (p : GatedVertex d → ℝ) :
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) p =
    optionalDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedUpper d P) p -
      ∑ v : d.tree.Child, t v * max (p (gatedAux d v) - p (gatedHead d v)) 0 := by
  let correction : GatedArc d → ℝ := fun a => match a with
    | .inr (.inr (v, k)) => if k = 1 then
        t v * max (p (gatedAux d v) - p (gatedHead d v)) 0 else 0
    | _ => 0
  have hsum : ∑ a, correction a =
      ∑ v : d.tree.Child, t v * max (p (gatedAux d v) - p (gatedHead d v)) 0 := by
    simp [correction, Fintype.sum_sum_type, Fintype.sum_prod_type]
  rw [← hsum]
  unfold realCapacityDualValue optionalDualValue
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro a _
  rcases a with a | (v | ⟨v, k⟩)
  · simp [gatedAugmentedUpper, gatedUpper, correction]
  · simp [gatedAugmentedUpper, gatedUpper, correction]
  · by_cases hk : k = 1
    · subst k
      simp only [gatedAugmentedUpper, if_pos rfl, gatedLower, gatedUpper,
        gatedCost, gatedNetwork, gatedExtraSrc, gatedExtraDst, correction, gatedFreeBase,
        Sum.elim_inl, Sum.elim_inr]
      norm_num [show (1 : Fin 8) ≠ 3 by decide]
      split_ifs <;> ring
    · simp only [gatedAugmentedUpper, if_neg hk, correction]
      cases he : gatedUpper d P (.inr (.inr (v, k))) <;> simp [he]

theorem gated_augmented_dual_selector_shift (P : GatePlan d) (t : d.tree.Child → ℝ)
    (p : GatedVertex d → ℤ)
    (hp : ∀ a, gatedUpper d P a = none →
      p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)) :
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
    optionalDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedUpper d P) (fun v => (p v : ℝ)) -
      ∑ v : d.tree.Child, t v * (gatedHeadSelector d p v : ℝ) := by
  rw [gated_augmented_dual_shift]
  congr 1
  apply Finset.sum_congr rfl
  intro v _
  have hb := gated_head_selector_binary d P p hp v
  have hn : 0 ≤ gatedHeadSelector d p v := by omega
  have hnR : (0 : ℝ) ≤ p (gatedAux d v) - p (gatedHead d v) := by
    exact_mod_cast hn
  rw [max_eq_left hnR]
  simp only [gatedHeadSelector, Int.cast_sub]

end TSP.Improvements20261105
