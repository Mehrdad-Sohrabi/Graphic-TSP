import TSP.Improvements20261105.DFSLeafIncidence

/-! Subtour feasibility gives at least one unit of outgoing back mass
at an actual original DFS leaf. Projection losses are counted explicitly. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem dfs_leaf_upper_ne (v : V) (hleaf : ∀ c : d.tree.Child, d.tree.parent c ≠ v)
    (e : E) : d.upper e ≠ v := by
  intro he
  exact hleaf (d.anchor e) ((d.anchor_spec e).1.trans he)

theorem dfs_leaf_cut (hs : G.IsSimple) (v : d.tree.Child)
    (hleaf : ∀ c : d.tree.Child, d.tree.parent c ≠ (v : V)) :
    G.cut {(v : V)} = insert (d.treeEdge v) (d.backEdges.filter (fun e => d.lower e = (v : V))) := by
  ext e
  have hu := dfs_leaf_upper_ne d v hleaf e
  have hcut : e ∈ G.cut {(v : V)} ↔ d.lower e = (v : V) := by
    rw [mem_singleton_cut_iff_incident G hs.1]
    rcases d.oriented e with ho | ho <;> simp [Graph.incident, ho.1, ho.2, hu]
  rw [hcut]
  constructor
  · intro he
    by_cases hb : e ∈ d.backEdges
    · exact Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨hb, he⟩)
    · have ht : e ∈ d.treeEdges := by
        by_contra hn
        exact hb (Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, hn⟩)
      obtain ⟨c, _, rfl⟩ := Finset.mem_image.mp ht
      rw [d.treeEdge_lower] at he
      have hcv : c = v := Subtype.ext he
      subst c
      exact Finset.mem_insert_self _ _
  · intro he
    rcases Finset.mem_insert.mp he with he | he
    · rw [he, d.treeEdge_lower]
    · exact (Finset.mem_filter.mp he).2

theorem dfs_leaf_back_mass (hs : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (v : d.tree.Child)
    (hleaf : ∀ c : d.tree.Child, d.tree.parent c ≠ (v : V)) :
    1 ≤ ∑ e ∈ d.backEdges, if d.lower e = (v : V) then x e else 0 := by
  have hcut := hx.2 {(v : V)} (Finset.singleton_nonempty _)
    ⟨d.tree.root, Finset.mem_compl.mpr (by simpa using v.2.symm)⟩
  rw [dfs_leaf_cut d hs v hleaf] at hcut
  have hn : d.treeEdge v ∉ d.backEdges.filter (fun e => d.lower e = (v : V)) := by
    intro hh
    have hb := (Finset.mem_filter.mp hh).1
    exact (Finset.mem_sdiff.mp hb).2 (Finset.mem_image.mpr ⟨v, Finset.mem_univ _, rfl⟩)
  rw [edgeSum, Finset.sum_insert hn, Finset.sum_filter] at hcut
  linarith [hcap (d.treeEdge v)]

noncomputable def leafProjectionLoss (x z : E → ℝ) (v : V) : ℝ :=
  ∑ e ∈ d.backEdges, if d.lower e = v then x e - z e else 0

theorem dfs_leaf_projected_mass (hs : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (z : E → ℝ) (v : d.tree.Child)
    (hleaf : ∀ c : d.tree.Child, d.tree.parent c ≠ (v : V)) :
    1 - leafProjectionLoss d x z v ≤
      ∑ e ∈ d.backEdges, if d.lower e = (v : V) then z e else 0 := by
  have hm := dfs_leaf_back_mass d hs hx hcap v hleaf
  have he : leafProjectionLoss d x z v =
      (∑ e ∈ d.backEdges, if d.lower e = (v : V) then x e else 0) -
      (∑ e ∈ d.backEdges, if d.lower e = (v : V) then z e else 0) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro e _
    change (if d.lower e = (v : V) then x e - z e else 0) = _
    split_ifs <;> ring
  linarith

end TSP.Improvements20261105
