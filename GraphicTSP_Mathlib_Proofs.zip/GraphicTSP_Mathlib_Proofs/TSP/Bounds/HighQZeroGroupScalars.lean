import Mathlib.Tactic

/-! A single receiver budget pays its selected surcharge in all four
selector states. The source and receiver share the same transfer g. -/
namespace TSP.Improvements20261105
set_option autoImplicit false

theorem high_q_zero_group_scalar (ts tw g rs ms ls rw mw lw : ℝ) (ns nw : ℤ)
    (hs : ns=0 ∨ ns=1) (hw : nw=0 ∨ nw=1)
    (hts : 0 ≤ ts) (htw : 1 ≤ tw) (hg : 0 ≤ g)
    (hms : ms ≤ 0) (hrs : rs+ls-48*g ≤ 4*ts)
    (hmw : mw ≤ -48*g) (hrw : rw+lw ≤ -48*g+1376/361) :
    ((ns:ℝ)*rs+(1-(ns:ℝ))*ms)+(ns:ℝ)*ls+
      ((nw:ℝ)*rw+(1-(nw:ℝ))*mw)+(nw:ℝ)*lw ≤ 4*(ts+tw) := by
  rcases hs with rfl | rfl <;> rcases hw with rfl | rfl <;> norm_num <;> linarith

end TSP.Improvements20261105
