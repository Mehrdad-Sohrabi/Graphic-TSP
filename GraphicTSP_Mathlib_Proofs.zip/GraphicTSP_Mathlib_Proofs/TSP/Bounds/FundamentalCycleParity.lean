import TSP.Chapter06.WeightedCycles
import TSP.Improvements20261105.ParityGauge

/-! The actual DFS fundamental cycle has even degree at every vertex.
The edge set uses the original tree edges and one original back edge. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def fundamentalPathChildren (b : BackEdge d) : Finset d.tree.Child :=
  Finset.univ.filter (fun c => d.tree.OnPath (d.anchor b.1) (d.lower b.1) c)

noncomputable def fundamentalCycleEdges (b : BackEdge d) : Finset E :=
  insert b.1 ((fundamentalPathChildren d b).image d.treeEdge)

theorem fundamental_path_parent_sum (b : BackEdge d) (v : V) :
    (∑ c ∈ fundamentalPathChildren d b, if d.tree.parent c = v then (1 : ℝ) else 0) =
      (if d.upper b.1 = v then 1 else 0) +
      (if d.tree.OnPath (d.anchor b.1) (d.lower b.1) v ∧ v ≠ d.lower b.1 then 1 else 0) := by
  have ha : d.tree.OnPath (d.anchor b.1) (d.lower b.1) (d.anchor b.1) :=
    ⟨.refl, (d.anchor_spec b.1).2⟩
  have hsplit : (∑ c ∈ fundamentalPathChildren d b, if d.tree.parent c = v then (1 : ℝ) else 0) =
      (∑ c : d.tree.Child, if c = d.anchor b.1 then (if d.tree.parent c = v then (1 : ℝ) else 0) else 0) +
      (∑ c : d.tree.Child, if d.tree.parent c = v ∧ d.tree.OnPath (d.anchor b.1) (d.lower b.1) c ∧ c ≠ d.anchor b.1 then (1 : ℝ) else 0) := by
    rw [fundamentalPathChildren, Finset.sum_filter, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro c _
    by_cases hc : c = d.anchor b.1
    · subst c
      simp [ha]
    · by_cases hp : d.tree.parent c = v <;>
        by_cases hh : d.tree.OnPath (d.anchor b.1) (d.lower b.1) c <;> simp [hc, hp, hh]
  rw [hsplit, d.tree.path_child_sum]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true, (d.anchor_spec b.1).1]

theorem fundamental_path_child_sum (b : BackEdge d) (v : V) :
    (∑ c ∈ fundamentalPathChildren d b, if (c : V) = v then (1 : ℝ) else 0) =
      if d.tree.OnPath (d.anchor b.1) (d.lower b.1) v then 1 else 0 := by
  rw [fundamentalPathChildren, Finset.sum_filter]
  by_cases hv : v = d.tree.root
  · subst v
    have hroot : ¬d.tree.OnPath (d.anchor b.1) (d.lower b.1) d.tree.root :=
      fun h => d.tree.onPath_ne_root _ _ _ h rfl
    simp [hroot, fun c : d.tree.Child => c.2]
  · rw [Finset.sum_eq_single (⟨v, hv⟩ : d.tree.Child)]
    · simp
    · intro c _ hc
      have hcv : (c : V) ≠ v := fun h => hc (Subtype.ext h)
      simp [hcv]
    · simp

theorem fundamental_cycle_even (b : BackEdge d) (v : V) :
    Even (G.intDegree (fundamentalCycleEdges d b) v) := by
  have hbnot : b.1 ∉ (fundamentalPathChildren d b).image d.treeEdge := by
    intro h
    obtain ⟨c, _, he⟩ := Finset.mem_image.mp h
    exact (Finset.mem_sdiff.mp b.2).2 (Finset.mem_image.mpr ⟨c, Finset.mem_univ _, he⟩)
  have htree (c : d.tree.Child) : (G.endpointCount v (d.treeEdge c) : ℝ) =
      (if d.tree.parent c = v then 1 else 0) + (if (c : V) = v then 1 else 0) := by
    have hor := d.oriented (d.treeEdge c)
    rw [d.treeEdge_upper, d.treeEdge_lower] at hor
    rcases hor with h | h <;> simp [endpointCount, h.1, h.2, Nat.cast_add] <;> ring
  have hback : (G.endpointCount v b.1 : ℝ) =
      (if d.upper b.1 = v then 1 else 0) + (if d.lower b.1 = v then 1 else 0) := by
    rcases d.oriented b.1 with h | h <;> simp [endpointCount, h.1, h.2, Nat.cast_add] <;> ring
  have hdeg : (G.intDegree (fundamentalCycleEdges d b) v : ℝ) =
      2 * (if d.upper b.1 = v then 1 else 0) +
      (if d.lower b.1 = v then 1 else 0) +
      (if d.tree.OnPath (d.anchor b.1) (d.lower b.1) v ∧ v ≠ d.lower b.1 then 1 else 0) +
      (if d.tree.OnPath (d.anchor b.1) (d.lower b.1) v then 1 else 0) := by
    rw [Graph.intDegree_eq_endpoint_sum, fundamentalCycleEdges, Finset.sum_insert hbnot,
      Nat.cast_add, Nat.cast_sum, Finset.sum_image (fun a _ c _ h => d.treeEdge_injective h), hback]
    simp_rw [htree]
    rw [Finset.sum_add_distrib, fundamental_path_parent_sum, fundamental_path_child_sum]
    ring
  have hbottom : d.tree.OnPath (d.anchor b.1) (d.lower b.1) (d.lower b.1) := ⟨(d.anchor_spec b.1).2, .refl⟩
  have hu : ¬d.tree.OnPath (d.anchor b.1) (d.lower b.1) (d.upper b.1) := by
    intro h
    have hdepth := d.tree.ancestor_depth_le h.1
    have hp := d.tree.parent_depth (d.anchor b.1) (d.anchor b.1).2
    rw [(d.anchor_spec b.1).1] at hp
    omega
  by_cases hup : d.upper b.1 = v
  · have hvpath : ¬d.tree.OnPath (d.anchor b.1) (d.lower b.1) v := hup ▸ hu
    have hvlow : d.lower b.1 ≠ v := by
      intro h
      exact hvpath (h ▸ hbottom)
    simp only [if_pos hup, if_neg hvlow, hvpath, false_and, if_false] at hdeg
    have hnat : G.intDegree (fundamentalCycleEdges d b) v = 2 := by exact_mod_cast hdeg
    rw [hnat]; norm_num
  · by_cases hlow : d.lower b.1 = v
    · have hvpath : d.tree.OnPath (d.anchor b.1) (d.lower b.1) v := hlow ▸ hbottom
      have hfalse : ¬(d.tree.OnPath (d.anchor b.1) (d.lower b.1) v ∧ v ≠ d.lower b.1) :=
        fun h => h.2 hlow.symm
      rw [if_neg hup, if_pos hlow, if_neg hfalse, if_pos hvpath] at hdeg
      norm_num at hdeg
      have hnat : G.intDegree (fundamentalCycleEdges d b) v = 2 := by exact_mod_cast hdeg
      rw [hnat]; norm_num
    · by_cases hp : d.tree.OnPath (d.anchor b.1) (d.lower b.1) v
      · simp [hup, hlow, hp, Ne.symm hlow] at hdeg
        have hnat : G.intDegree (fundamentalCycleEdges d b) v = 2 := by exact_mod_cast hdeg
        rw [hnat]; norm_num
      · simp [hup, hlow, hp] at hdeg
        have hnat : G.intDegree (fundamentalCycleEdges d b) v = 0 := by exact_mod_cast hdeg
        rw [hnat]; norm_num

end TSP.Improvements20261105
