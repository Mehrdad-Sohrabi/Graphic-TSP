import TSP.Improvements20261105.LargeSelectedGreedyT5R4CapCells00
import TSP.Improvements20261105.LargeSelectedGreedyT5R4CapCells01
import TSP.Improvements20261105.LargeSelectedGreedyT5R4CapCells02
import TSP.Improvements20261105.LargeSelectedGreedyT5R4CapCells03
import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t5_r4_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 5*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hq0 : (1/5 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (41/150 : ℝ) ∨ (211/500 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hql : (1/5 : ℝ) ≤ q := hq0
  have hqu : q ≤ (3/4 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/4 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (4/5 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t5_r4_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t5_r4_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t5_r4_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t5_r4_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/40 : ℝ)
      · have hqu : q ≤ (19/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (27/80 : ℝ)
        · have hqu : q ≤ (27/80 : ℝ) := hsplit
          exact large_selected_greedy_t5_r4_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (27/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            exact large_selected_greedy_t5_r4_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t5_r4_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (19/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t5_r4_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t5_r4_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t5_r4_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/40 : ℝ)
      · have hqu : q ≤ (19/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (27/80 : ℝ)
        · have hqu : q ≤ (27/80 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (43/160 : ℝ)
            · have hqu : q ≤ (43/160 : ℝ) := hsplit
              exact large_selected_greedy_t5_r4_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (97/320 : ℝ)
                · have hqu : q ≤ (97/320 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r4_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (97/320 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t5_r4_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t5_r4_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (97/320 : ℝ)
                · have hqu : q ≤ (97/320 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r4_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (97/320 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (41/128 : ℝ)
                    · have hqu : q ≤ (41/128 : ℝ) := hsplit
                      exact large_selected_greedy_t5_r4_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t5_r4_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (41/128 : ℝ)
                    · have hqu : q ≤ (41/128 : ℝ) := hsplit
                      exact large_selected_greedy_t5_r4_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t5_r4_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (43/160 : ℝ)
            · have hqu : q ≤ (43/160 : ℝ) := hsplit
              exact large_selected_greedy_t5_r4_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (97/320 : ℝ)
                · have hqu : q ≤ (97/320 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r4_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (97/320 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (41/128 : ℝ)
                    · have hqu : q ≤ (41/128 : ℝ) := hsplit
                      exact large_selected_greedy_t5_r4_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t5_r4_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t5_r4_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t5_r4_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (27/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (13/32 : ℝ)
            · have hqu : q ≤ (13/32 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (119/320 : ℝ)
                · have hqu : q ≤ (119/320 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r4_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (119/320 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t5_r4_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (119/320 : ℝ)
                · have hqu : q ≤ (119/320 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r4_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (119/320 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t5_r4_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (13/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t5_r4_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/32 : ℝ)
            · have hqu : q ≤ (13/32 : ℝ) := hsplit
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (119/320 : ℝ)
                · have hqu : q ≤ (119/320 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r4_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (119/320 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t5_r4_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t5_r4_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (13/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t5_r4_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (19/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t5_r4_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (19/40 : ℝ)
    · have hqu : q ≤ (19/40 : ℝ) := hsplit
      by_cases hsplit : z ≤ (13/20 : ℝ)
      · have hzu : z ≤ (13/20 : ℝ) := hsplit
        exact large_selected_greedy_t5_r4_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hzl : (13/20 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t5_r4_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    · have hql : (19/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t5_r4_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105
