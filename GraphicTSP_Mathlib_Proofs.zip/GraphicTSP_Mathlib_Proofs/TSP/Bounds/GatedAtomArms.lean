import TSP.Improvements20261105.GatedAugmentation

/-! Each rounded augmented circulation yields an actual feasible binary
point. Its connector and head arms retain their separate payments. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedAtomPoint (g : GatedArc d → ℕ) : (E ⊕ d.StarIndex) → ℝ :=
  binaryNonloopPoint d (positiveBackSet d (gatedNatBacks d g))
    (resetBypasses d (gatedNatBacks d g) (gatedUsedBypasses d g))

theorem gated_loose_bypass_bit (P : GatePlan d) (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ))) (v : d.tree.Child) :
    (if v ∈ gatedUsedBypasses d g then (1 : ℝ) else 0) = (g (gatedBypassArc d v) : ℝ) := by
  obtain ⟨_, hnb⟩ := gated_loose_normalized d P _ hg hb
  have hh := (gated_bypass_box d P _ hnb v).2
  rw [normalizeGatedFree_bypass] at hh
  have hn : g (gatedBypassArc d v) ≤ 1 := by exact_mod_cast hh
  by_cases hz : g (gatedBypassArc d v) = 0
  · simp [gatedUsedBypasses, hz]
  · have ho : g (gatedBypassArc d v) = 1 := by omega
    simp [gatedUsedBypasses, ho]

theorem gated_loose_root_unused (P : GatePlan d) (hP : P.ValidGadgets d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ)))
    (v : d.tree.Child) (hv : d.tree.parent v = d.tree.root) :
    v ∉ gatedUsedBypasses d g := by
  obtain ⟨_, hnb⟩ := gated_loose_normalized d P _ hg hb
  have hz := gated_bypass_disabled d P _ hnb v (hP.root v hv)
  rw [normalizeGatedFree_bypass] at hz
  have hn : g (gatedBypassArc d v) = 0 := by exact_mod_cast hz
  simp [gatedUsedBypasses, hn]

theorem gated_loose_bypass_witness (hs : G.IsSimple) (P : GatePlan d)
    (hP : P.ValidGadgets d) (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ)))
    (v : d.tree.Child) (hv : v ∈ gatedUsedBypasses d g) :
    OriginalBypassWitness d (positiveBackSet d (gatedNatBacks d g)) v := by
  obtain ⟨hn, hnb⟩ := gated_loose_normalized d P _ hg hb
  have hp : 0 < normalizeGatedFree d P (fun a => (g a : ℝ)) (gatedBypassArc d v) := by
    rw [normalizeGatedFree_bypass]
    exact_mod_cast (Finset.mem_filter.mp hv).2
  simpa only [normalizeGatedFree_positiveBacks, gatedPositiveBacks_nat] using
    gated_positive_bypass_witness d hs P hP _ hn hnb v hp

theorem gated_loose_inactive_cover (P : GatePlan d) (hP : P.RespectsTree d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ)))
    (v : d.tree.Child) (hv : ¬(d.backGroup v).Nonempty) :
    SelectedTreeCover d (positiveBackSet d (gatedNatBacks d g)) v := by
  obtain ⟨hn, hnb⟩ := gated_loose_normalized d P _ hg hb
  have hh := gated_nonremovable_coverage d P hP _ hn hnb v hv
  simp only [normalizeGatedFree_backVector, gatedBackVector_nat] at hh
  have hp : 0 < ∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, gatedNatBacks d g b := by
    have hh' : 1 ≤ ∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, gatedNatBacks d g b := by
      exact_mod_cast hh
    omega
  obtain ⟨b, hbm⟩ := (positiveBackSet_cover_iff d (gatedNatBacks d g)
    (G.cut (subtreeVertices d v) ∩ d.backEdges) Finset.inter_subset_right).mpr hp
  exact ⟨b, Finset.mem_inter.mpr ⟨(Finset.mem_inter.mp hbm).1,
    (Finset.mem_inter.mp (Finset.mem_inter.mp hbm).2).1⟩⟩

theorem gatedAtomPoint_feasible (hs : G.IsSimple) (P : GatePlan d) (hP : P.ValidGadgets d)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ))) :
    gatedAtomPoint d g ∈ projectedFrameworkTwo G d.centers owner := by
  apply binaryNonloopPoint_feasible d hs owner ho _ (positiveBackSet_subset d _) _
  · intro v hv
    exact (Finset.mem_filter.mp hv).2
  · intro v hv
    exact gated_loose_bypass_witness d hs P hP g hg hb v (Finset.mem_filter.mp hv).1

theorem gatedAtomPoint_nonremovable_sum (P : GatePlan d) (hP : P.RespectsTree d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ))) :
    edgeSum (gatedAtomPoint d g) (nonremovableRepresentatives d.stars) =
      ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 := by
  exact binary_nonremovable_sum d _ (positiveBackSet_subset d _) _
    (fun v hv => (Finset.mem_filter.mp hv).2) (gated_loose_inactive_cover d P hP g hg hb)

theorem gatedAtomPoint_connector (P : GatePlan d) (hP : P.RespectsTree d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ)))
    (i : d.StarIndex) (hi : d.centers i ≠ d.tree.root) :
    gatedAtomPoint d g (Sum.inr i) ≤ 1 / 3 + (2 / 3) * (g (gatedPaidArc d i.1) : ℝ) := by
  have hc := gated_loose_connector_payment d P hP _ hg hb i.1 hi
  simp only [gatedBackVector_nat] at hc
  have hh := (clipped_actual_connector_deficiency d (gatedNatBacks d g) i.1).trans
    (max_le hc (Nat.cast_nonneg _))
  change expandedBinaryPoint d _ _ (Sum.inr i.1) ≤ _
  rw [expandedBinaryPoint_connector d _ (positiveBackSet_subset d _)]
  split_ifs at hh ⊢ <;> linarith

theorem gatedAtomPoint_head (P : GatePlan d) (hP : P.RespectsTree d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ)))
    (i : d.StarIndex) (hi : d.centers i ≠ d.tree.root) :
    (d.stars i).card - 1 - edgeSum (gatedAtomPoint d g) (starRepresentatives d.stars i) ≤
      1 / 3 + (2 / 3) * ((g (gatedPaidArc d i.1) : ℝ) +
        gatedFreeExcess d (fun a => (g a : ℝ)) i.1) := by
  have hi' : d.tree.parent i.1 ≠ d.tree.root := hi
  have hh := gated_loose_head_payment d P hP _ hg hb i.1
  simp only [gatedBackVector_nat, gatedFreeBase, if_neg hi', Nat.cast_one] at hh
  rw [← gated_loose_bypass_bit d P g hg hb] at hh
  have hz : 0 ≤ (g (gatedPaidArc d i.1) : ℝ) + gatedFreeExcess d (fun a => (g a : ℝ)) i.1 :=
    add_nonneg (Nat.cast_nonneg _) (le_max_right _ _)
  have hclip := (clipped_actual_head_overflow d (gatedNatBacks d g) i.1
    (if i.1 ∈ gatedUsedBypasses d g then 1 else 0)).trans (max_le hh hz)
  have hlo := binary_star_sum_lower d (positiveBackSet d (gatedNatBacks d g))
    (positiveBackSet_subset d (gatedNatBacks d g))
    (resetBypasses d (gatedNatBacks d g) (gatedUsedBypasses d g)) i
  rw [reset_bypass_bit] at hlo
  have hclip' := (le_max_left _ _).trans hclip
  change ((d.group i.1).card : ℝ) - 1 - _ ≤ _
  rw [group_card, Nat.cast_add, Nat.cast_one]
  change _ ≤ _ at hlo
  dsimp only [gatedAtomPoint]
  linarith

theorem gatedAtomPoint_root_connector (g : GatedArc d → ℕ)
    (i : d.StarIndex) (hi : d.centers i = d.tree.root) :
    gatedAtomPoint d g (Sum.inr i) = 1 :=
  expandedBinaryPoint_root_connector d _ (positiveBackSet_subset d _) _ i.1 hi

theorem gatedAtomPoint_root_head (P : GatePlan d) (hP : P.ValidGadgets d)
    (g : GatedArc d → ℕ)
    (hg : Chapter06.Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : GatedLooseBounds d P (fun a => (g a : ℝ)))
    (i : d.StarIndex) (hi : d.centers i = d.tree.root) :
    (d.stars i).card - 1 - edgeSum (gatedAtomPoint d g) (starRepresentatives d.stars i) ≤
      1 + (2 / 3) * ((g (gatedPaidArc d i.1) : ℝ) +
        gatedFreeExcess d (fun a => (g a : ℝ)) i.1) := by
  have hr := gated_loose_root_unused d P hP g hg hb i.1 hi
  have hr' : i.1 ∉ resetBypasses d (gatedNatBacks d g) (gatedUsedBypasses d g) :=
    fun h => hr (Finset.mem_filter.mp h).1
  have hi' : d.tree.parent i.1 = d.tree.root := hi
  have hh := gated_loose_head_payment d P hP.tree _ hg hb i.1
  rw [← gated_loose_bypass_bit d P g hg hb, if_neg hr] at hh
  simp only [gatedBackVector_nat, gatedFreeBase, if_pos hi', Nat.cast_ofNat, sub_zero] at hh
  have hm : ((positiveBackSet d (gatedNatBacks d g) ∩ d.backGroup i.1).card : ℝ) ≤
      ∑ b ∈ d.backGroup i.1, (gatedNatBacks d g b : ℝ) := by
    exact_mod_cast positiveBackSet_mass d (gatedNatBacks d g) (d.backGroup i.1)
  have hlo := binary_star_sum_lower d (positiveBackSet d (gatedNatBacks d g))
    (positiveBackSet_subset d (gatedNatBacks d g))
    (resetBypasses d (gatedNatBacks d g) (gatedUsedBypasses d g)) i
  rw [if_neg hr'] at hlo
  change ((d.group i.1).card : ℝ) - 1 - _ ≤ _
  rw [group_card, Nat.cast_add, Nat.cast_one]
  dsimp only [gatedAtomPoint]
  linarith

end TSP.Improvements20261105
