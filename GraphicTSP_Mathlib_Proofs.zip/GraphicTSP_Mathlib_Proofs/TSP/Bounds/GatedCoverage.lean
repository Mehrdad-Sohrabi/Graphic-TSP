import TSP.Improvements20261105.GatedBalances

/-! Original graph cut sums derived from network conservation. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedBackVector (f : GatedArc d → ℝ) (e : E) : ℝ :=
  if h : e ∈ d.backEdges then f (gatedBackArc d ⟨e, h⟩) else 0

@[simp] theorem gatedBackVector_back (f : GatedArc d → ℝ) (b : BackEdge d) :
    gatedBackVector d f b.1 = f (gatedBackArc d b) := by simp [gatedBackVector, b.2]

theorem gatedBackVector_nonnegative (P : GatePlan d) (f : GatedArc d → ℝ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (e : E) :
    0 ≤ gatedBackVector d f e := by
  unfold gatedBackVector
  split_ifs <;> first | exact gated_nonnegative d P f hb _ | exact le_rfl

theorem gated_back_subset_sum (f : GatedArc d → ℝ) (S : Finset E) (hS : S ⊆ d.backEdges) :
    (∑ b : BackEdge d, if b.1 ∈ S then f (gatedBackArc d b) else 0) =
      ∑ b ∈ S, gatedBackVector d f b := by
  have hh : (∑ b : BackEdge d, if b.1 ∈ S then gatedBackVector d f b.1 else 0) =
      ∑ b ∈ d.backEdges, if b ∈ S then gatedBackVector d f b else 0 :=
    (Finset.sum_subtype d.backEdges (fun _ => Iff.rfl)
      (fun b => if b ∈ S then gatedBackVector d f b else 0)).symm
  simp only [gatedBackVector_back] at hh
  rw [hh, ← Finset.sum_filter]
  simp [Finset.filter_mem_eq_inter, Finset.inter_eq_right.mpr hS]

theorem back_anchor_iff_group (b : BackEdge d) (v : d.tree.Child) :
    d.anchor b.1 = v ↔ b.1 ∈ d.backGroup v := by
  constructor
  · intro h
    have hs := d.anchor_spec b.1
    rw [h] at hs
    exact (d.mem_backGroup_iff v b.1).mpr ⟨b.2, hs.1.symm, hs.2⟩
  · intro h
    exact (d.mem_group v b.1).mp (Finset.mem_sdiff.mp h).1

theorem gated_back_head_sum (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    backInflow d (routeFlow (gatedProjectionRoute d P) f) v =
      ∑ b ∈ d.backGroup v, gatedBackVector d f b := by
  simp only [backInflow, gated_projection_back, back_anchor_iff_group]
  exact gated_back_subset_sum d f _ (fun b hb => ((d.mem_backGroup_iff v b).mp hb).1)

theorem gated_foreign_coverage (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f) (v : d.tree.Child) :
    f (gatedSuffixArc d v) =
      (∑ b ∈ deletedSubtreeCut d v, gatedBackVector d f b) + f (gatedPaidArc d v) := by
  have hh := congrFun (gated_projection_decomposition d P hP f hf) (.inl (.inl v))
  rw [gated_projection_connector, weightedBackFlow_parent,
    gated_back_subset_sum d f _ (deletedSubtreeCut_back d v)] at hh
  linarith

theorem gated_head_balance (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    (∑ b ∈ d.backGroup v, gatedBackVector d f b) + f (gatedReverseArc d v) =
      f (gatedFreeArc d v) + f (gatedPaidArc d v) + f (gatedBypassArc d v) := by
  have hh := conservation_at_group d (routeFlow (gatedProjectionRoute d P) f)
    (gated_projection_balanced d P hP f hf) v
  rw [gated_projection_representative, gated_projection_connector, gated_back_head_sum,
    gated_effective_bypass_eq d P f hf hb] at hh
  have ha := gated_balance_aux d P f hf v
  linarith

theorem group_inter_back (v : d.tree.Child) : d.group v ∩ d.backEdges = d.backGroup v := by
  ext b
  constructor
  · intro hb
    exact (d.mem_backGroup_iff v b).mpr ⟨(Finset.mem_inter.mp hb).2,
      (d.mem_group_iff v b).mp (Finset.mem_inter.mp hb).1⟩
  · intro hb
    exact Finset.mem_inter.mpr ⟨(Finset.mem_sdiff.mp hb).1, ((d.mem_backGroup_iff v b).mp hb).1⟩

theorem subtree_back_partition (v : d.tree.Child) :
    G.cut (subtreeVertices d v) ∩ d.backEdges = d.backGroup v ∪ deletedSubtreeCut d v := by
  rw [subtree_cut_partition]
  have hi : (d.group v ∪ deletedSubtreeCut d v) ∩ d.backEdges =
      (d.group v ∩ d.backEdges) ∪ (deletedSubtreeCut d v ∩ d.backEdges) := by
    ext b
    simp only [Finset.mem_inter, Finset.mem_union]
    tauto
  rw [hi, group_inter_back, Finset.inter_eq_left.mpr (deletedSubtreeCut_back d v)]

theorem subtree_back_sum (x : E → ℝ) (v : d.tree.Child) :
    (∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, x b) =
      (∑ b ∈ d.backGroup v, x b) + ∑ b ∈ deletedSubtreeCut d v, x b := by
  rw [subtree_back_partition, Finset.sum_union]
  exact (group_deletedCut_disjoint d v).mono_left Finset.sdiff_subset

theorem gated_tree_coverage (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    f (gatedRepArc d v) + f (gatedBypassArc d v) =
      ∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, gatedBackVector d f b := by
  rw [subtree_back_sum]
  have hg := gated_head_balance d P hP f hf hb v
  have hc := gated_foreign_coverage d P hP f hf v
  have ha := gated_balance_aux d P f hf v
  linarith

theorem gated_connector_payment (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : d.tree.parent v ≠ d.tree.root) :
    1 - (∑ b ∈ deletedSubtreeCut d v, gatedBackVector d f b) ≤ f (gatedPaidArc d v) := by
  have hl := (hb (gatedSuffixArc d v)).1
  simp only [gatedLower, Sum.elim_inl, if_neg hv, Nat.cast_one] at hl
  rw [gated_foreign_coverage d P hP f hf v] at hl
  linarith

theorem gated_head_payment (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f) (v : d.tree.Child) :
    (∑ b ∈ d.backGroup v, gatedBackVector d f b) - f (gatedBypassArc d v) -
      (if d.tree.parent v = d.tree.root then (2 : ℝ) else 1) ≤ f (gatedPaidArc d v) := by
  have hh := gated_head_balance d P hP f hf hb v
  have hr := gated_nonnegative d P f hb (gatedReverseArc d v)
  have hc := gated_free_capacity d P f hb v
  linarith

theorem gated_nonremovable_coverage (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) f)
    (v : d.tree.Child) (hv : ¬(d.backGroup v).Nonempty) :
    1 ≤ ∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, gatedBackVector d f b := by
  rw [← gated_tree_coverage d P hP f hf hb v]
  have hl := (hb (gatedRepArc d v)).1
  simp only [gatedLower, Sum.elim_inl, Sum.elim_inr, if_neg hv, Nat.cast_one] at hl
  have hr := (gated_bypass_box d P f hb v).1
  linarith

end TSP.Improvements20261105
