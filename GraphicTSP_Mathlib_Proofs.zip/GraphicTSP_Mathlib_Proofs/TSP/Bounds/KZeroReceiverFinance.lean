import TSP.Improvements20261105.KZeroReceiverScalar
import TSP.Improvements20261105.PairIncomingBudget

/-! An unmatched protected source cannot have a matched projected-zero
receiver. Its actual cover edge pays the incoming K force, retaining
the negative receiver floor needed for leaf accounting. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem unmatched_link_zero_receiver (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child)
    (hl : s ∈ projectionLinks d x)
    (hu : s ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hz : edgeSum z (d.backGroup (unaryNext d s)) ≤ 1) :
    unaryNext d s ∉ matchingEndpoints id (unaryNext d) C.matching := by
  intro hmR
  rcases Finset.mem_union.mp hmR with hsrc | htgt
  · have hr : unaryNext d s ∈ C.matching := by simpa using hsrc
    have hp := projectionLink_source_positive d hs x z hx hn hm (unaryNext d s) (C.link_subset hr)
    linarith
  · obtain ⟨t,ht,he⟩ := Finset.mem_image.mp htgt
    have hps := projectionLinks_parent d x s hl
    have hpt := projectionLinks_parent d x t (C.link_subset ht)
    have hst : s = t := Subtype.ext (by rw [he] at hpt; exact hps.symm.trans hpt)
    apply hu
    apply Finset.mem_union_left
    apply Finset.mem_image.mpr
    exact ⟨t,ht,hst.symm⟩

theorem unmatched_link_zero_receiver_cover (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child)
    (hl : s ∈ projectionLinks d x)
    (hu : s ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hz : edgeSum z (d.backGroup (unaryNext d s)) ≤ 1) :
    C.cover (unaryNext d s) = -Q*(1-x (d.treeEdge s)-outgoingBackMass d x s) := by
  have hp := projectionLinks_parent d x s hl
  have hnr : d.tree.parent (unaryNext d s) ≠ d.tree.root := by rw [hp]; exact s.2
  have hev : Even (G.intDegree d.treeEdges (d.tree.parent (unaryNext d s))) := by
    rw [hp,tree_degree_eq,if_neg s.2,(Finset.mem_filter.mp hl).2.2.2.1]
    norm_num
  have hid := projectionLinks_receiver_identity d hs x z hm s hl
  have hy := (Finset.mem_filter.mp hl).2.2.2.2
  rw [C.unmatched_floor _ (unmatched_link_zero_receiver d hs x z hx hn hm P Q C s hl hu hz),
    fixedCoverFloor,if_neg hnr,if_pos hev,if_neg (not_lt.mpr hz),
    if_pos (projectionLinks_override d x s hl),max_eq_left (by linarith)]
  congr 1
  linarith

theorem protected_zero_receiver_export (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s : d.tree.Child)
    (hl : s ∈ projectionLinks d x)
    (hu : s ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hz : edgeSum z (d.backGroup (unaryNext d s)) ≤ 1) :
    (415/2 : ℝ)*max (protectedCoverIncrease d x z (415/2) (704/5) 60 C s-
      outgoingBackMass d x s) 0-(704/5 : ℝ)*(1-x (d.treeEdge s)-outgoingBackMass d x s) ≤
        -48*(1-x (d.treeEdge s)-outgoingBackMass d x s) := by
  have hprops := (Finset.mem_filter.mp hl).2
  have hprot : ProtectedHead d x z (415/2) (704/5) C s := ⟨hprops.1,hprops.2.1,hu⟩
  have hcov := unmatched_link_zero_receiver_cover d hs x z hx hn hm (415/2) (704/5) C s hl hu hz
  have ho : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hb := protectedCoverIncrease_bounds d hs x z hx hn hcap hm (415/2) (704/5) 60
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C s
  by_cases he : survivingExcess d x s ≤ outgoingBackMass d x s
  · rw [max_eq_right (by linarith : protectedCoverIncrease d x z (415/2) (704/5) 60 C s-
        outgoingBackMass d x s ≤ 0)]
    nlinarith [hprops.2.2.2]
  · have heo : outgoingBackMass d x s ≤ survivingExcess d x s := le_of_not_ge he
    have heta : preliminaryQIncrease d x s = outgoingBackMass d x s := by
      rw [preliminaryQIncrease,if_neg hprops.1,min_eq_right heo]
    have hbase : coveredPIncrease d x (415/2) (704/5) C.cover s = outgoingBackMass d x s := by
      rw [coveredPIncrease,if_neg hprops.1,if_pos hl,hcov]
      simp only [neg_mul,neg_add_cancel,zero_div,add_zero,min_eq_right heo]
    have hsource : C.cover s ≤ 0 := by
      rw [C.unmatched_floor s hu]
      exact fixedCoverFloor_nonpositive d hs x z hx hcap (704/5) (by norm_num) s
    have hedge := C.edge_bound s hl
    rw [fixedCoverEdge,heta,hcov] at hedge
    have hedge' : (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s) ≤
        (704/5 : ℝ)*(x (d.treeEdge s)+outgoingBackMass d x s) := by linarith
    have hfinance := current_K_zero_receiver_numerator (x (d.treeEdge s)) (outgoingBackMass d x s)
      (survivingExcess d x s) ho hprops.2.2.2.le (survivingExcess_bounds d hs hx hcap s).2 hedge'
    rw [protectedCoverIncrease,if_pos hprot,protectedIncrease,heta,hbase]
    let num := (415/2 : ℝ)*survivingExcess d x s-(704/5 : ℝ)*(x (d.treeEdge s)+outgoingBackMass d x s)+
      60*min (x (d.treeEdge s)) (1-x (d.treeEdge s))
    change (415/2 : ℝ)*max (max (outgoingBackMass d x s) (max 0 (num/(415/2)))-
      outgoingBackMass d x s) 0-(704/5 : ℝ)*(1-x (d.treeEdge s)-outgoingBackMass d x s) ≤ _
    rw [max_comm (0 : ℝ) (num/(415/2))]
    change max (num-(415/2 : ℝ)*outgoingBackMass d x s) 0-(704/5 : ℝ)*
      (1-x (d.treeEdge s)-outgoingBackMass d x s) ≤ _ at hfinance
    have hid : (415/2 : ℝ)*max (max (outgoingBackMass d x s) (max (num/(415/2)) 0)-
        outgoingBackMass d x s) 0 = max (num-(415/2 : ℝ)*outgoingBackMass d x s) 0 := by
      rcases le_total num ((415/2 : ℝ)*outgoingBackMass d x s) with h | h
      · have hdiv : num/(415/2 : ℝ) ≤ outgoingBackMass d x s := (div_le_iff₀ (by norm_num)).mpr (by linarith)
        rw [max_eq_left (max_le hdiv ho),sub_self,max_self,max_eq_right (by linarith)]
        ring
      · have hdiv : outgoingBackMass d x s ≤ num/(415/2 : ℝ) := (le_div_iff₀ (by norm_num)).mpr (by linarith)
        rw [max_eq_left (ho.trans hdiv),max_eq_right hdiv,max_eq_left (sub_nonneg.mpr hdiv),
          max_eq_left (by linarith)]
        ring
    rw [hid]
    exact hfinance

end TSP.Improvements20261105
