import TSP.Improvements20261105.ScoredOrdinaryGamma
import TSP.Improvements20261105.RefinedIncidenceCharge

/-! Bounds on the actual fixed critical incidence. The critical set is unchanged,
and its whole-incidence floor is retained. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem refined_fixed_incidence_le_clipped (x z : E → ℝ)
    (eligible T : Finset d.tree.Child) (s : d.tree.Child) (he : s ∈ eligible) :
    refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s ≤
      clippedCriticalIncidence d x z s := by
  by_cases hh : s ∈ fixedCriticalHeads d x z eligible
  · unfold refinedIncidenceCharge
    rw [if_pos hh]
    split_ifs
    · exact le_max_left _ _
    · exact le_rfl
  · have hlt : noncriticalIncidence d z s < clippedCriticalIncidence d x z s := by
      have hn : ¬clippedCriticalIncidence d x z s ≤ noncriticalIncidence d z s := by
        intro hc
        exact hh (Finset.mem_filter.mpr ⟨he,hc⟩)
      exact lt_of_not_ge hn
    rw [refinedIncidenceCharge_noncritical d x z _ _ _ hh]
    exact hlt.le

theorem rawCriticalIncidence_joint_linear (x z : E → ℝ) (s : d.tree.Child) (γ : ℝ)
    (hpoint : ∀ e ∈ d.backGroup s,
      (360/19)*incidenceRamp (9/20) (z e)+
        (96/19)*ScoredParameters.perBackPayment (d.backGroup s).card (winningBenchmark d x s) (z e) ≤ γ*z e) :
    rawCriticalIncidence d x z s ≤ γ*edgeSum z (d.backGroup s)-(360/19)*(1/10)-96/19 := by
  have hh := Finset.sum_le_sum hpoint
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at hh
  unfold rawCriticalIncidence signedStarIncidence starIncidenceRamp headScoreSum edgeSum
  linarith only [hh]

theorem rawCriticalIncidence_uniform_score (x z : E → ℝ) (s : d.tree.Child)
    (hlo : 4 ≤ (d.backGroup s).card) (hhi : (d.backGroup s).card ≤ 17)
    (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hcap : ∀ e ∈ d.backGroup s, z e ≤ ScoredParameters.upper (d.backGroup s).card) :
    rawCriticalIncidence d x z s ≤
      (360/19)*(scoredMuSlope (d.backGroup s).card*edgeSum z (d.backGroup s)-1/10)+
        (96/19)*(ScoredParameters.localMassSlope (d.backGroup s).card/ScoredParameters.coefficient (d.backGroup s).card)*
          (((d.backGroup s).card : ℝ)*winningBenchmark d x s-edgeSum z (d.backGroup s))-96/19 := by
  have h := scored_small_count_slopes (d.backGroup s).card hlo hhi
  have hr := Finset.sum_le_sum (s := d.backGroup s) (fun e he =>
    incidenceRamp_linear_cap (9/20) _ _ (z e) h.2.2.2.1 (by linarith only [h.2.2.2.2.1])
      (by linarith only [h.2.2.2.2.2]) (hz e he) (hcap e he))
  have hp := Finset.sum_le_sum (s := d.backGroup s) (fun e _ =>
    ScoredParameters.perBackPayment_le_score_defect (d.backGroup s).card (winningBenchmark d x s) (z e))
  simp only [← Finset.mul_sum,Finset.sum_sub_distrib,Finset.sum_const,nsmul_eq_mul] at hr hp
  unfold rawCriticalIncidence signedStarIncidence starIncidenceRamp headScoreSum edgeSum
  linarith only [hr,hp]

end TSP.Improvements20261105
