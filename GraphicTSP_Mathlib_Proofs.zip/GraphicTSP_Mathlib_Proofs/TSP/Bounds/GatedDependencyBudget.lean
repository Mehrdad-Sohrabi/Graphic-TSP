import TSP.Improvements20261105.GatedComponentMass
import TSP.Improvements20261105.GatedCutDependencies

/-! One global mass budget for all tail, gated-prefix and outside
dependencies. It follows directly from each actual back-path constraint. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.gatePathTerm (P : GatePlan d) (a : GatedDrops d)
    (b : BackEdge d) (w : (expandedTree d).Child) : ℝ :=
  if onExpandedBackPath d b w then
    match (expandedTreeRoles d).symm w with
    | .inl v => if P.IsReceiver d v then (a.pref v : ℝ) else 0
    | .inr _ => 0
  else 0

noncomputable def GatedDrops.dependencyUse (P : GatePlan d) (a : GatedDrops d)
    (b : BackEdge d) : ℝ :=
  (∑ w : (expandedTree d).Child, a.gatePathTerm d P b w) + (a.tail (d.lower b.1) : ℝ) +
    if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0

theorem GatedDrops.gatePathTerm_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child) :
    0 ≤ a.gatePathTerm d P b w := by
  unfold gatePathTerm
  split_ifs
  · cases h : (expandedTreeRoles d).symm w with
    | inl v =>
      change 0 ≤ if P.IsReceiver d v then (a.pref v : ℝ) else 0
      split_ifs
      · exact_mod_cast ha.pref_nonneg v
      · exact le_rfl
    | inr v => exact le_rfl
  · exact le_rfl

theorem GatedDrops.cut_and_gate_term_le {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child) :
    (if w ∈ a.backPathCuts d P b then (1 : ℝ) else 0) + a.gatePathTerm d P b w ≤
      a.physicalPathTerm d b w := by
  by_cases hp : onExpandedBackPath d b w
  · have hi : (if w ∈ a.backPathCuts d P b then (1 : ℝ) else 0) ≤
        (a.trueCutWeight d P w : ℝ) := by
      split_ifs with hm
      · have hpos := (Finset.mem_filter.mp (Finset.mem_filter.mp hm).1).2
        exact_mod_cast (show 1 ≤ a.trueCutWeight d P w by omega)
      · exact_mod_cast a.trueCutWeight_nonneg d ha w
    obtain ⟨v, rfl⟩ := (expandedTreeRoles d).surjective w
    cases v with
    | inl v =>
      have hpre : (0 : ℝ) ≤ a.pref v := by exact_mod_cast ha.pref_nonneg v
      have hsuf : (0 : ℝ) ≤ a.suffix v := by exact_mod_cast ha.suffix_nonneg v
      simp only [gatePathTerm, physicalPathTerm, if_pos hp, Equiv.symm_apply_apply,
        trueCutWeight, Equiv.symm_apply_apply, trueRoleWeight, physicalRoleWeight] at *
      split_ifs at * <;> push_cast at * <;> linarith
    | inr v =>
      have hrep : (0 : ℝ) ≤ a.representative v := by exact_mod_cast ha.representative_nonneg v
      simp only [gatePathTerm, physicalPathTerm, if_pos hp, Equiv.symm_apply_apply,
        trueCutWeight, Equiv.symm_apply_apply, trueRoleWeight, physicalRoleWeight] at *
      split_ifs at * <;> push_cast at * <;> linarith
  · have hn : w ∉ a.backPathCuts d P b := fun hw => hp (Finset.mem_filter.mp hw).2
    simp [gatePathTerm, physicalPathTerm, hp, hn]

theorem GatedDrops.dependencyUse_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) : 0 ≤ a.dependencyUse d P b := by
  have ht : (0 : ℝ) ≤ a.tail (d.lower b.1) := by exact_mod_cast ha.tail_nonneg _
  have ho : (0 : ℝ) ≤ a.outside (d.anchor b.1) := by exact_mod_cast ha.outside_nonneg _
  have hg := Finset.sum_nonneg (fun w (_ : w ∈ Finset.univ) => a.gatePathTerm_nonneg d ha b w)
  unfold dependencyUse
  split_ifs <;> linarith

theorem GatedDrops.cut_and_dependency_budget {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    ((a.backPathCuts d P b).card : ℝ) + a.dependencyUse d P b ≤ (a.head (d.anchor b.1) : ℝ) := by
  have h := Finset.sum_le_sum (fun w (_ : w ∈ Finset.univ) => a.cut_and_gate_term_le d ha b w)
  simp only [Finset.sum_add_distrib, a.physicalPathTerm_sum d b] at h
  have hcard : (∑ w : (expandedTree d).Child, if w ∈ a.backPathCuts d P b then (1 : ℝ) else 0) =
      (a.backPathCuts d P b).card := by simp
  rw [hcard] at h
  have hb := ha.back b
  unfold dependencyUse
  linarith

theorem GatedDrops.dependencyUse_le_internal_indicator {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    a.dependencyUse d P b ≤
      if a.head (d.anchor b.1) = 1 ∧
        a.component d P (.inr (d.anchor b.1)) = a.component d P (.inl (d.lower b.1)) then 1 else 0 := by
  have h := a.cut_and_dependency_budget d ha b
  rw [a.back_cut_indicator_identity d ha b] at h
  linarith

theorem GatedDrops.total_dependency_mass_bound {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) :
    (∑ b : BackEdge d, x b * a.dependencyUse d P b) ≤ a.internalSelectedBackMass d P x := by
  unfold internalSelectedBackMass
  apply Finset.sum_le_sum
  intro b _
  have h := mul_le_mul_of_nonneg_left (a.dependencyUse_le_internal_indicator d ha b) (hx b)
  split_ifs at * <;> simpa using h

end TSP.Improvements20261105
