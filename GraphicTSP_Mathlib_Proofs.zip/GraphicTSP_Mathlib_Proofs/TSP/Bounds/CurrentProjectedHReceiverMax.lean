import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost
import TSP.Improvements20261105.PairIncomingBudget
import TSP.Improvements20261105.TerminalHReceiver

/-! Every nonroot head of the actual simultaneous construction retains
its fixed cover bound in the signed P/Q arm. Actual-zero and erased-positive
heads are proved by different valid inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_H_receiver_max (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i=(v : V))
    (hunary : childCount d v=1) (hvH : v ∈ fixedHForceTargets d x z (415/2) (704/5) C) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
      max (C.cover i.1) (-targetForceSlack d x 24 4 v) := by
  have hnr : d.centers i ≠ d.tree.root := by rw [hv]; exact v.2
  have hir : i ≠ rootStar := fun he => hnr (he ▸ hroot)
  have hT : ∀ s ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d s := by
    intro c hc
    obtain ⟨k,hk,rfl⟩ := Finset.mem_image.mp hc
    exact (Finset.mem_filter.mp hk).2.1
  have hci := terminal_H_forced_PQ_connector d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) C (fixedHForceTargets d x z (415/2) (704/5) C)
    (fixedHForceTargets_subset d x z (415/2) (704/5) C)
    (fixedPositiveTerminalChildren d x) hT owner ho rootStar R hR i hir v hv hunary hvH
  have hdi := current_projected_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar Y R hY
    hrep hbacks hloss hterminal hzero i hnr
  change pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-_ ≤ _ at hci
  apply (sub_le_iff_le_add).mpr
  apply max_le
  · linarith only [hci]
  · linarith only [hdi,le_max_left (C.cover i.1) (-targetForceSlack d x 24 4 v)]

end TSP.Improvements20261105
