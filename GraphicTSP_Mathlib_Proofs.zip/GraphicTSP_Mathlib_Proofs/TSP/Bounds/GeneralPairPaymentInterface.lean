import TSP.Improvements20261105.CanonicalGlobalBudgetOfPairs
import TSP.Improvements20261105.PhysicalTourOfRoleBudget
import TSP.Improvements20261105.ProjectedGuardCompatibility
import TSP.Improvements20261105.FixedProjectionIntegration

/-! A transparent local interface for the remaining pair cases. Every
field describes the original graph, projected edge weights, or constructed
points. No tour-ratio or global cost inequality is a field. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]

noncomputable def generalEligibleHeads {G : Graph V E} (d : DFSData G) (x : E → ℝ) : Finset d.tree.Child :=
  Finset.univ.filter (ScoredStar d x)

noncomputable def generalRawCriticalHeads {G : Graph V E} (d : DFSData G) (x z : E → ℝ)
    (a : GatedDrops d) : Finset d.tree.Child :=
  (fixedCriticalHeads d x z (generalEligibleHeads d x)).filter (fun s =>
    2 ≤ (a.componentHeads d (fixedGatePlan d x) (a.headComponent d (fixedGatePlan d x) s)).card)

variable (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

structure GeneralPairPaymentContext where
  hc : IsTwoVertexConnected G
  hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ
  hpositive : ∀ e, 0 < x₀ e
  hx : G.SubtourFeasible x
  hcap : ∀ e, x e ≤ 1
  hdom : ∀ e, min (x₀ e) 1 ≤ x e
  hz : ∀ e, 0 ≤ z e
  hzx : ∀ e, z e ≤ x e
  htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s)
  hprojection : ∀ s, edgeSum z ((d).backGroup s)=edgeSum x ((d).backGroup s)-
    fixedRemoval d x (allFullOverrideTargets d x) s
  hparts : ∀ s, 1 < edgeSum z ((d).backGroup s) → PartitionableVertex G x₀ ((d).tree.parent s) →
    UnitPartCapacities G z ((d).tree.parent s)
  C : ProjectedCoverWitness d x z (415/2) (704/5)
  owner : E → Option (d).StarIndex
  ho : ValidOwner (d).stars owner
  rootStar : (d).StarIndex
  hrootStar : (d).centers rootStar=(d).tree.root
  Q : E ⊕ (d).StarIndex → ℝ
  R : E ⊕ (d).StarIndex → ℝ
  Z : E ⊕ (d).StarIndex → ℝ
  hQ : Q ∈ projectedFrameworkTwo G (d).centers owner
  hR : R ∈ projectedFrameworkTwo G (d).centers owner
  hZ : Z ∈ projectedFrameworkTwo G (d).centers owner
  hrep : ∀ c, Q (.inl ((d).treeEdge c))=x ((d).treeEdge c)/2+
    fixedQIncrease d x (fixedPositiveTerminalChildren d x) c
  hbacks : ∀ e ∈ (d).backEdges, Q (.inl e)=1-x e/2
  hconnectors : ∀ i, R (.inr i)=Q (.inr i)
  hconn : FixedQConnectorValues d x hx (by have hh := hc.1; omega) hcap R
  a : GatedDrops d
  ha : a.Admissible d (fixedGatePlan d x)
  t : (d).tree.Child → ℝ
  ht : ∀ v, 0 ≤ t v
  f : GatedArc d → ℝ
  hf : Chapter06.Balanced (gatedNetwork d (fixedGatePlan d x)) f
  hb : RealFlowBounds (gatedLower d (fixedGatePlan d x)) (gatedAugmentedUpper d (fixedGatePlan d x) t) f
  hcan : CanonicalGatedFor d (fixedGatePlan d x) t f (a.potential d (fixedGatePlan d x))
  m : (d).StarIndex → ℝ
  hmU : ∀ i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x, 0 ≤ m i
  hmprojected : ∀ i ∈ projectedZeroTerminalHeads d z,
    (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x ((d).treeEdge i.1)-projectedZeroGuardCapacity d x z Q i) 0) 0 ≤ m i
  hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
    m i=(15/88 : ℝ)*terminalSubtreeGuardValue d x i.1
  hsave : edgeSum R (nonremovableRepresentatives (d).stars) ≤
    edgeSum x (Finset.univ \ removableEdges (d).stars)/2-
      ((∑ i ∈ projectedZeroTerminalHeads d z, m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, m i))
  hloss : ∀ i, edgeSum Q (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
    (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Q i else 0)+
    2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0)
  hguarded : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
    max (R (.inr i)-edgeSum x ((d).stars i)/2)
      (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
      -zeroQCredit d x Q i
  hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
    ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
      -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1
  hZN : edgeSum Z (nonremovableRepresentatives (d).stars)=((Finset.univ \ removableEdges (d).stars).card : ℝ)/3
  hcost : (∑ i : (d).StarIndex,
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i+
      72*(Z (.inr i)-gatedArmBase d i.1))
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i+
        72*(((d).stars i).card-1-edgeSum Z (starRepresentatives (d).stars i)-gatedArmBase d i.1))) ≤
    (∑ i : (d).StarIndex,
      jointHeadTerm (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
        (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i) (a.head i.1 : ℝ))+
      48*a.value d (fixedGatePlan d x) (fun _ => 0)

/-- The remaining claim is one explicit local inequality for each actual
remaining pair. This definition contains no global bound or optimum. -/
def GeneralPairPaymentContext.PairPayments
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root) : Prop :=
  ∀ p ∈ K.a.internalMatchingPairs d (fixedGatePlan d x) x z K.C,
    currentSelectedHeadCost d x z K.C K.owner K.rootStar K.R (generalEligibleHeads d x)
        (generalRawCriticalHeads d x z K.a) K.a.head p.1+
      currentSelectedHeadCost d x z K.C K.owner K.rootStar K.R (generalEligibleHeads d x)
        (generalRawCriticalHeads d x z K.a) K.a.head p.2-
      24*retainedSelectedResidual d x z K.a.head p.2+
      24*extendedResidualIncomingDebt d x z K.a.head
        (K.a.internalUnmatchedHeads d (fixedGatePlan d x) x z K.C)
        (K.a.internalMatchingTargets d (fixedGatePlan d x) x z K.C) p.1 ≤
    4*((((d).backGroup p.1.1).card : ℝ)+((d).backGroup p.2.1).card)+
      2*(originalMatchingBadLabel d x₀ p.1.1 : ℝ)+
      (162/19)*(matchingPairCreditIndicator d K.a.head p : ℝ)

end TSP.Improvements20261105
