import TSP.Improvements20261105.MassRemoval

/-! Finite mixtures of conflict-free selections. A local closed-neighborhood
mass bound suffices. This elementary construction will be applied to the
internal-resource graph of the simultaneous Q construction. -/
namespace TSP.Improvements20261105
open Graph Classical
open scoped BigOperators
variable {E : Type} [DecidableEq E]

def ConflictFree (R : E → E → Prop) (J : Finset E) : Prop :=
  ∀ e ∈ J, ∀ f ∈ J, e ≠ f → ¬R e f

theorem conflict_free_available {I : Type} [Fintype I]
    (R : E → E → Prop) (A : Finset E) (x : E → ℝ)
    (w : I → ℝ) (J : I → Finset E) (hw : ∀ i, 0 ≤ w i)
    (hs : ∑ i, w i = 1) (hsub : ∀ i, J i ⊆ A)
    (hm : ∀ f ∈ A, ∑ i, w i * incidence (J i) f = x f) (e : E) :
    1 - (∑ f ∈ A.filter (R e), x f) ≤
      ∑ i, if (∀ f ∈ J i, ¬R e f) then w i else 0 := by
  let B := A.filter (R e)
  have hbad : (∑ i, if (∀ f ∈ J i, ¬R e f) then 0 else w i) ≤
      ∑ f ∈ B, x f := by
    calc
      _ ≤ ∑ i, ∑ f ∈ B, w i * incidence (J i) f := by
        apply Finset.sum_le_sum
        intro i _
        by_cases hf : ∀ f ∈ J i, ¬R e f
        · simp only [if_pos hf]
          exact Finset.sum_nonneg (fun f _ => mul_nonneg (hw i) (by unfold incidence; split_ifs <;> norm_num))
        · simp only [if_neg hf]
          push_neg at hf
          obtain ⟨f, hfJ, hef⟩ := hf
          have hfB : f ∈ B := Finset.mem_filter.mpr ⟨hsub i hfJ, hef⟩
          have ht := Finset.single_le_sum (s := B)
            (f := fun f => w i * incidence (J i) f)
            (fun f _ => mul_nonneg (hw i) (by unfold incidence; split_ifs <;> norm_num)) hfB
          simpa [incidence, hfJ] using ht
      _ = ∑ f ∈ B, x f := by
        rw [Finset.sum_comm]
        exact Finset.sum_congr rfl (fun f hf => hm f (Finset.mem_filter.mp hf).1)
  have hsplit : (∑ i, if (∀ f ∈ J i, ¬R e f) then w i else 0) +
      (∑ i, if (∀ f ∈ J i, ¬R e f) then 0 else w i) = 1 := by
    rw [← Finset.sum_add_distrib, ← hs]
    apply Finset.sum_congr rfl
    intro i _
    split_ifs <;> simp
  dsimp [B] at hbad
  linarith

theorem conflict_mixture_insert {I : Type} [Fintype I]
    (R : E → E → Prop) (hRs : Symmetric R) (A : Finset E) (e : E) (he : e ∉ A)
    (x : E → ℝ) (w : I → ℝ) (J : I → Finset E)
    (hw : ∀ i, 0 ≤ w i) (hs : ∑ i, w i = 1)
    (hJ : ∀ i, J i ⊆ A ∧ ConflictFree R (J i))
    (hm : ∀ f, ∑ i, w i * incidence (J i) f = if f ∈ A then x f else 0)
    (hx : 0 ≤ x e)
    (ha : x e ≤ ∑ i, if (∀ f ∈ J i, ¬R e f) then w i else 0) :
    ∃ (I' : Type) (_ : Fintype I') (w' : I' → ℝ) (J' : I' → Finset E),
      (∀ i, 0 ≤ w' i) ∧ (∑ i, w' i = 1) ∧
      (∀ i, J' i ⊆ insert e A ∧ ConflictFree R (J' i)) ∧
      ∀ f, ∑ i, w' i * incidence (J' i) f = if f ∈ insert e A then x f else 0 := by
  let F : Finset I := Finset.univ.filter (fun i => ∀ f ∈ J i, ¬R e f)
  have hmass : x e ≤ edgeSum w F := by simpa [F, edgeSum, Finset.sum_filter] using ha
  obtain ⟨v, hv, hout, hsum⟩ := exists_remove_mass w F hw (x e) hx hmass
  let r := fun i => w i - v i
  have hr : ∀ i, 0 ≤ r i ∧ r i ≤ w i := fun i => ⟨sub_nonneg.mpr (hv i).2, by
    dsimp [r]; linarith [(hv i).1]⟩
  have hrzero : ∀ i ∉ F, r i = 0 := fun i hi => by simp [r, hout i hi]
  have hrsum : ∑ i, r i = x e := by
    have hfilter : (∑ i, r i) = ∑ i ∈ F, r i := by
      symm
      apply Finset.sum_subset (Finset.subset_univ F)
      intro i _ hi
      exact hrzero i hi
    rw [hfilter]
    change (∑ i ∈ F, (w i - v i)) = _
    rw [Finset.sum_sub_distrib]
    change edgeSum w F - edgeSum v F = _
    linarith
  let K := fun i => if i ∈ F then insert e (J i) else J i
  have hK : ∀ i, K i ⊆ insert e A ∧ ConflictFree R (K i) := by
    intro i
    by_cases hi : i ∈ F
    · rw [show K i = insert e (J i) from if_pos hi]
      refine ⟨Finset.insert_subset_insert e (hJ i).1, ?_⟩
      have hfree := (Finset.mem_filter.mp hi).2
      intro f hf g hg hfg
      rcases Finset.mem_insert.mp hf with hfe | hfJ
      · subst f
        exact hfree g (Finset.mem_insert.mp hg |>.resolve_left (Ne.symm hfg))
      · rcases Finset.mem_insert.mp hg with hge | hgJ
        · subst g
          exact fun h => hfree f hfJ (hRs h)
        · exact (hJ i).2 f hfJ g hgJ hfg
    · rw [show K i = J i from if_neg hi]
      exact ⟨(hJ i).1.trans (Finset.subset_insert _ _), (hJ i).2⟩
  refine ⟨I ⊕ I, inferInstance, Sum.elim v r, Sum.elim J K, ?_, ?_, ?_, ?_⟩
  · intro i
    cases i with
    | inl i => exact (hv i).1
    | inr i => exact (hr i).1
  · simp only [Fintype.sum_sum_type, Sum.elim_inl, Sum.elim_inr]
    rw [← Finset.sum_add_distrib, ← hs]
    exact Finset.sum_congr rfl (fun i _ => by dsimp [r]; ring)
  · intro i
    cases i with
    | inl i => exact ⟨(hJ i).1.trans (Finset.subset_insert _ _), (hJ i).2⟩
    | inr i => exact hK i
  · intro f
    simp only [Fintype.sum_sum_type, Sum.elim_inl, Sum.elim_inr]
    by_cases hfe : f = e
    · subst f
      have hJe : ∀ i, e ∉ J i := fun i hi => he ((hJ i).1 hi)
      have hterm : ∀ i, r i * incidence (K i) e = r i := by
        intro i
        by_cases hi : i ∈ F
        · simp [K, hi, incidence]
        · simp [hrzero i hi]
      simp only [incidence, hJe, if_false, mul_zero, Finset.sum_const_zero, zero_add,
        Finset.mem_insert_self, if_true]
      change (∑ i, r i * incidence (K i) e) = _
      simp_rw [hterm]
      exact hrsum
    · have hKf : ∀ i, incidence (K i) f = incidence (J i) f := by
        intro i
        by_cases hi : i ∈ F <;> simp [K, hi, incidence, hfe]
      simp_rw [hKf]
      rw [← Finset.sum_add_distrib]
      have hterm : ∀ i, v i * incidence (J i) f + r i * incidence (J i) f =
          w i * incidence (J i) f := fun i => by dsimp [r]; ring
      simp_rw [hterm]
      simpa [hfe] using hm f

/-- A nonnegative vector whose every closed conflict neighborhood has mass
at most one is the marginal vector of actual finite conflict-free sets. -/
theorem conflict_mixture (R : E → E → Prop) (hRr : Reflexive R) (hRs : Symmetric R)
    (A : Finset E) (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (hbound : ∀ e ∈ A, (∑ f ∈ A.filter (R e), x f) ≤ 1) :
    ∃ (I : Type) (_ : Fintype I) (w : I → ℝ) (J : I → Finset E),
      (∀ i, 0 ≤ w i) ∧ (∑ i, w i = 1) ∧
      (∀ i, J i ⊆ A ∧ ConflictFree R (J i)) ∧
      ∀ f, ∑ i, w i * incidence (J i) f = if f ∈ A then x f else 0 := by
  induction A using Finset.induction_on with
  | empty =>
    refine ⟨Unit, inferInstance, fun _ => 1, fun _ => ∅, by simp, by simp, ?_, ?_⟩
    · intro i; exact ⟨Finset.Subset.refl _, by simp [ConflictFree]⟩
    · intro f; simp [incidence]
  | @insert e A he ih =>
    have hsmall : ∀ f ∈ A, (∑ g ∈ A.filter (R f), x g) ≤ 1 := by
      intro f hf
      apply le_trans _ (hbound f (Finset.mem_insert_of_mem hf))
      exact Finset.sum_le_sum_of_subset_of_nonneg
        (Finset.filter_subset_filter _ (Finset.subset_insert _ _)) (fun g _ _ => hx g)
    obtain ⟨I, hi, w, J, hw, hs, hJ, hm⟩ := ih hsmall
    letI := hi
    have hb := hbound e (Finset.mem_insert_self _ _)
    have hfilt : (insert e A).filter (R e) = insert e (A.filter (R e)) := by
      ext f; simp only [Finset.mem_filter, Finset.mem_insert]; constructor
      · rintro ⟨rfl | hf, hR⟩
        · exact Or.inl rfl
        · exact Or.inr ⟨hf, hR⟩
      · rintro (hfe | ⟨hf, hR⟩)
        · subst f
          exact ⟨Or.inl rfl, hRr e⟩
        · exact ⟨Or.inr hf, hR⟩
    rw [hfilt, Finset.sum_insert (fun h => he (Finset.mem_filter.mp h).1)] at hb
    have hav := conflict_free_available R A x w J hw hs (fun i => (hJ i).1)
      (fun f hf => by simpa [hf] using hm f) e
    exact conflict_mixture_insert R hRs A e he x w J hw hs hJ hm (hx e) (by linarith)

end TSP.Improvements20261105
