import TSP.Improvements20261105.GatedDualGeometry
import TSP.Improvements20261105.ComplementarityConverse

/-! Every optimal augmented dual has zero drop on each active representative.
This follows directly from complementary slackness and auxiliary-node balance. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem gated_optimal_complementary (P : GatePlan d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (he : realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
        ∑ v : d.tree.Child, f (gatedPaidArc d v)) :
    (∀ a u, gatedAugmentedUpper d P t a = some u → f a < u →
      (p ((gatedNetwork d P).dst a) : ℝ) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℝ)) ∧
    (∀ a, (gatedLower d P a : ℝ) < f a → (gatedCost d a : ℝ) ≤
      (p ((gatedNetwork d P).dst a) : ℝ) - p ((gatedNetwork d P).src a)) := by
  apply real_capacity_equality_complementary (gatedNetwork d P)
    (fun a => (gatedCost d a : ℤ)) (gatedLower d P) (gatedAugmentedUpper d P t)
    f hf hb (fun v => (p v : ℝ))
  · intro a ha
    exact_mod_cast hp a ((gatedAugmentedUpper_none d P t a).mp ha)
  · exact he.trans (gated_cost_sum d f).symm

theorem gated_optimal_active_representative_zero (P : GatePlan d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (he : realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
        ∑ v : d.tree.Child, f (gatedPaidArc d v))
    (v : d.tree.Child) (hv : (d.backGroup v).Nonempty) :
    gatedRepresentativeDrop d p v = 0 := by
  by_contra hn
  have hr : gatedRepresentativeDrop d p v = 1 :=
    (gated_representative_drop_binary d hp v hv).resolve_left hn
  have hh : gatedHeadSelector d p v = 1 := by
    have hbound := gated_representative_drop_bounds d hp v hv
    have hbin := gated_head_selector_binary d P p hp v
    omega
  have hrR : (p (gatedAux d v) : ℝ) - p (gatedCenter d v) = 1 := by
    exact_mod_cast hr
  have hhR : (p (gatedAux d v) : ℝ) - p (gatedHead d v) = 1 := by
    exact_mod_cast hh
  have hc := gated_optimal_complementary d P t f hf hb p hp he
  have hnonneg : ∀ a, 0 ≤ f a := fun a => (Nat.cast_nonneg _).trans (hb a).1
  have hrep : f (gatedRepArc d v) = 0 := by
    apply le_antisymm _ (hnonneg _)
    by_contra hpos
    have hlow : (gatedLower d P (gatedRepArc d v) : ℝ) < f (gatedRepArc d v) := by
      simpa [gatedLower, hv] using lt_of_not_ge hpos
    have hh' := hc.2 _ hlow
    simp [gatedCost, gatedNetwork] at hh'
    dsimp [gatedRepresentativeDrop] at hr
    omega
  have hrev : f (gatedReverseArc d v) = 0 := by
    apply le_antisymm _ (hnonneg _)
    by_contra hpos
    have hlow : (gatedLower d P (gatedReverseArc d v) : ℝ) < f (gatedReverseArc d v) := by
      simpa [gatedLower] using lt_of_not_ge hpos
    have hh' := hc.2 _ hlow
    simp [gatedCost, gatedNetwork, gatedExtraSrc, gatedExtraDst] at hh'
    dsimp [gatedHeadSelector] at hh
    omega
  have hfree : (gatedFreeBase d v : ℝ) + t v ≤ f (gatedFreeArc d v) := by
    by_contra hlt
    have hh' := hc.1 _ _ (gatedAugmentedUpper_free d P t v) (lt_of_not_ge hlt)
    simp [gatedCost, gatedNetwork, gatedExtraSrc, gatedExtraDst] at hh'
    dsimp [gatedHeadSelector] at hh
    omega
  have hbase : (1 : ℝ) ≤ gatedFreeBase d v := by
    unfold gatedFreeBase
    split_ifs <;> norm_num
  have hbal := gated_balance_aux d P f hf v
  rw [hrep, hrev] at hbal
  linarith [ht v, hnonneg (gatedSuffixArc d v)]

theorem exists_augmented_gated_dual_no_representative (hs : G.IsSimple)
    (hc : IsTwoVertexConnected G) (P : GatePlan d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) :
    ∃ (f : GatedArc d → ℝ) (p : GatedVertex d → ℤ),
      Chapter06.Balanced (gatedNetwork d P) f ∧
      RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f ∧
      GatedDualFeasible d P p ∧
      realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
        (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
          ∑ v : d.tree.Child, f (gatedPaidArc d v) ∧
      ∀ v, (d.backGroup v).Nonempty → gatedRepresentativeDrop d p v = 0 := by
  obtain ⟨f, p, hf, hb, hp, he⟩ := exists_augmented_gated_primal_dual d hs hc P t ht
  exact ⟨f, p, hf, hb, hp, he, gated_optimal_active_representative_zero d P t ht f hf hb p hp he⟩

end TSP.Improvements20261105
