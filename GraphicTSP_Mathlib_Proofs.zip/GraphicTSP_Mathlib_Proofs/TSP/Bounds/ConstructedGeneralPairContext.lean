import TSP.Improvements20261105.GeneralPairPaymentInterface

/-! All data in the local pair interface are constructed from the graph
and the original/capped LP vectors. No local cost estimate is assumed. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x₀ x : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem exists_general_pair_context (hc : IsTwoVertexConnected G)
    (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (hdom : ∀ e, min (x₀ e) 1 ≤ x e) :
    ∃ z : E → ℝ, Nonempty (GeneralPairPaymentContext G x₀ x z hs hconnected root) := by
  have hn : 2 ≤ Fintype.card V := by have hh := hc.1; omega
  obtain ⟨z,hbox,htree,hm,_,hparts⟩ := exists_fixed_projection d hs hx hcap hdom hn
    (scoredDFS_unit_priority G x hs hconnected root hcap)
    (allFullOverrideTargets d x) (allFullOverrideTargets_valid d x)
  obtain ⟨owner,ho⟩ := exists_validOwner (d).stars (d).dfs_removable_system.2.1
  have hdegree : 2 ≤ G.intDegree Finset.univ (d).tree.root := by
    have hh := (subtour_degree_ge_two G hn hx (d).tree.root).trans (degree_le_full_of_box G hcap (d).tree.root)
    exact_mod_cast hh
  obtain ⟨rootStar,hrootStar,_⟩ := root_star_exists d hc hdegree
  obtain ⟨C,Q,R,Z,m,a,hA,hQ,hR,hZ,hrep,hbacks,hconnectors,hconn,ha,hflow,hmU,hmprojected,
    hmpositive,hsave,hloss,hguarded,hterminal,hZN,hcost⟩ :=
    exists_current_projected_guarded_PQZ d hs hc x z hx hn hcap hm owner ho rootStar hrootStar
  let A := currentGuardedP d x z C owner rootStar
  let U := pqConnectorArm d x (415/2) (704/5) A R
  let W := pqDeficitArm d x (415/2) (704/5) A R
  let t := extendStarValue d (fun i => (max (U i) (W i)-W i)/48)
  have ht : ∀ v, 0 ≤ t v := by
    intro v
    dsimp only [t,extendStarValue]
    split_ifs
    · exact div_nonneg (sub_nonneg.mpr (le_max_right _ _)) (by norm_num)
    · exact le_rfl
  obtain ⟨f,hf,hb,hcan⟩ := hflow
  exact ⟨z,⟨{
    hc := hc, hx₀ := hx₀, hpositive := hpositive, hx := hx, hcap := hcap, hdom := hdom,
    hz := fun e => (hbox e).1, hzx := fun e => (hbox e).2, htree := htree,
    hprojection := hm, hparts := hparts, C := C, owner := owner, ho := ho,
    rootStar := rootStar, hrootStar := hrootStar, Q := Q, R := R, Z := Z,
    hQ := hQ, hR := hR, hZ := hZ, hrep := hrep, hbacks := hbacks,
    hconnectors := hconnectors, hconn := hconn, a := a, ha := ha, t := t, ht := ht,
    f := f, hf := hf, hb := hb, hcan := hcan, m := m, hmU := hmU,
    hmprojected := hmprojected, hmpositive := hmpositive, hsave := hsave, hloss := hloss,
    hguarded := hguarded, hterminal := hterminal, hZN := hZN, hcost := hcost }⟩⟩

end TSP.Improvements20261105
