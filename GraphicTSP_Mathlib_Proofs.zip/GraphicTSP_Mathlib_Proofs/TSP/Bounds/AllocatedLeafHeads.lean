import TSP.Improvements20261105.NoPairLeafDisjoint
import TSP.Improvements20261105.LeafProjectionConversion

/-! The head set already allocated by the leaf ledger is an actual
subset of leaf components. All its selectors vanish canonically. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.allocatedLeafHeads (P : GatePlan d) (a : GatedDrops d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5)) : Finset d.StarIndex :=
  ((((((((a.paidLeafHeads d P x ∪ pairStarHeads d (a.KLeafPairs d P x z C)) ∪
    pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C))) ∪
    a.componentStarUnion d P (a.largeRemainingLeafRoots d P x z C)) ∪
    a.componentStarUnion d P (a.solePairLeafRoots d P x z C)) ∪
    a.componentStarUnion d P (a.oneExtraBackLeafRoots d P x z C)) ∪
    a.componentStarUnion d P (a.twoBackSingleLeafRoots d P x z C)) ∪
    a.componentStarUnion d P (a.twoBackTwoHeadLeafRoots d P x z C)) ∪
    a.componentStarUnion d P (a.noPairLeafRoots d P x z C))

theorem GatedDrops.componentStarUnion_mono (P : GatePlan d) (a : GatedDrops d)
    (L M : Finset (FlowVertex d)) (hLM : L ⊆ M) :
    a.componentStarUnion d P L ⊆ a.componentStarUnion d P M := by
  intro i hi
  obtain ⟨r,hr,hir⟩ := Finset.mem_biUnion.mp hi
  exact Finset.mem_biUnion.mpr ⟨r,hLM hr,hir⟩

theorem GatedDrops.allocatedLeafHeads_subset_leaf_stars (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P)) :
    a.allocatedLeafHeads d P x z C ⊆ a.componentStarUnion d P
      ((a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d))) := by
  let L := (a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d))
  have hp : a.paidLeafHeads d P x ⊆ a.componentStarUnion d P L := by
    rw [a.paidLeafHeads_eq_starUnion d P x]
    exact a.componentStarUnion_mono d P _ L (Finset.union_subset
      (a.zeroLeafRoots_headful_subset d P x) (a.positiveTerminalLeafRoots_headful_subset d P x))
  have hk : pairStarHeads d (a.KLeafPairs d P x z C) ⊆ a.componentStarUnion d P L :=
    (a.KLeafHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan).trans
      (a.componentStarUnion_mono d P _ L (a.KLeafRoots_headful_subset d P x z C))
  have hM : pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)) ⊆
      a.componentStarUnion d P L :=
    (a.matchingPairHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan _).trans
      (a.componentStarUnion_mono d P _ L (Finset.filter_subset _ _))
  have hL := a.componentStarUnion_mono d P (a.largeRemainingLeafRoots d P x z C) L (Finset.filter_subset _ _)
  have hS := a.componentStarUnion_mono d P (a.solePairLeafRoots d P x z C) L (Finset.filter_subset _ _)
  have hE := a.componentStarUnion_mono d P (a.oneExtraBackLeafRoots d P x z C) L (Finset.filter_subset _ _)
  have hB := a.componentStarUnion_mono d P (a.twoBackSingleLeafRoots d P x z C) L (Finset.filter_subset _ _)
  have hD := a.componentStarUnion_mono d P (a.twoBackTwoHeadLeafRoots d P x z C) L (Finset.filter_subset _ _)
  have hN := a.componentStarUnion_mono d P (a.noPairLeafRoots d P x z C) L (Finset.filter_subset _ _)
  exact Finset.union_subset (Finset.union_subset (Finset.union_subset (Finset.union_subset
    (Finset.union_subset (Finset.union_subset (Finset.union_subset (Finset.union_subset hp hk) hM) hL) hS) hE) hB) hD) hN

theorem GatedDrops.allocatedLeafHeads_unselected (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (i : d.StarIndex) (hi : i ∈ a.allocatedLeafHeads d P x z C) : a.head i.1=0 := by
  have hsub := a.allocatedLeafHeads_subset_leaf_stars d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  obtain ⟨r,hr,hir⟩ := Finset.mem_biUnion.mp (hsub hi)
  obtain ⟨s,hsL,he⟩ := Finset.mem_image.mp hr
  have hcomp : a.headComponent d P i.1=s := Subtype.ext ((Finset.mem_filter.mp hir).2.trans he.symm)
  exact canonical_leaf_head_zero d hs hc P hP t ht f hf hb a ha hcan i.1 (hcomp.symm ▸ hsL)

end TSP.Improvements20261105
