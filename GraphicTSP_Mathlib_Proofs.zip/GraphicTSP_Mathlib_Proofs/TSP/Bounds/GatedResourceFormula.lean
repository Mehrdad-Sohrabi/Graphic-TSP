import TSP.Improvements20261105.GatedDonorResources
import TSP.Improvements20261105.GatedCoverageExcess

/-! Express donor resources using actual outgoing, gated-cut and outside
back masses. No resource is represented by an assumed certificate. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def tailBackMass (x : BackEdge d → ℝ) (v : V) : ℝ :=
  ∑ b : BackEdge d, if d.lower b.1 = v then x b else 0

noncomputable def gateBackMass (x : BackEdge d → ℝ) (v : d.tree.Child) : ℝ :=
  ∑ b : BackEdge d, if backConnectorPath d b v then x b else 0

noncomputable def outsideBackMass (P : GatePlan d) (x : BackEdge d → ℝ) (s : d.tree.Child) : ℝ :=
  ∑ b : BackEdge d, if d.anchor b.1 = s ∧ P.OutsideBack d b then x b else 0

theorem tailBackMass_nonneg (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) (v : V) :
    0 ≤ tailBackMass d x v := by
  apply Finset.sum_nonneg
  intro b _
  split_ifs <;> simp_all

theorem gateBackMass_nonneg (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) (v : d.tree.Child) :
    0 ≤ gateBackMass d x v := by
  apply Finset.sum_nonneg
  intro b _
  split_ifs <;> simp_all

theorem outsideBackMass_nonneg (P : GatePlan d) (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b)
    (s : d.tree.Child) : 0 ≤ outsideBackMass d P x s := by
  apply Finset.sum_nonneg
  intro b _
  split_ifs <;> simp_all

theorem tailBackMass_original (x : E → ℝ) (v : V) :
    tailBackMass d (fun b => x b.1) v = outgoingBackMass d x v := by
  unfold tailBackMass outgoingBackMass
  have he (b : BackEdge d) : d.lower b.1 = v ↔ b.1 ∈ d.backEdges.filter (fun e => d.lower e = v) := by
    simp [b.2]
  simp_rw [he]
  exact original_back_subset_sum d x _ (Finset.filter_subset _ _)

theorem gateBackMass_original (x : E → ℝ) (v : d.tree.Child) :
    gateBackMass d (fun b => x b.1) v = edgeSum x (deletedSubtreeCut d v) := by
  unfold gateBackMass
  have he (b : BackEdge d) : backConnectorPath d b v ↔ b.1 ∈ deletedSubtreeCut d v :=
    (cycle_parent_arc_iff d b v).trans (deletedSubtreeCut_iff d v b.1).symm
  simp_rw [he]
  exact original_back_subset_sum d x _ (deletedSubtreeCut_back d v)

theorem GatedDrops.donorResource_formula (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (s : d.tree.Child) :
    a.donorResource d P x s = (a.tail s : ℝ) * tailBackMass d x s +
      (if P.UsesGate d s then (a.pref (P.receiver s) : ℝ) * gateBackMass d x (P.receiver s) else 0) +
      (a.outside s : ℝ) * outsideBackMass d P x s := by
  unfold donorResource donorUse tailBackMass gateBackMass outsideBackMass
  by_cases hu : P.UsesGate d s
  · simp only [hu, true_and, if_true, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro b _
    split_ifs <;> ring
  · simp only [hu, false_and, if_false, add_zero, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro b _
    split_ifs <;> ring

end TSP.Improvements20261105
