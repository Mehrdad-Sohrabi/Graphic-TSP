import TSP.Improvements20261105.FixedCoverAdjustments

/-! The fixed P choices satisfy the actual projected deficit arms and
the source-cap inequalities used by subsequent target forces. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem coveredPIncrease_free_lower (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (s : d.tree.Child) (hr : d.tree.parent s ≠ d.tree.root) :
    min (survivingExcess d x s) (outgoingBackMass d x s) ≤ coveredPIncrease d x P Q C.cover s := by
  rw [coveredPIncrease, if_neg hr]
  split_ifs with hl
  · have hfR := (projectionLink_receiver_floor d hs x z hx hn hcap hm Q hQ s hl).trans
      (C.floor_bound (unaryNext d s))
    apply le_min (min_le_left _ _)
    apply (min_le_right _ _).trans
    apply le_add_of_nonneg_right
    apply div_nonneg _ hP.le
    linarith
  · exact min_le_left _ _

theorem coveredPIncrease_deficit (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (s : d.tree.Child) (hr : d.tree.parent s ≠ d.tree.root) :
    P * (edgeSum z (d.backGroup s) - 1 - coveredPIncrease d x P Q C.cover s) -
      Q * (x (d.treeEdge s) + preliminaryQIncrease d x s) ≤ C.cover s := by
  have he := fixed_projected_excess_eq d hs x z hx hn _ hm s
  by_cases hl : s ∈ projectionLinks d x
  · have hp := projectionLink_source_positive d hs x z hx hn hm s hl
    rw [max_eq_left (by linarith : 0 ≤ edgeSum z (d.backGroup s) - 1)] at he
    rw [he]
    exact (coveredPIncrease_link d hs x z hx hn hcap hm P Q hP hQ C s hl).2.2.1
  · rw [coveredPIncrease, if_neg hr, if_neg hl]
    by_cases hp : 1 < edgeSum z (d.backGroup s)
    · rw [max_eq_left (by linarith : 0 ≤ edgeSum z (d.backGroup s) - 1)] at he
      rw [← he]
      have hf := (fixedCoverFloor_positive_lower d hs x z hx hcap Q hQ s hp).trans (C.floor_bound s)
      nlinarith
    · have ha : edgeSum z (d.backGroup s) ≤ 1 := le_of_not_gt hp
      rw [max_eq_right (by linarith : edgeSum z (d.backGroup s) - 1 ≤ 0)] at he
      have heta := preliminaryQIncrease_bounds d hs hx hcap s
      have hzeta : preliminaryQIncrease d x s = 0 := by linarith [heta.1, heta.2.2.2]
      rw [← he, hzeta, sub_zero, add_zero]
      have hmax : max (x (d.treeEdge s) + edgeSum z (d.backGroup s) - 1) 0 ≤ x (d.treeEdge s) :=
        max_le (by linarith) (hx.1 _)
      have hf := (fixedCoverFloor_baseline_lower d hs x z hx hn hcap hm Q hQ s).trans (C.floor_bound s)
      have hmQ := mul_le_mul_of_nonpos_left hmax (neg_nonpos.mpr hQ)
      have hp0 := mul_nonpos_of_nonneg_of_nonpos hP.le (sub_nonpos.mpr ha)
      nlinarith

theorem coveredPIncrease_matched_cap (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (s : d.tree.Child) (hsM : s ∈ C.matching) :
    outgoingBackMass d x s ≤ coveredPIncrease d x P Q C.cover s ∧
      Q * survivingExcess d x s - P * x (d.treeEdge s) - Q * preliminaryQIncrease d x s ≤
        P * coveredPIncrease d x P Q C.cover s := by
  have hl := C.link_subset hsM
  have hb := coveredPIncrease_link d hs x z hx hn hcap hm P Q hP hQ C s hl
  have hcap' := C.source_cap s hsM
  have hfree := coveredPIncrease_free_lower d hs x z hx hn hcap hm P Q hP hQ C s
    (Finset.mem_filter.mp hl).2.1
  rw [min_eq_right (C.source_excess s hsM).le] at hfree
  exact ⟨hfree, by have h := hb.2.2.1; nlinarith⟩

end TSP.Improvements20261105
