import TSP.Improvements20261105.ActualZeroLeafCost
import TSP.Improvements20261105.ActualHighQGroupPayment
import TSP.Improvements20261105.SelectedHeadSums
import TSP.Improvements20261105.LeafProjectionConversion

/-! Convert the actual canonical selected-load sum to the head costs
used by the role proofs. Removed leaf heads have selector zero, so no
selected load disappears when those already paid heads are removed. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.selected_load_star_sum
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (load : d.tree.Child → ℝ) :
    (∑ s ∈ a.selectedHeads d, load s) = ∑ i : d.StarIndex, (a.head i.1 : ℝ)*load i.1 := by
  rw [← a.head_weighted_sum d ha]
  have hext (s : d.tree.Child) : (a.head s : ℝ)*load s =
      extendStarValue d (fun i : d.StarIndex => (a.head i.1 : ℝ)*load i.1) s := by
    by_cases hs : (d.backGroup s).Nonempty
    · rw [extendStarValue,dif_pos hs]
    · have hz := gated_optimal_inactive_head_zero d P hP t ht f hf hb
        (a.potential d P) hcan.1.1 hcan.1.2 s hs
      simp only [GatedDrops.potential_headSelector] at hz
      rw [extendStarValue,dif_neg hs,hz]
      simp only [Int.cast_zero,zero_mul]
  calc
    _ = ∑ s : d.tree.Child, extendStarValue d (fun i : d.StarIndex => (a.head i.1 : ℝ)*load i.1) s :=
      Finset.sum_congr rfl (fun s _ => hext s)
    _ = _ := sum_extendStarValue d _

theorem currentSelectedHeadCost_eq_guarded (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex) (R : E ⊕ d.StarIndex → ℝ)
    (eligible T : Finset d.tree.Child) (a : GatedDrops d) (i : d.StarIndex) :
    currentSelectedHeadCost d x z C owner rootStar R eligible T a.head i =
      guardedNormalizedHeadCost d x z C owner rootStar R a i+
      (a.head i.1 : ℝ)*canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) i.1 := rfl

theorem GatedDrops.remaining_head_cost_identity
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex) (R : E ⊕ d.StarIndex → ℝ)
    (eligible T : Finset d.tree.Child) (J : Finset d.StarIndex) (hJ : ∀ i ∈ J, a.head i.1=0) :
    (∑ s ∈ a.selectedHeads d, canonicalHeadLoad d (fixedGatePlan d x) x z
      (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z) s)+
      (∑ i ∈ Finset.univ \ J, guardedNormalizedHeadCost d x z C owner rootStar R a i) =
      ∑ i ∈ Finset.univ \ J, currentSelectedHeadCost d x z C owner rootStar R eligible T a.head i := by
  let load := canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
    (projectedOutgoingCoupon d x z)
  have hsel := a.selected_load_star_sum d P hP t ht f hf hb ha hcan load
  have hpart := Finset.sum_sdiff (Finset.subset_univ J) (f := fun i : d.StarIndex => (a.head i.1 : ℝ)*load i.1)
  have hzero : (∑ i ∈ J, (a.head i.1 : ℝ)*load i.1)=0 := by
    apply Finset.sum_eq_zero
    intro i hi
    rw [hJ i hi]
    simp only [Int.cast_zero,zero_mul]
  rw [hzero,add_zero] at hpart
  simp_rw [currentSelectedHeadCost_eq_guarded]
  rw [Finset.sum_add_distrib]
  change (∑ s ∈ a.selectedHeads d, load s)+_ = _+(∑ i ∈ Finset.univ \ J, (a.head i.1 : ℝ)*load i.1)
  rw [hsel,hpart]
  ring

end TSP.Improvements20261105
