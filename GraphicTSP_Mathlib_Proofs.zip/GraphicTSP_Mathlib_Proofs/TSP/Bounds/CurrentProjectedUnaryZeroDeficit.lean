import TSP.Improvements20261105.CurrentProjectedGuardedDeficits

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_unary_zero_Q_deficit (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (Y R : E ⊕ d.StarIndex → ℝ)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (i : d.StarIndex) (hu : childCount d (d.centers i)=1)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1) :
    (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
      -x (d.treeEdge i.1)+(15/44 : ℝ)*(1-edgeSum z (d.backGroup i.1)) := by
  have heta := (preliminaryQIncrease_bounds d hs hx hcap i.1).1
  by_cases ht : i ∈ fixedPositiveTerminalHeads d x
  · have hh := hterminal i ht
    linarith
  · have hbase := raisedQ_deficit d x (fixedQIncrease d x (fixedPositiveTerminalChildren d x)) Y hrep hbacks i
    have ht0 : 0 ≤ fixedQIncrease d x (fixedPositiveTerminalChildren d x) i.1 := by
      unfold fixedQIncrease
      split_ifs
      · linarith [hcap (d.treeEdge i.1)]
      · exact heta
    have hcapz : projectedZeroGuardCapacity d x z Y i ≤ 1-edgeSum z (d.backGroup i.1) := by
      rw [projectedZeroGuardCapacity, if_pos hu]
      exact min_le_right _ _
    have hl := hloss i
    rw [if_neg ht, mul_zero, add_zero] at hl
    by_cases hm : i ∈ projectedZeroTerminalHeads d z
    · rw [if_pos hm] at hl
      linarith
    · rw [if_neg hm, mul_zero] at hl
      linarith

theorem current_projected_unary_zero_deficit (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y R : E ⊕ d.StarIndex → ℝ)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root) (hu : childCount d (d.centers i)=1)
    (hz : edgeSum z (d.backGroup i.1) ≤ 1) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        (319/2 : ℝ)*(edgeSum z (d.backGroup i.1)-1)-(704/5)*x (d.treeEdge i.1) := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  let delta := terminalPIncrease d x (fixedPositiveTerminalChildren d x)
    (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H j.1)
  have hd : AdmissibleAdjustment d x delta := by
    apply terminalPIncrease_admissible d hs x hx hn hcap
    exact forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C H (fixedHForceTargets_subset d x z (415/2) (704/5) C)
  have hpd := generalP_deficit d owner rootStar x delta i
  rw [extendNonrootRepairs_active d delta i hnr] at hpd
  have hd0 := (hd i hnr).1
  have hmass := hm i.1
  have hrem : fixedRemoval d x (allFullOverrideTargets d x) i.1 ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := le_max_right _ _
  have hqd := current_projected_unary_zero_Q_deficit d hs x z hx hcap Y R hrep hbacks hloss hterminal i hu hz
  change pqDeficitArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i-_ ≤ _
  unfold pqDeficitArm
  linarith

end TSP.Improvements20261105
