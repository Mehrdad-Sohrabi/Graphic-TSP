import TSP.Improvements20261105.GatedTourBound

/-! Remove excess free-head flow through a paid return cycle. Back-edge,
bypass and representative coordinates are unchanged. This transfers the
already proved binary witnesses to flows with larger free-head capacities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 1000000
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedFreeBase (v : d.tree.Child) : ℕ :=
  if d.tree.parent v = d.tree.root then 2 else 1

noncomputable def gatedFreeExcess (f : GatedArc d → ℝ) (v : d.tree.Child) : ℝ :=
  max (f (gatedFreeArc d v) - gatedFreeBase d v) 0

noncomputable def gatedFreeReturn (P : GatePlan d) (v : d.tree.Child) (a : GatedArc d) : ℝ :=
  gatedPaidReturnRoute d P v a - singleArcFlow (gatedFreeArc d v) a

noncomputable def normalizeGatedFree (P : GatePlan d) (f : GatedArc d → ℝ) (a : GatedArc d) : ℝ :=
  f a + routeFlow (gatedFreeReturn d P) (gatedFreeExcess d f) a

theorem gatedFreeReturn_balanced (P : GatePlan d) (v : d.tree.Child) :
    Balanced (gatedNetwork d P) (gatedFreeReturn d P v) := by
  intro w
  apply sub_eq_zero.mp
  change flowDivergence (gatedNetwork d P) (gatedFreeReturn d P v) w = 0
  have he : gatedFreeReturn d P v = fun a => gatedPaidReturnRoute d P v a +
      (-1) * singleArcFlow (gatedFreeArc d v) a := by
    funext a
    simp [gatedFreeReturn, sub_eq_add_neg]
  rw [he]
  rw [flowDivergence_add, flowDivergence_smul, gatedPaidReturnRoute_divergence,
    singleArcFlow_divergence]
  simp [gatedNetwork, gatedExtraSrc, gatedExtraDst]

theorem normalizeGatedFree_balanced (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) : Balanced (gatedNetwork d P) (normalizeGatedFree d P f) := by
  intro v
  change arcSum _ (fun a => f a + routeFlow _ _ a) v = arcSum _ (fun a => f a + routeFlow _ _ a) v
  rw [arcSum_add, arcSum_add, hf v, arcSum_routeFlow, arcSum_routeFlow]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  rw [gatedFreeReturn_balanced d P i v]

theorem normalizeGatedFree_free (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    normalizeGatedFree d P f (gatedFreeArc d v) =
      f (gatedFreeArc d v) - gatedFreeExcess d f v := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow, sub_eq_add_neg, eq_comm]

theorem normalizeGatedFree_paid (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    normalizeGatedFree d P f (gatedPaidArc d v) =
      f (gatedPaidArc d v) + gatedFreeExcess d f v := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow, eq_comm]

theorem normalizeGatedFree_suffix (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    normalizeGatedFree d P f (gatedSuffixArc d v) =
      f (gatedSuffixArc d v) + gatedFreeExcess d f v := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow, eq_comm]

theorem normalizeGatedFree_back (P : GatePlan d) (f : GatedArc d → ℝ) (b : BackEdge d) :
    normalizeGatedFree d P f (gatedBackArc d b) = f (gatedBackArc d b) := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow]

theorem normalizeGatedFree_rep (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    normalizeGatedFree d P f (gatedRepArc d v) = f (gatedRepArc d v) := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow]

theorem normalizeGatedFree_bypass (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    normalizeGatedFree d P f (gatedBypassArc d v) = f (gatedBypassArc d v) := by
  simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
    gatedConnectorRoute, singleArcFlow]

theorem gatedFreeReturn_nonnegative_off_free (P : GatePlan d) (v : d.tree.Child)
    (a : GatedArc d) (ha : a ≠ gatedFreeArc d v) : 0 ≤ gatedFreeReturn d P v a := by
  simp only [gatedFreeReturn, singleArcFlow, if_neg ha, sub_zero]
  simp only [gatedPaidReturnRoute, gatedConnectorRoute, singleArcFlow]
  split_ifs <;> norm_num

theorem normalizeGatedFree_ge_off_free (P : GatePlan d) (f : GatedArc d → ℝ)
    (a : GatedArc d) (ha : ∀ v, a ≠ gatedFreeArc d v) : f a ≤ normalizeGatedFree d P f a := by
  unfold normalizeGatedFree routeFlow
  apply le_add_of_nonneg_right
  exact Finset.sum_nonneg (fun v _ => mul_nonneg (le_max_right _ _)
    (gatedFreeReturn_nonnegative_off_free d P v a (ha v)))

theorem normalizeGatedFree_bounded_off_free (P : GatePlan d) (f : GatedArc d → ℝ)
    (a : GatedArc d) (ha : ∀ v, a ≠ gatedFreeArc d v)
    (u : ℕ) (hu : gatedUpper d P a = some u) : normalizeGatedFree d P f a = f a := by
  rcases a with a | (v | ⟨v, k⟩)
  · simp [gatedUpper] at hu
  · simp [gatedUpper] at hu
  · have hk : k ≠ 1 := by intro h; subst k; exact ha v rfl
    have hk' : k = 4 ∨ k = 6 ∨ k = 7 := by
      by_contra hn
      push_neg at hn
      simp [gatedUpper, hk, hn.1, hn.2.1, hn.2.2] at hu
    rcases hk' with rfl | rfl | rfl <;>
      simp [normalizeGatedFree, routeFlow, gatedFreeReturn, gatedPaidReturnRoute,
        gatedConnectorRoute, singleArcFlow]

theorem normalizeGatedFree_feasible (P : GatePlan d) (f : GatedArc d → ℝ)
    (hf : Balanced (gatedNetwork d P) f) (hl : ∀ a, (gatedLower d P a : ℝ) ≤ f a)
    (hu : ∀ a, (∀ v, a ≠ gatedFreeArc d v) → ∀ u, gatedUpper d P a = some u → f a ≤ u) :
    Balanced (gatedNetwork d P) (normalizeGatedFree d P f) ∧
      OptionalFlowBounds (gatedLower d P) (gatedUpper d P) (normalizeGatedFree d P f) := by
  refine ⟨normalizeGatedFree_balanced d P f hf, ?_⟩
  intro a
  by_cases ha : ∃ v, a = gatedFreeArc d v
  · obtain ⟨v, rfl⟩ := ha
    rw [normalizeGatedFree_free]
    have hn : 0 ≤ f (gatedFreeArc d v) := by simpa [gatedLower] using hl (gatedFreeArc d v)
    have hc : (0 : ℝ) ≤ gatedFreeBase d v := Nat.cast_nonneg _
    have hzero : gatedLower d P (gatedFreeArc d v) = 0 := by simp [gatedLower]
    have hupper : gatedUpper d P (gatedFreeArc d v) = some (gatedFreeBase d v) := by
      simp [gatedUpper, gatedFreeBase]
    constructor
    · rw [hzero, Nat.cast_zero]
      unfold gatedFreeExcess
      exact sub_nonneg.mpr (max_le (by linarith) hn)
    · intro u he
      have hueq : gatedFreeBase d v = u := Option.some.inj (hupper.symm.trans he)
      rw [← hueq]
      have hh := le_max_left (f (gatedFreeArc d v) - (gatedFreeBase d v : ℝ)) 0
      change _ - max _ _ ≤ _
      linarith
  · push_neg at ha
    refine ⟨(hl a).trans (normalizeGatedFree_ge_off_free d P f a ha), ?_⟩
    intro u he
    rw [normalizeGatedFree_bounded_off_free d P f a ha u he]
    exact hu a ha u he

end TSP.Improvements20261105
