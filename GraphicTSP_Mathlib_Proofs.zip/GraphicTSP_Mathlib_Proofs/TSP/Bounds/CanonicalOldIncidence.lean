import TSP.Improvements20261105.LeafProjectionBudget
import TSP.Improvements20261105.OldParentIncidence

/-! The old incidence bound instantiated on the actual canonical
components. Every selected empty child supplies an actual DFS leaf. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_old_parent_incidence (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : r ∈ a.internalComponents d P)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (q : d.tree.Child → ℝ) (hq : ∀ s ∈ a.componentHeads d P r, 0 ≤ q s)
    (hpack : ∀ s ∈ a.componentHeads d P r, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s ∈ a.componentHeads d P r, (d.backGroup s).card ≤ 3 →
      ∀ e ∈ d.backGroup s, z e ≤ q s) :
    1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card ≤
      (∑ s ∈ a.componentHeads d P r, oldIncidence d z s) -
      (1 / 2) * (G.internalEdges (headCenters d
        (a.componentHeads d P r \ countExcluded d (1 / 2) z (a.componentHeads d P r) ∅))).card +
      2 * (∑ s ∈ a.componentHeads d P r, ownProjectionLoss d x z s) := by
  have h := old_parent_incidence d hs x₀ hx₀ hpositive
    (a.chosenLeaves d hs hc P r) (a.chosenLeaves_are_leaves d hs hc P r)
    (a.componentHeads d P r) (a.internal_component_occupied d hs hc ha r (Finset.mem_filter.mp hr).2)
    (a.chosenLeaves_heads_in d hs hc ha r) (a.chosenLeaf_has_back d hs hc P r hx hcap)
    z hz (fun e => (hzx e).trans (hcap e)) q hq hpack hsmall
    (canonical_component_head_size d P hP t ht f hf hb a ha hcan r)
    (leafProjectionLoss d x z) (fun v _ => leafProjectionLoss_nonneg d x z hzx v)
    (a.chosenLeaf_projected_mass d hs hc P r hx hcap z)
  rw [a.chosenLeaves_card d hs hc P r] at h
  have hdelta := leafProjectionLoss_le_heads d x z hzx _ _ (a.chosenLeaves_heads_in d hs hc ha r)
  linarith

end TSP.Improvements20261105
