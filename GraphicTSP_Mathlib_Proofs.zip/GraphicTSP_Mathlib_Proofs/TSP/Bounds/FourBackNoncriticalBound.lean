import TSP.Improvements20261105.ScoredUniformNetLoad

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem four_back_noncritical_bound (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : (1/4 : ℝ) ≤ q) (hcap : ∀ e ∈ d.backGroup s, z e ≤ q)
    (hcount : (d.backGroup s).card=4) :
    noncriticalIncidence d z s ≤ max (192*q-48)
      (144*q-684/19+(96/19)*((100/57)*edgeSum z (d.backGroup s)-1)) := by
  have ho : starIncidenceRamp d (1/2) z s ≤ 8*q-2 := by
    have hh := Finset.sum_le_sum (s := d.backGroup s) (fun e he =>
      show incidenceRamp (1/2) (z e) ≤ 2*q-1/2 by
        unfold incidenceRamp
        apply max_le <;> linarith only [hcap e he,hq])
    simp only [Finset.sum_const,hcount,nsmul_eq_mul,Nat.cast_ofNat] at hh
    change (∑ e ∈ d.backGroup s, incidenceRamp (1/2) (z e)) ≤ _
    linarith only [hh]
  have hn : signedStarIncidence d (9/20) z s ≤ (38/5)*q-19/10 := by
    have hh := Finset.sum_le_sum (s := d.backGroup s) (fun e he =>
      show incidenceRamp (9/20) (z e) ≤ (19/10)*q-9/20 by
        unfold incidenceRamp
        apply max_le <;> linarith only [hcap e he,hq])
    simp only [Finset.sum_const,hcount,nsmul_eq_mul,Nat.cast_ofNat] at hh
    unfold signedStarIncidence starIncidenceRamp edgeSum
    linarith only [hh]
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h3 := min_le_right (((d.backGroup s).card : ℝ)-1)
    (ScoredParameters.massSlope*edgeSum z (d.backGroup s)-1)
  unfold noncriticalIncidence oldIncidence mixedNoncriticalIncidence
  unfold ScoredParameters.massSlope at h3 ⊢
  apply max_le_max <;> linarith only [h1,h2,h3,ho,hn]

end TSP.Improvements20261105
