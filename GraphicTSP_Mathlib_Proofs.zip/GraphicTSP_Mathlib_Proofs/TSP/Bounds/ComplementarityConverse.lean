import TSP.Improvements20261105.RealCapacityDual

/-! Equality in weak duality forces complementary slackness on every
actual arc, including networks with real capacities and unlimited arcs. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem dual_edge_equality_converse (c l u x δ : ℝ)
    (he : l * (c - δ) - (u - l) * max (δ - c) 0 = x * (c - δ)) :
    (x < u → δ ≤ c) ∧ (l < x → c ≤ δ) := by
  constructor
  · intro hx
    by_contra hn
    have hp : 0 < δ - c := by linarith
    rw [max_eq_left hp.le] at he
    have hm := mul_pos (sub_pos.mpr hx) hp
    nlinarith
  · intro hx
    by_contra hn
    have hp : 0 < c - δ := by linarith
    rw [max_eq_right (by linarith : δ - c ≤ 0), mul_zero, sub_zero] at he
    have hm := mul_pos (sub_pos.mpr hx) hp
    nlinarith

theorem circulation_equality_complementary (N : Graph V E) (c : E → ℤ)
    (lower upper f : E → ℝ) (hf : Chapter06.Balanced N f)
    (hb : ∀ e, lower e ≤ f e ∧ f e ≤ upper e) (p : V → ℝ)
    (he : circulationDualValue N c lower upper p = ∑ e, (c e : ℝ) * f e) :
    (∀ e, f e < upper e → p (N.dst e) - p (N.src e) ≤ (c e : ℝ)) ∧
    (∀ e, lower e < f e → (c e : ℝ) ≤ p (N.dst e) - p (N.src e)) := by
  let L := fun e => lower e * ((c e : ℝ) - (p (N.dst e) - p (N.src e))) -
    (upper e - lower e) * max (p (N.dst e) - p (N.src e) - c e) 0
  let U := fun e => f e * ((c e : ℝ) - (p (N.dst e) - p (N.src e)))
  have hn : ∀ e, 0 ≤ U e - L e := fun e => sub_nonneg.mpr
    (dual_edge_bound (c e) (lower e) (upper e) (f e) (p (N.dst e) - p (N.src e))
      (hb e).1 (hb e).2)
  have hsum : ∑ e, (U e - L e) = 0 := by
    have hpot := balanced_potential_sum N f hf p
    have hL : ∑ e, L e = ∑ e, (c e : ℝ) * f e := he
    have hU : (∑ e, U e) = (∑ e, (c e : ℝ) * f e) -
        ∑ e, f e * (p (N.dst e) - p (N.src e)) := by
      simp [U, mul_sub, Finset.sum_sub_distrib, mul_comm]
    rw [Finset.sum_sub_distrib, hL, hU, hpot]
    ring
  have heach : ∀ e, L e = U e := by
    intro e
    have hh := (Finset.sum_eq_zero_iff_of_nonneg (fun e _ => hn e)).mp hsum e (Finset.mem_univ _)
    exact (sub_eq_zero.mp hh).symm
  exact ⟨fun e => (dual_edge_equality_converse _ _ _ _ _ (heach e)).1,
    fun e => (dual_edge_equality_converse _ _ _ _ _ (heach e)).2⟩

theorem real_capacity_equality_complementary (N : Graph V E) (c : E → ℤ)
    (lower : E → ℕ) (upper : E → Option ℝ) (f : E → ℝ)
    (hf : Chapter06.Balanced N f) (hb : RealFlowBounds lower upper f) (p : V → ℝ)
    (hp : ∀ e, upper e = none → p (N.dst e) - p (N.src e) ≤ (c e : ℝ))
    (he : realCapacityDualValue N c lower upper p = ∑ e, (c e : ℝ) * f e) :
    (∀ e u, upper e = some u → f e < u → p (N.dst e) - p (N.src e) ≤ (c e : ℝ)) ∧
    (∀ e, (lower e : ℝ) < f e → (c e : ℝ) ≤ p (N.dst e) - p (N.src e)) := by
  let U : E → ℝ := fun e => match upper e with
    | none => f e + 1
    | some u => u
  have hbox : ∀ e, (lower e : ℝ) ≤ f e ∧ f e ≤ U e := by
    intro e
    refine ⟨(hb e).1, ?_⟩
    cases hu : upper e with
    | none => simp [U, hu]
    | some u => simpa [U, hu] using (hb e).2 u hu
  have hv : circulationDualValue N c (fun e => (lower e : ℝ)) U p =
      realCapacityDualValue N c lower upper p := by
    unfold circulationDualValue realCapacityDualValue
    apply Finset.sum_congr rfl
    intro e _
    cases hu : upper e with
    | none =>
      have hn : p (N.dst e) - p (N.src e) - c e ≤ 0 := by linarith [hp e hu]
      simp [hu, max_eq_right hn]
    | some u => simp [U, hu]
  have hh := circulation_equality_complementary N c (fun e => (lower e : ℝ)) U f hf hbox p
    (hv.trans he)
  refine ⟨?_, hh.2⟩
  intro e u hu hf'
  apply hh.1 e
  simpa [U, hu] using hf'

end TSP.Improvements20261105
