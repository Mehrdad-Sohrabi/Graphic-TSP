import TSP.Improvements20261105.AdaptiveSnapshots
import TSP.GraphVertexConnectivity
import TSP.Chapter05.RootedPath

/-! The final DFS subtree is exactly the unvisited connected component at its
entry decision. Thus component-dependent counts and maxima describe actual
stars, rather than larger sets of unrelated eligible edges. -/
namespace TSP.Improvements20261105.AdaptiveDFS
open Graph Chapter05 Chapter05.GreedySearch
open Classical
variable {V E W : Type} [Fintype V] [Fintype E] [DecidableEq V]
  [LinearOrder E] [LinearOrder W]

noncomputable def freshComponent (G : Graph V E) (seen : Finset V) (v : V) : Finset V :=
  Finset.univ.filter (fun w => w ∉ seen ∧ Relation.ReflTransGen (G.AdjOn (G.liveEdges seen)) v w)

noncomputable def componentCandidates (G : Graph V E) (seen : Finset V) (u v : V) : Finset E :=
  (eligibleEdges G seen u).filter (fun e => GreedySearch.otherEndpoint G u e ∈ freshComponent G seen v)

theorem dfs_adj_comparable {G : Graph V E} (d : DFSData G) {a b : V}
    (h : G.AdjOn Finset.univ a b) : d.tree.Ancestor a b ∨ d.tree.Ancestor b a := by
  obtain ⟨e, _, he⟩ := h
  have ha := d.edge_ancestor e
  rcases d.oriented e with hor | hor <;> rcases he with he | he
  · exact Or.inl (by rwa [← hor.1, ← hor.2, he.1, he.2] at ha)
  · exact Or.inr (by rwa [← hor.1, ← hor.2, he.1, he.2] at ha)
  · exact Or.inr (by rwa [← hor.2, ← hor.1, he.1, he.2] at ha)
  · exact Or.inl (by rwa [← hor.2, ← hor.1, he.1, he.2] at ha)

theorem live_adj_fresh {G : Graph V E} {seen : Finset V} {a b : V}
    (h : G.AdjOn (G.liveEdges seen) a b) : a ∉ seen ∧ b ∉ seen := by
  obtain ⟨e, he, hor⟩ := h
  have hh := (Finset.mem_filter.mp he).2
  rcases hor with hor | hor
  · simpa only [hor.1, hor.2] using hh
  · simpa only [hor.1, hor.2] using hh.symm

theorem parent_not_descendant {G : Graph V E} (d : DFSData G) (v : d.tree.Child) :
    ¬d.tree.Ancestor v (d.tree.parent v) := by
  intro h
  have hd := d.tree.ancestor_depth_le h
  have hp := d.tree.parent_depth v v.2
  omega

theorem descendant_closed_on_fresh_edges {G : Graph V E} (d : DFSData G)
    (v : d.tree.Child) (seen : Finset V)
    (hanc : ∀ a, d.tree.Ancestor a (d.tree.parent v) → a ∈ seen)
    {a b : V} (ha : d.tree.Ancestor v a) (hab : G.AdjOn (G.liveEdges seen) a b) :
    d.tree.Ancestor v b := by
  have hcomp := dfs_adj_comparable d (G.adjOn_mono (Finset.subset_univ _) hab)
  rcases hcomp with hab' | hba
  · exact hab'.trans ha
  · have hu : Relator.RightUnique d.tree.ParentStep := by
      intro x y z hxy hxz
      exact hxy.2.symm.trans hxz.2
    rcases Relation.ReflTransGen.total_of_right_unique hu hba ha with hbc | hcb
    · exact hbc
    · by_cases hb : b = (v : V)
      · subst b; exact .refl
      · have hbp := d.tree.ancestor_parent_of_ne hcb (Ne.symm hb)
        exact ((live_adj_fresh hab).2 (hanc b hbp)).elim

theorem descendant_fresh_reachable {G : Graph V E} (d : DFSData G)
    (v : d.tree.Child) (seen : Finset V)
    (hfresh : ∀ w, d.tree.Ancestor v w → w ∉ seen)
    {w : V} (h : d.tree.Ancestor v w) :
    Relation.ReflTransGen (G.AdjOn (G.liveEdges seen)) w v := by
  induction h using Relation.ReflTransGen.head_induction_on with
  | refl => exact .refl
  | @head w z hstep hrest ih =>
    let a : d.tree.Child := ⟨w, hstep.1⟩
    have hu : d.upper (d.treeEdge a) = z := (d.treeEdge_upper a).trans hstep.2
    have hl : d.lower (d.treeEdge a) = w := d.treeEdge_lower a
    have hw := hfresh w (.head hstep hrest)
    have hz := hfresh z hrest
    have hadj : G.AdjOn (G.liveEdges seen) w z := by
      refine ⟨d.treeEdge a, ?_, ?_⟩
      · apply Finset.mem_filter.mpr
        refine ⟨Finset.mem_univ _, ?_⟩
        rcases d.oriented (d.treeEdge a) with hor | hor
        · simpa only [hor.1, hor.2, hu, hl] using And.intro hz hw
        · simpa only [hor.1, hor.2, hu, hl] using And.intro hw hz
      · rcases d.oriented (d.treeEdge a) with hor | hor
        · exact Or.inr ⟨hor.1.trans hu, hor.2.trans hl⟩
        · exact Or.inl ⟨hor.1.trans hl, hor.2.trans hu⟩
    exact (Relation.ReflTransGen.single hadj).trans ih

theorem freshComponent_iff_descendant {G : Graph V E} (d : DFSData G)
    (v : d.tree.Child) (seen : Finset V)
    (hanc : ∀ a, d.tree.Ancestor a (d.tree.parent v) → a ∈ seen)
    (hfresh : ∀ w, d.tree.Ancestor v w → w ∉ seen) (w : V) :
    w ∈ freshComponent G seen v ↔ d.tree.Ancestor v w := by
  constructor
  · intro hw
    have hp := (Finset.mem_filter.mp hw).2.2
    clear hw
    induction hp with
    | refl => exact .refl
    | @tail a b hab hlast ih => exact descendant_closed_on_fresh_edges d v seen hanc ih hlast
  · intro hw
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hfresh w hw,
      Relation.ReflTransGen.symmetric (adjOn_symmetric G _)
        (descendant_fresh_reachable d v seen hfresh hw)⟩

theorem group_of_parent_endpoint {G : Graph V E} (d : DFSData G) (v : d.tree.Child)
    (e : E) (w : V)
    (hor : (G.src e = d.tree.parent v ∧ G.dst e = w) ∨
      (G.dst e = d.tree.parent v ∧ G.src e = w))
    (hw : d.tree.Ancestor v w) : e ∈ d.group v := by
  have hends : (d.upper e = d.tree.parent v ∧ d.lower e = w) ∨
      (d.lower e = d.tree.parent v ∧ d.upper e = w) := by
    rcases d.oriented e with he | he <;> rcases hor with hor | hor
    · exact Or.inl ⟨he.1.symm.trans hor.1, he.2.symm.trans hor.2⟩
    · exact Or.inr ⟨he.2.symm.trans hor.1, he.1.symm.trans hor.2⟩
    · exact Or.inr ⟨he.1.symm.trans hor.1, he.2.symm.trans hor.2⟩
    · exact Or.inl ⟨he.2.symm.trans hor.1, he.1.symm.trans hor.2⟩
  rcases hends with he | he
  · exact (d.mem_group_iff v e).mpr ⟨he.1, he.2 ▸ hw⟩
  · have ha := d.edge_ancestor e
    rw [he.1, he.2] at ha
    exact (parent_not_descendant d v (ha.trans hw)).elim

theorem componentCandidates_eq_group {G : Graph V E} (d : DFSData G)
    (v : d.tree.Child) (seen : Finset V)
    (hanc : ∀ a, d.tree.Ancestor a (d.tree.parent v) → a ∈ seen)
    (hfresh : ∀ w, d.tree.Ancestor v w → w ∉ seen) :
    componentCandidates G seen (d.tree.parent v) v = d.group v := by
  ext e
  constructor
  · intro he
    have hh := Finset.mem_filter.mp he
    exact group_of_parent_endpoint d v e _ (otherEndpoint_oriented G seen _ hh.1)
      ((freshComponent_iff_descendant d v seen hanc hfresh _).mp hh.2)
  · intro he
    have hg := (d.mem_group_iff v e).mp he
    have hlo := hfresh (d.lower e) hg.2
    have hm : e ∈ eligibleEdges G seen (d.tree.parent v) := by
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_univ _, ?_⟩
      rcases d.oriented e with hor | hor
      · exact Or.inl ⟨hor.1.trans hg.1, hor.2 ▸ hlo⟩
      · exact Or.inr ⟨hor.2.trans hg.1, hor.1 ▸ hlo⟩
    have hother : GreedySearch.otherEndpoint G (d.tree.parent v) e = d.lower e := by
      rcases d.oriented e with hor | hor
      · simp [GreedySearch.otherEndpoint, hor.1, hg.1, hor.2]
      · have hn : d.lower e ≠ d.tree.parent v := by
          rw [← hg.1]
          exact (d.edge_strict e).symm
        simp only [GreedySearch.otherEndpoint, hor.1, if_neg hn, hor.2]
    apply Finset.mem_filter.mpr
    refine ⟨hm, ?_⟩
    rw [hother, freshComponent_iff_descendant d v seen hanc hfresh]
    exact hg.2

theorem freshComponent_eq_of_mem (G : Graph V E) (seen : Finset V) {u v : V}
    (hu : u ∉ seen) (hv : v ∈ freshComponent G seen u) :
    freshComponent G seen v = freshComponent G seen u := by
  have huv := (Finset.mem_filter.mp hv).2.2
  have hvu := Relation.ReflTransGen.symmetric (adjOn_symmetric G _) huv
  ext w
  simp only [freshComponent, Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨hw, hp⟩
    exact ⟨hw, huv.trans hp⟩
  · rintro ⟨hw, hp⟩
    exact ⟨hw, hvu.trans hp⟩

theorem candidate_component_nonempty (G : Graph V E) (seen : Finset V) (u : V)
    (e : E) (he : e ∈ eligibleEdges G seen u) :
    e ∈ componentCandidates G seen u (GreedySearch.otherEndpoint G u e) := by
  exact Finset.mem_filter.mpr ⟨he, Finset.mem_filter.mpr ⟨Finset.mem_univ _,
    otherEndpoint_fresh G seen u he, .refl⟩⟩

theorem candidate_component_eq (G : Graph V E) (seen : Finset V) (u v : V)
    (hv : v ∉ seen) (e : E) (he : e ∈ componentCandidates G seen u v) :
    componentCandidates G seen u (GreedySearch.otherEndpoint G u e) =
      componentCandidates G seen u v := by
  unfold componentCandidates
  rw [freshComponent_eq_of_mem G seen hv (Finset.mem_filter.mp he).2]

structure StarDecision (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (d : DFSData G) (v : d.tree.Child) where
  state : State V E
  tail : List V
  valid : Invariants G root state
  head : state.stack = d.tree.parent v :: tail
  choice : pickEdge G (score state (d.tree.parent v)) state.seen (d.tree.parent v) = some (d.treeEdge v)
  component : componentCandidates G state.seen (d.tree.parent v) v = d.group v
  ancestors : ∀ a, Ancestor root state a (d.tree.parent v) ↔ d.tree.Ancestor a (d.tree.parent v)
  fresh : ∀ w, d.tree.Ancestor v w → w ∉ state.seen
  incoming : ∀ u : d.tree.Child, (u : V) = d.tree.parent v → state.entering u = some (d.treeEdge u)

theorem searchDFS_star_decision (G : Graph V E) (score : State V E → V → E → W)
    (hsimple : G.IsSimple) (hconn : G.Connected) (root : V)
    (v : (searchDFS G score hsimple hconn root).tree.Child) :
    Nonempty (StarDecision G score root (searchDFS G score hsimple hconn root) v) := by
  let final := run G score (initial root)
  let hi := run_invariants G score root _ (initial_invariants G root)
  let hall := run_initial_spanning G score hconn root
  let d := searchDFS G score hsimple hconn root
  obtain ⟨snap⟩ := searchDFS_entry_snapshot G score hsimple hconn root v
  have henter : final.entering v = some (d.treeEdge v) :=
    (chosenTreeEdge_spec G root final hi.2.1 hall v).1
  have hedge : snap.edge = d.treeEdge v := Option.some.inj (snap.entering_eq.symm.trans henter)
  have hparent : snap.parent = d.tree.parent v := snap.parent_eq.symm
  have hp : snap.parent ∈ snap.state.seen :=
    snap.valid.1.1 _ (by rw [snap.head]; exact List.mem_cons_self)
  have hanc (a : V) (ha : d.tree.Ancestor a (d.tree.parent v)) : a ∈ snap.state.seen := by
    apply ancestor_seen G root snap.state snap.valid.2.1 hp
    apply (snap.ancestors a).mpr
    simpa only [hparent] using ha
  have hfresh (w : V) (hw : d.tree.Ancestor v w) : w ∉ snap.state.seen :=
    snap.fresh_descendants w (by rw [hall]; exact Finset.mem_univ _) hw
  exact ⟨{ state := snap.state
           tail := snap.tail
           valid := snap.valid
           head := by simpa only [hparent] using snap.head
           choice := by simpa only [hparent, hedge] using snap.choice
           component := componentCandidates_eq_group d v snap.state.seen hanc hfresh
           ancestors := fun a => by simpa only [hparent] using snap.ancestors a
           fresh := hfresh
           incoming := fun u hu => by
             have huS : (u : V) ∈ snap.state.seen := by rwa [hu, ← hparent]
             have hst := snap.entering_stable u huS
             have hentry := (chosenTreeEdge_spec G root final hi.2.1 hall u).1
             exact hst.symm.trans hentry }⟩

end TSP.Improvements20261105.AdaptiveDFS
