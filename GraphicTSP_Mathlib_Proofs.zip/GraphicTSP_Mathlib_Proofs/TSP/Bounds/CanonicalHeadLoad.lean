import TSP.Improvements20261105.ActualHighQLoads
import TSP.Improvements20261105.TotalCouponPayment

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def canonicalHeadLoad (P : GatePlan d) (x z : E → ℝ)
    (S T : Finset d.tree.Child) (b : d.tree.Child → ℝ) (s : d.tree.Child) : ℝ :=
  24*(edgeSum z (d.backGroup s)-gatedFreeBase d s)+refinedIncidenceCharge d x z S T s-
    24*accountedCoupon d P b s+24*couponResidual d P (fun e => x e.1) b s

theorem payableCoupon_nonnegative (P : GatePlan d) (x : BackEdge d → ℝ)
    (hx : ∀ e, 0 ≤ x e) (b : d.tree.Child → ℝ) (hb : ∀ s, 0 ≤ b s) (s : d.tree.Child) :
    0 ≤ payableCoupon d P x b s := by
  have ht := tailBackMass_nonneg d x hx (s : V)
  cases hk : P.kind s <;> simp only [payableCoupon, hk] <;> first | exact hb s | exact le_rfl | exact le_min (hb s) ht

theorem canonicalHeadLoad_le_uncouponed (P : GatePlan d) (x z : E → ℝ)
    (hx : ∀ e, 0 ≤ x e) (S T : Finset d.tree.Child) (b : d.tree.Child → ℝ)
    (hb : ∀ s, 0 ≤ b s) (s : d.tree.Child) :
    canonicalHeadLoad d P x z S T b s ≤
      24*(edgeSum z (d.backGroup s)-1)+refinedIncidenceCharge d x z S T s := by
  have hp := payableCoupon_nonnegative d P (fun e => x e.1) (fun e => hx e.1) b hb s
  have he := coupon_payment_split d P (fun e => x e.1) b s
  have hf : (1 : ℝ) ≤ gatedFreeBase d s := by
    unfold gatedFreeBase
    split_ifs <;> norm_num
  unfold canonicalHeadLoad
  linarith

end TSP.Improvements20261105
