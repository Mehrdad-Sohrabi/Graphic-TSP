import TSP.Improvements20261105.CycleGuardMixture
import TSP.Improvements20261105.FiniteEventThinning

/-! Build one feasible guard from an explicit finite join event, with
exact path savings and bounded removable-edge loss. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Classical
open scoped BigOperators
variable {V E I : Type} [Fintype V] [Fintype E] [Fintype I]
  [DecidableEq V] [DecidableEq E] [DecidableEq I]

theorem exists_guard_from_finite_event (G : Graph V E) (T : Finset V)
    (w : I → ℝ) (J : I → Finset E) (x : E → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hsum : ∑ i, w i = 1) (hJ : ∀ i, G.IsJoin T (J i))
    (hcoords : ∀ e, ∑ i, w i * incidence (J i) e = x e)
    (C N : Finset E) (hC : ∀ v, Even (G.intDegree C v)) (hNC : N ⊆ C)
    (m : ℝ) (hm : 0 ≤ m)
    (hevent : m ≤ ∑ i ∈ Finset.univ.filter (fun i => N ⊆ J i), w i) :
    ∃ y : E → ℝ,
      y ∈ joinPolytope G T (G.intDegree Finset.univ) ∧
      (∀ e ∉ C, y e = x e) ∧
      (∀ e ∈ N, y e = x e - m) ∧
      edgeSum y N = edgeSum x N - (N.card : ℝ) * m ∧
      (∀ S : Finset E, edgeSum x S - edgeSum y S ≤ ((S ∩ C).card : ℝ) * m) := by
  obtain ⟨r, hr, hoff, hmass⟩ := finite_event_thinning w (Finset.univ.filter (fun i => N ⊆ J i)) m hw hm hevent
  have hselected : ∀ i, r i ≠ 0 → N ⊆ J i := by
    intro i hi
    by_contra hn
    exact hi (hoff i (by simpa using hn))
  refine ⟨thinnedCyclePoint w J C r, thinnedCyclePoint_feasible G T w J C r hsum hr hJ hC, ?_, ?_, ?_, ?_⟩
  · intro e he
    rw [thinnedCyclePoint_outside w J C r e he, hcoords]
  · intro e he
    rw [thinnedCyclePoint_selected w J C r e (hNC he) (fun i hi => hselected i hi he), hcoords, hmass]
  · simpa only [hcoords, hmass] using thinnedCyclePoint_selected_set w J C N r hNC hselected
  · intro S
    simpa only [hcoords, hmass] using thinnedCyclePoint_set_loss w J C S r (fun i => (hr i).1)

end TSP.Improvements20261105
