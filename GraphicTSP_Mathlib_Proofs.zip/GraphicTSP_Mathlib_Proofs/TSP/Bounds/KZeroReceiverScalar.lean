import TSP.Improvements20261105.PairLeafTent

/-! Exact finance for a protected unmatched source with a projected-zero
receiver. The two inequalities come from the actual cover edge and
the original center cut; no extra error allowance is introduced. -/
namespace TSP.Improvements20261105
set_option autoImplicit false

theorem current_K_zero_receiver_finance (g m : ℝ) (hg : 0 ≤ g)
    (hsmall : m ≤ 30) (hcut : m ≤ (3483/10 : ℝ)*g-554/5) :
    max m 0-(704/5 : ℝ)*g ≤ -48*g := by
  have hm : m ≤ (464/5 : ℝ)*g := by
    by_cases h : g ≤ 1/3
    · linarith
    · linarith
  have hz : (0 : ℝ) ≤ (464/5 : ℝ)*g := mul_nonneg (by norm_num) hg
  have hh := max_le hm hz
  linarith

theorem current_K_zero_receiver_numerator (q o e : ℝ)
    (ho : 0 ≤ o) (hlink : q+o ≤ 1) (he : e ≤ 1-q)
    (hedge : (415/2 : ℝ)*(e-o) ≤ (704/5 : ℝ)*(q+o)) :
    max ((415/2 : ℝ)*e-(704/5 : ℝ)*(q+o)+60*min q (1-q)-(415/2 : ℝ)*o) 0 -
      (704/5 : ℝ)*(1-q-o) ≤ -48*(1-q-o) := by
  have hhalf : min q (1-q) ≤ (1/2 : ℝ) := by
    have h1 := min_le_left q (1-q)
    have h2 := min_le_right q (1-q)
    linarith
  apply current_K_zero_receiver_finance
  · linarith
  · linarith
  · linarith

end TSP.Improvements20261105
