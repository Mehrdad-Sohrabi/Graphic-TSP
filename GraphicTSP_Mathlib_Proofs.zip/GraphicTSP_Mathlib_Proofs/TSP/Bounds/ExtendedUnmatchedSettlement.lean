import TSP.Improvements20261105.ExtendedResidualMassBalance
import TSP.Improvements20261105.ExtendedResidualEdgePayment
import TSP.Improvements20261105.UnmatchedHeadRetainedPayment
import TSP.Improvements20261105.UnmatchedResidualFamilyPayment
import TSP.Improvements20261105.UnselectedUnmatchedHeadPayment
import TSP.Improvements20261105.RetainedSelectedResidual
import TSP.Improvements20261105.UnselectedPositiveUnaryResidualPayment
import TSP.Improvements20261105.UnaryUnmatchedForceBudget
import TSP.Improvements20261105.ResidualReceiverForceBudget
import TSP.Improvements20261105.GreedyFreePositiveLoad
import TSP.Improvements20261105.CurrentProjectedUnmatchedHeadCost
import TSP.Improvements20261105.SelectedZeroHeadPayment
import TSP.Improvements20261105.CurrentProjectedKZeroReceiver
import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost
import TSP.Improvements20261105.KOriginOwnership

/-! Unmatched nonroot heads outside protected receivers are paid
with no charge when unselected. Selected projected-zero heads use only
their own original back budget. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_extended_unmatched_settlement
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (a : GatedDrops d) (ha : a.Admissible d (fixedGatePlan d x))
    (H : Finset (d).StarIndex)
    (hH : ∀ i ∈ H, i.1 ∉ matchingEndpoints id (unaryNext d) C.matching ∧
      (d).centers i ≠ (d).tree.root ∧ i ∉ a.selectedHighQHeads d x z C)
    (hel : ∀ s, ScoredStar d x s → s ∈ eligible)
    (M : Finset (d).StarIndex) (hdis : Disjoint H M)
    (hM : ∀ i ∈ M, i.1 ∉ C.matching) :
    (∑ i ∈ H, currentSelectedHeadCost d x z C owner rootStar R eligible T a.head i)+
      24*(∑ i ∈ M, retainedSelectedResidual d x z a.head i) ≤
      (4*∑ i ∈ H, (((d).backGroup i.1).card : ℝ))+
      24*(∑ p ∈ extendedResidualOutside d x z a.head H M, actualCouponResidual d x z p.1) := by
  let F := extendedResidualDonors d x z a.head H M
  have hF (i : (d).StarIndex) (hi : i ∈ F) :
      i.1 ∉ C.matching ∧ a.head i.1=1 ∧ 1 < edgeSum z ((d).backGroup i.1) := by
    have hh := Finset.mem_filter.mp hi
    refine ⟨?_,hh.2⟩
    rcases Finset.mem_union.mp hh.1 with hhH | hhM
    · intro hsrc
      apply (hH i hhH).1
      simpa only [matchingEndpoints,Finset.image_id] using
        (Finset.mem_union_left (C.matching.image (unaryNext d)) hsrc)
    · exact hM i hhM
  have hp := scoredDFS_extended_unmatched_residual_payment G x z hs hc root hx hn hcap hz hzx hm C owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T a ha H hH hel F hF
  have he := extendedResidual_mass_balance d hs x z hx hcap a.head H M hdis
  have hf : Set.InjOn Prod.fst (extendedResidualInside d x z a.head H M : Set ((d).StarIndex × (d).StarIndex)) := by
    intro p hp q hq he
    exact couponResidualStarPairs_fst_injective d hs x z hx hcap F
      (Finset.mem_filter.mp hp).1 (Finset.mem_filter.mp hq).1 he
  have himage : (∑ i ∈ (extendedResidualInside d x z a.head H M).image Prod.fst, actualCouponResidual d x z i)=
      ∑ p ∈ extendedResidualInside d x z a.head H M, actualCouponResidual d x z p.1 :=
    Finset.sum_image (fun p hp q hq he => hf hp hq he)
  change (∑ i ∈ H, currentSelectedHeadCost d x z C owner rootStar R eligible T a.head i)+
    24*(∑ i ∈ (extendedResidualInside d x z a.head H M).image Prod.fst, actualCouponResidual d x z i) ≤
    (4*∑ i ∈ H, (((d).backGroup i.1).card : ℝ))+24*(∑ i ∈ H, retainedSelectedResidual d x z a.head i) at hp
  rw [himage] at hp
  linarith only [hp,he]

end TSP.Improvements20261105
