import TSP.Improvements20261105.ForcedCoverGeometry
import TSP.Improvements20261105.FixedPQBasePoints

/-! The actual simultaneous forced P point is feasible. Its signed arm
can only decrease, and each unary connector increase has its one explicit
predecessor as owner. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (x z : E → ℝ) (hx : G.SubtourFeasible x)
variable (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
variable (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
  fixedRemoval d x (allFullOverrideTargets d x) s)
variable (P Q K D B : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
variable (hD : 0 ≤ D) (hDQ : D ≤ Q) (hQP : Q ≤ P) (hB : 0 ≤ B)
variable (C : ProjectedCoverWitness d x z P Q) (H : Finset d.tree.Child)
variable (hH : H ⊆ C.matching.image (unaryNext d))

include hs hx hn hcap hm hP hQ hK hKQ hD hDQ hQP hB hH in
theorem forced_P_feasible (hc : IsTwoVertexConnected G)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root) :
    generalPoint d owner rootStar x (fun i => forcedCoverIncrease d x z P Q K D B C H i.1) ∈
      projectedFrameworkTwo G d.centers owner := by
  have hh := enlargedRepairPoint_feasible d hs hc owner ho rootStar hroot x hx hcap _
    (forcedCoverIncrease_admissible d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ hD hDQ hQP hB C H hH)
  rwa [Manuscript20261105.nonloopReconnectionLP_eq_projection] at hh

include hs hx hn hcap hm hP hQ hK hKQ hH in
theorem forcedPQ_deficit_identity (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y : E ⊕ d.StarIndex → ℝ)
    (hr : ∀ s, Y (.inl (d.treeEdge s)) = x (d.treeEdge s) / 2 + preliminaryQIncrease d x s)
    (hb : ∀ e ∈ d.backEdges, Y (.inl e) = 1 - x e / 2) (i : d.StarIndex) :
    pqDeficitArm d x P Q
      (generalPoint d owner rootStar x (fun j => forcedCoverIncrease d x z P Q K D B C H j.1)) Y i =
      P * (edgeSum x (d.backGroup i.1) - 1 - forcedCoverIncrease d x z P Q K D B C H i.1) -
        Q * (x (d.treeEdge i.1) + preliminaryQIncrease d x i.1) := by
  have hp := generalP_deficit d owner rootStar x (fun j => forcedCoverIncrease d x z P Q K D B C H j.1) i
  rw [forcedCoverIncrease_extension d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H hH i.1] at hp
  have hq := raisedQ_deficit d x (preliminaryQIncrease d x) Y hr hb i
  unfold pqDeficitArm
  rw [hq]
  nlinarith [congrArg (fun r : ℝ => P * r) hp]

include hs hx hn hcap hm hP hQ hK hKQ hH in
theorem forcedPQ_deficit_le_cover (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y : E ⊕ d.StarIndex → ℝ)
    (hr : ∀ s, Y (.inl (d.treeEdge s)) = x (d.treeEdge s) / 2 + preliminaryQIncrease d x s)
    (hb : ∀ e ∈ d.backEdges, Y (.inl e) = 1 - x e / 2)
    (i : d.StarIndex) (hi : d.centers i ≠ d.tree.root) :
    pqDeficitArm d x P Q
      (generalPoint d owner rootStar x (fun j => forcedCoverIncrease d x z P Q K D B C H j.1)) Y i -
      P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 := by
  rw [forcedPQ_deficit_identity d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H hH owner rootStar Y hr hb i]
  have hg := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H i.1
  have hraw := coveredPIncrease_deficit d hs x z hx hn hcap hm P Q hP hQ C i.1 hi
  rw [hm] at hraw
  have hrem : fixedRemoval d x (allFullOverrideTargets d x) i.1 ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := le_max_right _ _
  nlinarith [mul_le_mul_of_nonneg_left hrem hP.le]

include hs hx hn hcap hm hP hQ in
theorem covered_unary_export_Q (Y : E ⊕ d.StarIndex → ℝ)
    (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (v : d.tree.Child) (hv : d.centers i = (v : V))
    (hc : childCount d v = 1) :
    P * max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 +
      Q * (Y (.inr i) - edgeSum x (d.stars i) / 2) ≤ C.cover i.1 := by
  by_cases he : outgoingBackMass d x v < coveredPIncrease d x P Q C.cover v
  · have hl := coveredPIncrease_export_link d hs x z hx hn hcap hm P Q hP hQ C v hc he
    have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v hc).2 i.1 hv).symm
    have hqn := fixedQ_link_connector d hs x z hx hn hcap hm Y hY i v hv hl
    have hxi := degreeExcess_nonnegative G hx hn (d.centers i)
    have hqle : Y (.inr i) - edgeSum x (d.stars i) / 2 ≤
        -(1 - x (d.treeEdge v) - outgoingBackMass d x v) := by linarith
    have hlb := (coveredPIncrease_link d hs x z hx hn hcap hm P Q hP hQ C v hl).2.2.2
    rw [hnext] at hlb
    rw [max_eq_left (by linarith : 0 ≤ coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v)]
    nlinarith [mul_le_mul_of_nonneg_left hqle hQ]
  · rw [max_eq_right (by linarith : coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v ≤ 0)]
    simpa using (fixedQ_connector_floor_bound d hs x z hx hn hcap hm Y hY Q hQ i).trans (C.floor_bound i.1)

include hs hx hn hcap hm hP hQ hK hKQ hD hDQ hQP hB hH in
theorem forcedPQ_connector_unary (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (Y : E ⊕ d.StarIndex → ℝ)
    (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (hi : i ≠ rootStar)
    (v : d.tree.Child) (hv : d.centers i = (v : V)) (hc : childCount d v = 1) :
    pqConnectorArm d x P Q
      (generalPoint d owner rootStar x (fun j => forcedCoverIncrease d x z P Q K D B C H j.1)) Y i -
      P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 +
      P * (forcedCoverIncrease d x z P Q K D B C H v - coveredPIncrease d x P Q C.cover v) := by
  have hp := enlarged_connector_one_child d hs owner ho rootStar x hx hcap _
    (forcedCoverIncrease_admissible d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ hD hDQ hQP hB C H hH) i hi v hv hc
  rw [forcedCoverIncrease_extension d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H hH v] at hp
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  have hc0 : 0 ≤ fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := (tau_nonneg _ _).trans ht
  have hg := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ C H v
  have hmax : max (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0 ≤
      max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 +
      (forcedCoverIncrease d x z P Q K D B C H v - coveredPIncrease d x P Q C.cover v) := by
    apply max_le
    · linarith [le_max_left (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0]
    · linarith [le_max_right (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0]
  have hout : max (starTau d x i) (max (forcedCoverIncrease d x z P Q K D B C H v - outgoingBackMass d x v) 0) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
      max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 +
      (forcedCoverIncrease d x z P Q K D B C H v - coveredPIncrease d x P Q C.cover v) := by
    apply max_le
    · linarith [le_max_right (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0]
    · linarith
  have hcov := covered_unary_export_Q d hs x z hx hn hcap hm P Q hP hQ C Y hY i v hv hc
  unfold pqConnectorArm
  have hp' : (3 / 2 : ℝ) * (generalPoint d owner rootStar x
      (fun j => forcedCoverIncrease d x z P Q K D B C H j.1) (.inr i) - 1 / 3) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
      max (coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v) 0 +
      (forcedCoverIncrease d x z P Q K D B C H v - coveredPIncrease d x P Q C.cover v) := by linarith
  nlinarith [mul_le_mul_of_nonneg_left hp' hP.le]

include hs hx hn hcap hm hP hQ hK hKQ hD hDQ hQP hB hH in
theorem forcedPQ_connector_many (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (Y : E ⊕ d.StarIndex → ℝ)
    (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (hi : i ≠ rootStar) (hc : 2 ≤ childCount d (d.centers i)) :
    pqConnectorArm d x P Q
      (generalPoint d owner rootStar x (fun j => forcedCoverIncrease d x z P Q K D B C H j.1)) Y i -
      P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 := by
  have hp := enlarged_connector_many_children d hs owner ho rootStar x hx hcap _
    (forcedCoverIncrease_admissible d hs x z hx hn hcap hm P Q K D B hP hQ hK hKQ hD hDQ hQP hB C H hH) i hi hc
  have ht := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  have hq := (fixedQ_connector_floor_bound d hs x z hx hn hcap hm Y hY Q hQ i).trans (C.floor_bound i.1)
  unfold pqConnectorArm
  have hp' : (3 / 2 : ℝ) * (generalPoint d owner rootStar x
      (fun j => forcedCoverIncrease d x z P Q K D B C H j.1) (.inr i) - 1 / 3) ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := by linarith
  nlinarith [mul_le_mul_of_nonneg_left hp' hP.le]

end TSP.Improvements20261105
