import TSP.Improvements20261105.ActualHighQTripleGroup
import TSP.Improvements20261105.HighQGroupShapes
import TSP.Improvements20261105.HighQGroupSum

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]

noncomputable def currentSelectedHeadCost {G : Graph V E} (d : DFSData G) (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex) (R : E ⊕ d.StarIndex → ℝ)
    (eligible T : Finset d.tree.Child) (ν : d.tree.Child → ℤ) (i : d.StarIndex) : ℝ :=
  (jointHeadTerm
      (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i) (ν i.1:ℝ)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)+
      (ν i.1:ℝ)*canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) i.1

variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem actual_high_q_group_payment
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (ν : (d).tree.Child → ℤ)
    (hν : ∀ s, ν s=0 ∨ ν s=1) (i : (d).StarIndex)
    (hi : HighQGroupOwner d x z C i.1) (hq : 1/2 ≤ x ((d).treeEdge i.1))
    (hout : outgoingBackMass d x i.1 < survivingExcess d x i.1) :
    (∑ k ∈ highQGroupStars d x z C i.1,
      currentSelectedHeadCost d x z C owner rootStar R eligible T ν k) ≤
      4*(∑ k ∈ highQGroupStars d x z C i.1, (((d).backGroup k.1).card:ℝ)) := by
  have hl := (Finset.mem_filter.mp hi.2.1).2
  have hprotected : ProtectedHead d x z (415/2) (704/5) C i.1 := ⟨hl.1,hl.2.1,hi.2.2⟩
  obtain ⟨j,hj,hp,hcases⟩ := high_q_successor_classification d hs x z hx hcap hm C i hprotected hl.2.2.1 hout
  have hne := highQGroupStars_pair_distinct d x i j hi.2.1 hj
  rcases hcases with hsmall | ⟨hpos,hunmatched⟩ | ⟨hpos,hmatched,k,hk⟩
  · have hjnot : j.1 ∉ C.matching := by
      intro hjm
      have hE := (Finset.mem_filter.mp (C.link_subset hjm)).2.2.1
      have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm j.1
      rw [← he,max_eq_right (by linarith)] at hE
      exact (lt_irrefl _ hE)
    rw [highQGroupStars_pair d x z C i j hj hjnot]
    have hh := actual_high_q_zero_group G x z hs hc root hx hn hcap hm hz hzx C owner ho rootStar hroot
      Y R hY hR hrep hbacks hloss hterminal hzero eligible T i j hi hq hout.le hp hsmall
      (ν i.1) (ν j.1) (hν _) (hν _)
    simpa [currentSelectedHeadCost,Finset.sum_pair hne,add_assoc] using hh
  · have hjnot : j.1 ∉ C.matching := by
      intro hjm
      exact hunmatched (Finset.mem_union_left _ (Finset.mem_image.mpr ⟨j.1,hjm,rfl⟩))
    rw [highQGroupStars_pair d x z C i j hj hjnot]
    have hh := actual_high_q_positive_group G x z hs hc root hx hn hcap hm hz hzx C owner ho rootStar hroot
      Y R hY hR hrep hbacks hloss hterminal hzero eligible T i j hi hq hp hpos hunmatched
      (ν i.1) (ν j.1) (hν _) (hν _)
    simpa [currentSelectedHeadCost,Finset.sum_pair hne,add_assoc] using hh
  · have hd := highQGroupStars_triple_distinct d x z C i j k hi.2.1 hj hk hmatched
    rw [highQGroupStars_triple d x z C i j k hj hk hmatched]
    have hh := actual_high_q_triple_group G x z hs hc root hx hn hcap hm hz hzx C owner ho rootStar hroot
      Y R hY hR hrep hbacks hloss hterminal hzero eligible T i j k hi hq hp hmatched hk
      (ν i.1) (ν j.1) (ν k.1) (hν _) (hν _) (hν _)
    simpa [currentSelectedHeadCost,hd.1,hd.2.1,hd.2.2,add_assoc] using hh

end TSP.Improvements20261105
