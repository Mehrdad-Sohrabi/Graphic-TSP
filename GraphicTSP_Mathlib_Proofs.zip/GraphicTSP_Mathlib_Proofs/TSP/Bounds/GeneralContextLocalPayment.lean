import TSP.Improvements20261105.GeneralPairLocalData
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

/-- The same transparent pointwise inequality as PairPayments. -/
def GeneralPairPaymentContext.PairPayment
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (p : (d).StarIndex × (d).StarIndex) : Prop :=
    currentSelectedHeadCost d x z K.C K.owner K.rootStar K.R (generalEligibleHeads d x)
        (generalRawCriticalHeads d x z K.a) K.a.head p.1+
      currentSelectedHeadCost d x z K.C K.owner K.rootStar K.R (generalEligibleHeads d x)
        (generalRawCriticalHeads d x z K.a) K.a.head p.2-
      24*retainedSelectedResidual d x z K.a.head p.2+
      24*extendedResidualIncomingDebt d x z K.a.head
        (K.a.internalUnmatchedHeads d (fixedGatePlan d x) x z K.C)
        (K.a.internalMatchingTargets d (fixedGatePlan d x) x z K.C) p.1 ≤
    4*((((d).backGroup p.1.1).card : ℝ)+((d).backGroup p.2.1).card)+
      2*(originalMatchingBadLabel d x₀ p.1.1 : ℝ)+
      (162/19)*(matchingPairCreditIndicator d K.a.head p : ℝ)

theorem GeneralPairPaymentContext.Q_connector_values
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root) (hn : 2 ≤ Fintype.card V) :
    FixedQConnectorValues d x K.hx hn K.hcap K.Q := by
  constructor
  · intro i
    rw [← K.hconnectors]
    exact K.hconn.1 i
  · intro i hh
    rw [← K.hconnectors]
    exact K.hconn.2 i hh

end TSP.Improvements20261105
