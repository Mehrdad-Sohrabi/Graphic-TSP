import TSP.Improvements20261105.GatedBinaryCuts
import TSP.Improvements20261105.GatedOptimalHeads

/-! Choose the lexicographically minimal actual optimal integer potential.
The choice preserves the primal-dual equality already proved from the graph. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators

theorem exists_nat_minimizer {A : Type} (S : A → Prop) (m : A → ℕ)
    (h : ∃ a, S a) : ∃ a, S a ∧ ∀ b, S b → m a ≤ m b := by
  have hex : ∃ n, ∃ a, S a ∧ m a = n := by
    obtain ⟨a, ha⟩ := h
    exact ⟨m a, a, ha, rfl⟩
  obtain ⟨a, ha, hm⟩ := Nat.find_spec hex
  refine ⟨a, ha, ?_⟩
  intro b hb
  rw [hm]
  exact Nat.find_min' hex ⟨b, hb, rfl⟩

theorem exists_three_nat_minimizer {A : Type} (S : A → Prop) (m₁ m₂ m₃ : A → ℕ)
    (h : ∃ a, S a) : ∃ a, S a ∧
      (∀ b, S b → m₁ a ≤ m₁ b) ∧
      (∀ b, S b → m₁ b = m₁ a → m₂ a ≤ m₂ b) ∧
      (∀ b, S b → m₁ b = m₁ a → m₂ b = m₂ a → m₃ a ≤ m₃ b) := by
  obtain ⟨a₁, ha₁, hmin₁⟩ := exists_nat_minimizer S m₁ h
  obtain ⟨a₂, ⟨ha₂, hm₁⟩, hmin₂⟩ :=
    exists_nat_minimizer (fun a => S a ∧ m₁ a = m₁ a₁) m₂ ⟨a₁, ha₁, rfl⟩
  obtain ⟨a₃, ⟨ha₃, hm₁', hm₂⟩, hmin₃⟩ :=
    exists_nat_minimizer (fun a => S a ∧ m₁ a = m₁ a₁ ∧ m₂ a = m₂ a₂) m₃
      ⟨a₂, ha₂, hm₁, rfl⟩
  refine ⟨a₃, ha₃, ?_, ?_, ?_⟩
  · intro b hb
    rw [hm₁']
    exact hmin₁ b hb
  · intro b hb he
    rw [hm₂]
    exact hmin₂ b ⟨hb, he.trans hm₁'⟩
  · intro b hb he₁ he₂
    exact hmin₃ b ⟨hb, he₁.trans hm₁', he₂.trans hm₂⟩

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedPrefixCount (P : GatePlan d) (p : GatedVertex d → ℤ) : ℕ :=
  (Finset.univ.filter (fun v : d.tree.Child => P.IsReceiver d v ∧ 0 < gatedPrefixDrop d p v)).card

noncomputable def gatedCutCount (P : GatePlan d) (p : GatedVertex d → ℤ) : ℕ :=
  (Finset.univ.filter (fun a : GatedArc d => 0 < gatedLower d P a ∧
    p ((gatedNetwork d P).dst a) < p ((gatedNetwork d P).src a))).card

noncomputable def gatedSelectedHeadCount (p : GatedVertex d → ℤ) : ℕ :=
  (Finset.univ.filter (fun v : d.tree.Child => gatedHeadSelector d p v = 1)).card

def GatedOptimalFor (P : GatePlan d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (p : GatedVertex d → ℤ) : Prop :=
  GatedDualFeasible d P p ∧
  realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
    (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) =
      ∑ v : d.tree.Child, f (gatedPaidArc d v)

def CanonicalGatedFor (P : GatePlan d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (p : GatedVertex d → ℤ) : Prop :=
  GatedOptimalFor d P t f p ∧
    (∀ q, GatedOptimalFor d P t f q → gatedPrefixCount d P p ≤ gatedPrefixCount d P q) ∧
    (∀ q, GatedOptimalFor d P t f q → gatedPrefixCount d P q = gatedPrefixCount d P p →
      gatedCutCount d P p ≤ gatedCutCount d P q) ∧
    (∀ q, GatedOptimalFor d P t f q → gatedPrefixCount d P q = gatedPrefixCount d P p →
      gatedCutCount d P q = gatedCutCount d P p → gatedSelectedHeadCount d p ≤ gatedSelectedHeadCount d q)

theorem exists_canonical_gated_dual (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) :
    ∃ (f : GatedArc d → ℝ) (p : GatedVertex d → ℤ),
      Chapter06.Balanced (gatedNetwork d P) f ∧
      RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f ∧
      CanonicalGatedFor d P t f p := by
  obtain ⟨f, p, hf, hb, hp, he⟩ := exists_augmented_gated_primal_dual d hs hc P t ht
  obtain ⟨q, hq⟩ := exists_three_nat_minimizer (GatedOptimalFor d P t f)
    (gatedPrefixCount d P) (gatedCutCount d P) (gatedSelectedHeadCount d) ⟨p, hp, he⟩
  exact ⟨f, q, hf, hb, hq⟩

end TSP.Improvements20261105
