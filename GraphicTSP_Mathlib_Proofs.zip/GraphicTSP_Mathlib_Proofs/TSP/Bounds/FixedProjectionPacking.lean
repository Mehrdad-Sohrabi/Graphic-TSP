import TSP.Improvements20261105.FixedProjectionIntegration
import TSP.Improvements20261105.ScoredDFSBounds

/-! The fixed projection really satisfies the star packing inequalities
used by the incidence proofs. Small stars use the actual greedy branch
of the scored DFS rule. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]

theorem group_mass_le_degree {G : Graph V E} (d : DFSData G) (hs : G.IsSimple)
    (x : E → ℝ) (hx : ∀ e, 0 ≤ x e) (s : d.tree.Child) :
    x (d.treeEdge s) + edgeSum x (d.backGroup s) ≤ G.degree x (d.tree.parent s) := by
  have hh : edgeSum x (d.group s) ≤ edgeSum x (G.cut {d.tree.parent s}) :=
    Finset.sum_le_sum_of_subset_of_nonneg (group_subset_center_cut d hs s) (fun e _ _ => hx e)
  rw [d.group_eq_insert_backGroup, edgeSum, Finset.sum_insert (by simp [DFSData.backGroup])] at hh
  rw [loopless_degree_eq_cut G hs.1]
  exact hh

theorem fixed_projection_star_pack {G : Graph V E} (d : DFSData G) (hs : G.IsSimple)
    {x z : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (hn : 2 ≤ Fintype.card V)
    (T : Finset d.tree.Child)
    (hprojection : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) - fixedRemoval d x T s)
    (s : d.tree.Child) : edgeSum z (d.backGroup s) ≤ 2 - x (d.treeEdge s) := by
  by_cases hpos : 1 < edgeSum z (d.backGroup s)
  · have hpos' := hpos
    rw [hprojection s] at hpos'
    have hsurv := (fixed_projected_positive_iff d hs hx hn T s).mp hpos'
    have hrem := fixedRemoval_surviving d hs hx hn T s hsurv
    have hm := group_mass_le_degree d hs x hx.1 s
    rw [hprojection s, hrem]
    rw [loopless_degree_eq_cut G hs.1] at hm
    unfold degreeExcess
    linarith
  · have hq := hcap (d.treeEdge s)
    linarith

section Ordered

theorem scoredDFS_small_back_greedy (G : Graph V E) (x : E → ℝ) (hs : G.IsSimple)
    (hc : G.Connected) (root : V) (s : (scoredDFS G x hs hc root).tree.Child)
    (hsmall : ((scoredDFS G x hs hc root).backGroup s).card ≤ 3)
    (e : E) (he : e ∈ (scoredDFS G x hs hc root).backGroup s) :
    x e ≤ x ((scoredDFS G x hs hc root).treeEdge s) := by
  apply scoredDFS_unscored_greedy G x hs hc root s
  · intro hg
    have hh := hg.1
    omega
  · exact (Finset.mem_sdiff.mp he).1

theorem scoredDFS_small_projected_back (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple)
    (hc : G.Connected) (root : V) (hzx : ∀ e, z e ≤ x e)
    (s : (scoredDFS G x hs hc root).tree.Child)
    (hsmall : ((scoredDFS G x hs hc root).backGroup s).card ≤ 3)
    (e : E) (he : e ∈ (scoredDFS G x hs hc root).backGroup s) :
    z e ≤ x ((scoredDFS G x hs hc root).treeEdge s) :=
  (hzx e).trans (scoredDFS_small_back_greedy G x hs hc root s hsmall e he)

end Ordered
end TSP.Improvements20261105
