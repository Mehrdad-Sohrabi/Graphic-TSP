import TSP.Improvements20261105.ForceArithmetic

/-! Exact inequalities for the current tuple P=415/2, Q=704/5, D=24,
B=4, K=60 and cutoff 13/40. These are local guard checks only. -/
namespace TSP.Improvements20261105

theorem current_force_constants :
    (0 : ℝ) < 415 / 2 ∧ (0 : ℝ) ≤ 704 / 5 ∧
    (60 : ℝ) ≤ 704 / 5 ∧ (24 : ℝ) ≤ 704 / 5 ∧ (704 / 5 : ℝ) ≤ 415 / 2 ∧
    (415 / 2 : ℝ) * 60 ≤ (704 / 5 : ℝ) * (704 / 5 - 48) ∧
    (1 - 13 / 40 : ℝ) * (415 / 2) - 704 / 5 < 0 := by norm_num

theorem current_protected_zero_floor (w q y : ℝ)
    (hq : q ≤ y) (hleft : w ≤ (704 / 5 : ℝ) * y)
    (hright : w ≤ (415 / 2 : ℝ) * (1 - y)) :
    w - 704 / 5 + 60 * q ≤ -48 * (1 - y) := by linarith

theorem current_H_frozen_pair (E q : ℝ) (h : E + q ≤ 27 / 40) :
    (415 / 2 : ℝ) * (E + q) - 704 / 5 ≤ -59 / 80 := by linarith

theorem current_pair_protection_tent (E q t : ℝ)
    (ht : 2 ≤ t) (hE : E ≤ 1 - q) (hpacked : E ≤ t * q - 1) :
    (415 / 2 : ℝ) * E + 84 * (1 - q - E) - 704 / 5 ≤
      415 / 2 - 704 / 5 - 415 / (t + 1) := by
  have ht1 : 0 < t + 1 := by linarith
  suffices hfinal : 415 / (t + 1) ≤ 415 / 2 - 704 / 5 -
      ((415 / 2 : ℝ) * E + 84 * (1 - q - E) - 704 / 5) by linarith
  apply (div_le_iff₀ ht1).mpr
  by_cases hq : q ≤ 2 / (t + 1)
  · have hqt := (le_div_iff₀ ht1).mp hq
    have hcoeff : 0 ≤ (415 / 2 - 84 : ℝ) * t - 84 := by linarith
    have h1 := mul_le_mul_of_nonneg_left hpacked (show (0 : ℝ) ≤ 415 / 2 - 84 by norm_num)
    have h2 := mul_le_mul_of_nonneg_left hqt hcoeff
    have h1t := mul_le_mul_of_nonneg_right h1 ht1.le
    nlinarith
  · have hqt := (div_lt_iff₀ ht1).mp (lt_of_not_ge hq)
    have h1 := mul_le_mul_of_nonneg_left hE (show (0 : ℝ) ≤ 415 / 2 - 84 by norm_num)
    have h1t := mul_le_mul_of_nonneg_right h1 ht1.le
    nlinarith

end TSP.Improvements20261105
