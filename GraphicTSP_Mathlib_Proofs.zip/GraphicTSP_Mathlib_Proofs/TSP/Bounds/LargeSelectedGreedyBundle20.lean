import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
private theorem greedybundle20_cached_cap_000 :
    0 ≤ (16/15 : ℝ) ∧ 0 ≤ 2-(16/15 : ℝ) ∧ (2-(16/15 : ℝ))*(15/28 : ℝ) ≤ 1/2 ∧
    0 ≤ (53/50 : ℝ) ∧ 0 ≤ 19/10-(53/50 : ℝ) ∧ (19/10-(53/50 : ℝ))*(15/28 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_001 :
    0 ≤ (7/5 : ℝ) ∧ 0 ≤ 2-(7/5 : ℝ) ∧ (2-(7/5 : ℝ))*(5/6 : ℝ) ≤ 1/2 ∧
    0 ≤ (34/25 : ℝ) ∧ 0 ≤ 19/10-(34/25 : ℝ) ∧ (19/10-(34/25 : ℝ))*(5/6 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_002 :
    0 ≤ (3/2 : ℝ) ∧ 0 ≤ 2-(3/2 : ℝ) ∧ (2-(3/2 : ℝ))*(1/1 : ℝ) ≤ 1/2 ∧
    0 ≤ (29/20 : ℝ) ∧ 0 ≤ 19/10-(29/20 : ℝ) ∧ (19/10-(29/20 : ℝ))*(1/1 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_003 :
    0 ≤ (19/13 : ℝ) ∧ 0 ≤ 2-(19/13 : ℝ) ∧ (2-(19/13 : ℝ))*(13/14 : ℝ) ≤ 1/2 ∧
    0 ≤ (92/65 : ℝ) ∧ 0 ≤ 19/10-(92/65 : ℝ) ∧ (19/10-(92/65 : ℝ))*(13/14 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_004 :
    0 ≤ (6/13 : ℝ) ∧ 0 ≤ 2-(6/13 : ℝ) ∧ (2-(6/13 : ℝ))*(13/40 : ℝ) ≤ 1/2 ∧
    0 ≤ (67/130 : ℝ) ∧ 0 ≤ 19/10-(67/130 : ℝ) ∧ (19/10-(67/130 : ℝ))*(13/40 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_005 :
    0 ≤ (1/1 : ℝ) ∧ 0 ≤ 2-(1/1 : ℝ) ∧ (2-(1/1 : ℝ))*(1/2 : ℝ) ≤ 1/2 ∧
    0 ≤ (1/1 : ℝ) ∧ 0 ≤ 19/10-(1/1 : ℝ) ∧ (19/10-(1/1 : ℝ))*(1/2 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_006 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(3/16 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(3/16 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_007 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(13/80 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(13/80 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_008 :
    0 ≤ (6/17 : ℝ) ∧ 0 ≤ 2-(6/17 : ℝ) ∧ (2-(6/17 : ℝ))*(17/56 : ℝ) ≤ 1/2 ∧
    0 ≤ (71/170 : ℝ) ∧ 0 ≤ 19/10-(71/170 : ℝ) ∧ (19/10-(71/170 : ℝ))*(17/56 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_009 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(39/160 : ℝ) ≤ 1/2 ∧
    0 ≤ (7/130 : ℝ) ∧ 0 ≤ 19/10-(7/130 : ℝ) ∧ (19/10-(7/130 : ℝ))*(39/160 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_010 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(29/224 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(29/224 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_011 :
    0 ≤ (38/59 : ℝ) ∧ 0 ≤ 2-(38/59 : ℝ) ∧ (2-(38/59 : ℝ))*(59/160 : ℝ) ≤ 1/2 ∧
    0 ≤ (401/590 : ℝ) ∧ 0 ≤ 19/10-(401/590 : ℝ) ∧ (19/10-(401/590 : ℝ))*(59/160 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_012 :
    0 ≤ (26/33 : ℝ) ∧ 0 ≤ 2-(26/33 : ℝ) ∧ (2-(26/33 : ℝ))*(33/80 : ℝ) ≤ 1/2 ∧
    0 ≤ (89/110 : ℝ) ∧ 0 ≤ 19/10-(89/110 : ℝ) ∧ (19/10-(89/110 : ℝ))*(33/80 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_013 :
    0 ≤ (66/73 : ℝ) ∧ 0 ≤ 2-(66/73 : ℝ) ∧ (2-(66/73 : ℝ))*(73/160 : ℝ) ≤ 1/2 ∧
    0 ≤ (667/730 : ℝ) ∧ 0 ≤ 19/10-(667/730 : ℝ) ∧ (19/10-(667/730 : ℝ))*(73/160 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_014 :
    0 ≤ (5/4 : ℝ) ∧ 0 ≤ 2-(5/4 : ℝ) ∧ (2-(5/4 : ℝ))*(2/3 : ℝ) ≤ 1/2 ∧
    0 ≤ (49/40 : ℝ) ∧ 0 ≤ 19/10-(49/40 : ℝ) ∧ (19/10-(49/40 : ℝ))*(2/3 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_015 :
    0 ≤ (1/3 : ℝ) ∧ 0 ≤ 2-(1/3 : ℝ) ∧ (2-(1/3 : ℝ))*(3/10 : ℝ) ≤ 1/2 ∧
    0 ≤ (2/5 : ℝ) ∧ 0 ≤ 19/10-(2/5 : ℝ) ∧ (19/10-(2/5 : ℝ))*(3/10 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_016 :
    0 ≤ (17/16 : ℝ) ∧ 0 ≤ 2-(17/16 : ℝ) ∧ (2-(17/16 : ℝ))*(8/15 : ℝ) ≤ 1/2 ∧
    0 ≤ (169/160 : ℝ) ∧ 0 ≤ 19/10-(169/160 : ℝ) ∧ (19/10-(169/160 : ℝ))*(8/15 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_017 :
    0 ≤ (41/28 : ℝ) ∧ 0 ≤ 2-(41/28 : ℝ) ∧ (2-(41/28 : ℝ))*(14/15 : ℝ) ≤ 1/2 ∧
    0 ≤ (397/280 : ℝ) ∧ 0 ≤ 19/10-(397/280 : ℝ) ∧ (19/10-(397/280 : ℝ))*(14/15 : ℝ) ≤ 9/20 := by norm_num

private theorem greedybundle20_cached_cap_018 :
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 2-(0/1 : ℝ) ∧ (2-(0/1 : ℝ))*(11/60 : ℝ) ≤ 1/2 ∧
    0 ≤ (0/1 : ℝ) ∧ 0 ≤ 19/10-(0/1 : ℝ) ∧ (19/10-(0/1 : ℝ))*(11/60 : ℝ) ≤ 9/20 := by norm_num

set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t14_r3_all_cell_60
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (27/250 : ℝ))
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t14_r3_all_cell_61
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (27/250 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (15/28 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (15/28 : ℝ) (16/15 : ℝ) (53/50 : ℝ) greedybundle20_cached_cap_000.1 greedybundle20_cached_cap_000.2.1 greedybundle20_cached_cap_000.2.2.1 greedybundle20_cached_cap_000.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle20_cached_cap_001.1 greedybundle20_cached_cap_001.2.1 greedybundle20_cached_cap_001.2.2.1 greedybundle20_cached_cap_001.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (2331/10:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15909/5:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (2331/10:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1148257/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (853579/3610:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1165553/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (853579/3610:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5825901/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_62
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (27/250 : ℝ))
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t14_r3_all_cell_63
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (27/250 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (13/14 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (13/14 : ℝ) (19/13 : ℝ) (92/65 : ℝ) greedybundle20_cached_cap_003.1 greedybundle20_cached_cap_003.2.1 greedybundle20_cached_cap_003.2.2.1 greedybundle20_cached_cap_003.2.2.2.1 greedybundle20_cached_cap_003.2.2.2.2.1 greedybundle20_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6307/26:ℝ)*hzl + (1027/10:ℝ)*hem + (6931/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (15781/13:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (768/13:ℝ)*hmass
  · linear_combination (2282507/9386:ℝ)*hzl + (1027/10:ℝ)*hem + (2507771/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (5694101/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (280088/4693:ℝ)*hmass
  · linear_combination (6307/26:ℝ)*hzl + (371967/3610:ℝ)*hem + (6931/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (5719145/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (768/13:ℝ)*hmass
  · linear_combination (2282507/9386:ℝ)*hzl + (371967/3610:ℝ)*hem + (2507771/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (5716305/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (280088/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_64
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (15/28 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (15/28 : ℝ) (16/15 : ℝ) (53/50 : ℝ) greedybundle20_cached_cap_000.1 greedybundle20_cached_cap_000.2.1 greedybundle20_cached_cap_000.2.2.1 greedybundle20_cached_cap_000.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (2331/10:ℝ)*hg0 + (2571/10:ℝ)*hgap + (1/1:ℝ)*hH0 + (37983/130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (2331/10:ℝ)*hg0 + (2571/10:ℝ)*hgap + (1/1:ℝ)*hH0 + (14066303/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (853579/3610:ℝ)*hg0 + (940219/3610:ℝ)*hgap + (1/1:ℝ)*hH0 + (13869007/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (853579/3610:ℝ)*hg0 + (940219/3610:ℝ)*hgap + (1/1:ℝ)*hH0 + (14223447/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_65
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_66
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (15/28 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (15/28 : ℝ) (16/15 : ℝ) (53/50 : ℝ) greedybundle20_cached_cap_000.1 greedybundle20_cached_cap_000.2.1 greedybundle20_cached_cap_000.2.2.1 greedybundle20_cached_cap_000.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (2331/10:ℝ)*hg0 + (2571/10:ℝ)*hgap + (1/1:ℝ)*hH0 + (3051/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (2331/10:ℝ)*hg0 + (2571/10:ℝ)*hgap + (1/1:ℝ)*hH0 + (1115171/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (853579/3610:ℝ)*hg0 + (940219/3610:ℝ)*hgap + (1/1:ℝ)*hH0 + (1113499/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (853579/3610:ℝ)*hg0 + (940219/3610:ℝ)*hgap + (1/1:ℝ)*hH0 + (1127259/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_67
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_68
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle20_cached_cap_001.1 greedybundle20_cached_cap_001.2.1 greedybundle20_cached_cap_001.2.2.1 greedybundle20_cached_cap_001.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1027/10:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3251/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1027/10:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1177339/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (371967/3610:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1174831/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (371967/3610:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1178559/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_69
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (13/14 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t14_r3_all_cell_70
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_007.1 greedybundle20_cached_cap_007.2.1 greedybundle20_cached_cap_007.2.2.1 greedybundle20_cached_cap_007.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/30:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2857/15:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (190871/10830:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1028177/5415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (190871/10830:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1076177/5415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (65757/3610:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (357659/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_71
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/16 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_007.1 greedybundle20_cached_cap_007.2.1 greedybundle20_cached_cap_007.2.2.1 greedybundle20_cached_cap_007.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (8975/34:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (3348775/12274:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (3341935/12274:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (3450735/12274:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_72
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) greedybundle20_cached_cap_009.1 greedybundle20_cached_cap_009.2.1 greedybundle20_cached_cap_009.2.2.1 greedybundle20_cached_cap_009.2.2.2.1 greedybundle20_cached_cap_009.2.2.2.2.1 greedybundle20_cached_cap_009.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/30:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2857/15:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (2490899/140790:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13361513/70395:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (190871/10830:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1076177/5415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (858033/46930:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4647971/23465:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_73
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6931/390:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (36997/195:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2572979/140790:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13320473/70395:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2585291/140790:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13938317/70395:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (885393/46930:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4634291/23465:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_74
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/16 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) greedybundle20_cached_cap_009.1 greedybundle20_cached_cap_009.2.1 greedybundle20_cached_cap_009.2.2.1 greedybundle20_cached_cap_009.2.2.2.1 greedybundle20_cached_cap_009.2.2.2.2.1 greedybundle20_cached_cap_009.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (8975/34:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (43696867/159562:ℝ)*hql + (271652/4693:ℝ)*hzl + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass
  · linear_combination (3341935/12274:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (45022347/159562:ℝ)*hql + (271652/4693:ℝ)*hzl + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_75
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/16 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (121571/442:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (45092227/159562:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (45212611/159562:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (46417707/159562:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_76
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (15/28 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (15/28 : ℝ) (16/15 : ℝ) (53/50 : ℝ) greedybundle20_cached_cap_000.1 greedybundle20_cached_cap_000.2.1 greedybundle20_cached_cap_000.2.2.1 greedybundle20_cached_cap_000.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (37983/130:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2331/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (14066303/46930:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2331/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (13869007/46930:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (853579/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (14223447/46930:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (853579/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_77
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_78
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (29/224 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (29/224 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_010.1 greedybundle20_cached_cap_010.2.1 greedybundle20_cached_cap_010.2.2.1 greedybundle20_cached_cap_010.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.2 hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) greedybundle20_cached_cap_011.1 greedybundle20_cached_cap_011.2.1 greedybundle20_cached_cap_011.2.2.1 greedybundle20_cached_cap_011.2.2.2.1 greedybundle20_cached_cap_011.2.2.2.2.1 greedybundle20_cached_cap_011.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3744/59:ℝ)*hzl + (31973/1770:ℝ)*hem + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (167651/885:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (11809957/638970:ℝ)*hem + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (60388159/319485:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (3744/59:ℝ)*hzl + (11919853/638970:ℝ)*hem + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (63165211/319485:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (4062519/212990:ℝ)*hem + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (21010453/106495:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_79
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (29/224 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (29/224 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_010.1 greedybundle20_cached_cap_010.2.1 greedybundle20_cached_cap_010.2.2.1 greedybundle20_cached_cap_010.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.2 hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) greedybundle20_cached_cap_012.1 greedybundle20_cached_cap_012.2.1 greedybundle20_cached_cap_012.2.2.1 greedybundle20_cached_cap_012.2.2.2.1 greedybundle20_cached_cap_012.2.2.2.2.1 greedybundle20_cached_cap_012.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (736/11:ℝ)*hzl + (6037/330:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (31219/165:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2221333/119130:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11249071/59565:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (736/11:ℝ)*hzl + (749919/39710:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3920953/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (763911/39710:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3913957/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t14_r3_all_cell_80
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (29/224 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) greedybundle20_cached_cap_011.1 greedybundle20_cached_cap_011.2.1 greedybundle20_cached_cap_011.2.2.1 greedybundle20_cached_cap_011.2.2.2.1 greedybundle20_cached_cap_011.2.2.2.2.1 greedybundle20_cached_cap_011.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (31973/118:ℝ)*hql + (3744/59:ℝ)*hzl + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (415/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (11809957/42598:ℝ)*hql + (1485436/21299:ℝ)*hzl + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (415/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (11919853/42598:ℝ)*hql + (3744/59:ℝ)*hzl + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (156215/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (12187557/42598:ℝ)*hql + (1485436/21299:ℝ)*hzl + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (156215/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_81
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (29/224 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) greedybundle20_cached_cap_012.1 greedybundle20_cached_cap_012.2.1 greedybundle20_cached_cap_012.2.2.1 greedybundle20_cached_cap_012.2.2.2.1 greedybundle20_cached_cap_012.2.2.2.2.1 greedybundle20_cached_cap_012.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6037/22:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (415/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (2221333/7942:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (415/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (2249757/7942:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (156215/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (2291733/7942:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (156215/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_82
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (29/224 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (73/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (29/224 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_010.1 greedybundle20_cached_cap_010.2.1 greedybundle20_cached_cap_010.2.2.1 greedybundle20_cached_cap_010.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.2 hqu
  have hI := hIall (73/160 : ℝ) (66/73 : ℝ) (667/730 : ℝ) greedybundle20_cached_cap_013.1 greedybundle20_cached_cap_013.2.1 greedybundle20_cached_cap_013.2.2.1 greedybundle20_cached_cap_013.2.2.2.1 greedybundle20_cached_cap_013.2.2.2.2.1 greedybundle20_cached_cap_013.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5088/73:ℝ)*hzl + (40471/2190:ℝ)*hem + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (206977/1095:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (3336/73:ℝ)*hmass
  · linear_combination (1954772/26353:ℝ)*hzl + (14846039/790590:ℝ)*hem + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (74600693/395295:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1322300/26353:ℝ)*hmass
  · linear_combination (5088/73:ℝ)*hzl + (15077231/790590:ℝ)*hem + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (77989097/395295:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (3336/73:ℝ)*hmass
  · linear_combination (1954772/26353:ℝ)*hzl + (5104413/263530:ℝ)*hem + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (25957031/131765:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1322300/26353:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_83
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (29/224 : ℝ))
    (hzl : (73/160 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (29/224 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_010.1 greedybundle20_cached_cap_010.2.1 greedybundle20_cached_cap_010.2.2.1 greedybundle20_cached_cap_010.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.1 greedybundle20_cached_cap_010.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (559/30:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (721/15:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (204551/10830:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (51781/1083:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (208199/10830:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (305081/5415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (70317/3610:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (20247/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_84
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (29/224 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (73/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (73/160 : ℝ) (66/73 : ℝ) (667/730 : ℝ) greedybundle20_cached_cap_013.1 greedybundle20_cached_cap_013.2.1 greedybundle20_cached_cap_013.2.2.1 greedybundle20_cached_cap_013.2.2.2.1 greedybundle20_cached_cap_013.2.2.2.2.1 greedybundle20_cached_cap_013.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (40471/146:ℝ)*hql + (5088/73:ℝ)*hzl + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (415/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (3336/73:ℝ)*hmass
  · linear_combination (14846039/52706:ℝ)*hql + (1954772/26353:ℝ)*hzl + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (415/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1322300/26353:ℝ)*hmass
  · linear_combination (15077231/52706:ℝ)*hql + (5088/73:ℝ)*hzl + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (156215/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (3336/73:ℝ)*hmass
  · linear_combination (15313239/52706:ℝ)*hql + (1954772/26353:ℝ)*hzl + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (156215/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1322300/26353:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_85
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (29/224 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (73/160 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (559/2:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (667/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (204551/722:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (667/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (208199/722:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (272787/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (210951/722:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (272787/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_86
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/16 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) greedybundle20_cached_cap_012.1 greedybundle20_cached_cap_012.2.1 greedybundle20_cached_cap_012.2.2.1 greedybundle20_cached_cap_012.2.2.2.1 greedybundle20_cached_cap_012.2.2.2.2.1 greedybundle20_cached_cap_012.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (105797/374:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (38906309/135014:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (39314277/135014:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (40027869/135014:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_87
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/16 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9791/34:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (3581335/12274:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (3636511/12274:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (3683295/12274:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_88
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (15/28 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (15/28 : ℝ) (16/15 : ℝ) (53/50 : ℝ) greedybundle20_cached_cap_000.1 greedybundle20_cached_cap_000.2.1 greedybundle20_cached_cap_000.2.2.1 greedybundle20_cached_cap_000.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3051/10:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2331/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1115171/3610:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2331/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (1113499/3610:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (853579/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1127259/3610:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (853579/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_89
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t14_r3_all_cell_90
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (3/16 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (3/16 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_006.1 greedybundle20_cached_cap_006.2.1 greedybundle20_cached_cap_006.2.2.1 greedybundle20_cached_cap_006.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.1 greedybundle20_cached_cap_006.2.2.2.2.2 hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) greedybundle20_cached_cap_014.1 greedybundle20_cached_cap_014.2.1 greedybundle20_cached_cap_014.2.2.1 greedybundle20_cached_cap_014.2.2.2.1 greedybundle20_cached_cap_014.2.2.2.2.1 greedybundle20_cached_cap_014.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hzl + (571/30:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (143/3:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (207629/10830:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (257366/5415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hzl + (212531/10830:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (60583/1083:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (71343/3610:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (100722/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_91
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/16 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) greedybundle20_cached_cap_014.1 greedybundle20_cached_cap_014.2.1 greedybundle20_cached_cap_014.2.2.1 greedybundle20_cached_cap_014.2.2.2.1 greedybundle20_cached_cap_014.2.2.2.2.1 greedybundle20_cached_cap_014.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9995/34:ℝ)*hql + (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (12779/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (3633661/12274:ℝ)*hql + (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (12779/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (3710155/12274:ℝ)*hql + (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (5123019/61370:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (3735621/12274:ℝ)*hql + (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (5123019/61370:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_92
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) greedybundle20_cached_cap_008.1 greedybundle20_cached_cap_008.2.1 greedybundle20_cached_cap_008.2.2.1 greedybundle20_cached_cap_008.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.1 greedybundle20_cached_cap_008.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle20_cached_cap_001.1 greedybundle20_cached_cap_001.2.1 greedybundle20_cached_cap_001.2.2.1 greedybundle20_cached_cap_001.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (50587/2550:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (70549/1275:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (18325283/920550:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (25436501/460275:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (18771707/920550:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (29036789/460275:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (6278361/306850:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (9668367/153425:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_93
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (15/28 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (15/28 : ℝ) (16/15 : ℝ) (53/50 : ℝ) greedybundle20_cached_cap_000.1 greedybundle20_cached_cap_000.2.1 greedybundle20_cached_cap_000.2.2.1 greedybundle20_cached_cap_000.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.1 greedybundle20_cached_cap_000.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle20_cached_cap_001.1 greedybundle20_cached_cap_001.2.1 greedybundle20_cached_cap_001.2.2.1 greedybundle20_cached_cap_001.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3147/10:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (923/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (227959/722:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (923/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (229631/722:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (345291/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (1151883/3610:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (345291/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t14_r3_all_cell_94
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (15/28 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t14_r3_all_cell_95
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/14 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (13/14 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (13/14 : ℝ) (19/13 : ℝ) (92/65 : ℝ) greedybundle20_cached_cap_003.1 greedybundle20_cached_cap_003.2.1 greedybundle20_cached_cap_003.2.2.1 greedybundle20_cached_cap_003.2.2.2.1 greedybundle20_cached_cap_003.2.2.2.2.1 greedybundle20_cached_cap_003.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6307/26:ℝ)*hzl + (135328/8801:ℝ)*hem + (1691232/8801:ℝ)*ho0 + (677376/44005:ℝ)*hgap + (28224/44005:ℝ)*hS + (1/1:ℝ)*hI + (15781/44005:ℝ)*hsource + (1/1:ℝ)*hR + (768/13:ℝ)*hmass
  · linear_combination (2282507/9386:ℝ)*hzl + (48991716/3177161:ℝ)*hem + (612575292/3177161:ℝ)*ho0 + (244600896/15885805:ℝ)*hgap + (10191704/15885805:ℝ)*hS + (1/1:ℝ)*hI + (5694101/15885805:ℝ)*hsource + (1/1:ℝ)*hR + (280088/4693:ℝ)*hmass
  · linear_combination (6307/26:ℝ)*hzl + (1222920224/79540045:ℝ)*hem + (3053985504/15908009:ℝ)*ho0 + (244532736/15908009:ℝ)*hgap + (10188864/15908009:ℝ)*hS + (1/1:ℝ)*hI + (5719145/15908009:ℝ)*hsource + (1/1:ℝ)*hR + (768/13:ℝ)*hmass
  · linear_combination (2282507/9386:ℝ)*hzl + (442724162964/28713956245:ℝ)*hem + (1106176792364/5742791249:ℝ)*ho0 + (244600896/15908009:ℝ)*hgap + (10191704/15908009:ℝ)*hS + (1/1:ℝ)*hI + (5716305/15908009:ℝ)*hsource + (1/1:ℝ)*hR + (280088/4693:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t15_r3_all_cell_0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (3/10 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) greedybundle20_cached_cap_015.1 greedybundle20_cached_cap_015.2.1 greedybundle20_cached_cap_015.2.2.1 greedybundle20_cached_cap_015.2.2.2.1 greedybundle20_cached_cap_015.2.2.2.2.1 greedybundle20_cached_cap_015.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (431/2:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (82509/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (431/2:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (29714861/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (161687/722:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (30974469/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (161687/722:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (30903581/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (3/10 : ℝ) ≤ q) (hqu : q ≤ (8/15 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t15_r3_all_cell_2
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (8/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t15_r3_all_cell_3
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (8/15 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (8/15 : ℝ) (17/16 : ℝ) (169/160 : ℝ) greedybundle20_cached_cap_016.1 greedybundle20_cached_cap_016.2.1 greedybundle20_cached_cap_016.2.2.1 greedybundle20_cached_cap_016.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (233/1:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3423/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (233/1:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1234327/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (341329/1444:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5015967/1444:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (341329/1444:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5010463/1444:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_4
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (8/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t15_r3_all_cell_5
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (8/15 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (8/15 : ℝ) (17/16 : ℝ) (169/160 : ℝ) greedybundle20_cached_cap_016.1 greedybundle20_cached_cap_016.2.1 greedybundle20_cached_cap_016.2.2.1 greedybundle20_cached_cap_016.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle20_cached_cap_001.1 greedybundle20_cached_cap_001.2.1 greedybundle20_cached_cap_001.2.2.1 greedybundle20_cached_cap_001.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (233/1:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (17067/5:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (233/1:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6159323/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (341329/1444:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (25010523/7220:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (341329/1444:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (25003067/7220:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_6
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (8/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t15_r3_all_cell_7
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (103/1000 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (14/15 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (14/15 : ℝ) (41/28 : ℝ) (397/280 : ℝ) greedybundle20_cached_cap_017.1 greedybundle20_cached_cap_017.2.1 greedybundle20_cached_cap_017.2.2.1 greedybundle20_cached_cap_017.2.2.2.1 greedybundle20_cached_cap_017.2.2.2.2.1 greedybundle20_cached_cap_017.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3397/14:ℝ)*hzl + (1027/10:ℝ)*hem + (3733/14:ℝ)*ho0 + (24/1:ℝ)*hgap + (92159/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (414/7:ℝ)*hmass
  · linear_combination (1229279/5054:ℝ)*hzl + (1027/10:ℝ)*hem + (1350575/5054:ℝ)*ho0 + (24/1:ℝ)*hgap + (33254589/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (150935/2527:ℝ)*hmass
  · linear_combination (3397/14:ℝ)*hzl + (371967/3610:ℝ)*hem + (3733/14:ℝ)*ho0 + (24/1:ℝ)*hgap + (33397499/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (414/7:ℝ)*hmass
  · linear_combination (1229279/5054:ℝ)*hzl + (371967/3610:ℝ)*hem + (1350575/5054:ℝ)*ho0 + (24/1:ℝ)*hgap + (33382689/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (150935/2527:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_8
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (8/15 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (8/15 : ℝ) (17/16 : ℝ) (169/160 : ℝ) greedybundle20_cached_cap_016.1 greedybundle20_cached_cap_016.2.1 greedybundle20_cached_cap_016.2.2.1 greedybundle20_cached_cap_016.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (233/1:ℝ)*hg0 + (257/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3797/13:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (233/1:ℝ)*hg0 + (257/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1406161/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (341329/1444:ℝ)*hg0 + (375985/1444:ℝ)*hgap + (1/1:ℝ)*hH0 + (5546269/18772:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (341329/1444:ℝ)*hg0 + (375985/1444:ℝ)*hgap + (1/1:ℝ)*hH0 + (5688045/18772:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_9
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (8/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t15_r3_all_cell_10
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (8/15 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (8/15 : ℝ) (17/16 : ℝ) (169/160 : ℝ) greedybundle20_cached_cap_016.1 greedybundle20_cached_cap_016.2.1 greedybundle20_cached_cap_016.2.2.1 greedybundle20_cached_cap_016.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (233/1:ℝ)*hg0 + (257/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (305/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (233/1:ℝ)*hg0 + (257/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (111481/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (341329/1444:ℝ)*hg0 + (375985/1444:ℝ)*hgap + (1/1:ℝ)*hH0 + (445297/1444:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (341329/1444:ℝ)*hg0 + (375985/1444:ℝ)*hgap + (1/1:ℝ)*hH0 + (450801/1444:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_11
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (8/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) greedybundle20_cached_cap_005.1 greedybundle20_cached_cap_005.2.1 greedybundle20_cached_cap_005.2.2.1 greedybundle20_cached_cap_005.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.1 greedybundle20_cached_cap_005.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_12
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) greedybundle20_cached_cap_002.1 greedybundle20_cached_cap_002.2.1 greedybundle20_cached_cap_002.2.2.1 greedybundle20_cached_cap_002.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.1 greedybundle20_cached_cap_002.2.2.2.2.2 hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) greedybundle20_cached_cap_001.1 greedybundle20_cached_cap_001.2.1 greedybundle20_cached_cap_001.2.2.1 greedybundle20_cached_cap_001.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.1 greedybundle20_cached_cap_001.2.2.2.2.2 hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1027/10:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3251/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1027/10:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1177339/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (371967/3610:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1174831/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (371967/3610:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1178559/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_13
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (14/15 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t15_r3_all_cell_14
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (11/60 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (11/60 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_018.1 greedybundle20_cached_cap_018.2.1 greedybundle20_cached_cap_018.2.2.1 greedybundle20_cached_cap_018.2.2.2.1 greedybundle20_cached_cap_018.2.2.2.2.1 greedybundle20_cached_cap_018.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_007.1 greedybundle20_cached_cap_007.2.1 greedybundle20_cached_cap_007.2.2.1 greedybundle20_cached_cap_007.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/32:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6129/32:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (190871/11552:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2206169/11552:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (190871/11552:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2308569/11552:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (197271/11552:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2302169/11552:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_15
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (11/60 : ℝ) ≤ q) (hqu : q ≤ (3/10 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) greedybundle20_cached_cap_015.1 greedybundle20_cached_cap_015.2.1 greedybundle20_cached_cap_015.2.2.1 greedybundle20_cached_cap_015.2.2.2.1 greedybundle20_cached_cap_015.2.2.2.2.1 greedybundle20_cached_cap_015.2.2.2.2.2 hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_007.1 greedybundle20_cached_cap_007.2.1 greedybundle20_cached_cap_007.2.2.1 greedybundle20_cached_cap_007.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.1 greedybundle20_cached_cap_007.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (527/2:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (431/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (196647/722:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (431/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (196343/722:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (161687/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (202743/722:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (161687/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_16
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (11/60 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (11/60 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_018.1 greedybundle20_cached_cap_018.2.1 greedybundle20_cached_cap_018.2.2.1 greedybundle20_cached_cap_018.2.2.2.1 greedybundle20_cached_cap_018.2.2.2.2.1 greedybundle20_cached_cap_018.2.2.2.2.2 hqu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) greedybundle20_cached_cap_009.1 greedybundle20_cached_cap_009.2.1 greedybundle20_cached_cap_009.2.2.1 greedybundle20_cached_cap_009.2.2.2.1 greedybundle20_cached_cap_009.2.2.2.2.1 greedybundle20_cached_cap_009.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/32:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6129/32:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (2490899/150176:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (28670621/150176:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (190871/11552:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2308569/11552:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (2574099/150176:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (29918621/150176:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_17
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/15 : ℝ) ≤ q) (hqu : q ≤ (11/60 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (11/60 : ℝ) (0/1 : ℝ) (0/1 : ℝ) greedybundle20_cached_cap_018.1 greedybundle20_cached_cap_018.2.1 greedybundle20_cached_cap_018.2.2.1 greedybundle20_cached_cap_018.2.2.2.1 greedybundle20_cached_cap_018.2.2.2.2.1 greedybundle20_cached_cap_018.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6931/416:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (79389/416:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2572979/150176:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (28588541/150176:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2585291/150176:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (29907429/150176:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2656179/150176:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (29836541/150176:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_18
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (11/60 : ℝ) ≤ q) (hqu : q ≤ (3/10 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) greedybundle20_cached_cap_015.1 greedybundle20_cached_cap_015.2.1 greedybundle20_cached_cap_015.2.2.1 greedybundle20_cached_cap_015.2.2.2.1 greedybundle20_cached_cap_015.2.2.2.2.1 greedybundle20_cached_cap_015.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7139/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (431/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2648067/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (431/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2656427/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (161687/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2727315/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (161687/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t15_r3_all_cell_19
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (3/10 : ℝ) ≤ q) (hqu : q ≤ (8/15 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hS := hSall (8/15 : ℝ) (17/16 : ℝ) (169/160 : ℝ) greedybundle20_cached_cap_016.1 greedybundle20_cached_cap_016.2.1 greedybundle20_cached_cap_016.2.2.1 greedybundle20_cached_cap_016.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.1 greedybundle20_cached_cap_016.2.2.2.2.2 hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) greedybundle20_cached_cap_004.1 greedybundle20_cached_cap_004.2.1 greedybundle20_cached_cap_004.2.2.1 greedybundle20_cached_cap_004.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.1 greedybundle20_cached_cap_004.2.2.2.2.2 hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3797/13:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (233/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (1406161/4693:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (233/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (5546269/18772:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (341329/1444:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (5688045/18772:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (341329/1444:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

end TSP.Improvements20261105
