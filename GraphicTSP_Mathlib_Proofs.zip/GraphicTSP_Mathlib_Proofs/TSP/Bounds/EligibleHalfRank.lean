import TSP.Improvements20261105.AugmentedLaminar

/-! Original extreme-vector half-rank allowance, including degree slack.
No capped-vector extremality and no DFS edge-weight priority are assumed. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter10
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

/-- If b original-vector eligible vertices have no incident partition into
two unit-mass sets, and h vertices have cut mass above two, then
2m + b + h <= 4n - 6. The n >= 3 hypothesis separates the two-vertex block,
where the artificial top and one singleton coincide. -/
theorem eligible_half_rank {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x e)
    (hn : 3 ≤ Fintype.card V) (B : Finset V)
    (hB : ∀ v ∈ B, EligibleVertex d x v ∧ ¬PartitionableVertex G x v) :
    2 * Fintype.card E + B.card + (degreeSlackVertices G x).card + 6 ≤ 4 * Fintype.card V := by
  have hempty : LaminarFamily (∅ : Finset (Finset V)) := by intro A hA; simp at hA
  obtain ⟨F, _, hlam, htight, hspan⟩ := exists_laminar_tight_span_extension G hx.1 hpositive
    d.tree.root ∅ hempty (by intro A hA; simp at hA)
  have hfull : ∀ A, edgeSum x (G.cut A) = 2 → incidence (G.cut A) ∈ tightCutSpan G F := by
    intro A hA
    by_cases hr : d.tree.root ∈ A
    · have hc := hspan Aᶜ (tight_shore_of_avoids G x d.tree.root Aᶜ (by simpa using hr)
        (by simpa only [cut_complement] using hA))
      simpa only [cut_complement] using hc
    · exact hspan A (tight_shore_of_avoids G x d.tree.root A hr hA)
  let L := augmentedLaminar G x d.tree.root (by omega) F hlam htight
  let S := nontightShores G x L
  have hdis : Disjoint F S := by
    apply Finset.disjoint_left.mpr
    intro A hF hS
    exact (Finset.mem_filter.mp hS).2 (htight A hF).2.2
  have hsub : F ∪ S ⊆ L.family := by
    intro A hA
    rcases Finset.mem_union.mp hA with hf | hs
    · exact Finset.mem_union_left _ hf
    · exact (Finset.mem_filter.mp hs).1
  have hcard := Finset.card_le_card hsub
  rw [Finset.card_union_of_disjoint hdis] at hcard
  have hslack : S.card = (degreeSlackVertices G x).card :=
    augmented_nontight_card G hx.1 d.tree.root hn F hlam htight
  have hrank := extreme_support_card_le_spanning_family G hx hpositive F hfull
  have hmarked := eligible_marked_count d hx.1 hn L rfl
    (augmented_internal_tight G x d.tree.root (by omega) F hlam htight) B hB
  change B.card ≤ 2 * L.deficiency + S.card at hmarked
  have hidentity := L.family_deficiency_identity
  omega

theorem eligible_half_rank_real {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x e)
    (hn : 3 ≤ Fintype.card V) (B : Finset V)
    (hB : ∀ v ∈ B, EligibleVertex d x v ∧ ¬PartitionableVertex G x v) :
    (Fintype.card E : ℝ) + (B.card : ℝ) / 2 + ((degreeSlackVertices G x).card : ℝ) / 2 ≤
      2 * (Fintype.card V : ℝ) - 3 := by
  have hn := eligible_half_rank d hx hpositive hn B hB
  have hr : 2 * (Fintype.card E : ℝ) + (B.card : ℝ) + ((degreeSlackVertices G x).card : ℝ) + 6 ≤
      4 * (Fintype.card V : ℝ) := by exact_mod_cast hn
  linarith

end TSP.Improvements20261105
