import TSP.Improvements20261105.ZeroLeafFamilyPayment
import TSP.Improvements20261105.GuardedZeroLeafFamilyCost
import TSP.Improvements20261105.ActualZeroLeafOwners

/-! The payment applies to actual nonroot zero-only leaf roots. Entry
geometry is derived from the graph, rather than supplied as a surrogate. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def guardedNormalizedHeadCost (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (R : E ⊕ d.StarIndex → ℝ) (a : GatedDrops d) (i : d.StarIndex) : ℝ :=
  let A := currentGuardedP d x z C owner rootStar
  jointHeadTerm (pqConnectorArm d x (415/2) (704/5) A R i)
    (pqDeficitArm d x (415/2) (704/5) A R i) (a.head i.1 : ℝ)-
    (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1

noncomputable def GatedDrops.zeroLeafOwnedError (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) : ℝ :=
  24*(∑ r ∈ a.zeroLeafRoots d P x, ∑ v ∈ a.originalComponentVertices d P r, degreeExcess G x v)+
  12*(∑ r ∈ a.zeroLeafRoots d P x, componentEntryError d x r)

theorem GatedDrops.zeroLeafOwnedError_bound (hs : G.IsSimple)
    (P : GatePlan d) (a : GatedDrops d) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) :
    a.zeroLeafOwnedError d P x ≤ 48*(edgeSum x Finset.univ-Fintype.card V) := by
  apply a.leaf_total_error_budget d hs P x hx hn (a.zeroLeafRoots d P x)
  · exact fun r hr => (a.zeroLeafRoot_spec d P x r hr).1
  · exact fun r hr => (a.zeroLeafRoot_spec d P x r hr).2.2.1

theorem GatedDrops.zero_guard_mass_partition (P : GatePlan d) (a : GatedDrops d)
    (x : E → ℝ) (m : d.StarIndex → ℝ) (L : Finset (FlowVertex d)) :
    (∑ i ∈ fixedZeroTerminalHeads d x, m i) =
      (∑ r ∈ L, a.zeroGuardMassInComponent d P x m r)+
      ∑ i ∈ fixedZeroTerminalHeads d x \ a.componentStarUnion d P L, m i := by
  rw [a.component_guard_mass_sum d P x m L, Finset.filter_mem_eq_inter, Finset.inter_comm]
  exact (Finset.sum_inter_add_sum_diff _ _ _).symm

theorem GatedDrops.actual_zero_leaf_cost (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hprojection : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eta : d.tree.Child → ℝ) (heta : ∀ c, eta c ≠ 0 → SurvivingPositive d x c)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hrootStar : d.centers rootStar = d.tree.root)
    (R : E ⊕ d.StarIndex → ℝ)
    (Q : E ⊕ d.StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G d.centers owner)
    (hrep : ∀ c, Q (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+eta c)
    (hbacks : ∀ e ∈ d.backEdges, Q (.inl e) = 1-x e/2)
    (m : d.StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x (d.treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Q i) :
    (∑ i ∈ a.componentStarUnion d P (a.zeroLeafRoots d P x),
      guardedNormalizedHeadCost d x z C owner rootStar R a i)+
      (∑ r ∈ a.zeroLeafRoots d P x, 24*(2-componentEntryCoverage d x r))-
      (704/5 : ℝ)*(∑ r ∈ a.zeroLeafRoots d P x, a.zeroGuardMassInComponent d P x m r) ≤
      a.zeroLeafOwnedError d P x := by
  have hp := a.guarded_zero_leaf_family_cost d hs P hP t ht f hf hb ha hcan x z hx hn hcap hprojection C
    (a.zeroLeafRoots d P x)
    (fun r hr => (a.zeroLeafRoot_spec d P x r hr).2.1)
    (fun r hr => (a.zeroLeafRoot_spec d P x r hr).1)
    (fun r hr => (a.zeroLeafRoot_spec d P x r hr).2.2.1)
    (fun r hr => (a.zeroLeafRoot_spec d P x r hr).2.2.2.1)
    (fun r hr => (a.zeroLeafRoot_spec d P x r hr).2.2.2.2)
    eta heta owner ho rootStar hrootStar R Q hQ hrep hbacks m hm0 hm hguarded
  exact hp

end TSP.Improvements20261105
