import TSP.Improvements20261105.EffectiveKOrigins
import TSP.Improvements20261105.ActiveUnaryComponents

/-! The protected-unmatched owner groups are concrete, disjoint pairs
of original heads. Their endpoints lie in the same canonical component. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def KUnmatchedOrigins (x z : E → ℝ) (P Q K : ℝ)
    (C : ProjectedCoverWitness d x z P Q) : Finset d.tree.Child :=
  Finset.univ.filter (fun s =>
    coveredPIncrease d x P Q C.cover s < protectedCoverIncrease d x z P Q K C s ∧
    childCount d s = 1 ∧
    unaryNext d s ∉ matchingEndpoints id (unaryNext d) C.matching ∧
    0 < survivingExcess d x (unaryNext d s))

theorem KUnmatchedOrigins_protected (x z : E → ℝ) (P Q K : ℝ)
    (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child)
    (hs : s ∈ KUnmatchedOrigins d x z P Q K C) : ProtectedHead d x z P Q C s := by
  have he := (Finset.mem_filter.mp hs).2.1
  by_contra h
  simp [protectedCoverIncrease, h] at he

theorem KUnmatchedOrigins_disjoint (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q K : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (C : ProjectedCoverWitness d x z P Q) :
    Disjoint (KUnmatchedOrigins d x z P Q K C)
      ((KUnmatchedOrigins d x z P Q K C).image (unaryNext d)) := by
  apply Finset.disjoint_left.mpr
  intro s hsL htL
  obtain ⟨u, hu, he⟩ := Finset.mem_image.mp htL
  have hb := (effective_K_origin_nonunary d hs x z hx hn hcap hm P Q K hP hQ hK hKQ C s
    (Finset.mem_filter.mp hsL).2.1).2
  have hc := (Finset.mem_filter.mp hu).2.2.1
  have hp := (unaryNext_spec d u hc).1
  rw [he] at hp
  rw [hp, hc] at hb
  omega

theorem KUnmatchedOrigins_receiver_injective (x z : E → ℝ) (P Q K : ℝ)
    (C : ProjectedCoverWitness d x z P Q) :
    Set.InjOn (unaryNext d) (KUnmatchedOrigins d x z P Q K C : Set d.tree.Child) := by
  intro s hs u hu he
  have hspar := (unaryNext_spec d s (Finset.mem_filter.mp hs).2.2.1).1
  have hupar := (unaryNext_spec d u (Finset.mem_filter.mp hu).2.2.1).1
  apply Subtype.ext
  rw [← hspar, ← hupar, he]

theorem KUnmatchedOrigins_no_matching_budget (x z : E → ℝ) (P Q K : ℝ)
    (C : ProjectedCoverWitness d x z P Q) :
    Disjoint (matchingEndpoints id (unaryNext d) (KUnmatchedOrigins d x z P Q K C))
      (matchingEndpoints id (unaryNext d) C.matching) := by
  apply Finset.disjoint_left.mpr
  intro s hs hm
  rcases Finset.mem_union.mp hs with h | h
  · have hsL : s ∈ KUnmatchedOrigins d x z P Q K C := by simpa using h
    exact (KUnmatchedOrigins_protected d x z P Q K C s hsL).2.2 hm
  · obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp h
    exact (Finset.mem_filter.mp hu).2.2.2.1 hm

theorem KUnmatchedOrigins_same_component (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (p q k : ℝ) (C : ProjectedCoverWitness d x z p q)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsL : s ∈ KUnmatchedOrigins d x z p q k C) :
    a.headComponent d P s = a.headComponent d P (unaryNext d s) := by
  have hp := KUnmatchedOrigins_protected d x z p q k C s hsL
  have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent s)
  have hactive : (d.backGroup s).Nonempty := by
    by_contra h
    have he := Finset.not_nonempty_iff_eq_empty.mp h
    have hpos := hp.2.1
    rw [survivingExcess, he] at hpos
    simp only [edgeSum, Finset.sum_empty] at hpos
    have hl := (lt_max_iff.mp hpos).resolve_right (lt_irrefl _)
    linarith
  have hc := (Finset.mem_filter.mp hsL).2.2.1
  exact canonical_active_unary_same_component d hs P hP t ht f hf hb a ha hcan s (unaryNext d s)
    hc (unaryNext_spec d s hc).1 hactive

end TSP.Improvements20261105
