import TSP.Improvements20261105.KOriginOwnership
import TSP.Improvements20261105.ActualZeroLeafCost

/-! Concrete pairs of actual stars for protected unmatched origins.
Both endpoint images are injective and disjoint, so a family of these
pairs spends each original head and its back-edge count at most once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def KUnmatchedStarPairs (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) : Finset (d.StarIndex × d.StarIndex) :=
  Finset.univ.filter (fun p => p.1.1 ∈ KUnmatchedOrigins d x z (415/2) (704/5) 60 C ∧
    unaryNext d p.1.1 = p.2.1)

noncomputable def pairStarHeads (J : Finset (d.StarIndex × d.StarIndex)) : Finset d.StarIndex :=
  J.image Prod.fst ∪ J.image Prod.snd

theorem KUnmatchedStarPairs_fst_injective (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    Set.InjOn Prod.fst (KUnmatchedStarPairs d x z C : Set (d.StarIndex × d.StarIndex)) := by
  intro p hp q hq he
  apply Prod.ext he
  apply Subtype.ext
  have hp' := (Finset.mem_filter.mp hp).2.2
  have hq' := (Finset.mem_filter.mp hq).2.2
  rw [← hp',← hq',he]

theorem KUnmatchedStarPairs_snd_injective (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    Set.InjOn Prod.snd (KUnmatchedStarPairs d x z C : Set (d.StarIndex × d.StarIndex)) := by
  intro p hp q hq he
  apply Prod.ext _ he
  apply Subtype.ext
  apply KUnmatchedOrigins_receiver_injective d x z (415/2) (704/5) 60 C
    (Finset.mem_filter.mp hp).2.1 (Finset.mem_filter.mp hq).2.1
  rw [(Finset.mem_filter.mp hp).2.2,(Finset.mem_filter.mp hq).2.2,he]

theorem KUnmatchedStarPairs_endpoints_disjoint (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    Disjoint ((KUnmatchedStarPairs d x z C).image Prod.fst)
      ((KUnmatchedStarPairs d x z C).image Prod.snd) := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hi
  obtain ⟨q,hq,he⟩ := Finset.mem_image.mp hj
  have hdis := KUnmatchedOrigins_disjoint d hs x z hx hn hcap hm (415/2) (704/5) 60
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
  apply Finset.disjoint_left.mp hdis (Finset.mem_filter.mp hp).2.1
  exact Finset.mem_image.mpr ⟨q.1.1,(Finset.mem_filter.mp hq).2.1,
    (Finset.mem_filter.mp hq).2.2.trans (congrArg Subtype.val he)⟩

theorem KUnmatchedStarPairs_ne (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (p : d.StarIndex × d.StarIndex) (hp : p ∈ KUnmatchedStarPairs d x z C) : p.1 ≠ p.2 := by
  intro he
  exact Finset.disjoint_left.mp (KUnmatchedStarPairs_endpoints_disjoint d hs x z hx hn hcap hm C)
    (Finset.mem_image.mpr ⟨p,hp,rfl⟩) (Finset.mem_image.mpr ⟨p,hp,he.symm⟩)

theorem KStarPair_family_sum (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (J : Finset (d.StarIndex × d.StarIndex)) (hJ : J ⊆ KUnmatchedStarPairs d x z C)
    (g : d.StarIndex → ℝ) :
    (∑ i ∈ pairStarHeads d J, g i) = ∑ p ∈ J, (g p.1+g p.2) := by
  have hdis : Disjoint (J.image Prod.fst) (J.image Prod.snd) :=
    (KUnmatchedStarPairs_endpoints_disjoint d hs x z hx hn hcap hm C).mono
      (Finset.image_subset_image hJ) (Finset.image_subset_image hJ)
  rw [pairStarHeads,Finset.sum_union hdis]
  rw [Finset.sum_image (fun p hp q hq he => KUnmatchedStarPairs_fst_injective d x z C (hJ hp) (hJ hq) he)]
  rw [Finset.sum_image (fun p hp q hq he => KUnmatchedStarPairs_snd_injective d x z C (hJ hp) (hJ hq) he)]
  exact (Finset.sum_add_distrib).symm

end TSP.Improvements20261105
