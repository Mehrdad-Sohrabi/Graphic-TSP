import TSP.Improvements20261105.FixedGateSelection
import TSP.Improvements20261105.GatedResourceFormula

/-! The fixed minimum-mass child leaves at least half of a branching
head's actual own-back mass outside its receiver subtree. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem fixedGatePlan_outside_shape (x : E → ℝ) (s : d.tree.Child)
    (hs : (fixedGatePlan d x).kind s = .outsideGate) :
    2 ≤ (Chapter11.childSet d s).card ∧ headlessChildren d s = ∅ := by
  have h1 : ¬(Chapter11.childSet d s).card ≤ 1 := by
    simp only [fixedGatePlan, fixedBypassKind] at hs
    split_ifs at hs <;> simp_all
  have h2 : ¬(headlessChildren d s).Nonempty := by
    simp only [fixedGatePlan, fixedBypassKind] at hs
    split_ifs at hs <;> simp_all
  exact ⟨by omega, Finset.not_nonempty_iff_eq_empty.mp h2⟩

theorem headedChildren_eq_all (s : d.tree.Child) (h : headlessChildren d s = ∅) :
    headedChildren d s = Chapter11.childSet d s := by
  apply Finset.filter_eq_self.mpr
  intro u hu
  by_contra hn
  have hm : u ∈ headlessChildren d s := Finset.mem_filter.mpr ⟨hu, hn⟩
  rw [h] at hm
  exact Finset.not_mem_empty _ hm

theorem two_child_own_mass (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (s r u : d.tree.Child) (hr : d.tree.parent r = (s : V)) (hu : d.tree.parent u = (s : V))
    (hne : r ≠ u) : childOwnMass d x s r + childOwnMass d x s u ≤ edgeSum x (d.backGroup s) := by
  let A := (d.backGroup s).filter (fun e => d.tree.Ancestor r (d.lower e))
  let B := (d.backGroup s).filter (fun e => d.tree.Ancestor u (d.lower e))
  have hd : Disjoint A B := by
    apply Finset.disjoint_left.mpr
    intro e heA heB
    have hr' := (Finset.mem_filter.mp heA).2
    have hu' := (Finset.mem_filter.mp heB).2
    exact hne (d.tree.child_below_unique r u ⟨hr, hr'⟩ ⟨hu, hu'⟩)
  have hsub : A ∪ B ⊆ d.backGroup s := Finset.union_subset (Finset.filter_subset _ _) (Finset.filter_subset _ _)
  have hh := Finset.sum_le_sum_of_subset_of_nonneg hsub (fun e _ _ => hx e)
  rw [Finset.sum_union hd] at hh
  exact hh

theorem fixedGatePlan_receiver_half_mass (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (s : d.tree.Child) (hs : (fixedGatePlan d x).kind s = .outsideGate) :
    2 * childOwnMass d x s ((fixedGatePlan d x).receiver s) ≤ edgeSum x (d.backGroup s) := by
  have hshape := fixedGatePlan_outside_shape d x s hs
  have hall := headedChildren_eq_all d s hshape.2
  have hmin := minimumHeadedChild_spec d x s (fixedGatePlan_use_headed d x s (Or.inr hs))
  rw [hall] at hmin
  let r := (fixedGatePlan d x).receiver s
  have hr : r ∈ Chapter11.childSet d s := hmin.1
  have hex : ∃ u ∈ Chapter11.childSet d s, u ≠ r := by
    by_contra hn
    have hc : (Chapter11.childSet d s).card ≤ 1 := Finset.card_le_one.mpr (by
      intro u hu v hv
      have heU : u = r := by by_contra he; exact hn ⟨u, hu, he⟩
      have heV : v = r := by by_contra he; exact hn ⟨v, hv, he⟩
      exact heU.trans heV.symm)
    omega
  obtain ⟨u, hu, hne⟩ := hex
  have hmass := two_child_own_mass d x hx s r u
    (Finset.mem_filter.mp hr).2 (Finset.mem_filter.mp hu).2 hne.symm
  have hle := hmin.2 u hu
  change childOwnMass d x s r ≤ childOwnMass d x s u at hle
  linarith

theorem outsideBackMass_difference (P : GatePlan d) (x : E → ℝ) (s : d.tree.Child)
    (hs : P.kind s = .outsideGate) :
    outsideBackMass d P (fun b => x b.1) s = edgeSum x (d.backGroup s) - childOwnMass d x s (P.receiver s) := by
  let A := (d.backGroup s).filter (fun e => ¬d.tree.Ancestor (P.receiver s) (d.lower e))
  have he (b : BackEdge d) : d.anchor b.1 = s ∧ P.OutsideBack d b ↔ b.1 ∈ A := by
    constructor
    · rintro ⟨ha, hb⟩
      refine Finset.mem_filter.mpr ⟨(back_anchor_iff_group d b s).mp ha, ?_⟩
      simpa only [ha] using hb.2
    · intro hb
      have hh := Finset.mem_filter.mp hb
      have ha := (back_anchor_iff_group d b s).mpr hh.1
      exact ⟨ha, by simpa only [GatePlan.OutsideBack, ha, hs, true_and] using hh.2⟩
  unfold outsideBackMass
  simp_rw [he]
  rw [original_back_subset_sum d x A ((Finset.filter_subset _ _).trans (fun e he =>
    ((d.mem_backGroup_iff s e).mp he).1))]
  have hsplit : edgeSum x A + childOwnMass d x s (P.receiver s) = edgeSum x (d.backGroup s) := by
    simp only [A, childOwnMass, edgeSum, Finset.sum_filter, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro e _
    split_ifs <;> simp_all
  linarith

theorem fixedGatePlan_outside_half_mass (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (s : d.tree.Child) (hs : (fixedGatePlan d x).kind s = .outsideGate) :
    edgeSum x (d.backGroup s) / 2 ≤ outsideBackMass d (fixedGatePlan d x) (fun b => x b.1) s := by
  have hh := fixedGatePlan_receiver_half_mass d x hx s hs
  rw [outsideBackMass_difference d (fixedGatePlan d x) x s hs]
  linarith

end TSP.Improvements20261105
