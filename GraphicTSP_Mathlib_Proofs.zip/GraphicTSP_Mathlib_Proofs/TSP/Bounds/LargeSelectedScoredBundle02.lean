import TSP.Improvements20261105.LargeSelectedGreedyScoredSourceEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_60
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (12024783392/107316987:ℝ)*hR0 + (23199248648/107316987:ℝ)*hRo + (2659757868272/21212991097:ℝ)*hchoice + (1329878934136/63638973291:ℝ)*hem + (3479138944/178861645:ℝ)*hgap + (434892368/536584935:ℝ)*hC + (1/1:ℝ)*hI + (101692567/536584935:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (1479139394592/12913810769:ℝ)*hR0 + (2848874576520/12913810769:ℝ)*hRo + (987570769645008/7657889786017:ℝ)*hchoice + (164595128274168/7657889786017:ℝ)*hem + (66347412096/3398371255:ℝ)*hgap + (2764475504/3398371255:ℝ)*hC + (1/1:ℝ)*hI + (633895751/3398371255:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_61
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (5243/16000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (5243/16000 : ℝ) (27617/52430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5208/43:ℝ)*hzu + (1/1:ℝ)*hH0 + (1560/43:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (2327432/15523:ℝ)*hzu + (1/1:ℝ)*hH0 + (674996/15523:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource

theorem large_selected_scored_t6_r4_cap_cell_62
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (72133/224000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (72133/224000 : ℝ) (362527/721330 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53928/2185:ℝ)*hMl + (26964/2185:ℝ)*hR0 + (53928/2185:ℝ)*hRo + (53928/2185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (53928/2185:ℝ)*hmass
  · linear_combination (66232/2185:ℝ)*hMl + (33116/2185:ℝ)*hR0 + (66232/2185:ℝ)*hRo + (66232/2185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (66232/2185:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_63
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (72133/224000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (72133/224000 : ℝ) (362527/721330 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1384/37:ℝ)*hMl + (2272/37:ℝ)*hzl + (692/37:ℝ)*hR0 + (1384/37:ℝ)*hRo + (1384/37:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1384/37:ℝ)*hmass
  · linear_combination (591500/13357:ℝ)*hMl + (912068/13357:ℝ)*hzl + (295750/13357:ℝ)*hR0 + (591500/13357:ℝ)*hRo + (591500/13357:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_64
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (72133/224000 : ℝ) ≤ M) (hMu : M ≤ (5243/16000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (5243/16000 : ℝ) (27617/52430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1384/37:ℝ)*hMl + (2272/37:ℝ)*hzl + (692/37:ℝ)*hR0 + (1384/37:ℝ)*hRo + (1384/37:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1384/37:ℝ)*hmass
  · linear_combination (591500/13357:ℝ)*hMl + (912068/13357:ℝ)*hzl + (295750/13357:ℝ)*hR0 + (591500/13357:ℝ)*hRo + (591500/13357:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_65
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (5243/16000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_66
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (72133/224000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (72133/224000 : ℝ) (362527/721330 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9243260033885288/74438562034253:ℝ)*hMl + (112651/458:ℝ)*hzl + (6437152866720820/74438562034253:ℝ)*hR0 + (165519313718008/896850144991:ℝ)*hRo + (9243260033885288/74438562034253:ℝ)*hchoice + (27463519091712/1625296114285:ℝ)*hgap + (1144313295488/1625296114285:ℝ)*hC + (1/1:ℝ)*hI + (480982818797/1625296114285:ℝ)*hsource + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (3513431949905928492/26872320894365333:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (2412119723722885782/26872320894365333:ℝ)*hR0 + (61880364754289316/323762902341751:ℝ)*hRo + (3513431949905928492/26872320894365333:ℝ)*hchoice + (27463519091712/1625296114285:ℝ)*hgap + (1144313295488/1625296114285:ℝ)*hC + (1/1:ℝ)*hI + (480982818797/1625296114285:ℝ)*hsource + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_67
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (72133/224000 : ℝ) ≤ M) (hMu : M ≤ (5243/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (5243/16000 : ℝ) (27617/52430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (674068111191448/5422964811763:ℝ)*hMl + (112651/458:ℝ)*hzl + (467251903548620/5422964811763:ℝ)*hR0 + (999032823579544/5422964811763:ℝ)*hRo + (674068111191448/5422964811763:ℝ)*hchoice + (1996190794752/118405345235:ℝ)*hgap + (83174616448/118405345235:ℝ)*hC + (1/1:ℝ)*hI + (35230728787/118405345235:ℝ)*hsource + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (256205270747557332/1957690297046443:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (175111278484774122/1957690297046443:ℝ)*hR0 + (373517531919659988/1957690297046443:ℝ)*hRo + (256205270747557332/1957690297046443:ℝ)*hchoice + (1996190794752/118405345235:ℝ)*hgap + (83174616448/118405345235:ℝ)*hC + (1/1:ℝ)*hI + (35230728787/118405345235:ℝ)*hsource + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_68
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (5243/16000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (5243/16000 : ℝ) (27617/52430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (175058044228328/1397183073773:ℝ)*hMl + (29141/118:ℝ)*hzl + (121078598660980/1397183073773:ℝ)*hR0 + (258782577114344/1397183073773:ℝ)*hRo + (175058044228328/1397183073773:ℝ)*hchoice + (1996190794752/118405345235:ℝ)*hgap + (83174616448/118405345235:ℝ)*hC + (1/1:ℝ)*hI + (35230728787/118405345235:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (66365712420505452/504383089632053:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (45294253343653302/504383089632053:ℝ)*hR0 + (96590268792357228/504383089632053:ℝ)*hRo + (66365712420505452/504383089632053:ℝ)*hchoice + (1996190794752/118405345235:ℝ)*hgap + (83174616448/118405345235:ℝ)*hC + (1/1:ℝ)*hI + (35230728787/118405345235:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_69
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (5243/16000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (491217030113512/3944369901277:ℝ)*hMl + (112651/458:ℝ)*hzl + (337513710780020/3944369901277:ℝ)*hR0 + (724158625657576/3944369901277:ℝ)*hRo + (491217030113512/3944369901277:ℝ)*hchoice + (1445648759808/86121613565:ℝ)*hgap + (60235364992/86121613565:ℝ)*hC + (1/1:ℝ)*hI + (25886248573/86121613565:ℝ)*hsource + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (186687873579277548/1423917534360997:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (126521712445737078/1423917534360997:ℝ)*hR0 + (270779789570684652/1423917534360997:ℝ)*hRo + (186687873579277548/1423917534360997:ℝ)*hchoice + (1445648759808/86121613565:ℝ)*hgap + (60235364992/86121613565:ℝ)*hC + (1/1:ℝ)*hI + (25886248573/86121613565:ℝ)*hsource + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_70
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (5243/16000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (127568994209432/1016235040067:ℝ)*hMl + (29141/118:ℝ)*hzl + (87463128317260/1016235040067:ℝ)*hR0 + (187584514458776/1016235040067:ℝ)*hRo + (127568994209432/1016235040067:ℝ)*hchoice + (1445648759808/86121613565:ℝ)*hgap + (60235364992/86121613565:ℝ)*hC + (1/1:ℝ)*hI + (25886248573/86121613565:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (48357916953385428/366860849464187:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (32726944344421098/366860849464187:ℝ)*hR0 + (70023519763398612/366860849464187:ℝ)*hRo + (48357916953385428/366860849464187:ℝ)*hchoice + (1445648759808/86121613565:ℝ)*hgap + (60235364992/86121613565:ℝ)*hC + (1/1:ℝ)*hI + (25886248573/86121613565:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_71
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_72
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (39239/112000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (39239/112000 : ℝ) (241541/392390 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5105863823930104/40926644343199:ℝ)*hMl + (112651/458:ℝ)*hzl + (204677111221180/2407449667247:ℝ)*hR0 + (7489942748094712/40926644343199:ℝ)*hRo + (5105863823930104/40926644343199:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1940320576352649636/14774518607894839:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (76744429383607218/869089329876167:ℝ)*hR0 + (2800973067976073124/14774518607894839:ℝ)*hRo + (1940320576352649636/14774518607894839:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_73
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (39239/112000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (39239/112000 : ℝ) (241541/392390 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1325973574590344/10544419284929:ℝ)*hMl + (29141/118:ℝ)*hzl + (53041904454020/620259957937:ℝ)*hR0 + (1940212249375112/10544419284929:ℝ)*hRo + (1325973574590344/10544419284929:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (502598352124170396/3806535361859369:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (19851712557814638/223913844815257:ℝ)*hR0 + (724338513721471644/3806535361859369:ℝ)*hRo + (502598352124170396/3806535361859369:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_74
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (39239/112000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (344064301771592/2731622042297:ℝ)*hMl + (29141/118:ℝ)*hzl + (232198367066020/2731622042297:ℝ)*hR0 + (501144838540616/2731622042297:ℝ)*hRo + (344064301771592/2731622042297:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (130404383678621628/986115557269217:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (86922195880371678/986115557269217:ℝ)*hR0 + (187110457452239292/986115557269217:ℝ)*hRo + (130404383678621628/986115557269217:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_75
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24437990155608/189467549843:ℝ)*hMl + (5509/22:ℝ)*hzl + (16633655134380/189467549843:ℝ)*hR0 + (35627324439384/189467549843:ℝ)*hRo + (24437990155608/189467549843:ℝ)*hchoice + (1445648759808/86121613565:ℝ)*hgap + (60235364992/86121613565:ℝ)*hC + (1/1:ℝ)*hI + (25886248573/86121613565:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (9183618531274932/68397785493323:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (6185501546061402/68397785493323:ℝ)*hR0 + (13222968207718068/68397785493323:ℝ)*hRo + (9183618531274932/68397785493323:ℝ)*hchoice + (1445648759808/86121613565:ℝ)*hgap + (60235364992/86121613565:ℝ)*hC + (1/1:ℝ)*hI + (25886248573/86121613565:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_76
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (65905362029448/509285465513:ℝ)*hMl + (5509/22:ℝ)*hzl + (44170111150020/509285465513:ℝ)*hR0 + (95191563799944/509285465513:ℝ)*hRo + (65905362029448/509285465513:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (24763552360829532/183852053050193:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (16431268459256622/183852053050193:ℝ)*hR0 + (35335871199978588/183852053050193:ℝ)*hRo + (24763552360829532/183852053050193:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_77
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (21523/56000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (21523/56000 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_78
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (21523/56000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (21523/56000 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_79
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (21523/56000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_80
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2697361975368/20732808833:ℝ)*hMl + (5509/22:ℝ)*hzl + (76618102140/901426471:ℝ)*hR0 + (3837073900104/20732808833:ℝ)*hRo + (2697361975368/20732808833:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1013305872361212/7484543988713:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (28519095725874/325414956031:ℝ)*hR0 + (1424741877190908/7484543988713:ℝ)*hRo + (1013305872361212/7484543988713:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_81
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6227098912336/46298678683:ℝ)*hMl + (511/2:ℝ)*hzl + (4133315832104/46298678683:ℝ)*hR0 + (8889480891472/46298678683:ℝ)*hRo + (6227098912336/46298678683:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (2311689689221104/16713823004563:ℝ)*hMl + (187223/722:ℝ)*hzl + (1523980506323448/16713823004563:ℝ)*hR0 + (3272809583689200/16713823004563:ℝ)*hRo + (2311689689221104/16713823004563:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_82
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_83
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (5776369856/50701605:ℝ)*hR0 + (11289993008/50701605:ℝ)*hRo + (1364520811424/10022017255:ℝ)*hchoice + (682260405712/30066051765:ℝ)*hem + (322682624/16900535:ℝ)*hgap + (40335328/50701605:ℝ)*hC + (1/1:ℝ)*hI + (10366277/50701605:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (699179431728/6101093135:ℝ)*hR0 + (1365860001324/6101093135:ℝ)*hRo + (496105281620856/3617948229055:ℝ)*hchoice + (82684213603476/3617948229055:ℝ)*hem + (1227407808/64222033:ℝ)*hgap + (51141992/64222033:ℝ)*hC + (1/1:ℝ)*hI + (13080041/64222033:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_84
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (37130459094/2243608747:ℝ)*hR0 + (76683241548/2243608747:ℝ)*hRo + (67852828908/2243608747:ℝ)*hchoice + (2641345344/2243608747:ℝ)*hgap + (1/1:ℝ)*hH0 + (22617609636/2243608747:ℝ)*hgood + (110056056/2243608747:ℝ)*hC + (1/1:ℝ)*hI + (2133552691/2243608747:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (18354823612134/809942757667:ℝ)*hR0 + (37907082405228/809942757667:ℝ)*hRo + (33541915090188/809942757667:ℝ)*hchoice + (68721318336/42628566193:ℝ)*hgap + (1/1:ℝ)*hH0 + (11180638363396/809942757667:ℝ)*hgood + (2863388264/42628566193:ℝ)*hC + (1/1:ℝ)*hI + (39765177929/42628566193:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (286853395709/648720059:ℝ)*hMu + (768/13:ℝ)*hzl + (293960216621/2594880236:ℝ)*hR0 + (6307/26:ℝ)*hRo + (202840438781/1297440118:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (5357124503203/12325681121:ℝ)*hMu + (312692/4693:ℝ)*hzl + (5771424146335/49302724484:ℝ)*hR0 + (2347715/9386:ℝ)*hRo + (4040148367375/24651362242:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hMl + (48/1:ℝ)*hzl + (12/1:ℝ)*hR0 + (24/1:ℝ)*hRo + (24/1:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (159020/4693:ℝ)*hMl + (271652/4693:ℝ)*hzl + (79510/4693:ℝ)*hR0 + (159020/4693:ℝ)*hRo + (159020/4693:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (159020/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (17485474343346/717945291271:ℝ)*hR0 + (35979539764932/717945291271:ℝ)*hRo + (31668296219172/717945291271:ℝ)*hchoice + (96055411392/55226560867:ℝ)*hgap + (1/1:ℝ)*hH0 + (10556098739724/717945291271:ℝ)*hgood + (4002308808/55226560867:ℝ)*hC + (1/1:ℝ)*hI + (51224252059/55226560867:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (7671368414758335/259178250148831:ℝ)*hR0 + (15785234046869070/259178250148831:ℝ)*hRo + (13893770485981470/259178250148831:ℝ)*hchoice + (116737410720/55226560867:ℝ)*hgap + (1/1:ℝ)*hH0 + (4631256828660490/259178250148831:ℝ)*hgood + (4864058780/55226560867:ℝ)*hC + (1/1:ℝ)*hI + (50362502087/55226560867:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (456/13:ℝ)*hMl + (768/13:ℝ)*hzl + (228/13:ℝ)*hR0 + (456/13:ℝ)*hRo + (456/13:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (200060/4693:ℝ)*hMl + (312692/4693:ℝ)*hzl + (100030/4693:ℝ)*hR0 + (200060/4693:ℝ)*hRo + (200060/4693:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (238422894203/548916973:ℝ)*hMu + (736/11:ℝ)*hzl + (257333987627/2195667892:ℝ)*hR0 + (5509/22:ℝ)*hRo + (180232637147/1097833946:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (4474912169621/10429422487:ℝ)*hMu + (286684/3971:ℝ)*hzl + (4999591405385/41717689948:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (3534665746265/20858844974:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1711762909/249507715:ℝ)*hMu + (511/2:ℝ)*hzl + (23902087313/199606172:ℝ)*hR0 + (511/2:ℝ)*hRo + (16892873633/99803086:ℝ)*hchoice + (24/1:ℝ)*hgap + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (14453883911/4740646585:ℝ)*hMu + (187223/722:ℝ)*hzl + (461367503491/3792517268:ℝ)*hR0 + (187223/722:ℝ)*hRo + (328192443571/1896258634:ℝ)*hchoice + (24/1:ℝ)*hgap + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3744/59:ℝ)*hzl + (89267947963398/3258367091153:ℝ)*hR0 + (183685018799916/3258367091153:ℝ)*hRo + (161674985961036/3258367091153:ℝ)*hchoice + (6375045987648/3258367091153:ℝ)*hgap + (1/1:ℝ)*hH0 + (53891661987012/3258367091153:ℝ)*hgood + (265626916152/3258367091153:ℝ)*hC + (1/1:ℝ)*hI + (2992740175001/3258367091153:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (37358329459974285/1176270519906233:ℝ)*hR0 + (76871549147768970/1176270519906233:ℝ)*hRo + (67660426040549370/1176270519906233:ℝ)*hchoice + (7390401214560/3258367091153:ℝ)*hgap + (1/1:ℝ)*hH0 + (22553475346849790/1176270519906233:ℝ)*hgood + (307933383940/3258367091153:ℝ)*hC + (1/1:ℝ)*hI + (2950433707213/3258367091153:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_8
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (67964434230150/607492169537:ℝ)*hR0 + (147249860949036/607492169537:ℝ)*hRo + (98858043044172/607492169537:ℝ)*hchoice + (70081691115072/3037460847685:ℝ)*hgap + (32952681014724/607492169537:ℝ)*hgood + (2920070463128/3037460847685:ℝ)*hC + (1/1:ℝ)*hI + (117390384557/3037460847685:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (25339952720939733/219304673202857:ℝ)*hR0 + (54813205461782682/219304673202857:ℝ)*hRo + (37145328541244298/219304673202857:ℝ)*hchoice + (70877729855712/3037460847685:ℝ)*hgap + (12381776180414766/219304673202857:ℝ)*hgood + (2953238743988/3037460847685:ℝ)*hC + (1/1:ℝ)*hI + (84222103697/3037460847685:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_9
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_10
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2697361975368/20732808833:ℝ)*hMl + (5509/22:ℝ)*hzl + (76618102140/901426471:ℝ)*hR0 + (3837073900104/20732808833:ℝ)*hRo + (2697361975368/20732808833:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1013305872361212/7484543988713:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (28519095725874/325414956031:ℝ)*hR0 + (1424741877190908/7484543988713:ℝ)*hRo + (1013305872361212/7484543988713:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_11
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_12
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1343795072568/11218043735:ℝ)*hR0 + (2929822481136/11218043735:ℝ)*hRo + (2046781217136/11218043735:ℝ)*hchoice + (52826906880/2243608747:ℝ)*hgap + (682260405712/11218043735:ℝ)*hgood + (2201121120/2243608747:ℝ)*hC + (1/1:ℝ)*hI + (42487627/2243608747:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (487993820186682/4049713788335:ℝ)*hR0 + (1063621647450324/4049713788335:ℝ)*hRo + (744157922431284/4049713788335:ℝ)*hchoice + (5029353231936/213142830965:ℝ)*hgap + (248052640810428/4049713788335:ℝ)*hgood + (209556384664/213142830965:ℝ)*hC + (1/1:ℝ)*hI + (3586446301/213142830965:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_13
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

theorem large_selected_scored_t6_r5_all_cell_14
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (7589/28000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (7589/28000 : ℝ) (18191/75890 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (176525883/144191:ℝ)*hMu + (48/1:ℝ)*hzl + (611184/11267:ℝ)*hqM + (4064621/22534:ℝ)*hR0 + (463/2:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (3329706977/2739629:ℝ)*hMu + (20528/361:ℝ)*hzl + (9714896/214073:ℝ)*hqM + (81022999/428146:ℝ)*hR0 + (173543/722:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_15
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (253/896 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (253/896 : ℝ) (155/506 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5921379/4807:ℝ)*hMu + (48/1:ℝ)*hzl + (611184/11267:ℝ)*hqM + (4064621/22534:ℝ)*hR0 + (463/2:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (111696601/91333:ℝ)*hMu + (20528/361:ℝ)*hzl + (9714896/214073:ℝ)*hqM + (81022999/428146:ℝ)*hR0 + (173543/722:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_16
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (253/896 : ℝ) ≤ M) (hMu : M ≤ (9217/32000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (9217/32000 : ℝ) (31123/92170 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/1280 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (146193758/1225861:ℝ)*hR0 + (463/2:ℝ)*hRo + (88859485311/726935573:ℝ)*hchoice + (29619828437/1453871146:ℝ)*hem + (216344799/1225861:ℝ)*hg0 + (245765463/1225861:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (2895659002/23291359:ℝ)*hR0 + (173543/722:ℝ)*hRo + (1793271296109/13811775887:ℝ)*hchoice + (597757098703/27623551774:ℝ)*hem + (4081056781/23291359:ℝ)*hg0 + (4640049397/23291359:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_17
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (9217/32000 : ℝ) ≤ M) (hMu : M ≤ (130307/448000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (130307/448000 : ℝ) (459833/1303070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (419602156927/2936337938:ℝ)*hMl + (48/1:ℝ)*hzl + (639694980367/5872675876:ℝ)*hR0 + (463/2:ℝ)*hRo + (419602156927/2936337938:ℝ)*hchoice + (578885263903/2936337938:ℝ)*hg0 + (649357374415/2936337938:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (8466982108013/55790420822:ℝ)*hMl + (20528/361:ℝ)*hzl + (12648745753373/111580841644:ℝ)*hR0 + (173543/722:ℝ)*hRo + (8466982108013/55790420822:ℝ)*hchoice + (578885263903/2936337938:ℝ)*hg0 + (649357374415/2936337938:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_18
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (130307/448000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53065839467/370616698:ℝ)*hMl + (48/1:ℝ)*hzl + (80635803707/741233396:ℝ)*hR0 + (463/2:ℝ)*hRo + (53065839467/370616698:ℝ)*hchoice + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1070670604273/7041717262:ℝ)*hMl + (20528/361:ℝ)*hzl + (1594499924833/14083434524:ℝ)*hR0 + (173543/722:ℝ)*hRo + (1070670604273/7041717262:ℝ)*hchoice + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_19
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (9217/32000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (13/2560 : ℝ) ≤ z) (hzu : z ≤ (13/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/1280 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53065839467/370616698:ℝ)*hMl + (48/1:ℝ)*hzl + (80635803707/741233396:ℝ)*hR0 + (463/2:ℝ)*hRo + (53065839467/370616698:ℝ)*hchoice + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1070670604273/7041717262:ℝ)*hMl + (20528/361:ℝ)*hzl + (1594499924833/14083434524:ℝ)*hR0 + (173543/722:ℝ)*hRo + (1070670604273/7041717262:ℝ)*hchoice + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r5_all_cell_20
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (253/896 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (13/1280 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (260335778/2187451:ℝ)*hR0 + (463/2:ℝ)*hRo + (159197518401/1297158443:ℝ)*hchoice + (53065839467/2594316886:ℝ)*hem + (387120609/2187451:ℝ)*hg0 + (439619433/2187451:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (5156901382/41561569:ℝ)*hR0 + (173543/722:ℝ)*hRo + (3212011812819/24646010417:ℝ)*hchoice + (1070670604273/49292020834:ℝ)*hem + (7302661171/41561569:ℝ)*hg0 + (8300138827/41561569:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_21
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (13/640 : ℝ) ≤ z) (hzu : z ≤ (13/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/320 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (260335778/2187451:ℝ)*hR0 + (463/2:ℝ)*hRo + (159197518401/1297158443:ℝ)*hchoice + (53065839467/2594316886:ℝ)*hem + (387120609/2187451:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (5156901382/41561569:ℝ)*hR0 + (173543/722:ℝ)*hRo + (3212011812819/24646010417:ℝ)*hchoice + (1070670604273/49292020834:ℝ)*hem + (7302661171/41561569:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_22
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (26569/89600 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (26569/89600 : ℝ) (101611/265690 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (85890254909/598705846:ℝ)*hMl + (48/1:ℝ)*hzl + (130095575789/1197411692:ℝ)*hR0 + (463/2:ℝ)*hRo + (85890254909/598705846:ℝ)*hchoice + (118367350301/598705846:ℝ)*hg0 + (132736290605/598705846:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1732749512071/11375411074:ℝ)*hMl + (20528/361:ℝ)*hzl + (2572650608791/22750822148:ℝ)*hR0 + (173543/722:ℝ)*hRo + (1732749512071/11375411074:ℝ)*hchoice + (118367350301/598705846:ℝ)*hg0 + (132736290605/598705846:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_23
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (26569/89600 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (11430942983/79529602:ℝ)*hMl + (48/1:ℝ)*hzl + (327934664117/3022124876:ℝ)*hR0 + (463/2:ℝ)*hRo + (11430942983/79529602:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (4381065143263/28710186322:ℝ)*hMl + (20528/361:ℝ)*hzl + (6485253344623/57420372644:ℝ)*hR0 + (173543/722:ℝ)*hRo + (4381065143263/28710186322:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_24
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (13/2560 : ℝ) ≤ z) (hzu : z ≤ (13/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/1280 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (11430942983/79529602:ℝ)*hMl + (48/1:ℝ)*hzl + (327934664117/3022124876:ℝ)*hR0 + (463/2:ℝ)*hRo + (11430942983/79529602:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (4381065143263/28710186322:ℝ)*hMl + (20528/361:ℝ)*hzl + (6485253344623/57420372644:ℝ)*hR0 + (173543/722:ℝ)*hRo + (4381065143263/28710186322:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_25
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (67057/224000 : ℝ) ≤ M) (hMu : M ≤ (135383/448000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (135383/448000 : ℝ) (556277/1353830 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (439300392163/3050720522:ℝ)*hMl + (48/1:ℝ)*hzl + (34803198817/321128476:ℝ)*hR0 + (463/2:ℝ)*hRo + (439300392163/3050720522:ℝ)*hchoice + (31830959953/160564238:ℝ)*hg0 + (35684501665/160564238:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (8860513012697/57963689918:ℝ)*hMl + (20528/361:ℝ)*hzl + (13077760334537/115927379836:ℝ)*hR0 + (173543/722:ℝ)*hRo + (8860513012697/57963689918:ℝ)*hchoice + (31830959953/160564238:ℝ)*hg0 + (35684501665/160564238:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_26
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (135383/448000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/2560 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (111056237743/769829042:ℝ)*hMl + (48/1:ℝ)*hzl + (166663056703/1539658084:ℝ)*hR0 + (463/2:ℝ)*hRo + (111056237743/769829042:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2239723934717/14626751798:ℝ)*hMl + (20528/361:ℝ)*hzl + (3296253494957/29253503596:ℝ)*hR0 + (173543/722:ℝ)*hRo + (2239723934717/14626751798:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_27
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (67057/224000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (13/2560 : ℝ) ≤ z) (hzu : z ≤ (13/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/1280 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (111056237743/769829042:ℝ)*hMl + (48/1:ℝ)*hzl + (166663056703/1539658084:ℝ)*hR0 + (463/2:ℝ)*hRo + (111056237743/769829042:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2239723934717/14626751798:ℝ)*hMl + (20528/361:ℝ)*hzl + (3296253494957/29253503596:ℝ)*hR0 + (173543/722:ℝ)*hRo + (2239723934717/14626751798:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_28
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (13/1280 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (11430942983/79529602:ℝ)*hMl + (48/1:ℝ)*hzl + (327934664117/3022124876:ℝ)*hR0 + (463/2:ℝ)*hRo + (11430942983/79529602:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (4381065143263/28710186322:ℝ)*hMl + (20528/361:ℝ)*hzl + (6485253344623/57420372644:ℝ)*hR0 + (173543/722:ℝ)*hRo + (4381065143263/28710186322:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_scored_t6_r5_all_cell_29
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (67057/224000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (13/1280 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (111056237743/769829042:ℝ)*hMl + (48/1:ℝ)*hzl + (166663056703/1539658084:ℝ)*hR0 + (463/2:ℝ)*hRo + (111056237743/769829042:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2239723934717/14626751798:ℝ)*hMl + (20528/361:ℝ)*hzl + (3296253494957/29253503596:ℝ)*hR0 + (173543/722:ℝ)*hRo + (2239723934717/14626751798:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

end TSP.Improvements20261105
