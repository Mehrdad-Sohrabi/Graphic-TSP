import TSP.Improvements20261105.ExtendedActualResidualBoundary
import TSP.Improvements20261105.ExtendedResidualIncomingDebt
import TSP.Improvements20261105.RemainingMatchingPartition
import TSP.Improvements20261105.MatchingResidualIncomingBudget

/-! The remaining unmatched residual boundary is charged exactly once to
its actual matching sources. The remaining ledger is a pair sum and root sum. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem extended_internal_matching_incoming_sum
    (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
 :
    (∑ p ∈ a.internalMatchingPairs d P x z C,
      extendedResidualIncomingDebt d x z a.head (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C) p.1)=
      ∑ p ∈ extendedResidualOutside d x z a.head (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C), actualCouponResidual d x z p.1 := by
  have hh := extendedResidualIncomingDebt_sum d x z a.head (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C)
    ((a.internalMatchingPairs d P x z C).image Prod.fst)
    (fun p hp => extended_actual_residual_outside_receiver d hs hc x z hx hn hcap hm C P hP t ht f hf hb a ha hcan p hp)
  rw [Finset.sum_image (s := a.internalMatchingPairs d P x z C)
    (fun p hp q hq he => fixedMatchingStarPairs_fst_injective d x z C
    (Finset.mem_filter.mp hp).1 (Finset.mem_filter.mp hq).1 he)] at hh
  exact hh

theorem extended_internal_matching_ledger_identity
    (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

    (cost : d.StarIndex → ℝ) :
    (∑ i ∈ a.afterUnmatchedHeads d P x z C, cost i)+
      24*(∑ p ∈ extendedResidualOutside d x z a.head (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C), actualCouponResidual d x z p.1)-
      24*(∑ i ∈ a.internalMatchingTargets d P x z C, retainedSelectedResidual d x z a.head i)=
    (∑ p ∈ a.internalMatchingPairs d P x z C,
      (cost p.1+cost p.2-24*retainedSelectedResidual d x z a.head p.2+24*extendedResidualIncomingDebt d x z a.head (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C) p.1))+
      ∑ i ∈ a.remainingRootHeads d P x z C, cost i := by
  rw [a.afterUnmatchedHeads_matching_partition d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan]
  rw [Finset.sum_union (a.internalMatchingPairs_disjoint_root d P x z C)]
  have hsub : a.internalMatchingPairs d P x z C ⊆ fixedMatchingStarPairs d x z C :=
    Finset.filter_subset _ _
  rw [fixedMatchingStarPair_family_sum d x z C _ hsub cost]
  rw [← extended_internal_matching_incoming_sum d hs hc x z hx hn hcap hm C P hP t ht f hf hb a ha hcan]
  rw [GatedDrops.internalMatchingTargets,Finset.sum_image (s := a.internalMatchingPairs d P x z C)
    (fun p hp q hq he => fixedMatchingStarPairs_snd_injective d x z C
      (Finset.mem_filter.mp hp).1 (Finset.mem_filter.mp hq).1 he)]
  simp only [Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.mul_sum]
  ring

end TSP.Improvements20261105
