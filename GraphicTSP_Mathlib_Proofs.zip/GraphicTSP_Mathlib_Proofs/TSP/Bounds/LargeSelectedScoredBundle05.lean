import TSP.Improvements20261105.LargeSelectedScoredT7R4CapPointwise
import TSP.Improvements20261105.LargeSelectedGreedyScoredSourceEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_70
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (22171063231672/112939214407:ℝ)*hBl + (6401512832/9571119865:ℝ)*hCaffine + (29141/118:ℝ)*hzl + (215036617445664/2823480360175:ℝ)*hR0 + (20130417578296/112939214407:ℝ)*hRo + (153636307968/9571119865:ℝ)*hgap + (1/1:ℝ)*hI + (3169607033/9571119865:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (8259976533867588/40771056400927:ℝ)*hBl + (6401512832/9571119865:ℝ)*hCaffine + (10787605/42598:ℝ)*hzl + (80702891384692656/1019276410023175:ℝ)*hR0 + (7523303452998852/40771056400927:ℝ)*hRo + (153636307968/9571119865:ℝ)*hgap + (1/1:ℝ)*hI + (3169607033/9571119865:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_71
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (12439/50:ℝ)*hzl + (1852159351/15010000:ℝ)*hR0 + (12439/50:ℝ)*hRo + (1042028449/7805200:ℝ)*hchoice + (148861207/7805200:ℝ)*hem + (273532833/7805200:ℝ)*hg0 + (460857633/7805200:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (4594391/18050:ℝ)*hzl + (36085813901/285190000:ℝ)*hR0 + (4594391/18050:ℝ)*hRo + (20545563899/148298800:ℝ)*hchoice + (2935080557/148298800:ℝ)*hem + (5090406203/148298800:ℝ)*hg0 + (8649577403/148298800:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_72
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (25/64 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (820813861/6604400:ℝ)*hR0 + (5509/22:ℝ)*hRo + (463387939/3434288:ℝ)*hchoice + (66198277/3434288:ℝ)*hem + (598275503/17171440:ℝ)*hg0 + (1010390063/17171440:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (3191383739/25096720:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (9106136305/65251472:ℝ)*hchoice + (1300876615/65251472:ℝ)*hem + (11151687797/326257360:ℝ)*hg0 + (18981864437/326257360:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_73
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (23380632704/33691949155:ℝ)*hCaffine + (33478826435192/168459745775:ℝ)*hMl + (12439/50:ℝ)*hzl + (345060874742304/4211493644375:ℝ)*hR0 + (31211424735992/168459745775:ℝ)*hRo + (33478826435192/168459745775:ℝ)*hchoice + (561135184896/33691949155:ℝ)*hgap + (1/1:ℝ)*hI + (10311316451/33691949155:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (23380632704/33691949155:ℝ)*hCaffine + (12435956125163748/60813968224775:ℝ)*hMl + (4594391/18050:ℝ)*hzl + (128768173166684976/1520349205619375:ℝ)*hR0 + (11617424111752548/60813968224775:ℝ)*hRo + (12435956125163748/60813968224775:ℝ)*hchoice + (561135184896/33691949155:ℝ)*hgap + (1/1:ℝ)*hI + (10311316451/33691949155:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_74
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (25/64 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (23380632704/33691949155:ℝ)*hCaffine + (14851435577256/74122288141:ℝ)*hMl + (5509/22:ℝ)*hzl + (153275808235872/1853057203525:ℝ)*hR0 + (13853778829608/74122288141:ℝ)*hRo + (14851435577256/74122288141:ℝ)*hchoice + (561135184896/33691949155:ℝ)*hgap + (1/1:ℝ)*hI + (10311316451/33691949155:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (23380632704/33691949155:ℝ)*hCaffine + (5502793569162444/26758146018901:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (57029670682426128/668953650472525:ℝ)*hR0 + (5142639483261516/26758146018901:ℝ)*hRo + (5502793569162444/26758146018901:ℝ)*hchoice + (561135184896/33691949155:ℝ)*hgap + (1/1:ℝ)*hI + (10311316451/33691949155:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_75
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (160525225/429286:ℝ)*hBl + (597006/2717:ℝ)*hMu + (5509/22:ℝ)*hzl + (597006/2717:ℝ)*hqM + (5509/22:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (3132881875/8156434:ℝ)*hBl + (11594970/51623:ℝ)*hMu + (2030725/7942:ℝ)*hzl + (11594970/51623:ℝ)*hqM + (2030725/7942:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_76
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (289092075688/1457012725:ℝ)*hBl + (198326656/291402545:ℝ)*hCaffine + (12439/50:ℝ)*hzl + (412791112608/5203616875:ℝ)*hR0 + (265909390888/1457012725:ℝ)*hRo + (4759839744/291402545:ℝ)*hgap + (1/1:ℝ)*hI + (93075889/291402545:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (107390261448972/525981593725:ℝ)*hBl + (198326656/291402545:ℝ)*hCaffine + (4594391/18050:ℝ)*hzl + (154208486723952/1878505691875:ℝ)*hR0 + (99021312236172/525981593725:ℝ)*hRo + (4759839744/291402545:ℝ)*hgap + (1/1:ℝ)*hI + (93075889/291402545:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_77
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9481729064936/47855599325:ℝ)*hBl + (6401512832/9571119865:ℝ)*hCaffine + (12439/50:ℝ)*hzl + (92163739739232/1196389983125:ℝ)*hR0 + (8617048703336/47855599325:ℝ)*hRo + (153636307968/9571119865:ℝ)*hgap + (1/1:ℝ)*hI + (3169607033/9571119865:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (3522359613183084/17275871356325:ℝ)*hBl + (6401512832/9571119865:ℝ)*hCaffine + (4594391/18050:ℝ)*hzl + (34464575094757008/431896783908125:ℝ)*hR0 + (3210210002645484/17275871356325:ℝ)*hRo + (153636307968/9571119865:ℝ)*hgap + (1/1:ℝ)*hI + (3169607033/9571119865:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_78
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (25/64 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (326319230616/2629173371:ℝ)*hBl + (5509/22:ℝ)*hzl + (5676802428192/65729334275:ℝ)*hR0 + (501618052248/2629173371:ℝ)*hRo + (20440882176/1195078805:ℝ)*hgap + (851703424/1195078805:ℝ)*hC + (1/1:ℝ)*hI + (343375381/1195078805:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (122817705044244/949131586931:ℝ)*hBl + (2030725/7942:ℝ)*hzl + (2109523230079728/23728289673275:ℝ)*hR0 + (186100579653396/949131586931:ℝ)*hRo + (20440882176/1195078805:ℝ)*hgap + (851703424/1195078805:ℝ)*hC + (1/1:ℝ)*hI + (343375381/1195078805:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_79
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (4577839504/43190725:ℝ)*hR0 + (369990656/1727629:ℝ)*hRo + (216175344784/1774274983:ℝ)*hchoice + (30882192112/1774274983:ℝ)*hem + (166013184/8638145:ℝ)*hgap + (6917216/8638145:ℝ)*hC + (1/1:ℝ)*hI + (1720929/8638145:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (1689029505456/15591851725:ℝ)*hR0 + (136280186880/623674069:ℝ)*hRo + (80341499276976/640513268863:ℝ)*hchoice + (11477357039568/640513268863:ℝ)*hem + (3164487936/164124755:ℝ)*hgap + (131853664/164124755:ℝ)*hC + (1/1:ℝ)*hI + (32271091/164124755:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_80
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (77/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (77/320 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_0 hBu
  have hCaffine := hAffine (77/320 : ℝ) (-20774769/1502501 : ℝ) (4325025/1248832 : ℝ) large_selected_scored_t7_r4_cap_point_affine_0 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_81
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_82
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_83
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (1023532625/18186116:ℝ)*hMl + (60893111131/60154076:ℝ)*hzu + (40941305/1398932:ℝ)*hRo + (1023532625/18186116:ℝ)*hchoice + (1914223973/9093058:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (12903828575/60154076:ℝ)*htarget + (1/1:ℝ)*hI + (-249337085/1398932:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (1023532625/18186116:ℝ)*hMl + (1189906155521/1142927444:ℝ)*hzu + (40941305/1398932:ℝ)*hRo + (1023532625/18186116:ℝ)*hchoice + (1914223973/9093058:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (253407003933/1142927444:ℝ)*htarget + (1/1:ℝ)*hI + (-249337085/1398932:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_84
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (2911659918831/13165323535:ℝ)*hMl + (2048738385219/25317929875:ℝ)*hR0 + (36246/185:ℝ)*hRo + (2911659918831/13165323535:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (11339602659433/50028229433:ℝ)*hMl + (8039324295717/96208133525:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (11339602659433/50028229433:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_85
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (3647/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (187515914409/841107865:ℝ)*hBl + (1/1:ℝ)*hCaffine + (129394643541/1617515125:ℝ)*hR0 + (36246/185:ℝ)*hRo + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (730148554687/3196209887:ℝ)*hBl + (1/1:ℝ)*hCaffine + (507934796163/6146557475:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_86
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2321/8000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (187515914409/841107865:ℝ)*hMl + (129394643541/1617515125:ℝ)*hR0 + (36246/185:ℝ)*hRo + (187515914409/841107865:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (730148554687/3196209887:ℝ)*hMl + (507934796163/6146557475:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (730148554687/3196209887:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_87
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_88
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (4553/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (17374863991049/64189847722:ℝ)*hMl + (221389/902:ℝ)*hzl + (6461517131763/61721007425:ℝ)*hR0 + (221389/902:ℝ)*hRo + (17374863991049/64189847722:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (338321906673475/1219607106718:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (5062128235713/46907965643:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (338321906673475/1219607106718:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_89
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (4553/16000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (8839235914991/32593071238:ℝ)*hMl + (112651/458:ℝ)*hzl + (3288733713717/31339491575:ℝ)*hR0 + (112651/458:ℝ)*hRo + (8839235914991/32593071238:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (172015548710245/619268353522:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (12872886542163/119090067985:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (172015548710245/619268353522:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_90
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4553/16000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (8839235914991/32593071238:ℝ)*hMl + (112651/458:ℝ)*hzl + (3288733713717/31339491575:ℝ)*hR0 + (112651/458:ℝ)*hRo + (8839235914991/32593071238:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (172015548710245/619268353522:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (12872886542163/119090067985:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (172015548710245/619268353522:ℝ)*hchoice + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_91
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (3647/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (568424391449/2082310282:ℝ)*hBl + (1/1:ℝ)*hCaffine + (112651/458:ℝ)*hzl + (208259956563/2002221425:ℝ)*hR0 + (112651/458:ℝ)*hRo + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (11060092352755/39563895358:ℝ)*hBl + (1/1:ℝ)*hCaffine + (41753675/165338:ℝ)*hzl + (815390504037/7608441415:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_92
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (146983623559/536490422:ℝ)*hMl + (29141/118:ℝ)*hzl + (53902805133/515856175:ℝ)*hR0 + (29141/118:ℝ)*hRo + (146983623559/536490422:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (2856748005485/10193318018:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (210743812539/1960253465:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (2856748005485/10193318018:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_93
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2321/8000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (146983623559/536490422:ℝ)*hMl + (29141/118:ℝ)*hzl + (53902805133/515856175:ℝ)*hR0 + (29141/118:ℝ)*hRo + (146983623559/536490422:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (2856748005485/10193318018:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (210743812539/1960253465:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (2856748005485/10193318018:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_94
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (241/800 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_95
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (27748954391/100023638:ℝ)*hMl + (5509/22:ℝ)*hzl + (10209011517/96176575:ℝ)*hR0 + (5509/22:ℝ)*hRo + (27748954391/100023638:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (537274612445/1900449122:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (39721426443/365470985:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (537274612445/1900449122:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_96
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_97
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (2568924149/9093058:ℝ)*hMl + (511/2:ℝ)*hzl + (949457463/8743325:ℝ)*hR0 + (511/2:ℝ)*hRo + (2568924149/9093058:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (49468087663/172768102:ℝ)*hMl + (187223/722:ℝ)*hzl + (18343628181/166123175:ℝ)*hR0 + (187223/722:ℝ)*hRo + (49468087663/172768102:ℝ)*hchoice + (3169607033/45465290:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_98
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (469/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (469/2000 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (149477865/429286:ℝ)*hBl + (1875093178/1073215:ℝ)*hMu + (575281/1430:ℝ)*hqM + (26073/110:ℝ)*hRo + (7497895/39026:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (2906401515/8156434:ℝ)*hBl + (35706356878/20391085:ℝ)*hMu + (209691289/516230:ℝ)*hqM + (9580257/39710:ℝ)*hRo + (7497895/39026:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_99
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (789518585/2302534:ℝ)*hBl + (36078338262/178446385:ℝ)*hMu + (36078338262/178446385:ℝ)*hqM + (138217/590:ℝ)*hRo + (239015761/1209806:ℝ)*hg0 + (268051105/1209806:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (15423825435/43748146:ℝ)*hBl + (701222997282/3390481315:ℝ)*hMu + (701222997282/3390481315:ℝ)*hqM + (50967153/212990:ℝ)*hRo + (239015761/1209806:ℝ)*hg0 + (268051105/1209806:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_100
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (160525225/429286:ℝ)*hBl + (1444445694/6653933:ℝ)*hMu + (5509/22:ℝ)*hzl + (1444445694/6653933:ℝ)*hqM + (5509/22:ℝ)*hRo + (343375381/6049030:ℝ)*hg0 + (488552101/6049030:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (3132881875/8156434:ℝ)*hBl + (28061263530/126424727:ℝ)*hMu + (2030725/7942:ℝ)*hzl + (28061263530/126424727:ℝ)*hqM + (2030725/7942:ℝ)*hRo + (343375381/6049030:ℝ)*hg0 + (488552101/6049030:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_101
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (547/1600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (157/400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (157/400 : ℝ) (42588/2983 : ℝ) large_selected_scored_t7_r4_cap_point_linear_14 hBu
  have hCaffine := hAffine (157/400 : ℝ) (402468/19513 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_14 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (160525225/429286:ℝ)*hBl + (1444445694/6653933:ℝ)*hMu + (736/11:ℝ)*hzl + (1444445694/6653933:ℝ)*hqM + (5509/22:ℝ)*hRo + (239015761/1209806:ℝ)*hg0 + (268051105/1209806:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (3132881875/8156434:ℝ)*hBl + (28061263530/126424727:ℝ)*hMu + (286684/3971:ℝ)*hzl + (28061263530/126424727:ℝ)*hqM + (2030725/7942:ℝ)*hRo + (239015761/1209806:ℝ)*hg0 + (268051105/1209806:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_102
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (157/400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (157/400 : ℝ) (42588/2983 : ℝ) large_selected_scored_t7_r4_cap_point_linear_14 hBu
  have hCaffine := hAffine (157/400 : ℝ) (402468/19513 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_14 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (14975275/39026:ℝ)*hBl + (10319682/46531:ℝ)*hMu + (511/2:ℝ)*hzl + (10319682/46531:ℝ)*hqM + (511/2:ℝ)*hRo + (343375381/6049030:ℝ)*hg0 + (488552101/6049030:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (289965425/741494:ℝ)*hBl + (2589399342/11493157:ℝ)*hMu + (187223/722:ℝ)*hzl + (2589399342/11493157:ℝ)*hqM + (187223/722:ℝ)*hRo + (343375381/6049030:ℝ)*hg0 + (488552101/6049030:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_103
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (389/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (389/1280 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_11 hBu
  have hCaffine := hAffine (389/1280 : ℝ) (48189207/7590557 : ℝ) (2422425/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_11 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (317744405397/1404253045:ℝ)*hBl + (1/1:ℝ)*hCaffine + (211346611953/2700486625:ℝ)*hR0 + (36246/185:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (1236792530611/5336161571:ℝ)*hBl + (1/1:ℝ)*hCaffine + (830222162439/10261849175:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_104
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (389/1280 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1013/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1013/3200 : ℝ) (174492/19247 : ℝ) large_selected_scored_t7_r4_cap_point_linear_12 hBu
  have hCaffine := hAffine (1013/3200 : ℝ) (186117159/19766669 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_12 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (430355/962:ℝ)*hBl + (1/1:ℝ)*hCjoint + (8409061122/46289035:ℝ)*hMu + (8409061122/46289035:ℝ)*hqM + (86071/370:ℝ)*hRo + (8336489/38494:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (4648/185:ℝ)*hmass
  · linear_combination (159033195/347282:ℝ)*hBl + (1/1:ℝ)*hCjoint + (164239539942/879491665:ℝ)*hMu + (164239539942/879491665:ℝ)*hqM + (31806639/133570:ℝ)*hRo + (8336489/38494:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_105
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (2321/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (389/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (389/1280 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_11 hBu
  have hCaffine := hAffine (389/1280 : ℝ) (48189207/7590557 : ℝ) (2422425/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_11 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (728525/1534:ℝ)*hBl + (1/1:ℝ)*hCaffine + (88499264169/447842863:ℝ)*hMu + (29141/118:ℝ)*hzl + (88499264169/447842863:ℝ)*hqM + (29141/118:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (269690125/553774:ℝ)*hBl + (1/1:ℝ)*hCaffine + (1730846888955/8509014397:ℝ)*hMu + (10787605/42598:ℝ)*hzl + (1730846888955/8509014397:ℝ)*hqM + (10787605/42598:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_106
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2321/8000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (389/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (389/1280 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_11 hBu
  have hCaffine := hAffine (389/1280 : ℝ) (48189207/7590557 : ℝ) (2422425/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_11 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (960589895957/3476475106:ℝ)*hBl + (1/1:ℝ)*hCaffine + (112651/458:ℝ)*hzl + (341901048759/3342764525:ℝ)*hR0 + (112651/458:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (18685333551175/66053027014:ℝ)*hBl + (1/1:ℝ)*hCaffine + (41753675/165338:ℝ)*hzl + (267859422189/2540501039:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_107
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2321/8000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (389/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (389/1280 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_11 hBu
  have hCaffine := hAffine (389/1280 : ℝ) (48189207/7590557 : ℝ) (2422425/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_11 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (248379205387/895685726:ℝ)*hBl + (1/1:ℝ)*hCaffine + (29141/118:ℝ)*hzl + (88499264169/861236275:ℝ)*hR0 + (29141/118:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (4826153453465/17018028794:ℝ)*hBl + (1/1:ℝ)*hCaffine + (10787605/42598:ℝ)*hzl + (346169377791/3272697845:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (5544793589/75905570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_108
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (241/800 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (389/1280 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1013/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1013/3200 : ℝ) (174492/19247 : ℝ) large_selected_scored_t7_r4_cap_point_linear_12 hBu
  have hCaffine := hAffine (1013/3200 : ℝ) (186117159/19766669 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_12 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (728525/1534:ℝ)*hBl + (1/1:ℝ)*hCjoint + (2877126822/14762449:ℝ)*hMu + (29141/118:ℝ)*hzl + (2877126822/14762449:ℝ)*hqM + (29141/118:ℝ)*hRo + (14582669/192470:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (269690125/553774:ℝ)*hBl + (1/1:ℝ)*hCjoint + (56292514530/280486531:ℝ)*hMu + (10787605/42598:ℝ)*hzl + (56292514530/280486531:ℝ)*hqM + (10787605/42598:ℝ)*hRo + (14582669/192470:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_109
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (241/800 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1013/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1013/3200 : ℝ) (174492/19247 : ℝ) large_selected_scored_t7_r4_cap_point_linear_12 hBu
  have hCaffine := hAffine (1013/3200 : ℝ) (186117159/19766669 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_12 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCjoint + (3035750399/11355730:ℝ)*hMl + (13520904894/141946625:ℝ)*hR0 + (138217/590:ℝ)*hRo + (3035750399/11355730:ℝ)*hchoice + (8336489/38494:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCjoint + (58763994189/215758870:ℝ)*hMl + (263405612634/2696985875:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (58763994189/215758870:ℝ)*hchoice + (8336489/38494:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_110
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1013/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1651473481/6131870:ℝ)*hBl + (1/1:ℝ)*hCjoint + (7221538386/76648375:ℝ)*hR0 + (138217/590:ℝ)*hRo + (4542991/20786:ℝ)*hg0 + (5041855/20786:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (31963732491/116505530:ℝ)*hBl + (1/1:ℝ)*hCjoint + (140723647446/1456319125:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (4542991/20786:ℝ)*hg0 + (5041855/20786:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_111
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1013/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1013/3200 : ℝ) (174492/19247 : ℝ) large_selected_scored_t7_r4_cap_point_linear_12 hBu
  have hCaffine := hAffine (1013/3200 : ℝ) (186117159/19766669 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_12 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (120032963/423434:ℝ)*hBl + (1/1:ℝ)*hCjoint + (5509/22:ℝ)*hzl + (545182278/5292925:ℝ)*hR0 + (5509/22:ℝ)*hRo + (14582669/192470:ℝ)*hg0 + (19201949/192470:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2323147985/8045246:ℝ)*hBl + (1/1:ℝ)*hCjoint + (2030725/7942:ℝ)*hzl + (2122718682/20113115:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (14582669/192470:ℝ)*hg0 + (19201949/192470:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_112
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (1013/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (65271397/228646:ℝ)*hBl + (1/1:ℝ)*hCjoint + (5509/22:ℝ)*hzl + (291423882/2858075:ℝ)*hR0 + (5509/22:ℝ)*hRo + (8081611/103930:ℝ)*hg0 + (10575931/103930:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1263117415/4344274:ℝ)*hBl + (1/1:ℝ)*hCjoint + (2030725/7942:ℝ)*hzl + (1134963798/10860685:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (8081611/103930:ℝ)*hg0 + (10575931/103930:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_113
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCjoint + (1651473481/6131870:ℝ)*hMl + (7221538386/76648375:ℝ)*hR0 + (138217/590:ℝ)*hRo + (1651473481/6131870:ℝ)*hchoice + (4542991/20786:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCjoint + (31963732491/116505530:ℝ)*hMl + (140723647446/1456319125:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (31963732491/116505530:ℝ)*hchoice + (4542991/20786:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_114
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCjoint + (65271397/228646:ℝ)*hMl + (5509/22:ℝ)*hzl + (291423882/2858075:ℝ)*hR0 + (5509/22:ℝ)*hRo + (65271397/228646:ℝ)*hchoice + (8081611/103930:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCjoint + (1263117415/4344274:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (1134963798/10860685:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (1263117415/4344274:ℝ)*hchoice + (8081611/103930:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_115
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (647/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (547/1600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (157/400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (157/400 : ℝ) (42588/2983 : ℝ) large_selected_scored_t7_r4_cap_point_linear_14 hBu
  have hCaffine := hAffine (157/400 : ℝ) (402468/19513 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_14 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (130365/286:ℝ)*hBl + (1/1:ℝ)*hCjoint + (385015854/2132845:ℝ)*hMu + (385015854/2132845:ℝ)*hqM + (26073/110:ℝ)*hRo + (1323121/5966:ℝ)*hg0 + (1466305/5966:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (47901285/103246:ℝ)*hBl + (1/1:ℝ)*hCjoint + (7473466794/40524055:ℝ)*hMu + (7473466794/40524055:ℝ)*hqM + (9580257/39710:ℝ)*hRo + (1323121/5966:ℝ)*hg0 + (1466305/5966:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_116
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (547/1600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (157/400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (157/400 : ℝ) (42588/2983 : ℝ) large_selected_scored_t7_r4_cap_point_linear_14 hBu
  have hCaffine := hAffine (157/400 : ℝ) (402468/19513 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_14 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (479667511/1759970:ℝ)*hBl + (1/1:ℝ)*hCjoint + (2035927566/21999625:ℝ)*hR0 + (138217/590:ℝ)*hRo + (1323121/5966:ℝ)*hg0 + (1466305/5966:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (9281800821/33439430:ℝ)*hBl + (1/1:ℝ)*hCjoint + (39691332426/417992875:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (1323121/5966:ℝ)*hg0 + (1466305/5966:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_117
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (647/2000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
    (hBl : (547/1600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (157/400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (157/400 : ℝ) (42588/2983 : ℝ) large_selected_scored_t7_r4_cap_point_linear_14 hBu
  have hCaffine := hAffine (157/400 : ℝ) (402468/19513 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_14 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (18945307/65626:ℝ)*hBl + (1/1:ℝ)*hCjoint + (5509/22:ℝ)*hzl + (82272342/820325:ℝ)*hR0 + (5509/22:ℝ)*hRo + (2415541/29830:ℝ)*hg0 + (3131461/29830:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (366551065/1246894:ℝ)*hBl + (1/1:ℝ)*hCjoint + (2030725/7942:ℝ)*hzl + (320543178/3117235:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (2415541/29830:ℝ)*hg0 + (3131461/29830:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_118
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (233/800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (547/1600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (547/1600 : ℝ) (114948/10393 : ℝ) large_selected_scored_t7_r4_cap_point_linear_13 hBu
  have hCaffine := hAffine (547/1600 : ℝ) (158702721/10673611 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_13 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (927956752/4542991:ℝ)*hBl + (14633344/22714955:ℝ)*hCjoint + (511/2:ℝ)*hzl + (8570245824/113574775:ℝ)*hR0 + (825347344/4542991:ℝ)*hRo + (351200256/22714955:ℝ)*hgap + (1/1:ℝ)*hI + (8081611/22714955:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (341243543088/1640019751:ℝ)*hBl + (14633344/22714955:ℝ)*hCjoint + (187223/722:ℝ)*hzl + (3168872609856/41000493775:ℝ)*hR0 + (304201546800/1640019751:ℝ)*hRo + (351200256/22714955:ℝ)*hgap + (1/1:ℝ)*hI + (8081611/22714955:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_119
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (279/1000 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (547/1600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (157/400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (157/400 : ℝ) (42588/2983 : ℝ) large_selected_scored_t7_r4_cap_point_linear_14 hBu
  have hCaffine := hAffine (157/400 : ℝ) (402468/19513 : ℝ) (0/1 : ℝ) large_selected_scored_t7_r4_cap_point_affine_14 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1752673/5966:ℝ)*hBl + (1/1:ℝ)*hCjoint + (511/2:ℝ)*hzl + (7661538/74575:ℝ)*hR0 + (511/2:ℝ)*hRo + (2415541/29830:ℝ)*hg0 + (3131461/29830:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (33732851/113354:ℝ)*hBl + (1/1:ℝ)*hCjoint + (187223/722:ℝ)*hzl + (148161606/1416925:ℝ)*hR0 + (187223/722:ℝ)*hRo + (2415541/29830:ℝ)*hg0 + (3131461/29830:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_120
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (157/400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (119/200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (46/125 : ℝ) (59/92 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (119/200 : ℝ) (4783964/214795 : ℝ) large_selected_scored_t7_r4_cap_point_linear_15 hBu
  have hCaffine := hAffine (119/200 : ℝ) (402468/19513 : ℝ) (12126/19513 : ℝ) large_selected_scored_t7_r4_cap_point_affine_15 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (15095/13:ℝ)*hBl + (774354/1495:ℝ)*hMu + (511/2:ℝ)*hzl + (774354/1495:ℝ)*hqM + (3019/5:ℝ)*hRo + (10253/46:ℝ)*hg0 + (11357/46:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (5483695/4693:ℝ)*hBl + (281440674/539695:ℝ)*hMu + (187223/722:ℝ)*hzl + (281440674/539695:ℝ)*hqM + (1096739/1805:ℝ)*hRo + (10253/46:ℝ)*hg0 + (11357/46:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (15095/13:ℝ)*hBl + (276139759/539695:ℝ)*hMu + (511/2:ℝ)*hzl + (276139759/539695:ℝ)*hqM + (3019/5:ℝ)*hRo + (3806011/16606:ℝ)*hg0 + (4204555/16606:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (5483695/4693:ℝ)*hBl + (278038639/539695:ℝ)*hMu + (187223/722:ℝ)*hzl + (278038639/539695:ℝ)*hqM + (1096739/1805:ℝ)*hRo + (3806011/16606:ℝ)*hg0 + (4204555/16606:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_121
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
    (hBl : (119/200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (1/1 : ℝ) (1417918/45125 : ℝ) large_selected_scored_t7_r4_cap_point_linear_16 hBu
  have hCaffine := hAffine (1/1 : ℝ) (402468/19513 : ℝ) (133626/19513 : ℝ) large_selected_scored_t7_r4_cap_point_affine_16 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBl,hMu,hqM,hRo,ha,htarget,hmass]

theorem large_selected_scored_t7_r4_cap_cell_122
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (46/125 : ℝ) (623/920 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1/1 : ℝ) (1417918/45125 : ℝ) large_selected_scored_t7_r4_cap_point_linear_16 hBu
  have hCaffine := hAffine (1/1 : ℝ) (402468/19513 : ℝ) (133626/19513 : ℝ) large_selected_scored_t7_r4_cap_point_affine_16 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (17667595168/165875875:ℝ)*hR0 + (1455799616/6635035:ℝ)*hRo + (907592223328/6814180945:ℝ)*hchoice + (129656031904/6814180945:ℝ)*hem + (24835584/1327007:ℝ)*hgap + (1034816/1327007:ℝ)*hC + (1/1:ℝ)*hI + (292191/1327007:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (6415627200792/59881190875:ℝ)*hR0 + (528355248144/2395247635:ℝ)*hRo + (330041211821832/2459919321145:ℝ)*hchoice + (47148744545976/2459919321145:ℝ)*hem + (2361438336/126065665:ℝ)*hgap + (98393264/126065665:ℝ)*hC + (1/1:ℝ)*hI + (27672401/126065665:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_123
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (19/100 : ℝ) ≤ M) (hMu : M ≤ (46/125 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
    (hBl : (19/100 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (1/1 : ℝ) (1417918/45125 : ℝ) large_selected_scored_t7_r4_cap_point_linear_16 hBu
  have hCaffine := hAffine (1/1 : ℝ) (402468/19513 : ℝ) (133626/19513 : ℝ) large_selected_scored_t7_r4_cap_point_affine_16 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

end TSP.Improvements20261105
