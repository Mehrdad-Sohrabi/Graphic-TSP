import TSP.Improvements20261105.GatedBinaryCuts

/-! Move a receiving connector's positive prefix drop onto its suffix
when its own head is unselected. Shared collectors move with the gate. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 1000000
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatePromotionSide (P : GatePlan d) (r : d.tree.Child) : GatedVertex d → ℤ
  | .inr (.inr (v, k)) => if k = 1 then (if v = r then 1 else 0)
      else if k = 3 ∧ P.kind v = .sharedGate ∧ P.receiver v = r then 1 else 0
  | _ => 0

noncomputable def promoteGatePrefix (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (w : GatedVertex d) : ℤ := p w + gatePromotionSide d P r w

theorem gatePromotionSide_free_incoming (P : GatePlan d) (r : d.tree.Child)
    (a : GatedArc d) (ha : gatedUpper d P a = none) :
    gatePromotionSide d P r ((gatedNetwork d P).dst a) -
      gatePromotionSide d P r ((gatedNetwork d P).src a) ≤
      if a = gatedPrefixArc d r ∨ a = gatedPaidArc d r then 1 else 0 := by
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · simp only [gatedNetwork, gatePromotionSide, Sum.elim_inl, Sum.elim_inr]
    split_ifs <;> norm_num
  · simp [gatedNetwork, gatePromotionSide]
  · by_cases ho : P.OutsideBack d b <;> simp [gatedNetwork, gatePromotionSide, ho]
  · simp [gatedNetwork, gatePromotionSide]
  · fin_cases k
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatePromotionSide]
    · simp [gatedUpper] at ha
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatePromotionSide]
    · by_cases ho : P.IsReceiver d v <;>
        simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatePromotionSide, ho] <;>
        split_ifs <;> norm_num
    · simp [gatedUpper] at ha
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatePromotionSide]
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatePromotionSide]
      split_ifs <;> norm_num
    · by_cases ho : P.kind v = .sharedGate <;>
        simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatePromotionSide, ho]

theorem promoteGatePrefix_feasible (P : GatePlan d) (p : GatedVertex d → ℤ)
    (hp : GatedDualFeasible d P p) (r : d.tree.Child) (hr : P.IsReceiver d r)
    (hpre : gatedPrefixDrop d p r = 1) (hsuf : gatedSuffixDrop d p r = 0)
    (hhead : gatedHeadSelector d p r = 0) :
    GatedDualFeasible d P (promoteGatePrefix d P p r) := by
  intro a ha
  have ho := hp a ha
  have hb := gatePromotionSide_free_incoming d P r a ha
  by_cases he : a = gatedPrefixArc d r ∨ a = gatedPaidArc d r
  · rcases he with rfl | rfl
    · simp [promoteGatePrefix, gatedNetwork, gatedExtraSrc, gatedExtraDst,
        gatedCost, gatePromotionSide]
      dsimp [gatedPrefixDrop] at hpre
      omega
    · simp [promoteGatePrefix, gatedNetwork, gatedExtraSrc, gatedExtraDst,
        gatedCost, gatePromotionSide, hr]
      dsimp [gatedSuffixDrop] at hsuf
      dsimp [gatedHeadSelector] at hhead
      omega
  · rw [if_neg he] at hb
    dsimp only [promoteGatePrefix]
    omega

theorem promoteGatePrefix_head (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedHeadSelector d (promoteGatePrefix d P p r) v =
      gatedHeadSelector d p v := by
  simp [gatedHeadSelector, promoteGatePrefix, gatePromotionSide]

theorem promoteGatePrefix_representative (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedRepresentativeDrop d (promoteGatePrefix d P p r) v =
      gatedRepresentativeDrop d p v := by
  simp [gatedRepresentativeDrop, promoteGatePrefix, gatePromotionSide]

theorem promoteGatePrefix_prefix (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedPrefixDrop d (promoteGatePrefix d P p r) v =
      gatedPrefixDrop d p v - (if v = r then 1 else 0) := by
  simp [gatedPrefixDrop, promoteGatePrefix, gatePromotionSide]
  ring

theorem promoteGatePrefix_suffix (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedSuffixDrop d (promoteGatePrefix d P p r) v =
      gatedSuffixDrop d p v + (if v = r then 1 else 0) := by
  simp [gatedSuffixDrop, promoteGatePrefix, gatePromotionSide]
  ring

theorem gatePromotionSide_bypass (P : GatePlan d) (r v : d.tree.Child) :
    gatePromotionSide d P r (gatedBypassTarget d P v) -
      gatePromotionSide d P r (gatedBypassSource d P v) =
      if P.UsesGate d v ∧ P.receiver v = r then 1 else 0 := by
  cases hv : P.kind v <;>
    simp [gatedBypassTarget, gatedBypassSource, gatePromotionSide, GatePlan.UsesGate, hv]

end TSP.Improvements20261105
