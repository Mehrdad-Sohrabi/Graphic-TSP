import TSP.Improvements20261105.GeneralPairPaymentInterface
import TSP.Improvements20261105.SmallNetPairPayment

/-! Close all actual remaining pairs with at most three source back edges
in the concrete endpoint context. No local cost premise remains here. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem GeneralPairPaymentContext.small_pair_payment
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (p : (d).StarIndex × (d).StarIndex)
    (hp : p ∈ K.a.internalMatchingPairs d (fixedGatePlan d x) x z K.C)
    (hsmall : ((d).backGroup p.1.1).card ≤ 3) :
    currentSelectedHeadCost d x z K.C K.owner K.rootStar K.R (generalEligibleHeads d x)
        (generalRawCriticalHeads d x z K.a) K.a.head p.1+
      currentSelectedHeadCost d x z K.C K.owner K.rootStar K.R (generalEligibleHeads d x)
        (generalRawCriticalHeads d x z K.a) K.a.head p.2-
      24*retainedSelectedResidual d x z K.a.head p.2+
      24*extendedResidualIncomingDebt d x z K.a.head
        (K.a.internalUnmatchedHeads d (fixedGatePlan d x) x z K.C)
        (K.a.internalMatchingTargets d (fixedGatePlan d x) x z K.C) p.1 ≤
    4*((((d).backGroup p.1.1).card : ℝ)+((d).backGroup p.2.1).card)+
      2*(originalMatchingBadLabel d x₀ p.1.1 : ℝ)+
      (162/19)*(matchingPairCreditIndicator d K.a.head p : ℝ) := by
  have hpF := (Finset.mem_filter.mp hp).1
  have hpair := (Finset.mem_filter.mp hpF).2
  have hi := hpair.1
  have hj := hpair.2.symm
  have hn : 2 ≤ Fintype.card V := by have hh:=K.hc.1; omega
  have hpos := projectionLink_source_positive d hs x z K.hx hn K.hprojection p.1.1 (K.C.link_subset hi)
  have hsum : edgeSum z ((d).backGroup p.1.1) ≤ (((d).backGroup p.1.1).card : ℝ) := by
    have hh := Finset.sum_le_sum (s := (d).backGroup p.1.1) (fun e _ => (K.hzx e).trans (K.hcap e))
    simpa [edgeSum] using hh
  have hn2 : 1 < ((d).backGroup p.1.1).card := by exact_mod_cast hpos.trans_le hsum
  have hcount : ((d).backGroup p.1.1).card=2 ∨ ((d).backGroup p.1.1).card=3 := by omega
  have hQconn : FixedQConnectorValues d x K.hx hn K.hcap K.Q := by
    constructor
    · intro i
      rw [← K.hconnectors]
      exact K.hconn.1 i
    · intro i hh
      rw [← K.hconnectors]
      exact K.hconn.2 i hh
  let H := K.a.internalUnmatchedHeads d (fixedGatePlan d x) x z K.C
  let M := K.a.internalMatchingTargets d (fixedGatePlan d x) x z K.C
  let δ := extendedResidualIncomingDebt d x z K.a.head H M p.1
  have hδ0 := extendedResidualIncomingDebt_nonnegative d x z K.a.head H M p.1
  have hδ := extendedResidualIncomingDebt_matching_cap d hs x z K.hx hn K.hcap K.hprojection K.C K.a.head H M p.1 hi
  have hh := scoredDFS_small_net_pair_payment G x z hs hconnected root K.hx hn K.hcap K.hz K.hzx
    K.hprojection K.C K.owner K.ho K.rootStar K.hrootStar K.Q K.R hQconn K.hconn K.hrep K.hbacks
    K.hloss K.hterminal K.hguarded (generalEligibleHeads d x) (generalRawCriticalHeads d x z K.a)
    K.a.head p.1 p.2 hi hj (K.a.head_binary d K.ha p.1.1) (K.a.head_binary d K.ha p.2.1)
    δ hδ0 hδ hcount
  have hid : (if K.a.head p.1.1=1 ∧ K.a.head p.2.1=1 ∧ 3 ≤ ((d).backGroup p.1.1).card ∧
      3 ≤ ((d).backGroup p.2.1).card then (162/19 : ℝ) else 0)=
      (162/19)*(matchingPairCreditIndicator d K.a.head p : ℝ) := by
    unfold matchingPairCreditIndicator
    split_ifs <;> norm_num
  have hbad0 : (0 : ℝ) ≤ (originalMatchingBadLabel d x₀ p.1.1 : ℝ) := Nat.cast_nonneg _
  dsimp only [δ,H,M] at hh
  linarith only [hh,hid,hbad0]

end TSP.Improvements20261105
