import TSP.Improvements20261105.BoundedCirculationMixture

/-! Existence of an integral minimum-cost circulation for nonnegative integral
costs, integral lower bounds, and optional integral upper bounds. Feasibility
alone is required; no optimality or strong-duality premise is assumed. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

def OptionalFlowBounds (lower : E → ℕ) (upper : E → Option ℕ) (f : E → ℝ) : Prop :=
  ∀ e, (lower e : ℝ) ≤ f e ∧ ∀ u, upper e = some u → f e ≤ u

theorem optional_circulation_rounding (N : Graph V E) (cost : E → ℝ)
    (lower : E → ℕ) (upper : E → Option ℕ) (f : E → ℝ)
    (hf : Balanced N f) (hbox : OptionalFlowBounds lower upper f) :
    ∃ g : E → ℕ, Balanced N (fun e => (g e : ℝ)) ∧
      OptionalFlowBounds lower upper (fun e => (g e : ℝ)) ∧
      (∑ e, cost e * (g e : ℝ)) ≤ ∑ e, cost e * f e := by
  obtain ⟨g, hg, hint, hb, hc⟩ := integral_flow_rounding N f cost hf
    (fun e => (Nat.cast_nonneg _).trans (hbox e).1)
  choose gn hgn using hint
  have heq : g = fun e => (gn e : ℝ) := funext hgn
  refine ⟨gn, by simpa only [heq] using hg, ?_, by simpa only [heq] using hc⟩
  intro e
  have hlo : (lower e : ℤ) ≤ ⌊f e⌋ := Int.le_floor.mpr (by simpa using (hbox e).1)
  have hloR : (lower e : ℝ) ≤ (⌊f e⌋ : ℤ) := by exact_mod_cast hlo
  constructor
  · simpa only [hgn] using hloR.trans (hb e).1
  · intro u hu
    have hup : ⌈f e⌉ ≤ (u : ℤ) := Int.ceil_le.mpr (by simpa using (hbox e).2 u hu)
    have hupR : ((⌈f e⌉ : ℤ) : ℝ) ≤ u := by exact_mod_cast hup
    simpa only [hgn] using (hb e).2.trans hupR

theorem exists_minimum_integral_circulation (N : Graph V E) (cost lower : E → ℕ)
    (upper : E → Option ℕ)
    (hfeas : ∃ f : E → ℝ, Balanced N f ∧ OptionalFlowBounds lower upper f) :
    ∃ g : E → ℕ, Balanced N (fun e => (g e : ℝ)) ∧
      OptionalFlowBounds lower upper (fun e => (g e : ℝ)) ∧
      ∀ f : E → ℝ, Balanced N f → OptionalFlowBounds lower upper f →
        (∑ e, (cost e : ℝ) * (g e : ℝ)) ≤ ∑ e, (cost e : ℝ) * f e := by
  let P : ℕ → Prop := fun k => ∃ g : E → ℕ,
    Balanced N (fun e => (g e : ℝ)) ∧
    OptionalFlowBounds lower upper (fun e => (g e : ℝ)) ∧
    (∑ e, cost e * g e) = k
  have hex : ∃ k, P k := by
    obtain ⟨f, hf, hb⟩ := hfeas
    obtain ⟨g, hg, hgb, _⟩ := optional_circulation_rounding N (fun e => (cost e : ℝ))
      lower upper f hf hb
    exact ⟨∑ e, cost e * g e, g, hg, hgb, rfl⟩
  obtain ⟨g, hg, hgb, hcost⟩ := Nat.find_spec hex
  refine ⟨g, hg, hgb, ?_⟩
  intro f hf hfb
  obtain ⟨h, hh, hhb, hhc⟩ := optional_circulation_rounding N (fun e => (cost e : ℝ))
    lower upper f hf hfb
  have hmin : Nat.find hex ≤ ∑ e, cost e * h e :=
    Nat.find_min' hex ⟨h, hh, hhb, rfl⟩
  rw [← hcost] at hmin
  have hminR : (∑ e, (cost e : ℝ) * (g e : ℝ)) ≤
      ∑ e, (cost e : ℝ) * (h e : ℝ) := by exact_mod_cast hmin
  exact hminR.trans hhc

end TSP.Improvements20261105
