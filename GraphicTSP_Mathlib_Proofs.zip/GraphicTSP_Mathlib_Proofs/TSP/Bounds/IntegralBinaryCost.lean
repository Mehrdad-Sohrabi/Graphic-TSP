import TSP.Improvements20261105.BinaryZCost

/-! Integral clipping, bypass resets, and the actual paid-flow tour row.
The network supplies coverage, witnesses and its two local payment arms. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def resetBypasses (z : E → ℕ) (R₀ : Finset d.tree.Child) : Finset d.tree.Child :=
  R₀.filter (fun v => 2 ≤ (positiveBackSet d z ∩ d.backGroup v).card)

theorem reset_bypass_bit (z : E → ℕ) (R₀ : Finset d.tree.Child) (v : d.tree.Child) :
    (if v ∈ resetBypasses d z R₀ then (1 : ℝ) else 0) =
      if 2 ≤ (positiveBackSet d z ∩ d.backGroup v).card then
        (if v ∈ R₀ then 1 else 0) else 0 := by
  simp only [resetBypasses, Finset.mem_filter]
  split_ifs <;> simp_all

theorem clipped_binary_head_paid (z : E → ℕ) (R₀ : Finset d.tree.Child)
    (v : d.tree.Child) (ω : ℝ) (hω : 0 ≤ ω)
    (hc : 1 - ∑ b ∈ deletedSubtreeCut d v, (z b : ℝ) ≤ ω)
    (ha : (∑ b ∈ d.backGroup v, (z b : ℝ)) - (if v ∈ R₀ then 1 else 0) - 1 ≤ ω) :
    binaryHeadCharge d (positiveBackSet d z) (resetBypasses d z R₀) v ≤ ω := by
  unfold binaryHeadCharge
  apply max_le
  · exact (clipped_actual_connector_deficiency d z v).trans (max_le hc hω)
  · rw [reset_bypass_bit]
    have hh := clipped_actual_head_overflow d z v (if v ∈ R₀ then 1 else 0)
    exact (le_max_left _ _).trans (hh.trans (max_le ha hω))

theorem clipped_binary_root_paid (z : E → ℕ) (v : d.tree.Child)
    (ω : ℝ) (hω : 0 ≤ ω) (ha : (∑ b ∈ d.backGroup v, (z b : ℝ)) - 2 ≤ ω) :
    max (((positiveBackSet d z ∩ d.backGroup v).card : ℝ) - 2) 0 ≤ ω := by
  have hh : ((positiveBackSet d z ∩ d.backGroup v).card : ℝ) ≤
      ∑ b ∈ d.backGroup v, (z b : ℝ) := by
    exact_mod_cast positiveBackSet_mass d z (d.backGroup v)
  exact max_le (by linarith) hω

theorem integral_binary_Z_paid_bound (hsimple : G.IsSimple) (hconn : IsTwoVertexConnected G)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (z : E → ℕ) (R₀ : Finset d.tree.Child)
    (hwitness : ∀ v ∈ R₀, OriginalBypassWitness d (positiveBackSet d z) v)
    (hcover : ∀ v : d.tree.Child, ¬(d.backGroup v).Nonempty →
      1 ≤ ∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, z b)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (hrootR : rootStar.1 ∉ R₀) (ω : d.StarIndex → ℝ) (hω : ∀ i, 0 ≤ ω i)
    (hrootpay : (∑ b ∈ d.backGroup rootStar.1, (z b : ℝ)) - 2 ≤ ω rootStar)
    (hconnector : ∀ i, i ≠ rootStar →
      1 - ∑ b ∈ deletedSubtreeCut d i.1, (z b : ℝ) ≤ ω i)
    (hhead : ∀ i, i ≠ rootStar → (∑ b ∈ d.backGroup i.1, (z b : ℝ)) -
      (if i.1 ∈ R₀ then 1 else 0) - 1 ≤ ω i) :
    (G.tsp : ℝ) ≤ (4 * Fintype.card V - 2) / 3 + (2 / 3) * ∑ i, ω i := by
  let B := positiveBackSet d z
  let R := resetBypasses d z R₀
  have hR : R ⊆ R₀ := Finset.filter_subset _ _
  have hc : ∀ v : d.tree.Child, ¬(d.backGroup v).Nonempty → SelectedTreeCover d B v := by
    intro v hv
    have hh := hcover v hv
    obtain ⟨b, hb⟩ := (positiveBackSet_cover_iff d z
      (G.cut (subtreeVertices d v) ∩ d.backEdges) Finset.inter_subset_right).mpr (by omega)
    exact ⟨b, Finset.mem_inter.mpr ⟨(Finset.mem_inter.mp hb).1,
      (Finset.mem_inter.mp (Finset.mem_inter.mp hb).2).1⟩⟩
  have ht := binary_Z_tsp_bound d hsimple hconn owner ho B (positiveBackSet_subset d z) R
    (fun v hv => (Finset.mem_filter.mp hv).2) (fun v hv => hwitness v (hR hv)) hc
    rootStar hroot (fun hh => hrootR (hR hh))
  have hp := Finset.sum_le_sum (s := Finset.univ.erase rootStar) (fun i hi =>
    clipped_binary_head_paid d z R₀ i.1 (ω i) (hω i)
      (hconnector i (Finset.mem_erase.mp hi).1) (hhead i (Finset.mem_erase.mp hi).1))
  have hr := clipped_binary_root_paid d z rootStar.1 (ω rootStar) (hω rootStar) hrootpay
  have hs := Finset.sum_erase_add (Finset.univ : Finset d.StarIndex) ω (Finset.mem_univ rootStar)
  dsimp [B, R] at ht
  linarith

end TSP.Improvements20261105
