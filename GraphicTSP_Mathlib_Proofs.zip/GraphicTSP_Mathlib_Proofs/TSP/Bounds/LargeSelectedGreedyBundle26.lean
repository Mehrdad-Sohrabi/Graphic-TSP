import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_cell_10
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (12041/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (4494001/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (4495369/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (4642569/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_11
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (163157/598:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (60530101/215878:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (60831061/215878:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (62461485/215878:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_12
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3929/14:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1463169/5054:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (1435961/5054:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1480761/5054:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_13
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53093/182:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19662789/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (19395269/65702:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19891485/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_14
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_15
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (27/160 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hqu,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_16
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (142019/506:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (52234307/182666:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (52903107/182666:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (53868555/182666:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_17
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (16781/230:ℝ)*heq + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (13145/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (16781/230:ℝ)*heq + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (4808641/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (6800781/83030:ℝ)*heq + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (4893913/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (6800781/83030:ℝ)*heq + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (4957209/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_18
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (13/32 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (13/32 : ℝ) (10/13 : ℝ) (103/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7747/26:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (5875/26:ℝ)*hg0 + (6499/26:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2832443/9386:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (5875/26:ℝ)*hg0 + (6499/26:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (2847491/9386:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (2171699/9386:ℝ)*hg0 + (2396963/9386:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2883267/9386:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (2171699/9386:ℝ)*hg0 + (2396963/9386:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_19
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (13/32 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4265/14:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1558929/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (1557257/5054:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1576521/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_cell_20
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_21
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (2983136/16285:ℝ)*ho0 + (236544/16285:ℝ)*hgap + (3467488/16285:ℝ)*hgate + (9856/16285:ℝ)*hS + (1/1:ℝ)*hI + (6429/16285:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1082983144/5878885:ℝ)*ho0 + (236544/16285:ℝ)*hgap + (1257834216/5878885:ℝ)*hgate + (9856/16285:ℝ)*hS + (1/1:ℝ)*hI + (6429/16285:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1081978592/5966845:ℝ)*ho0 + (85392384/5966845:ℝ)*hgap + (1269214432/5966845:ℝ)*hgate + (3558016/5966845:ℝ)*hS + (1/1:ℝ)*hI + (2408829/5966845:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (392818711528/2154031045:ℝ)*ho0 + (85392384/5966845:ℝ)*hgap + (460410849768/2154031045:ℝ)*hgate + (3558016/5966845:ℝ)*hS + (1/1:ℝ)*hI + (2408829/5966845:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_22
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t20_r3_all_cell_23
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (19/20 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_24
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (12041/966:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (97226/483:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (4494001/348726:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (35024986/174363:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (4495369/348726:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (36584266/174363:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (1547523/116242:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (640538/3059:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_25
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (27/160 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (27/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6931/546:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (53182/273:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2572979/197106:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19163258/98553:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2585291/197106:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (20030702/98553:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (885393/65702:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (350794/1729:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_26
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (163157/598:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (60530101/215878:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (60831061/215878:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (62461485/215878:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_27
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53093/182:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19662789/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (19395269/65702:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19891485/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_28
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_29
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (27/160 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (27/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (559/42:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4078/21:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (204551/15162:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1470782/7581:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (208199/15162:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1536158/7581:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (70317/5054:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (26926/133:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_cell_30
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13145/46:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (4808641/16606:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (4893913/16606:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (4957209/16606:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_31
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4265/14:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1558929/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (1557257/5054:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1576521/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_32
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_33
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (67933/4830:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (142234/2415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (3515651/249090:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (7329086/124545:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (25266653/1743630:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (58774874/871815:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1207257/83030:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (147198/2185:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_34
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (21997/70:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (6429/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (7967013/25270:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (6429/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (8028877/25270:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (2408829/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (8054973/25270:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (2408829/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_35
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t20_r3_all_cell_36
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (19/20 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (19/20 : ℝ) (28/19 : ℝ) (271/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9229/38:ℝ)*hzl + (495142/46037:ℝ)*hem + (8678766/46037:ℝ)*ho0 + (3438432/230185:ℝ)*hgap + (143268/230185:ℝ)*hS + (1/1:ℝ)*hI + (86917/230185:ℝ)*hsource + (1/1:ℝ)*hR + (1128/19:ℝ)*hmass
  · linear_combination (175727/722:ℝ)*hzl + (9430587/874703:ℝ)*hem + (165371583/874703:ℝ)*ho0 + (65341488/4373515:ℝ)*hgap + (2722562/4373515:ℝ)*hS + (1/1:ℝ)*hI + (1650953/4373515:ℝ)*hsource + (1/1:ℝ)*hR + (21620/361:ℝ)*hmass
  · linear_combination (9229/38:ℝ)*hzl + (894891286/83212685:ℝ)*hem + (3134410686/16642537:ℝ)*ho0 + (65330208/4379615:ℝ)*hgap + (2722092/4379615:ℝ)*hS + (1/1:ℝ)*hI + (1657523/4379615:ℝ)*hsource + (1/1:ℝ)*hR + (1128/19:ℝ)*hmass
  · linear_combination (175727/722:ℝ)*hzl + (17044306419/1581041015:ℝ)*hem + (59725517863/316208203:ℝ)*ho0 + (65341488/4379615:ℝ)*hgap + (2722562/4379615:ℝ)*hS + (1/1:ℝ)*hI + (1657053/4379615:ℝ)*hsource + (1/1:ℝ)*hR + (21620/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_37
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (9833/46:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1260626/299:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (9833/46:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (454270774/107939:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (3698281/16606:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (474399826/107939:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (3698281/16606:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (24925506/5681:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_38
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_39
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hql,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_cell_40
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (9833/46:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (96674/23:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (9833/46:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (34867666/8303:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (3698281/16606:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (36384994/8303:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (3698281/16606:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1913334/437:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_41
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_42
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_43
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (9833/46:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (482266/115:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (9833/46:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (174055154/41515:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (3698281/16606:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (181526426/41515:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (3698281/16606:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9551766/2185:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_44
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_45
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_46
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (149/1750 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (19/20 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (19/20 : ℝ) (28/19 : ℝ) (271/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9229/38:ℝ)*hzl + (495142/46037:ℝ)*hem + (8678766/46037:ℝ)*ho0 + (3438432/230185:ℝ)*hgap + (143268/230185:ℝ)*hS + (1/1:ℝ)*hI + (86917/230185:ℝ)*hsource + (1/1:ℝ)*hR + (1128/19:ℝ)*hmass
  · linear_combination (175727/722:ℝ)*hzl + (9430587/874703:ℝ)*hem + (165371583/874703:ℝ)*ho0 + (65341488/4373515:ℝ)*hgap + (2722562/4373515:ℝ)*hS + (1/1:ℝ)*hI + (1650953/4373515:ℝ)*hsource + (1/1:ℝ)*hR + (21620/361:ℝ)*hmass
  · linear_combination (9229/38:ℝ)*hzl + (371967/3610:ℝ)*hem + (10141/38:ℝ)*ho0 + (24/1:ℝ)*hgap + (3315046/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1128/19:ℝ)*hmass
  · linear_combination (175727/722:ℝ)*hzl + (371967/3610:ℝ)*hem + (193055/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (3314106/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (21620/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_47
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (12041/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (4494001/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (4495369/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (4642569/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_48
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (163157/598:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (60530101/215878:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (60831061/215878:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (62461485/215878:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_49
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3929/14:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1463169/5054:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (1435961/5054:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1480761/5054:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_cell_50
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53093/182:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19662789/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (19395269/65702:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19891485/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_51
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_52
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (27/160 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hqu,hgate,hmass]

theorem large_selected_greedy_t20_r3_all_cell_53
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (142019/506:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (9833/46:ℝ)*hg0 + (10937/46:ℝ)*hgap + (1/1:ℝ)*hH0 + (52234307/182666:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (52903107/182666:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (3698281/16606:ℝ)*hg0 + (4096825/16606:ℝ)*hgap + (1/1:ℝ)*hH0 + (53868555/182666:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_54
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (16781/230:ℝ)*heq + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (13145/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (16781/230:ℝ)*heq + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (4808641/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (6800781/83030:ℝ)*heq + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (4893913/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (6800781/83030:ℝ)*heq + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (4957209/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_55
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4265/14:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1558929/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (3257/14:ℝ)*hg0 + (3593/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (1557257/5054:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1576521/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (1193369/5054:ℝ)*hg0 + (1314665/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_56
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_57
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (2983136/16285:ℝ)*ho0 + (236544/16285:ℝ)*hgap + (3467488/16285:ℝ)*hgate + (9856/16285:ℝ)*hS + (1/1:ℝ)*hI + (6429/16285:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1082983144/5878885:ℝ)*ho0 + (236544/16285:ℝ)*hgap + (1257834216/5878885:ℝ)*hgate + (9856/16285:ℝ)*hS + (1/1:ℝ)*hI + (6429/16285:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1081978592/5966845:ℝ)*ho0 + (85392384/5966845:ℝ)*hgap + (1269214432/5966845:ℝ)*hgate + (3558016/5966845:ℝ)*hS + (1/1:ℝ)*hI + (2408829/5966845:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (392818711528/2154031045:ℝ)*ho0 + (85392384/5966845:ℝ)*hgap + (460410849768/2154031045:ℝ)*hgate + (3558016/5966845:ℝ)*hS + (1/1:ℝ)*hI + (2408829/5966845:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_58
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t20_r3_all_cell_59
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (1/5 : ℝ) ≤ q)
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (19/20 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_cell_60
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (12041/966:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (97226/483:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (4494001/348726:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (35024986/174363:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (4495369/348726:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (36584266/174363:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (1547523/116242:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (640538/3059:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_61
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (27/160 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (27/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6931/546:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (53182/273:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2572979/197106:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (19163258/98553:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2585291/197106:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (20030702/98553:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (885393/65702:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (350794/1729:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_62
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (163157/598:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (60530101/215878:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (60831061/215878:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (62461485/215878:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_63
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53093/182:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19662789/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (19395269/65702:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (19891485/65702:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_64
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_65
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (27/160 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (27/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (559/42:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4078/21:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (204551/15162:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1470782/7581:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (208199/15162:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1536158/7581:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (70317/5054:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (26926/133:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_66
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (27/160 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13145/46:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (4808641/16606:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9833/46:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (4893913/16606:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (4957209/16606:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3698281/16606:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_67
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (23/80 : ℝ) ≤ q) (hqu : q ≤ (21/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (21/40 : ℝ) (22/21 : ℝ) (73/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4265/14:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1558929/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3257/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (1557257/5054:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1576521/5054:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1193369/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_68
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (21/40 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t20_r3_all_cell_69
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/20 : ℝ) ≤ q) (hqu : q ≤ (23/80 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hS := hSall (23/80 : ℝ) (6/23 : ℝ) (77/230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (67933/4830:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (142234/2415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (3515651/249090:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (7329086/124545:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (25266653/1743630:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (58774874/871815:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1207257/83030:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (147198/2185:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

end TSP.Improvements20261105
