import TSP.Improvements20261105.GatedAugmentedDual
import TSP.Chapter05.RootedPath

/-! Integer potential inequalities along the actual DFS tree and backs. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def GatedDualFeasible (P : GatePlan d) (p : GatedVertex d → ℤ) : Prop :=
  ∀ a, gatedUpper d P a = none →
    p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)

theorem gated_dual_prefix {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    p (gatedGate d v) ≤ p (gatedCenter d (d.tree.parent v)) := by
  have hh := hp (gatedPrefixArc d v) (by simp [gatedUpper])
  simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, sub_nonpos] using hh

theorem gated_dual_suffix {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    p (gatedAux d v) ≤ p (gatedGate d v) := by
  have hh := hp (gatedSuffixArc d v) (by simp [gatedUpper])
  simpa [gatedNetwork, gatedCost, sub_nonpos] using hh

theorem gated_dual_representative {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    p (gatedCenter d v) ≤ p (gatedAux d v) := by
  have hh := hp (gatedRepArc d v) (by simp [gatedUpper])
  simpa [gatedNetwork, gatedCost, sub_nonpos] using hh

theorem gated_dual_parent {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    p (gatedCenter d v) ≤ p (gatedCenter d (d.tree.parent v)) :=
  (gated_dual_representative d hp v).trans ((gated_dual_suffix d hp v).trans (gated_dual_prefix d hp v))

theorem gated_dual_ancestor {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) {a b : V} (hab : d.tree.Ancestor a b) :
    p (gatedCenter d b) ≤ p (gatedCenter d a) := by
  induction hab with
  | refl => exact le_rfl
  | @tail c a hprev hstep ih =>
    have hh := gated_dual_parent d hp ⟨c, hstep.1⟩
    change p (gatedCenter d c) ≤ p (gatedCenter d (d.tree.parent c)) at hh
    rw [hstep.2] at hh
    exact ih.trans hh

theorem gated_dual_tail {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : V) :
    p (gatedTail d v) ≤ p (gatedCenter d v) := by
  have hh := hp (gatedTailArc d v) (by simp [gatedUpper])
  simpa [gatedNetwork, gatedCost, sub_nonpos] using hh

theorem gated_dual_outside {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    p (gatedHead d v) ≤ p (gatedOutside d v) := by
  have hh := hp (gatedFeedArc d v) (by simp [gatedUpper])
  simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, sub_nonpos] using hh

theorem gated_dual_back {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (b : BackEdge d) :
    p (gatedHead d (d.anchor b.1)) ≤ p (gatedTail d (d.lower b.1)) := by
  have hh := hp (gatedBackArc d b) (by simp [gatedUpper])
  simp only [gatedNetwork, gatedCost, Sum.elim_inl, Sum.elim_inr, Nat.cast_zero,
    sub_nonpos] at hh
  split_ifs at hh with h
  · exact (gated_dual_outside d hp _).trans hh
  · exact hh

theorem gated_dual_own_back {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) (b : E) (hb : b ∈ d.backGroup v) :
    p (gatedHead d v) ≤ p (gatedCenter d v) := by
  have ha := (back_anchor_iff_group d ⟨b, ((d.mem_backGroup_iff v b).mp hb).1⟩ v).mpr hb
  have hh := gated_dual_back d hp ⟨b, ((d.mem_backGroup_iff v b).mp hb).1⟩
  rw [ha] at hh
  exact hh.trans ((gated_dual_tail d hp _).trans
    (gated_dual_ancestor d hp ((d.mem_backGroup_iff v b).mp hb).2.2))

def gatedRepresentativeDrop (p : GatedVertex d → ℤ) (v : d.tree.Child) : ℤ :=
  p (gatedAux d v) - p (gatedCenter d v)

theorem gated_representative_drop_bounds {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) (hv : (d.backGroup v).Nonempty) :
    0 ≤ gatedRepresentativeDrop d p v ∧
      gatedRepresentativeDrop d p v ≤ gatedHeadSelector d p v := by
  obtain ⟨b, hb⟩ := hv
  have hr := gated_dual_representative d hp v
  have hh := gated_dual_own_back d hp v b hb
  unfold gatedRepresentativeDrop gatedHeadSelector
  omega

theorem gated_representative_drop_binary {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) (hv : (d.backGroup v).Nonempty) :
    gatedRepresentativeDrop d p v = 0 ∨ gatedRepresentativeDrop d p v = 1 := by
  have hh := gated_head_selector_binary d P p hp v
  have hb := gated_representative_drop_bounds d hp v hv
  omega

end TSP.Improvements20261105
