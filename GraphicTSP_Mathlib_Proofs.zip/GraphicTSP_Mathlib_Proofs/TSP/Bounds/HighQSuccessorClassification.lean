import TSP.Improvements20261105.CanonicalHeadLoad

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem unaryNext_injective_on_projectionLinks (x : E → ℝ) (s t : d.tree.Child)
    (hs : s ∈ projectionLinks d x) (ht : t ∈ projectionLinks d x)
    (he : unaryNext d s = unaryNext d t) : s=t := by
  apply Subtype.ext
  exact (projectionLinks_parent d x s hs).symm.trans
    ((congrArg (fun u : d.tree.Child => d.tree.parent u) he).trans (projectionLinks_parent d x t ht))

theorem projectionLink_receiver_head (hs : G.IsSimple) (x z : E → ℝ)
    (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (s : d.tree.Child) (hl : s ∈ projectionLinks d x) :
    (d.backGroup (unaryNext d s)).Nonempty := by
  have hi := projectionLinks_receiver_identity d hs x z hm s hl
  have hh := (Finset.mem_filter.mp hl).2.2.2.2
  have hq := hcap (d.treeEdge (unaryNext d s))
  by_contra hn
  have he := Finset.not_nonempty_iff_eq_empty.mp hn
  rw [he] at hi
  simp only [edgeSum, Finset.sum_empty] at hi
  linarith

theorem unmatched_successor_not_matching_target (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s : d.tree.Child)
    (hl : s ∈ projectionLinks d x) (hu : s ∉ matchingEndpoints id (unaryNext d) C.matching) :
    unaryNext d s ∉ C.matching.image (unaryNext d) := by
  intro hm
  obtain ⟨t, ht, he⟩ := Finset.mem_image.mp hm
  have hts := unaryNext_injective_on_projectionLinks d x t s (C.link_subset ht) hl he
  apply hu
  apply Finset.mem_union_left
  exact Finset.mem_image.mpr ⟨t, ht, hts⟩

theorem high_q_successor_classification (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (i : d.StarIndex) (hp : ProtectedHead d x z (415/2) (704/5) C i.1)
    (hu : childCount d i.1=1) (ho : outgoingBackMass d x i.1 < survivingExcess d x i.1) :
    ∃ j : d.StarIndex, j.1=unaryNext d i.1 ∧ d.centers j=(i.1 : V) ∧
      (edgeSum z (d.backGroup j.1) ≤ 1 ∨
        (1 < edgeSum z (d.backGroup j.1) ∧
          j.1 ∉ matchingEndpoints id (unaryNext d) C.matching) ∨
        (1 < edgeSum z (d.backGroup j.1) ∧ j.1 ∈ C.matching ∧
          ∃ k : d.StarIndex, k.1=unaryNext d j.1)) := by
  have he := (survivingExcess_bounds d hs hx hcap i.1).2
  have hl : i.1 ∈ projectionLinks d x :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, hp.1, hp.2.1, hu, by linarith⟩
  let j : d.StarIndex := ⟨unaryNext d i.1, projectionLink_receiver_head d hs x z hcap hm i.1 hl⟩
  refine ⟨j, rfl, projectionLinks_parent d x i.1 hl, ?_⟩
  by_cases hmass : edgeSum z (d.backGroup j.1) ≤ 1
  · exact Or.inl hmass
  · have hpos : 1 < edgeSum z (d.backGroup j.1) := lt_of_not_ge hmass
    by_cases hj : j.1 ∈ C.matching
    · right; right
      refine ⟨hpos, hj, ⟨unaryNext d j.1, projectionLink_receiver_head d hs x z hcap hm j.1 (C.link_subset hj)⟩, rfl⟩
    · right; left
      refine ⟨hpos, ?_⟩
      have hnt := unmatched_successor_not_matching_target d x z C i.1 hl hp.2.2
      intro hc
      rcases Finset.mem_union.mp hc with hsource | htarget
      · exact hj (by simpa using hsource)
      · exact hnt htarget

end TSP.Improvements20261105
