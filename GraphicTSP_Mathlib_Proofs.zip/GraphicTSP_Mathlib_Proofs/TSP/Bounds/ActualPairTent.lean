import TSP.Improvements20261105.PairSourcePacking
import TSP.Improvements20261105.PairLeafTent

/-! The all-count pair surplus is derived from the actual scored DFS.
Both choice branches are covered; no abstract packing premise is left. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_source_leaf_surplus (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (s : (d).tree.Child) (hpos : 0 < survivingExcess d x s) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      60*(1-x ((d).treeEdge s)-survivingExcess d x s)+
      24*(1-x ((d).treeEdge s)-survivingExcess d x s)+(61/5) ≤
      4*(((d).backGroup s).card+1 : ℝ) := by
  have hcount := surviving_positive_two_backs d x hx hn hcap s hpos
  have ht : (2 : ℝ) ≤ ((d).backGroup s).card := by exact_mod_cast hcount
  have hcapE := (survivingExcess_bounds d hs hx hcap s).2
  have ho : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hpref := current_pair_prefix ((d).backGroup s).card
  by_cases hscored : ScoredStar d x s
  · have hpack := scoredDFS_surviving_source_pack G x hs hc root hx hn hcap s hpos hscored
    have hlam := ScoredParameters.coefficient_bounds ((d).backGroup s).card
    have htent := current_scored_pair_tent ((d).backGroup s).card (x ((d).treeEdge s))
      (survivingExcess d x s) (outgoingBackMass d x s)
      (ScoredParameters.coefficient ((d).backGroup s).card) ht ho hlam.1.le hlam.2.le hpack hcapE
    linarith only [htent,hpref]
  · have hgreedy := scoredDFS_not_scored_greedy G x hs hc root s hscored
    have hpack := survivingExcess_back_bound d x hx hn s hpos (x ((d).treeEdge s)) hgreedy
    have htent := current_pair_tent ((d).backGroup s).card (x ((d).treeEdge s))
      (survivingExcess d x s) ht hpack hcapE
    linarith only [htent,hpref,ho]

end TSP.Improvements20261105
