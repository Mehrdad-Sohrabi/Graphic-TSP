import TSP.Improvements20261105.CanonicalProtectedLeafCost
import TSP.Improvements20261105.MultiplePairLeafCost
import TSP.Improvements20261105.MatchingLeafDisjoint

/-! Eliminate protected unmatched leaf groups from the actual global
ledger. Their original back budgets are explicit, disjoint from the
already paid families. No new geometric or projection error is used. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem canonical_multiple_pair_leaf_elimination (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (S : Finset (d).tree.Child) (hscore : ScoreComparisons d x S)
    (T : Finset (d).tree.Child) (hTS : T ⊆ S)
    (hT : ∀ s ∈ T, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (b : (d).tree.Child → ℝ) (hbcap : ∀ s, b s ≤ 1)
    (hbout : ∀ s, P.kind s = .outsideGate → b s ≤ outsideBackMass d P (fun e => x e.1) s)
    (q : (d).tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z ((d).backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, ((d).backGroup s).card ≤ 3 → ∀ e ∈ (d).backGroup s, z e ≤ q s)
    (hn : 2 ≤ Fintype.card V)
    (hprojection : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hrootStar : (d).centers rootStar = (d).tree.root)
    (R : E ⊕ (d).StarIndex → ℝ)
    (Q : E ⊕ (d).StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G (d).centers owner)
    (hrep : ∀ c, Q (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Q (.inl e) = 1-x e/2)
    (m : (d).StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x ((d).treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : (d).StarIndex, edgeSum x ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Q i)
    (hconn : FixedQConnectorValues d x hx hn hcap R)
    (hloss : ∀ i, edgeSum Q (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Q i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
      m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1)
    (hconnectors : ∀ i : (d).StarIndex, R (.inr i) = Q (.inr i))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1) :
    let L := a.paidLeafRoots d P x
    let J := a.paidLeafHeads d P x
    let KJ := pairStarHeads d (a.KLeafPairs d P x z C)
    let ML := a.multiplePairLeafRoots d P x z C
    let MJ := pairStarHeads d (a.matchingPairsForRoots d P x z C ML)
    let J0 := a.componentStarUnion d P (a.zeroLeafRoots d P x)
    let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
    48*a.value d P (fun _ => 0)+(∑ i : (d).StarIndex, cost i)-
      (704/5 : ℝ)*((∑ i ∈ fixedZeroTerminalHeads d x, m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, m i)) ≤
      (∑ s ∈ a.selectedHeads d,
        (24*(edgeSum z ((d).backGroup s)-gatedFreeBase d s)+refinedIncidenceCharge d x z S T s-
          24*accountedCoupon d P b s+24*couponResidual d P (fun e => x e.1) b s))+
      24*((a.headfulLeafComponents d P).card-L.card-(a.KLeafRoots d P x z C).card-ML.card-1-(a.selectedRootHeads d).card)-
      (162/19)*(∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z S r : ℝ))+
      72*(∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s)+
      (244/5)*(edgeSum x Finset.univ-Fintype.card V)-12*Chapter11.totalOverage d x+
      (4*∑ i ∈ KJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ MJ, (((d).backGroup i.1).card : ℝ))+
      (∑ i ∈ Finset.univ \ ((J ∪ KJ) ∪ MJ), cost i)-
      (704/5 : ℝ)*((∑ i ∈ fixedZeroTerminalHeads d x \ J0, m i)+
        (∑ i ∈ fixedPositiveTerminalHeads d x \ a.positiveTerminalLeafHeads d P x, m i))+
      a.zeroLeafOwnedError d P x := by
  let J := a.paidLeafHeads d P x
  let KJ := pairStarHeads d (a.KLeafPairs d P x z C)
  let ML := a.multiplePairLeafRoots d P x z C
  let MJ := pairStarHeads d (a.matchingPairsForRoots d P x z C ML)
  let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
  have hledger := canonical_protected_leaf_elimination G x z hs hconnected root hc x₀ hx₀ hpositive
    P hP t ht f hf hb a ha hcan hx hcap hz hzx S hscore T hTS hT b hbcap hbout q hq hpack hsmall hn
    hprojection C owner ho rootStar hrootStar R Q hQ hrep hbacks m hm0 hm hguarded hconn hloss hmpositive hterminal
  have hbase : FixedQConnectorValues d x hx hn hcap Q := by
    constructor
    · intro i
      exact (hconnectors i.1).symm.trans (hconn.1 i)
    · intro i hi
      rw [← hconnectors i]
      exact hconn.2 i hi
  have hleaf := scoredDFS_multiple_pair_leaf_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hconn hrep hbacks hloss hterminal hguarded P a ha
  have hdis := a.multiplePairHeads_disjoint_prior d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hsub : MJ ⊆ Finset.univ \ (J ∪ KJ) := by
    intro i hi
    exact Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun hj => Finset.disjoint_left.mp hdis hi hj⟩
  have hdiff : (Finset.univ \ (J ∪ KJ)) \ MJ = Finset.univ \ ((J ∪ KJ) ∪ MJ) := by
    ext i
    simp only [Finset.mem_sdiff,Finset.mem_union,Finset.mem_univ,true_and]
    exact not_or.symm
  have hsum := Finset.sum_sdiff hsub (f := cost)
  rw [hdiff] at hsum
  dsimp only [J,KJ,ML,MJ,cost] at hsum
  dsimp only at hledger hleaf ⊢
  linarith only [hledger,hleaf,hsum]

end TSP.Improvements20261105
