import TSP.Improvements20261105.CurrentProjectedGuardedTargetGain
import TSP.Improvements20261105.MatchingTargetMassIdentity

/-! Actual full target projection identifies the source/target mass relation
and the H gain used by the finite paired inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem guardedMatchingTargetGain_mass_formula (hs : G.IsSimple) (x z : E → ℝ)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (s t : d.tree.Child) (hsM : s ∈ C.matching) (ht : t=unaryNext d s) :
    guardedMatchingTargetGain d x z s t=
      if (13/40 : ℝ) ≤ x (d.treeEdge t) then max 0 (max
        ((415/2)*(1-edgeSum z (d.backGroup t))+
          (704/5)*(2-x (d.treeEdge t)-edgeSum z (d.backGroup t))-targetForceSlack d x 24 4 t-(48)*x (d.treeEdge t))
        ((415/2)*(x (d.treeEdge t)-1)+(704/5)*(survivingExcess d x s+x (d.treeEdge s))-
          targetForceSlack d x 24 4 t-(48)*x (d.treeEdge t))) else 0 := by
  have hh := matching_target_mass_identity d hs x z hm C s t hsM ht
  unfold guardedMatchingTargetGain
  split_ifs
  · congr 2 <;> linarith only [hh]
  · rfl

end TSP.Improvements20261105
