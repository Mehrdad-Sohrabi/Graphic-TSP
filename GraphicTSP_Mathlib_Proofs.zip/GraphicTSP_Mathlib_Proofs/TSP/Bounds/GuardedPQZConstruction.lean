import TSP.Improvements20261105.FixedForcedPQZ
import TSP.Improvements20261105.TerminalPRepair
import TSP.Improvements20261105.RaisedQNonremovable
import TSP.Improvements20261105.TerminalGuardSelection

/-! Fixed cover and forces, terminal P endpoints, one simultaneously
guarded Q, and then canonical Z. This is point construction and exact
accounting; it does not assert the still-unproved global ratio budget. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def currentGuardedP (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex) : E ⊕ d.StarIndex → ℝ :=
  generalPoint d owner rootStar x (terminalPIncrease d x (fixedPositiveTerminalChildren d x)
    (fun i => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C
      (fixedHForceTargets d x z (415/2) (704/5) C) i.1))

theorem currentGuardedP_feasible (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root) :
    currentGuardedP d x z C owner rootStar ∈ projectedFrameworkTwo G d.centers owner := by
  apply terminal_P_feasible d hs hc x hx hn hcap owner ho rootStar hroot
  exact forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) C (fixedHForceTargets d x z (415/2) (704/5) C)
    (fixedHForceTargets_subset d x z (415/2) (704/5) C)

theorem currentGuardedP_nonremovable (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex) :
    edgeSum (currentGuardedP d x z C owner rootStar) (nonremovableRepresentatives d.stars) =
      ((Finset.univ \ removableEdges d.stars).card : ℝ)/3 := by
  unfold edgeSum nonremovableRepresentatives
  rw [Finset.sum_map]
  simp only [Function.Embedding.inl_apply, currentGuardedP, generalPoint_rep, pRepresentatives]
  rw [Finset.sum_congr rfl (fun e he => repairedNonloopPoint_nonremovable d x _ he)]
  simp [div_eq_mul_inv]

theorem exists_current_guarded_PQZ (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root) :
    ∃ C : ProjectedCoverWitness d x z (415/2) (704/5),
    ∃ (Y R Z : E ⊕ d.StarIndex → ℝ) (m : d.StarIndex → ℝ) (a : GatedDrops d),
      let A := currentGuardedP d x z C owner rootStar
      let U := pqConnectorArm d x (415/2) (704/5) A R
      let W := pqDeficitArm d x (415/2) (704/5) A R
      let t := extendStarValue d (fun i => (max (U i) (W i)-W i)/48)
      A ∈ projectedFrameworkTwo G d.centers owner ∧
      Y ∈ projectedFrameworkTwo G d.centers owner ∧
      R ∈ projectedFrameworkTwo G d.centers owner ∧
      Z ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
        fixedQIncrease d x (fixedPositiveTerminalChildren d x) c) ∧
      (∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2) ∧
      (∀ i, R (.inr i) = Y (.inr i)) ∧
      FixedQConnectorValues d x hx hn hcap R ∧
      a.Admissible d (fixedGatePlan d x) ∧
      (∃ f : GatedArc d → ℝ,
        Chapter06.Balanced (gatedNetwork d (fixedGatePlan d x)) f ∧
        RealFlowBounds (gatedLower d (fixedGatePlan d x)) (gatedAugmentedUpper d (fixedGatePlan d x) t) f ∧
        CanonicalGatedFor d (fixedGatePlan d x) t f (a.potential d (fixedGatePlan d x))) ∧
      (∀ i ∈ fixedZeroTerminalHeads d x ∪ fixedPositiveTerminalHeads d x, 0 ≤ m i) ∧
      (∀ i ∈ fixedZeroTerminalHeads d x,
        (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
          max (x (d.treeEdge i.1)-zeroGuardCapacity d x Y i) 0) 0 ≤ m i) ∧
      (∀ i ∈ fixedPositiveTerminalHeads d x,
        m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1) ∧
      edgeSum R (nonremovableRepresentatives d.stars) ≤
        edgeSum x (Finset.univ \ removableEdges d.stars)/2-
        ((∑ i ∈ fixedZeroTerminalHeads d x, m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, m i)) ∧
      (∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
        (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
        2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0)) ∧
      (∀ i, edgeSum x (d.backGroup i.1) ≤ 1 →
        max (R (.inr i)-edgeSum x (d.stars i)/2)
          ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
            -zeroQCredit d x Y i) ∧
      (∀ i ∈ fixedPositiveTerminalHeads d x,
        (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
          -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1) ∧
      edgeSum Z (nonremovableRepresentatives d.stars) = ((Finset.univ \ removableEdges d.stars).card : ℝ)/3 ∧
      (∑ i : d.StarIndex,
        max (U i+72*(Z (.inr i)-gatedArmBase d i.1))
          (W i+72*((d.stars i).card-1-edgeSum Z (starRepresentatives d.stars i)-gatedArmBase d i.1))) ≤
      (∑ i : d.StarIndex, jointHeadTerm (U i) (W i) (a.head i.1 : ℝ)) +
        48*a.value d (fixedGatePlan d x) (fun _ => 0) := by
  obtain ⟨C⟩ := exists_fixed_projected_cover d hs x z hx hn hcap hm (415/2) (704/5)
    (by norm_num) (by norm_num) (by norm_num)
  let A := currentGuardedP d x z C owner rootStar
  have hA := currentGuardedP_feasible d hs hc x z hx hn hcap hm C owner ho rootStar hroot
  obtain ⟨Y, R, m, hY, hR, hr, hb, heq, hconn, hm0, hmz, hmp, hsave, hloss, hzero, hpos⟩ :=
    exists_fixed_guarded_Q d hs x hx hn hcap owner ho
  have htQ := (fixedQIncrease_admissible d hs hx hn hcap (fixedPositiveTerminalChildren d x)
    (fixedPositiveTerminalChildren_admissible d x)).2.2.1
  rw [raised_Q_nonremovable_sum d x hx hn _ htQ Y hr] at hsave
  obtain ⟨Z, a, hZ, ha, hf, hN, hcost⟩ := exists_joint_coordinate_completion d hs hc
    (fixedGatePlan d x) (fixedGatePlan_valid d x) owner ho
    (pqConnectorArm d x (415/2) (704/5) A R) (pqDeficitArm d x (415/2) (704/5) A R)
    24 (by norm_num)
  refine ⟨C, Y, R, Z, m, a, hA, hY, hR, hZ, hr, hb, heq, hconn, ha, ?_,
    hm0, hmz, hmp, hsave, hloss, hzero, hpos, hN, ?_⟩
  · simpa only [show (2*(24 : ℝ)) = 48 by norm_num] using hf
  · simpa only [show (3*(24 : ℝ)) = 72 by norm_num, show (2*(24 : ℝ)) = 48 by norm_num] using hcost

end TSP.Improvements20261105
