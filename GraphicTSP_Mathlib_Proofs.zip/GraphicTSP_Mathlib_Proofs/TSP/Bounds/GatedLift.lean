import TSP.Improvements20261105.GatedCoverage

/-! A constructive feasible lift of the ordinary DFS circulation: each back
arc is routed through its tail, head and paid return. All bounded free and
bypass arcs have zero flow in this starting circulation. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 1000000
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedConnectorRoute (v : d.tree.Child) (a : GatedArc d) : ℝ :=
  singleArcFlow (gatedPrefixArc d v) a + singleArcFlow (gatedSuffixArc d v) a

noncomputable def gatedPaidReturnRoute (P : GatePlan d) (v : d.tree.Child) (a : GatedArc d) : ℝ :=
  singleArcFlow (gatedPaidArc d v) a +
    if P.IsReceiver d v then singleArcFlow (gatedSuffixArc d v) a else gatedConnectorRoute d v a

noncomputable def gatedBackRoute (P : GatePlan d) (b : BackEdge d) (a : GatedArc d) : ℝ :=
  singleArcFlow (gatedTailArc d (d.lower b.1)) a + singleArcFlow (gatedBackArc d b) a +
    (if P.OutsideBack d b then singleArcFlow (gatedFeedArc d (d.anchor b.1)) a else 0) +
      gatedPaidReturnRoute d P (d.anchor b.1) a

noncomputable def gatedLiftRoute (P : GatePlan d) : FlowArc d → GatedArc d → ℝ :=
  Sum.elim (Sum.elim (gatedConnectorRoute d) (fun v => singleArcFlow (gatedRepArc d v)))
    (gatedBackRoute d P)

theorem gatedConnectorRoute_divergence (P : GatePlan d) (v : d.tree.Child) (w : GatedVertex d) :
    flowDivergence (gatedNetwork d P) (gatedConnectorRoute d v) w =
      (if gatedCenter d (d.tree.parent v) = w then 1 else 0) -
      (if gatedAux d v = w then 1 else 0) := by
  change flowDivergence _ (fun a => _ + _) w = _
  rw [flowDivergence_add, singleArcFlow_divergence, singleArcFlow_divergence]
  simp only [gatedNetwork, Sum.elim_inl, Sum.elim_inr, gatedExtraSrc, gatedExtraDst]
  ring

theorem gatedPaidReturnRoute_divergence (P : GatePlan d) (v : d.tree.Child) (w : GatedVertex d) :
    flowDivergence (gatedNetwork d P) (gatedPaidReturnRoute d P v) w =
      (if gatedHead d v = w then 1 else 0) - (if gatedAux d v = w then 1 else 0) := by
  by_cases hv : P.IsReceiver d v
  · have he : gatedPaidReturnRoute d P v = fun a =>
        singleArcFlow (gatedPaidArc d v) a + singleArcFlow (gatedSuffixArc d v) a := by
      funext a; simp [gatedPaidReturnRoute, hv]
    rw [he, flowDivergence_add, singleArcFlow_divergence, singleArcFlow_divergence]
    simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, hv]
  · have he : gatedPaidReturnRoute d P v = fun a =>
        singleArcFlow (gatedPaidArc d v) a + gatedConnectorRoute d v a := by
      funext a; simp [gatedPaidReturnRoute, hv]
    rw [he, flowDivergence_add, singleArcFlow_divergence, gatedConnectorRoute_divergence]
    simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, hv]

theorem gatedBackRoute_divergence (P : GatePlan d) (b : BackEdge d) (w : GatedVertex d) :
    flowDivergence (gatedNetwork d P) (gatedBackRoute d P b) w =
      (if gatedCenter d (d.lower b.1) = w then 1 else 0) -
      (if gatedAux d (d.anchor b.1) = w then 1 else 0) := by
  change flowDivergence _ (fun a => (_ + _) + _ + _) w = _
  rw [flowDivergence_add, flowDivergence_add, flowDivergence_add,
    singleArcFlow_divergence, singleArcFlow_divergence, gatedPaidReturnRoute_divergence]
  by_cases hb : P.OutsideBack d b
  · simp only [hb, if_true, singleArcFlow_divergence, gatedNetwork, Sum.elim_inl,
      Sum.elim_inr, gatedExtraSrc, gatedExtraDst]
    ring
  · simp only [hb, if_false, zero_flow_divergence, gatedNetwork, Sum.elim_inl,
      Sum.elim_inr]
    ring

theorem gatedLiftRoute_divergence (P : GatePlan d) (a : FlowArc d) (w : GatedVertex d) :
    flowDivergence (gatedNetwork d P) (gatedLiftRoute d P a) w =
      (if Sum.inl (flowSrc d a) = w then 1 else 0) -
      (if Sum.inl (flowDst d a) = w then 1 else 0) := by
  rcases a with (v | v) | b
  · exact gatedConnectorRoute_divergence d P v w
  · exact singleArcFlow_divergence (gatedNetwork d P) (gatedRepArc d v) w
  · exact gatedBackRoute_divergence d P b w

theorem gatedLiftRoute_nonnegative (P : GatePlan d) (a : FlowArc d) (b : GatedArc d) :
    0 ≤ gatedLiftRoute d P a b := by
  rcases a with (v | v) | e <;>
    simp only [gatedLiftRoute, Sum.elim_inl, Sum.elim_inr, gatedBackRoute,
      gatedPaidReturnRoute, gatedConnectorRoute, singleArcFlow] <;>
    split_ifs <;> norm_num

theorem gated_lift_balanced (P : GatePlan d) (g : FlowArc d → ℝ)
    (hg : Balanced (ordinaryFlowNetwork d) g) :
    Balanced (gatedNetwork d P) (routeFlow (gatedLiftRoute d P) g) :=
  routeFlow_balanced _ _ Sum.inl _ (gatedLiftRoute_divergence d P) g hg

theorem gatedLiftRoute_bounded_zero (P : GatePlan d) (a : FlowArc d)
    (v : d.tree.Child) (k : Fin 8) (hk : k = 1 ∨ k = 4 ∨ k = 6 ∨ k = 7) :
    gatedLiftRoute d P a (.inr (.inr (v, k))) = 0 := by
  rcases hk with rfl | rfl | rfl | rfl <;>
    rcases a with (s | s) | b <;>
    simp [gatedLiftRoute, gatedConnectorRoute, gatedBackRoute, gatedPaidReturnRoute,
      singleArcFlow]

theorem gated_lift_upper (P : GatePlan d) (g : FlowArc d → ℝ)
    (a : GatedArc d) (u : ℕ) (hu : gatedUpper d P a = some u) :
    routeFlow (gatedLiftRoute d P) g a ≤ u := by
  rcases a with a | (v | ⟨v, k⟩)
  · simp [gatedUpper] at hu
  · simp [gatedUpper] at hu
  · have hk : k = 1 ∨ k = 4 ∨ k = 6 ∨ k = 7 := by
      by_contra hh
      push_neg at hh
      simp [gatedUpper, hh.1, hh.2.1, hh.2.2.1, hh.2.2.2] at hu
    have hz : routeFlow (gatedLiftRoute d P) g (.inr (.inr (v, k))) = 0 := by
      unfold routeFlow
      simp only [gatedLiftRoute_bounded_zero d P _ v k hk, mul_zero, Finset.sum_const_zero]
    rw [hz]
    exact Nat.cast_nonneg _

theorem gated_lift_single_lower (P : GatePlan d) (g : FlowArc d → ℝ)
    (hg : ∀ a, 0 ≤ g a) (a : FlowArc d) (b : GatedArc d)
    (hab : gatedLiftRoute d P a b = 1) : g a ≤ routeFlow (gatedLiftRoute d P) g b := by
  have hh := Finset.single_le_sum (s := Finset.univ)
    (fun e _ => mul_nonneg (hg e) (gatedLiftRoute_nonnegative d P e b)) (Finset.mem_univ a)
  simpa [hab, routeFlow] using hh

end TSP.Improvements20261105
