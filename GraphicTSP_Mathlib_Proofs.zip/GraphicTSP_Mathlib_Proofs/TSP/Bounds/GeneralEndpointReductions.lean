import TSP.Improvements20261105.ConstructedGeneralPairContext
import TSP.Improvements20261105.GeneralEndpointOfPairPayments
import TSP.Improvements20261105.GeneralCapping
import TSP.Improvements20261105.GeneralGluing

/-! The endpoint is reduced solely to the explicit local pair theorem.
These conditional results must not be presented as completed ratio proofs
until AllGeneralPairPayments has itself been proved. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators

/-- Universal closure of the one still-open local inequality. -/
def AllGeneralPairPayments : Prop :=
  ∀ (V E : Type) [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
    (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
    (K : GeneralPairPaymentContext G x₀ x z hs hc root), K.PairPayments G x₀ x z hs hc root

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem general_block_tour_of_local_pairs (hlocal : AllGeneralPairPayments)
    (G : Graph V E) (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (hopt : edgeSum x₀ Finset.univ=G.subtourLP) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ (14524*G.subtourLP-8166)/10481 := by
  obtain ⟨x,hx,hbox,hoptx,hdom,_⟩ := dominating_capped_sparse_optimum G hs hc hx₀ hpositive hopt
  letI : LinearOrder E := LinearOrder.lift' (Fintype.equivFin E) (Fintype.equivFin E).injective
  obtain ⟨root⟩ := hc.2.1.1
  obtain ⟨z,⟨K⟩⟩ := exists_general_pair_context G x₀ x hs hc.2.1 root hc hx₀ hpositive hx
    (fun e => (hbox e).2) hdom
  have ht := K.tsp_bound G x₀ x z hs hc.2.1 root (hlocal V E G x₀ x z hs hc.2.1 root K)
  rw [hoptx] at ht
  obtain ⟨c,hct,hlen⟩ := tsp_attained G hc.2.1
  exact ⟨c,hct,by rw [hlen]; exact ht⟩

theorem general_connected_affine_tour_of_local_pairs (hlocal : AllGeneralPairPayments)
    (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected) (hn : 2 ≤ Fintype.card V) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ (14524*G.subtourLP-8086)/10481 := by
  apply improved_general_tour_of_block_bound ?_ G hs hc hn
  intro V' E' _ _ _ _ H hH htwo x hx hp ho
  exact general_block_tour_of_local_pairs hlocal H hH htwo x hx hp ho

theorem general_connected_tour_of_local_pairs (hlocal : AllGeneralPairPayments)
    (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ (14524/10481 : ℝ)*G.subtourLP := by
  apply tour_bound_of_positive_extreme_blocks (14524/10481) (by norm_num) ?_ V E G hs hc
  intro V' E' _ _ _ _ H hH htwo x hx hp ho
  obtain ⟨c,hct,hlen⟩ := general_block_tour_of_local_pairs hlocal H hH htwo x hx hp ho
  exact ⟨c,hct,by linarith only [hlen]⟩

theorem general_subtour_ratio_of_local_pairs (hlocal : AllGeneralPairPayments)
    (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected) (hn : 2 ≤ Fintype.card V) :
    (G.tsp : ℝ)/G.subtourLP ≤ (14524/10481 : ℝ) := by
  obtain ⟨c,hct,hlen⟩ := general_connected_tour_of_local_pairs hlocal G hs hc
  have ht := (Nat.cast_le.mpr (tsp_le_tour G hct)).trans hlen
  have hp : 0 < G.subtourLP := lt_of_lt_of_le
    (by exact_mod_cast (show 0 < Fintype.card V by omega)) (subtourLP_ge_card G hc hn)
  exact (div_le_iff₀ hp).mpr ht

end TSP.Improvements20261105
