import TSP.Improvements20261105.RefinedIncidenceCharge
import TSP.Improvements20261105.SignedIncidenceCaps

/-! Greedy star packing controls both incidence ramps without a degree cutoff. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {I : Type} [Fintype I] [DecidableEq I]

theorem greedy_ramp_mass_bound (S : Finset I) (z : I → ℝ) (q : ℝ)
    (hq : 0 ≤ q) (hz : ∀ i ∈ S, 0 ≤ z i) (hzq : ∀ i ∈ S, z i ≤ q)
    (hpack : (∑ i ∈ S, z i) + q ≤ 2) :
    (∑ i ∈ S, z i) - 1 + (∑ i ∈ S, incidenceRamp (1/2) (z i)) ≤ 2 := by
  let H := S.filter (fun i => (1/4 : ℝ) < z i)
  have hsum : (∑ i ∈ H, z i) ≤ ∑ i ∈ S, z i :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun i hi _ => hz i hi)
  have hqsum : (∑ i ∈ H, z i) ≤ (H.card : ℝ) * q := by
    have hh := Finset.sum_le_sum (s := H) (fun i hi => hzq i (Finset.mem_filter.mp hi).1)
    simpa using hh
  have hquarter : (H.card : ℝ) / 4 ≤ ∑ i ∈ H, z i := by
    have hh := Finset.sum_le_sum (s := H) (fun i hi => (Finset.mem_filter.mp hi).2.le)
    simpa [div_eq_mul_inv] using hh
  have hcardR : (H.card : ℝ) ≤ 8 := by linarith
  have hcard : H.card ≤ 8 := by exact_mod_cast hcardR
  have hr : (∑ i ∈ S, incidenceRamp (1/2) (z i)) =
      2 * (∑ i ∈ H, z i) - (H.card : ℝ) / 2 := by
    calc
      _ = ∑ i ∈ H, (2 * z i - 1/2) := by
        rw [Finset.sum_filter]
        apply Finset.sum_congr rfl
        intro i hi
        by_cases hh : (1/4 : ℝ) < z i
        · simp only [if_pos hh, incidenceRamp]
          norm_num only
          exact max_eq_left (by linarith)
        · simp only [if_neg hh, incidenceRamp]
          norm_num only
          exact max_eq_right (by linarith)
      _ = _ := by
        simp only [Finset.sum_sub_distrib, ← Finset.mul_sum, Finset.sum_const, nsmul_eq_mul]
        ring
  rw [hr]
  interval_cases hk : H.card <;> norm_num [hk] at hqsum hquarter ⊢ <;> linarith

theorem signed_ramp_convex (z : ℝ) (hz : 0 ≤ z) :
    incidenceRamp (9/20) z ≤ (9/10) * incidenceRamp (1/2) z + (1/10) * z := by
  have h1 := le_max_left (2*z-1/2) (0:ℝ)
  have h0 := le_max_right (2*z-1/2) (0:ℝ)
  unfold incidenceRamp
  norm_num only
  apply max_le <;> linarith

theorem greedy_signed_ramp_mass_bound (S : Finset I) (z : I → ℝ) (q : ℝ)
    (hq : 0 ≤ q) (hz : ∀ i ∈ S, 0 ≤ z i) (hzq : ∀ i ∈ S, z i ≤ q)
    (hpack : (∑ i ∈ S, z i) + q ≤ 2) :
    (∑ i ∈ S, z i) - 1 + ((∑ i ∈ S, incidenceRamp (9/20) (z i)) - 1/10) ≤ 2 := by
  have hold := greedy_ramp_mass_bound S z q hq hz hzq hpack
  have hconvex := Finset.sum_le_sum (s := S) (fun i hi => signed_ramp_convex (z i) (hz i hi))
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum] at hconvex
  linarith

theorem greedy_ramp_quadratic (z q : ℝ) (hz : 0 ≤ z) (hzq : z ≤ q) :
    incidenceRamp (1/2) z ≤ 2*q*z := by
  have hprod : 0 ≤ z*(q-z) := mul_nonneg hz (sub_nonneg.mpr hzq)
  unfold incidenceRamp
  norm_num only
  apply max_le
  · nlinarith [sq_nonneg (2*z-1)]
  · nlinarith

end TSP.Improvements20261105
