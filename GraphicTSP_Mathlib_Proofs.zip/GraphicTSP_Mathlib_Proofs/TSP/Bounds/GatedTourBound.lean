import TSP.Improvements20261105.GatedGadgets

/-! The actual integral gated flow produces an original-graph tour. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedNatBacks (g : GatedArc d → ℕ) (e : E) : ℕ :=
  if h : e ∈ d.backEdges then g (gatedBackArc d ⟨e, h⟩) else 0

@[simp] theorem gatedBackVector_nat (g : GatedArc d → ℕ) (e : E) :
    gatedBackVector d (fun a => (g a : ℝ)) e = (gatedNatBacks d g e : ℝ) := by
  unfold gatedBackVector gatedNatBacks
  split_ifs <;> simp

theorem gatedPositiveBacks_nat (g : GatedArc d → ℕ) :
    gatedPositiveBacks d (fun a => (g a : ℝ)) = positiveBackSet d (gatedNatBacks d g) := by
  ext b
  simp [gatedPositiveBacks, positiveBackSet]

noncomputable def gatedUsedBypasses (g : GatedArc d → ℕ) : Finset d.tree.Child :=
  Finset.univ.filter (fun v => 0 < g (gatedBypassArc d v))

theorem gated_used_bypass_bit (P : GatePlan d) (g : GatedArc d → ℕ)
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) (fun a => (g a : ℝ)))
    (v : d.tree.Child) : (if v ∈ gatedUsedBypasses d g then (1 : ℝ) else 0) =
      (g (gatedBypassArc d v) : ℝ) := by
  have hh : g (gatedBypassArc d v) ≤ 1 := by
    exact_mod_cast (gated_bypass_box d P (fun a => (g a : ℝ)) hb v).2
  by_cases hz : g (gatedBypassArc d v) = 0
  · simp [gatedUsedBypasses, hz]
  · have ho : g (gatedBypassArc d v) = 1 := by omega
    simp [gatedUsedBypasses, ho]

theorem gated_integral_tour_bound (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.ValidGadgets d) (g : GatedArc d → ℕ)
    (hg : Balanced (gatedNetwork d P) (fun a => (g a : ℝ)))
    (hb : OptionalFlowBounds (gatedLower d P) (gatedUpper d P) (fun a => (g a : ℝ))) :
    (G.tsp : ℝ) ≤ (4 * Fintype.card V - 2) / 3 +
      (2 / 3) * ∑ v : d.tree.Child, (g (gatedPaidArc d v) : ℝ) := by
  obtain ⟨owner, ho⟩ := exists_validOwner d.stars d.dfs_removable_system.2.1
  obtain ⟨rootStar, hroot, _⟩ := root_star_exists d hc (twoVertexConnected_min_degree G hs hc _)
  have hrootParent : d.tree.parent rootStar.1 = d.tree.root := hroot
  have hrzero : (g (gatedBypassArc d rootStar.1) : ℝ) = 0 :=
    gated_bypass_disabled d P (fun a => (g a : ℝ)) hb rootStar.1 (hP.root rootStar.1 hroot)
  have hrootR : rootStar.1 ∉ gatedUsedBypasses d g := by
    have hn : g (gatedBypassArc d rootStar.1) = 0 := by exact_mod_cast hrzero
    simp [gatedUsedBypasses, hn]
  have hwitness : ∀ v ∈ gatedUsedBypasses d g,
      OriginalBypassWitness d (positiveBackSet d (gatedNatBacks d g)) v := by
    intro v hv
    have hp : 0 < (g (gatedBypassArc d v) : ℝ) := by
      exact_mod_cast (Finset.mem_filter.mp hv).2
    simpa only [gatedPositiveBacks_nat] using
      gated_positive_bypass_witness d hs P hP (fun a => (g a : ℝ)) hg hb v hp
  have hcover : ∀ v : d.tree.Child, ¬(d.backGroup v).Nonempty →
      1 ≤ ∑ b ∈ G.cut (subtreeVertices d v) ∩ d.backEdges, gatedNatBacks d g b := by
    intro v hv
    have hh := gated_nonremovable_coverage d P hP.tree (fun a => (g a : ℝ)) hg hb v hv
    simp only [gatedBackVector_nat] at hh
    exact_mod_cast hh
  have hrootpay : (∑ b ∈ d.backGroup rootStar.1, (gatedNatBacks d g b : ℝ)) - 2 ≤
      (g (gatedPaidArc d rootStar.1) : ℝ) := by
    have hh := gated_head_payment d P hP.tree (fun a => (g a : ℝ)) hg hb rootStar.1
    simpa only [gatedBackVector_nat, hrootParent, if_pos rfl, hrzero, sub_zero] using hh
  have hnr : ∀ i : d.StarIndex, i ≠ rootStar → d.tree.parent i.1 ≠ d.tree.root := by
    intro i hi hr
    exact hi (root_star_unique d hc i rootStar hr hroot)
  have hconnpay : ∀ i : d.StarIndex, i ≠ rootStar →
      1 - (∑ b ∈ deletedSubtreeCut d i.1, (gatedNatBacks d g b : ℝ)) ≤
        (g (gatedPaidArc d i.1) : ℝ) := by
    intro i hi
    simpa only [gatedBackVector_nat] using
      gated_connector_payment d P hP.tree (fun a => (g a : ℝ)) hg hb i.1 (hnr i hi)
  have hheadpay : ∀ i : d.StarIndex, i ≠ rootStar →
      (∑ b ∈ d.backGroup i.1, (gatedNatBacks d g b : ℝ)) -
        (if i.1 ∈ gatedUsedBypasses d g then 1 else 0) - 1 ≤ (g (gatedPaidArc d i.1) : ℝ) := by
    intro i hi
    rw [gated_used_bypass_bit d P g hb]
    simpa only [gatedBackVector_nat, if_neg (hnr i hi)] using
      gated_head_payment d P hP.tree (fun a => (g a : ℝ)) hg hb i.1
  have ht := integral_binary_Z_paid_bound d hs hc owner ho (gatedNatBacks d g)
    (gatedUsedBypasses d g) hwitness hcover rootStar hroot hrootR
    (fun i => (g (gatedPaidArc d i.1) : ℝ)) (fun _ => Nat.cast_nonneg _)
    hrootpay hconnpay hheadpay
  have hsum : (∑ i : d.StarIndex, (g (gatedPaidArc d i.1) : ℝ)) ≤
      ∑ v : d.tree.Child, (g (gatedPaidArc d v) : ℝ) := by
    have he : (∑ i : d.StarIndex, (g (gatedPaidArc d i.1) : ℝ)) =
        ∑ v ∈ Finset.univ.filter (fun v : d.tree.Child => (d.backGroup v).Nonempty),
          (g (gatedPaidArc d v) : ℝ) :=
      (Finset.sum_subtype _ (by intro; simp) (fun v => (g (gatedPaidArc d v) : ℝ))).symm
    rw [he]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
      (fun v _ _ => Nat.cast_nonneg _)
  linarith

theorem exists_gated_dual_tour_bound (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.ValidGadgets d) :
    ∃ p : GatedVertex d → ℤ,
      (∀ a, gatedUpper d P a = none →
        p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)) ∧
      (G.tsp : ℝ) ≤ (4 * Fintype.card V - 2) / 3 + (2 / 3) *
        optionalDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
          (gatedLower d P) (gatedUpper d P) (fun v => (p v : ℝ)) := by
  obtain ⟨g, p, hg, hb, hp, heq⟩ := gated_integral_primal_dual d hs hc P
  refine ⟨p, hp, ?_⟩
  rw [heq]
  exact gated_integral_tour_bound d hs hc P hP g hg hb

end TSP.Improvements20261105
