import TSP.Improvements20261105.IntegralPotentials

/-! An integer potential attains at least the value of any real potential
for a linear objective plus integer-breakpoint arc penalties. The result
allows arbitrary real coefficients and preserves every integer arc bound. -/
namespace TSP.Improvements20261105
open Graph Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def differenceObjective (G : Graph V E)
    (α : V → ℝ) (β : E → ℝ) (c : E → ℤ) (p : V → ℝ) : ℝ :=
  (∑ v, α v * p v) + ∑ e, β e * max (p (G.dst e) - p (G.src e) - c e) 0

theorem differenceObjective_expectation {ι : Type} [Fintype ι]
    (G : Graph V E) (α : V → ℝ) (β : E → ℝ) (c : E → ℤ)
    (p : V → ℝ) (w : ι → ℝ) (P : ι → V → ℤ)
    (hm : ∀ v, ∑ i, w i * (P i v : ℝ) = p v)
    (hp : ∀ u v (k : ℤ), (∑ i, w i * max ((P i v : ℝ) - (P i u : ℝ) - k) 0) =
      max (p v - p u - k) 0) :
    (∑ i, w i * differenceObjective G α β c (fun v => (P i v : ℝ))) =
      differenceObjective G α β c p := by
  unfold differenceObjective
  simp_rw [mul_add, Finset.mul_sum]
  rw [Finset.sum_add_distrib]
  congr 1
  · rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro v _
    calc
      (∑ i, w i * (α v * (P i v : ℝ))) = α v * ∑ i, w i * (P i v : ℝ) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i _
        ring
      _ = _ := by rw [hm]
  · rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro e _
    calc
      (∑ i, w i * (β e * max ((P i (G.dst e) : ℝ) - (P i (G.src e) : ℝ) - c e) 0)) =
          β e * ∑ i, w i * max ((P i (G.dst e) : ℝ) - (P i (G.src e) : ℝ) - c e) 0 := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i _
        ring
      _ = _ := by rw [hp]

theorem exists_value_ge_weighted_mean {ι : Type} [Fintype ι]
    (w a : ι → ℝ) (hw : ∀ i, 0 ≤ w i) (hsum : ∑ i, w i = 1) :
    ∃ i, (∑ j, w j * a j) ≤ a i := by
  classical
  have hne : (Finset.univ : Finset ι).Nonempty := by
    by_contra hn
    have he : (Finset.univ : Finset ι) = ∅ := Finset.not_nonempty_iff_eq_empty.mp hn
    rw [he, Finset.sum_empty] at hsum
    norm_num at hsum
  obtain ⟨i, _, hi⟩ := Finset.exists_max_image Finset.univ a hne
  refine ⟨i, ?_⟩
  calc
    _ ≤ ∑ j, w j * a i := Finset.sum_le_sum
      (fun j _ => mul_le_mul_of_nonneg_left (hi j (Finset.mem_univ _)) (hw j))
    _ = a i := by rw [← Finset.sum_mul, hsum, one_mul]

theorem exists_integral_potential_no_smaller (G : Graph V E)
    (α : V → ℝ) (β : E → ℝ) (c : E → ℤ) (p : V → ℝ) :
    ∃ P : V → ℤ,
      (∀ u v (k : ℤ), p v - p u ≤ (k : ℝ) → P v - P u ≤ k) ∧
      differenceObjective G α β c p ≤ differenceObjective G α β c (fun v => (P v : ℝ)) := by
  obtain ⟨ι, hi, w, P, hw, hsum, hbounds, hm, hp⟩ := finite_integral_potential_rounding p
  obtain ⟨i, hval⟩ := exists_value_ge_weighted_mean w
    (fun i => differenceObjective G α β c (fun v => (P i v : ℝ))) hw hsum
  rw [differenceObjective_expectation G α β c p w P hm hp] at hval
  exact ⟨P i, hbounds i, hval⟩

theorem integral_arc_dual_no_smaller (G : Graph V E)
    (α : V → ℝ) (β : E → ℝ) (c : E → ℤ) (free : Finset E)
    (p : V → ℝ) (hfree : ∀ e ∈ free, p (G.dst e) - p (G.src e) ≤ (c e : ℝ)) :
    ∃ P : V → ℤ,
      (∀ e ∈ free, P (G.dst e) - P (G.src e) ≤ c e) ∧
      differenceObjective G α β c p ≤ differenceObjective G α β c (fun v => (P v : ℝ)) := by
  obtain ⟨P, hb, hval⟩ := exists_integral_potential_no_smaller G α β c p
  exact ⟨P, fun e he => hb (G.src e) (G.dst e) (c e) (hfree e he), hval⟩

end TSP.Improvements20261105
