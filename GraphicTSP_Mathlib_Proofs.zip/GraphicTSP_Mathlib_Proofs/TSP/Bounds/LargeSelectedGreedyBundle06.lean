import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_50
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (139/320 : ℝ) ≤ z) (hzu : z ≤ (73/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (73/160 : ℝ) (66/73 : ℝ) (667/730 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1275625/4526:ℝ)*hql + (36967/146:ℝ)*hzl + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (22117/310:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3336/73:ℝ)*hmass
  · linear_combination (467816873/1633886:ℝ)*hql + (13581095/52706:ℝ)*hzl + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (22117/310:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1322300/26353:ℝ)*hmass
  · linear_combination (475882601/1633886:ℝ)*hql + (36967/146:ℝ)*hzl + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (9037797/111910:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3336/73:ℝ)*hmass
  · linear_combination (483198849/1633886:ℝ)*hql + (13581095/52706:ℝ)*hzl + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (9037797/111910:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1322300/26353:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_51
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (31/112 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (73/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (73/160 : ℝ) (66/73 : ℝ) (667/730 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (709031/2482:ℝ)*hql + (36967/146:ℝ)*hzl + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (12779/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3336/73:ℝ)*hmass
  · linear_combination (259972327/896002:ℝ)*hql + (13581095/52706:ℝ)*hzl + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (12779/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1322300/26353:ℝ)*hmass
  · linear_combination (263403271/896002:ℝ)*hql + (36967/146:ℝ)*hzl + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (5123019/61370:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3336/73:ℝ)*hmass
  · linear_combination (267415407/896002:ℝ)*hql + (13581095/52706:ℝ)*hzl + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (5123019/61370:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1322300/26353:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_52
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (73/160 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9791/34:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (12779/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (3581335/12274:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (12779/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (255091696/1251265:ℝ)*hql + (511/2:ℝ)*hzl + (44611888/250253:ℝ)*ho0 + (18852864/1251265:ℝ)*hgap + (785536/1251265:ℝ)*hS + (1/1:ℝ)*hI + (465729/1251265:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (93809842896/451706665:ℝ)*hql + (187223/722:ℝ)*hzl + (16449239696/90341333:ℝ)*ho0 + (18852864/1251265:ℝ)*hgap + (785536/1251265:ℝ)*hS + (1/1:ℝ)*hI + (465729/1251265:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_53
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (5/14 : ℝ) (3/5 : ℝ) (16/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2939/10:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (811/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1074739/3610:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (811/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (1084771/3610:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (316563/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1098531/3610:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (316563/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_54
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (13/28 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (13/28 : ℝ) (12/13 : ℝ) (121/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7843/26:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5971/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2867099/9386:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5971/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (2872115/9386:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2196323/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2907891/9386:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2196323/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_55
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (13/28 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (4/7 : ℝ) (9/8 : ℝ) (89/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3274/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (469/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1188794/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (469/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (2374453/3610:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (85717/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (2388213/3610:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (85717/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_56
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (4/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_57
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hzl + (571/16:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (2481/80:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (207629/5776:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (888151/28880:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hzl + (213899/5776:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1167521/28880:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (215397/5776:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1160031/28880:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_58
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (5/14 : ℝ) (3/5 : ℝ) (16/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2330266/11095:ℝ)*hql + (523/2:ℝ)*hzl + (411986/2219:ℝ)*ho0 + (33792/2219:ℝ)*hgap + (1408/2219:ℝ)*hS + (1/1:ℝ)*hI + (811/2219:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (849536181/4005295:ℝ)*hql + (190301/722:ℝ)*hzl + (150388977/801059:ℝ)*ho0 + (33792/2219:ℝ)*hgap + (1408/2219:ℝ)*hS + (1/1:ℝ)*hI + (811/2219:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (864399434/4124255:ℝ)*hql + (523/2:ℝ)*hzl + (150011714/824851:ℝ)*ho0 + (12198912/824851:ℝ)*hgap + (508288/824851:ℝ)*hS + (1/1:ℝ)*hI + (316563/824851:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (315137262669/1488856055:ℝ)*hql + (190301/722:ℝ)*hzl + (54772042153/297771211:ℝ)*ho0 + (12198912/824851:ℝ)*hgap + (508288/824851:ℝ)*hS + (1/1:ℝ)*hI + (316563/824851:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_59
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (5/14 : ℝ) (3/5 : ℝ) (16/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (2370208/76465:ℝ)*hem + (16688384/76465:ℝ)*ho0 + (284160/15293:ℝ)*hgap + (11840/15293:ℝ)*hS + (1/1:ℝ)*hI + (3453/15293:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (859781304/27603865:ℝ)*hem + (6056880576/27603865:ℝ)*ho0 + (102671232/5520773:ℝ)*hgap + (4277968/5520773:ℝ)*hS + (1/1:ℝ)*hI + (1242805/5520773:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (879246752/28436585:ℝ)*hem + (6072471296/28436585:ℝ)*ho0 + (102581760/5687317:ℝ)*hgap + (4274240/5687317:ℝ)*hS + (1/1:ℝ)*hI + (1413077/5687317:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (318945599736/10265607185:ℝ)*hem + (2204159572544/10265607185:ℝ)*ho0 + (102671232/5687317:ℝ)*hgap + (4277968/5687317:ℝ)*hS + (1/1:ℝ)*hI + (1409349/5687317:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_60
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (4/7 : ℝ) (9/8 : ℝ) (89/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3161/10:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (937/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (1144849/3610:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (937/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (575873/1805:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (174441/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (577737/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (174441/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_61
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (4/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t7_r5_all_cell_62
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (6/7 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (6/7 : ℝ) (17/12 : ℝ) (11/8 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (17077/10:ℝ)*hzl + (535/2:ℝ)*hem + (2080/1:ℝ)*ho0 + (7331/5:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3745/2:ℝ)*hmass
  · linear_combination (17077/10:ℝ)*hzl + (535/2:ℝ)*hem + (2080/1:ℝ)*ho0 + (2644836/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3745/2:ℝ)*hmass
  · linear_combination (6173337/3610:ℝ)*hzl + (193379/722:ℝ)*hem + (751734/361:ℝ)*ho0 + (2650761/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1353653/722:ℝ)*hmass
  · linear_combination (6173337/3610:ℝ)*hzl + (193379/722:ℝ)*hem + (751734/361:ℝ)*ho0 + (2649106/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1353653/722:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r3_cap_cell_0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (73/450 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (2062/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (743350/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (750374/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (749342/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (73/450 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (523/2:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (10172/5:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (523/2:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (3670228/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (190301/722:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (3702052/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (190301/722:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (3700188/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_2
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q ≤ (73/450 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (7/8 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (7/8 : ℝ) (10/7 : ℝ) (97/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3385/14:ℝ)*hzl + (1207/10:ℝ)*hem + (3721/14:ℝ)*ho0 + (24/1:ℝ)*hghalf + (26828/35:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (408/7:ℝ)*hmass
  · linear_combination (1226201/5054:ℝ)*hzl + (1207/10:ℝ)*hem + (1347497/5054:ℝ)*ho0 + (24/1:ℝ)*hghalf + (9674368/12635:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (149396/2527:ℝ)*hmass
  · linear_combination (3385/14:ℝ)*hzl + (443217/3610:ℝ)*hem + (3721/14:ℝ)*ho0 + (24/1:ℝ)*hghalf + (9894628/12635:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (408/7:ℝ)*hmass
  · linear_combination (1226201/5054:ℝ)*hzl + (443217/3610:ℝ)*hem + (1347497/5054:ℝ)*ho0 + (24/1:ℝ)*hghalf + (9884088/12635:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (149396/2527:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_3
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7794925/68456:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (511/8:ℝ)*htarget + (47895713/342280:ℝ)*hgate + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (2884614517/24712616:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (187223/2888:ℝ)*htarget + (17643585353/123563080:ℝ)*hgate + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (147586431/1333240:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (511/8:ℝ)*htarget + (930366331/6666200:ℝ)*hgate + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (54654605271/481299640:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (187223/2888:ℝ)*htarget + (342741763891/2406498200:ℝ)*hgate + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_4
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (19/48 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13297/40:ℝ)*hql + (13297/40:ℝ)*ho0 + (511/8:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (13297/40:ℝ)*hmass
  · linear_combination (4841497/14440:ℝ)*hql + (4841497/14440:ℝ)*ho0 + (187223/2888:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (4841497/14440:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_5
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (85792/475:ℝ)*ho0 + (33792/2375:ℝ)*hgap + (504992/2375:ℝ)*hgate + (1408/2375:ℝ)*hS + (1/1:ℝ)*hI + (967/2375:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1639368/9025:ℝ)*ho0 + (33792/2375:ℝ)*hgap + (9641448/45125:ℝ)*hgate + (1408/2375:ℝ)*hS + (1/1:ℝ)*hI + (967/2375:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (155285984/864865:ℝ)*ho0 + (12198912/864865:ℝ)*hgap + (183788128/864865:ℝ)*hgate + (508288/864865:ℝ)*hS + (1/1:ℝ)*hI + (356577/864865:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (56380661896/312216265:ℝ)*ho0 + (12198912/864865:ℝ)*hgap + (13333987176/62443253:ℝ)*hgate + (508288/864865:ℝ)*hS + (1/1:ℝ)*hI + (356577/864865:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_6
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (7/8 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t8_r3_cap_cell_7
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7521/10:ℝ)*hzu + (24/1:ℝ)*hgap + (2507/10:ℝ)*htarget + (162/25:ℝ)*hgood + (3107/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (2771409/3610:ℝ)*hzu + (24/1:ℝ)*hgap + (923803/3610:ℝ)*htarget + (162/25:ℝ)*hgood + (3107/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (7521/10:ℝ)*hzu + (24/1:ℝ)*hgap + (2507/10:ℝ)*htarget + (81503/9025:ℝ)*hgood + (1259753/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (2771409/3610:ℝ)*hzu + (24/1:ℝ)*hgap + (923803/3610:ℝ)*htarget + (81503/9025:ℝ)*hgood + (1259753/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_8
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (37/192 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (37/192 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1606/1:ℝ)*hqu + (415/2:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (578734/361:ℝ)*hqu + (415/2:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass
  · linear_combination (605366/361:ℝ)*hqu + (156215/722:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (604334/361:ℝ)*hqu + (156215/722:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_9
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (37/192 : ℝ) ≤ q) (hqu : q ≤ (29/128 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (29/128 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (23237/440:ℝ)*hqu + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (667/10:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (7859237/158840:ℝ)*hqu + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (667/10:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (12612557/158840:ℝ)*hqu + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (272787/3610:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (12083237/158840:ℝ)*hqu + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (272787/3610:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r3_cap_cell_10
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (29/128 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (7/16 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (7/16 : ℝ) (6/7 : ℝ) (61/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (10587/14:ℝ)*hzu + (24/1:ℝ)*hgap + (3529/14:ℝ)*htarget + (162/25:ℝ)*hgood + (3107/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (3894747/5054:ℝ)*hzu + (24/1:ℝ)*hgap + (1298249/5054:ℝ)*htarget + (162/25:ℝ)*hgood + (3107/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (10587/14:ℝ)*hzu + (24/1:ℝ)*hgap + (3529/14:ℝ)*htarget + (81503/9025:ℝ)*hgood + (1259753/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (3894747/5054:ℝ)*hzu + (24/1:ℝ)*hgap + (1298249/5054:ℝ)*htarget + (81503/9025:ℝ)*hgood + (1259753/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_11
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (29/128 : ℝ) ≤ q) (hqu : q ≤ (187/768 : ℝ))
    (hzl : (7/16 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (187/768 : ℝ) (0/1 : ℝ) (97/1870 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (18831/352:ℝ)*hgood + (23237/1760:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (6903855/127072:ℝ)*hgood + (7859237/635360:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (120883831/2160224:ℝ)*hgood + (222375229/10801120:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (122683519/2160224:ℝ)*hgood + (213376789/10801120:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_12
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (187/768 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (7/16 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (474999/2200:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (3431/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (174121239/794200:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (3431/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (179578031/794200:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (1422759/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (182224631/794200:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (1422759/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_13
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (37/192 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (14262411/56320:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (347/28160:ℝ)*hH0 + (14071/200:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (27813/28160:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (5200977091/20331520:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (194067/10165760:ℝ)*hH0 + (5148431/72200:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (9971693/10165760:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (5263799/72200:ℝ)*hgood + (427237/72200:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (5332599/72200:ℝ)*hgood + (358437/72200:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_14
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (25/96 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (792/19:ℝ)*hql + (7521/10:ℝ)*hzu + (24/1:ℝ)*hgap + (2507/10:ℝ)*htarget + (16033/190:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (792/19:ℝ)*hql + (2771409/3610:ℝ)*hzu + (24/1:ℝ)*hgap + (923803/3610:ℝ)*htarget + (16033/190:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (17084/361:ℝ)*hql + (7521/10:ℝ)*hzu + (24/1:ℝ)*hgap + (2507/10:ℝ)*htarget + (324987/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (17084/361:ℝ)*hql + (2771409/3610:ℝ)*hzu + (24/1:ℝ)*hgap + (923803/3610:ℝ)*htarget + (324987/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_15
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (25/96 : ℝ) ≤ q) (hqu : q ≤ (113/384 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (113/384 : ℝ) (34/113 : ℝ) (419/1130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2199711/9944:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (83531/1130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (806058303/3589784:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (83531/1130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (825214231/3589784:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (33690891/407930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (837176863/3589784:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (33690891/407930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_16
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (113/384 : ℝ) ≤ q) (hqu : q ≤ (21/64 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (21/64 : ℝ) (10/21 : ℝ) (37/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (138857/616:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (5469/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (50868425/222376:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (5469/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (51784241/222376:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (2162589/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (52525289/222376:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (2162589/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_17
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (25/96 : ℝ) ≤ q) (hqu : q ≤ (113/384 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (113/384 : ℝ) (34/113 : ℝ) (419/1130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (64799/226:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (83531/1130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (23703415/81586:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (83531/1130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (24099679/81586:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (33690891/407930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (24410655/81586:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (33690891/407930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_18
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (113/384 : ℝ) ≤ q) (hqu : q ≤ (21/64 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (21/64 : ℝ) (10/21 : ℝ) (37/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4073/14:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (5469/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1489617/5054:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (5469/70:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (1508009/5054:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (2162589/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1527273/5054:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (2162589/25270:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_19
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (21/64 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (35463/152:ℝ)*hql + (1533/8:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (16033/190:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (682053/2888:ℝ)*hql + (561669/2888:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (16033/190:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (690085/2888:ℝ)*hql + (1533/8:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (324987/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (698341/2888:ℝ)*hql + (561669/2888:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (324987/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r3_cap_cell_20
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (19/48 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (23757/40:ℝ)*hql + (21597/40:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (13297/40:ℝ)*hmass
  · linear_combination (8617557/14440:ℝ)*hql + (7837797/14440:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4841497/14440:ℝ)*hmass
  · linear_combination (8606237/14440:ℝ)*hql + (21597/40:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (13297/40:ℝ)*hmass
  · linear_combination (8647517/14440:ℝ)*hql + (7837797/14440:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4841497/14440:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_21
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hzl + (647/250:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (8254/125:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (271017/90250:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (2960969/45125:ℝ)*hgood + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (5372099/72200:ℝ)*hgood + (318937/72200:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (5409549/72200:ℝ)*hgood + (281487/72200:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_22
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (25/96 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (7/12 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (7/12 : ℝ) (8/7 : ℝ) (79/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (62065832/299495:ℝ)*hql + (3625/14:ℝ)*hzl + (10851976/59899:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (360/7:ℝ)*hmass
  · linear_combination (22710565692/108117695:ℝ)*hql + (1322873/5054:ℝ)*hzl + (3978523404/21623539:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (137084/2527:ℝ)*hmass
  · linear_combination (1206647224/5832925:ℝ)*hql + (3625/14:ℝ)*hzl + (207653464/1166585:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (360/7:ℝ)*hmass
  · linear_combination (441535898964/2105685925:ℝ)*hql + (1322873/5054:ℝ)*hzl + (76150150724/421137185:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (137084/2527:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_23
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (25/96 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (7/12 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (8976566/42785:ℝ)*hql + (523/2:ℝ)*hzl + (1572286/8557:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (3272586291/15445385:ℝ)*hql + (190301/722:ℝ)*hzl + (574004439/3089077:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (174520882/833275:ℝ)*hql + (523/2:ℝ)*hzl + (30093322/166655:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (63626161377/300812275:ℝ)*hql + (190301/722:ℝ)*hzl + (10988513837/60162455:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_24
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (31605632/123795:ℝ)*ho0 + (943616/41265:ℝ)*hgap + (9130592/123795:ℝ)*hgood + (117952/123795:ℝ)*hS + (1/1:ℝ)*hI + (5843/123795:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1389856/5415:ℝ)*ho0 + (2176/95:ℝ)*hgap + (80264/1083:ℝ)*hgood + (272/285:ℝ)*hS + (1/1:ℝ)*hI + (13/285:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (604025216/2413185:ℝ)*ho0 + (17928704/804395:ℝ)*hgap + (177520672/2413185:ℝ)*hgood + (2241088/2413185:ℝ)*hS + (1/1:ℝ)*hI + (172097/2413185:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (73077331168/290386595:ℝ)*ho0 + (17958528/804395:ℝ)*hgap + (21465202504/290386595:ℝ)*hgood + (748272/804395:ℝ)*hS + (1/1:ℝ)*hI + (56123/804395:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_25
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (19/48 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3337/5:ℝ)*hql + (2651/10:ℝ)*hzl + (3067/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (1206521/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (1109051/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass
  · linear_combination (1208402/1805:ℝ)*hql + (2651/10:ℝ)*hzl + (3067/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (1210266/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (1109051/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_26
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (7/8 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (7/8 : ℝ) (10/7 : ℝ) (97/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (10083/10:ℝ)*hzl + (1207/10:ℝ)*hem + (10323/10:ℝ)*ho0 + (26828/35:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (4124/5:ℝ)*hmass
  · linear_combination (10083/10:ℝ)*hzl + (1207/10:ℝ)*hem + (10323/10:ℝ)*ho0 + (9674368/12635:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (4124/5:ℝ)*hmass
  · linear_combination (3699883/3610:ℝ)*hzl + (443217/3610:ℝ)*hem + (3786523/3610:ℝ)*ho0 + (9894628/12635:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1518724/1805:ℝ)*hmass
  · linear_combination (3699883/3610:ℝ)*hzl + (443217/3610:ℝ)*hem + (3786523/3610:ℝ)*ho0 + (9884088/12635:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1518724/1805:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_27
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q ≤ (73/450 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (2062/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (743350/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (750374/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (749342/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_28
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q ≤ (73/450 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (523/2:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (10172/5:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (523/2:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (3670228/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (190301/722:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (3702052/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (190301/722:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hghalf + (1/1:ℝ)*hH0 + (3700188/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_29
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q ≤ (73/450 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (7/8 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (7/8 : ℝ) (10/7 : ℝ) (97/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3385/14:ℝ)*hzl + (1207/10:ℝ)*hem + (3721/14:ℝ)*ho0 + (24/1:ℝ)*hghalf + (26828/35:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (408/7:ℝ)*hmass
  · linear_combination (1226201/5054:ℝ)*hzl + (1207/10:ℝ)*hem + (1347497/5054:ℝ)*ho0 + (24/1:ℝ)*hghalf + (9674368/12635:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (149396/2527:ℝ)*hmass
  · linear_combination (3385/14:ℝ)*hzl + (443217/3610:ℝ)*hem + (3721/14:ℝ)*ho0 + (24/1:ℝ)*hghalf + (9894628/12635:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (408/7:ℝ)*hmass
  · linear_combination (1226201/5054:ℝ)*hzl + (443217/3610:ℝ)*hem + (1347497/5054:ℝ)*ho0 + (24/1:ℝ)*hghalf + (9884088/12635:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (149396/2527:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r3_cap_cell_30
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (19/48 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (19/48 : ℝ) (14/19 : ℝ) (29/38 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7794925/68456:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (511/8:ℝ)*htarget + (47895713/342280:ℝ)*hgate + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (2884614517/24712616:ℝ)*ho0 + (642048/42785:ℝ)*hgap + (187223/2888:ℝ)*htarget + (17643585353/123563080:ℝ)*hgate + (26752/42785:ℝ)*hS + (1/1:ℝ)*hI + (16033/42785:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (147586431/1333240:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (511/8:ℝ)*htarget + (930366331/6666200:ℝ)*hgate + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (54654605271/481299640:ℝ)*ho0 + (12198912/833275:ℝ)*hgap + (187223/2888:ℝ)*htarget + (342741763891/2406498200:ℝ)*hgate + (508288/833275:ℝ)*hS + (1/1:ℝ)*hI + (324987/833275:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_31
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (19/48 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13297/40:ℝ)*hql + (13297/40:ℝ)*ho0 + (511/8:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (13297/40:ℝ)*hmass
  · linear_combination (4841497/14440:ℝ)*hql + (4841497/14440:ℝ)*ho0 + (187223/2888:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (4841497/14440:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_32
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (85792/475:ℝ)*ho0 + (33792/2375:ℝ)*hgap + (504992/2375:ℝ)*hgate + (1408/2375:ℝ)*hS + (1/1:ℝ)*hI + (967/2375:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1639368/9025:ℝ)*ho0 + (33792/2375:ℝ)*hgap + (9641448/45125:ℝ)*hgate + (1408/2375:ℝ)*hS + (1/1:ℝ)*hI + (967/2375:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (155285984/864865:ℝ)*ho0 + (12198912/864865:ℝ)*hgap + (183788128/864865:ℝ)*hgate + (508288/864865:ℝ)*hS + (1/1:ℝ)*hI + (356577/864865:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (56380661896/312216265:ℝ)*ho0 + (12198912/864865:ℝ)*hgap + (13333987176/62443253:ℝ)*hgate + (508288/864865:ℝ)*hS + (1/1:ℝ)*hI + (356577/864865:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_33
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (43/125 : ℝ) ≤ q)
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (7/8 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t8_r3_cap_cell_34
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7521/10:ℝ)*hzu + (72/25:ℝ)*hem + (24/1:ℝ)*hgap + (2507/10:ℝ)*htarget + (3287/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (2771409/3610:ℝ)*hzu + (72/25:ℝ)*hem + (24/1:ℝ)*hgap + (923803/3610:ℝ)*htarget + (3287/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (7521/10:ℝ)*hzu + (326012/81225:ℝ)*hem + (24/1:ℝ)*hgap + (2507/10:ℝ)*htarget + (12152807/162450:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass
  · linear_combination (2771409/3610:ℝ)*hzu + (326012/81225:ℝ)*hem + (24/1:ℝ)*hgap + (923803/3610:ℝ)*htarget + (12152807/162450:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-415/2:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_35
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/8 : ℝ) ≤ q) (hqu : q ≤ (37/192 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (37/192 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1606/1:ℝ)*hqu + (415/2:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (578734/361:ℝ)*hqu + (415/2:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass
  · linear_combination (605366/361:ℝ)*hqu + (156215/722:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (604334/361:ℝ)*hqu + (156215/722:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_36
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (37/192 : ℝ) ≤ q) (hqu : q ≤ (29/128 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (29/128 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6277/264:ℝ)*hem + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (56659/1320:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (767095/31768:ℝ)*hem + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (6759153/158840:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (7079591/285912:ℝ)*hem + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (72625697/1429560:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (7185455/285912:ℝ)*hem + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (72096377/1429560:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_37
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (29/128 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (11/24 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (11/24 : ℝ) (10/11 : ℝ) (101/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (474999/2200:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (3431/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (174121239/794200:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (3431/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass
  · linear_combination (179578031/794200:ℝ)*hql + (16719/88:ℝ)*ho0 + (24/1:ℝ)*hgap + (5573/88:ℝ)*htarget + (1422759/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1541/88:ℝ)*hmass
  · linear_combination (182224631/794200:ℝ)*hql + (6141423/31768:ℝ)*ho0 + (24/1:ℝ)*hgap + (2047141/31768:ℝ)*htarget + (1422759/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-450437/31768:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_38
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (37/192 : ℝ) ≤ q) (hqu : q ≤ (29/128 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (29/128 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (559/18:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1604/45:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (204551/6498:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (572164/16245:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (208199/6498:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (707044/16245:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (23439/722:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (77796/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t8_r3_cap_cell_39
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (29/128 : ℝ) ≤ q) (hqu : q ≤ (25/96 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hS := hSall (25/96 : ℝ) (2/25 : ℝ) (43/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (14071/50:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (3431/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (5148431/18050:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (3431/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (5263799/18050:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1422759/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (5332599/18050:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1422759/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

end TSP.Improvements20261105
