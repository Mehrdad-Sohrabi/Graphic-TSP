import TSP.Improvements20261105.ActualScoredKGroup
import TSP.Improvements20261105.KStarPairOwners

/-! Protected unmatched pairs pay one whole leaf charge using their
own original back counts, for the current P and simultaneous guarded Q. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_K_pair_normalized_cost
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415 / 2) (704 / 5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (Qbase : E ⊕ (d).StarIndex → ℝ)
    (hrep : ∀ c, Qbase (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Qbase (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Qbase (starRepresentatives (d).stars i)-edgeSum Y (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Qbase i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum Y (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (P : GatePlan d) (a : GatedDrops d) (ha : a.Admissible d P)
    (p : (d).StarIndex × (d).StarIndex) (hp : p ∈ KUnmatchedStarPairs d x z C) :
    guardedNormalizedHeadCost d x z C owner rootStar Y a p.1+
      guardedNormalizedHeadCost d x z C owner rootStar Y a p.2+24 ≤
      4*((d).backGroup p.1.1).card+4*((d).backGroup p.2.1).card := by
  have hpair := (Finset.mem_filter.mp hp).2
  have horigin := (Finset.mem_filter.mp hpair.1).2
  have hv : (d).centers p.2 = (p.1.1 : V) := by
    change (d).tree.parent p.2.1 = (p.1.1 : V)
    rw [← hpair.2]
    exact (unaryNext_spec d p.1.1 horigin.2.1).1
  have hpos : 0 < survivingExcess d x p.2.1 := by rw [← hpair.2]; exact horigin.2.2.2
  have hu : p.2.1 ∉ matchingEndpoints id (unaryNext d) C.matching := by
    rw [← hpair.2]; exact horigin.2.2.1
  have hb := scoredDFS_current_guarded_K_group_bound G x z hs hc root hx hn hcap hm C
    (fixedHForceTargets d x z (415/2) (704/5) C)
    (fixedHForceTargets_subset d x z (415/2) (704/5) C)
    owner ho rootStar hroot Y hY Qbase hrep hbacks hloss hterminal
    p.1 p.2 hv horigin.2.1 horigin.1 hpos hu
  have hj1 := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.1)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.1)
    (a.head p.1.1) (by exact_mod_cast ha.head_nonneg p.1.1)
  have hj2 := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.2)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.2)
    (a.head p.2.1) (by exact_mod_cast ha.head_nonneg p.2.1)
  change max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.1)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.1)+
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.2)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y p.2)+24 ≤ _ at hb
  unfold guardedNormalizedHeadCost
  linarith

end TSP.Improvements20261105
