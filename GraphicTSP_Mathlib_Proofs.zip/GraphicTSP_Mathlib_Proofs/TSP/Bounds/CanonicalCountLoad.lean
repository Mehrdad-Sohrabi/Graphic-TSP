import TSP.Improvements20261105.ScoredUniformNetLoad
import TSP.Improvements20261105.NoncriticalCountLoad

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_count_load (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset d.tree.Child) (s : d.tree.Child) :
    canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
      (projectedOutgoingCoupon d x z) s ≤ 24*((d.backGroup s).card : ℝ) := by
  have hinc := (refined_fixed_incidence_le_noncritical d x z eligible T s).trans
    (noncriticalIncidence_le_count d z s)
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hq0 := hx.1 (d.treeEdge s)
  have hload := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun c => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz c) s
  linarith only [hinc,hpack,hq0,hload]

end TSP.Improvements20261105
