import Mathlib.Tactic

/-! Exact integer switch payments used by the four actual bypass types. -/
namespace TSP.Improvements20261105
set_option autoImplicit false

theorem outgoing_switch_payment (k : ℤ) (hk : 0 ≤ k) (o : ℝ) (ho : 0 ≤ o) :
    min o 2 ≤ (k : ℝ) * o + 2 * (max (1 - k) 0 : ℤ) := by
  by_cases h : 1 ≤ k
  · have hr : (1 : ℝ) ≤ k := by exact_mod_cast h
    have hp : (0 : ℝ) ≤ (max (1 - k) 0 : ℤ) := by exact_mod_cast le_max_right (1-k) 0
    have hm := min_le_left o 2
    nlinarith
  · have he : k = 0 := by omega
    subst k
    norm_num

theorem shared_switch_payment (k l : ℤ) (hk : 0 ≤ k) (hl : 0 ≤ l)
    (o F : ℝ) (ho : 0 ≤ o) (hF : 0 ≤ F) :
    min (o + F) 2 ≤ (k : ℝ) * o + (l : ℝ) * F + 2 * (max (max (1-k) (1-l)) 0 : ℤ) := by
  by_cases h : 1 ≤ k ∧ 1 ≤ l
  · have hkR : (1 : ℝ) ≤ k := by exact_mod_cast h.1
    have hlR : (1 : ℝ) ≤ l := by exact_mod_cast h.2
    have hp : (0 : ℝ) ≤ (max (max (1-k) (1-l)) 0 : ℤ) := by exact_mod_cast le_max_right _ _
    have hm := min_le_left (o+F) 2
    nlinarith
  · have hp : (1 : ℤ) ≤ max (max (1-k) (1-l)) 0 := by
      have h1 := le_max_left (1-k) (1-l)
      have h2 := le_max_right (1-k) (1-l)
      have h3 := le_max_left (max (1-k) (1-l)) 0
      omega
    have hpR : (1 : ℝ) ≤ (max (max (1-k) (1-l)) 0 : ℤ) := by exact_mod_cast hp
    have hkR : (0 : ℝ) ≤ k := by exact_mod_cast hk
    have hlR : (0 : ℝ) ≤ l := by exact_mod_cast hl
    have hm := min_le_right (o+F) 2
    nlinarith

theorem outside_switch_payment (k l : ℤ) (hk : 0 ≤ k) (hl : 0 ≤ l)
    (A F : ℝ) (hA : 0 ≤ A) (hF : 0 ≤ F) :
    min (min A F) 2 ≤ (k : ℝ) * A + (l : ℝ) * F + 2 * (max (1-k-l) 0 : ℤ) := by
  have hkR : (0 : ℝ) ≤ k := by exact_mod_cast hk
  have hlR : (0 : ℝ) ≤ l := by exact_mod_cast hl
  have hpR : (0 : ℝ) ≤ (max (1-k-l) 0 : ℤ) := by exact_mod_cast le_max_right _ _
  by_cases h : 1 ≤ k
  · have hr : (1 : ℝ) ≤ k := by exact_mod_cast h
    have hm := (min_le_left (min A F) 2).trans (min_le_left A F)
    nlinarith
  · by_cases h' : 1 ≤ l
    · have hr : (1 : ℝ) ≤ l := by exact_mod_cast h'
      have hm := (min_le_left (min A F) 2).trans (min_le_right A F)
      nlinarith
    · have hk0 : k = 0 := by omega
      have hl0 : l = 0 := by omega
      subst k; subst l
      norm_num

end TSP.Improvements20261105
