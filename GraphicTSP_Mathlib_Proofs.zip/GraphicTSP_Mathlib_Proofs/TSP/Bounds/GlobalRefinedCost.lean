import TSP.Improvements20261105.GlobalRefinedIncidence
import TSP.Improvements20261105.SelectedHeadSums

/-! Combine incidence with the exact selected-back mass identity.
Internal mass, penalties and true-cut coverage are kept explicit so
subsequent transfer payments cannot reuse an already-spent account. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_global_refined_cost_ledger (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : Finset d.tree.Child) (hscore : ScoreComparisons d x C)
    (R : Finset d.tree.Child) (hRC : R ⊆ C)
    (hR : ∀ s ∈ R, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (q : d.tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, (d.backGroup s).card ≤ 3 → ∀ e ∈ d.backGroup s, z e ≤ q s) :
    48 * a.value d P (fun _ => 0) ≤
      (∑ s ∈ a.selectedHeads d,
        (24 * (edgeSum z (d.backGroup s) - gatedFreeBase d s) + refinedIncidenceCharge d x z C R s)) +
      24 * ((a.headfulLeafComponents d P).card - 1 - (a.selectedRootHeads d).card) -
      24 * a.internalSelectedBackMass d P (fun b => x b.1) -
      48 * (∑ s : d.tree.Child, (a.penalty d P s : ℝ)) -
      24 * a.coverageExcess d P (fun b => x b.1) -
      (162 / 19) * (∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z C r : ℝ)) +
      72 * (∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s) +
      (124 / 5) * (edgeSum x Finset.univ - Fintype.card V) := by
  have hi := canonical_global_refined_incidence d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
    x z hx hcap hz hzx C hscore R hRC hR q hq hpack hsmall
  have hm := a.selected_mass_ledger d hs hc ha x
  have he : (∑ s ∈ a.selectedHeads d, (edgeSum x (d.backGroup s) - gatedFreeBase d s)) =
      (∑ s ∈ a.selectedHeads d, (edgeSum z (d.backGroup s) - gatedFreeBase d s)) +
      ∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro s _
    unfold ownProjectionLoss
    ring
  rw [he] at hm
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum]
  linarith

end TSP.Improvements20261105
