import TSP.Improvements20261105.CurrentProjectedBranchSource
import TSP.Improvements20261105.ActualHighQZeroSourceLoad
import TSP.Improvements20261105.ActualHighQSelectedZeroReceiver
import TSP.Improvements20261105.CurrentProjectedKZeroReceiver
import TSP.Improvements20261105.HighQZeroGroupScalars

/-! An actual high-q origin and its projected-small receiver are paid
jointly for every binary selector, retaining one common transfer. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem actual_high_q_zero_group
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (i j : (d).StarIndex)
    (hi : HighQGroupOwner d x z C i.1) (hq : 1/2 ≤ x ((d).treeEdge i.1))
    (hout : outgoingBackMass d x i.1 ≤ survivingExcess d x i.1)
    (hp : (d).centers j=(i.1:V)) (hsmall : edgeSum z ((d).backGroup j.1) ≤ 1)
    (ns nw : ℤ) (hns : ns=0 ∨ ns=1) (hnw : nw=0 ∨ nw=1) :
    (jointHeadTerm
      (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i) (ns:ℝ)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)+
      (ns:ℝ)*canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) i.1+
    (jointHeadTerm
      (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j) (nw:ℝ)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) j.1)+
      (nw:ℝ)*canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) j.1 ≤
      4*((((d).backGroup i.1).card:ℝ)+(((d).backGroup j.1).card:ℝ)) := by
  have hl := (Finset.mem_filter.mp hi.2.1).2
  have hprotected : ProtectedHead d x z (415/2) (704/5) C i.1 := ⟨hl.1,hl.2.1,hi.2.2⟩
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  have hpos : 1 < edgeSum z ((d).backGroup i.1) := by
    have hh := hl.2.1
    rw [← he] at hh
    have h := (lt_max_iff.mp hh).resolve_right (lt_irrefl _)
    linarith
  have hdef := guarded_projected_positive_Q_deficit d x z Y R hrep hbacks hloss hterminal i hpos
  have hsource := actual_high_q_zero_source_load G x z hs hc root hx hn hcap hz hzx hm C
    owner rootStar R i hdef hprotected hq hout hl.2.2.1 eligible T
  have hreceiver := actual_high_q_selected_zero_receiver G x z hs hc root hx hn hcap hz hzx hm C
    owner rootStar Y R hrep hbacks hloss hterminal eligible T j i.1 hp hi.2.1 hq hsmall
  have hsource0 := current_projected_branch_source_max d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero i hi
  have hreceiver0 := current_projected_K_zero_receiver_max d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero j i.1 hp hi.2.1 hi.2.2 hsmall
  have hg : 0 ≤ 1-x ((d).treeEdge i.1)-outgoingBackMass d x i.1 := by linarith [hl.2.2.2]
  have hjcard : (1:ℝ) ≤ (((d).backGroup j.1).card:ℝ) := by
    exact_mod_cast Finset.card_pos.mpr j.2
  have hh := high_q_zero_group_scalar (((d).backGroup i.1).card:ℝ) (((d).backGroup j.1).card:ℝ)
    (1-x ((d).treeEdge i.1)-outgoingBackMass d x i.1)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)
    (max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)
    (canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
      (projectedOutgoingCoupon d x z) i.1)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) j.1)
    (max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) j.1)
    (canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
      (projectedOutgoingCoupon d x z) j.1)
    ns nw hns hnw (Nat.cast_nonneg _) hjcard hg hsource0 hsource hreceiver0 hreceiver
  convert hh using 1 <;> unfold jointHeadTerm <;> ring

end TSP.Improvements20261105
