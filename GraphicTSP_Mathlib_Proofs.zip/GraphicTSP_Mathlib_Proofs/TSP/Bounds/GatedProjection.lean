import TSP.Improvements20261105.GatedNetwork

/-! Project a gated circulation back onto the ordinary expanded DFS network.
The projected connector flow is suffix minus paid flow; the representative
flow is ordinary representative flow plus the effective bypass. Signed routes
are used only for this exact conservation identity. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 1000000
open Graph Chapter05 Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def ordinaryFlowNetwork : Graph (FlowVertex d) (FlowArc d) :=
  ⟨flowSrc d, flowDst d⟩

def gatedCollapse : GatedVertex d → FlowVertex d :=
  Sum.elim id (Sum.elim Sum.inl
    (fun a => if a.2 = 1 then .inl (d.tree.parent a.1) else .inr a.1))

noncomputable def gatedExtraProjection (P : GatePlan d) (v : d.tree.Child) :
    Fin 8 → FlowArc d → ℝ
  | 3 => fun a => -singleArcFlow (.inl (.inl v)) a
  | 4 => fun a => if P.kind v = .sharedGate then 0 else singleArcFlow (.inl (.inr v)) a
  | 6 => singleArcFlow (.inl (.inr v))
  | 7 => singleArcFlow (.inl (.inr v))
  | _ => fun _ => 0

noncomputable def gatedProjectionRoute (P : GatePlan d) : GatedArc d → FlowArc d → ℝ :=
  Sum.elim singleArcFlow (Sum.elim (fun _ _ => 0) (fun a => gatedExtraProjection d P a.1 a.2))

theorem zero_flow_divergence (N : Graph V E) (v : V) :
    flowDivergence N (fun _ => 0) v = 0 := by simp [flowDivergence, arcSum]

theorem gatedProjectionRoute_divergence (P : GatePlan d) (hP : P.RespectsTree d)
    (a : GatedArc d) (w : FlowVertex d) :
    flowDivergence (ordinaryFlowNetwork d) (gatedProjectionRoute d P a) w =
      (if gatedCollapse d ((gatedNetwork d P).src a) = w then 1 else 0) -
      (if gatedCollapse d ((gatedNetwork d P).dst a) = w then 1 else 0) := by
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · simpa [gatedProjectionRoute, gatedNetwork, gatedCollapse, ordinaryFlowNetwork,
      flowSrc, flowDst] using singleArcFlow_divergence (ordinaryFlowNetwork d) (.inl (.inl v)) w
  · simpa [gatedProjectionRoute, gatedNetwork, gatedCollapse, ordinaryFlowNetwork,
      flowSrc, flowDst] using singleArcFlow_divergence (ordinaryFlowNetwork d) (.inl (.inr v)) w
  · have hh := singleArcFlow_divergence (ordinaryFlowNetwork d) (.inr b) w
    by_cases hb : P.OutsideBack d b
    · simpa [gatedProjectionRoute, gatedNetwork, gatedCollapse, ordinaryFlowNetwork,
        flowSrc, flowDst, hb] using hh
    · simpa [gatedProjectionRoute, gatedNetwork, gatedCollapse, ordinaryFlowNetwork,
        flowSrc, flowDst, hb] using hh
  · simp [gatedProjectionRoute, gatedNetwork, gatedCollapse, zero_flow_divergence]
  · fin_cases k
    all_goals simp only [gatedProjectionRoute, Sum.elim_inr, gatedExtraProjection,
      gatedNetwork, gatedExtraSrc, gatedExtraDst]
    · simp [gatedCollapse, zero_flow_divergence]
    · simp [gatedCollapse, zero_flow_divergence]
    · simp [gatedCollapse, zero_flow_divergence]
    · have hh := flowDivergence_smul (ordinaryFlowNetwork d) (-1)
        (singleArcFlow (.inl (.inl v))) w
      simp only [neg_one_mul] at hh
      rw [hh, singleArcFlow_divergence]
      by_cases hr : P.IsReceiver d v
      · simp [gatedCollapse, ordinaryFlowNetwork, flowSrc, flowDst, hr]
      · simp [gatedCollapse, ordinaryFlowNetwork, flowSrc, flowDst, hr]
    · cases hk : P.kind v <;>
        simp [gatedBypassSource, gatedBypassTarget, hk, gatedCollapse,
          zero_flow_divergence, singleArcFlow_divergence, ordinaryFlowNetwork, flowSrc, flowDst]
      rw [hP v (Or.inr hk)]
    · simp [gatedCollapse, zero_flow_divergence]
    · simp [singleArcFlow_divergence, gatedCollapse, ordinaryFlowNetwork, flowSrc, flowDst]
    · by_cases hk : P.kind v = .sharedGate
      · simp [singleArcFlow_divergence, gatedCollapse, ordinaryFlowNetwork, flowSrc, flowDst,
          hk, hP v (Or.inl hk)]
      · simp [singleArcFlow_divergence, gatedCollapse, ordinaryFlowNetwork, flowSrc, flowDst, hk]

theorem gated_projection_balanced (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f) :
    Balanced (ordinaryFlowNetwork d) (routeFlow (gatedProjectionRoute d P) f) :=
  routeFlow_balanced _ _ (gatedCollapse d) _ (gatedProjectionRoute_divergence d P hP) f hf

noncomputable def gatedEffectiveBypass (P : GatePlan d) (f : GatedArc d → ℝ)
    (v : d.tree.Child) : ℝ :=
  (if P.kind v = .sharedGate then 0 else f (gatedBypassArc d v)) +
    f (gatedExitTailArc d v) + f (gatedExitGateArc d v)

theorem gated_projection_connector (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    routeFlow (gatedProjectionRoute d P) f (.inl (.inl v)) =
      f (gatedSuffixArc d v) - f (gatedPaidArc d v) := by
  simp [routeFlow, gatedProjectionRoute, gatedExtraProjection, singleArcFlow,
    Fintype.sum_sum_type, Fintype.sum_prod_type, Fin.sum_univ_succ,
    Finset.sum_add_distrib, sub_eq_add_neg, eq_comm]

theorem gated_projection_representative (P : GatePlan d) (f : GatedArc d → ℝ) (v : d.tree.Child) :
    routeFlow (gatedProjectionRoute d P) f (.inl (.inr v)) =
      f (gatedRepArc d v) + gatedEffectiveBypass d P f v := by
  simp [routeFlow, gatedProjectionRoute, gatedExtraProjection, singleArcFlow,
    gatedEffectiveBypass, Fintype.sum_sum_type, Fintype.sum_prod_type, Fin.sum_univ_succ,
    mul_ite, Finset.sum_add_distrib, add_assoc, eq_comm]
  symm
  rw [Finset.sum_eq_single v]
  · simp
  · intro x _ hx
    simp [Ne.symm hx]
  · simp

theorem gated_projection_back (P : GatePlan d) (f : GatedArc d → ℝ) (b : BackEdge d) :
    routeFlow (gatedProjectionRoute d P) f (.inr b) = f (gatedBackArc d b) := by
  simp [routeFlow, gatedProjectionRoute, gatedExtraProjection, singleArcFlow,
    Fintype.sum_sum_type, Fintype.sum_prod_type, Fin.sum_univ_succ]

theorem gated_projection_decomposition (P : GatePlan d) (hP : P.RespectsTree d)
    (f : GatedArc d → ℝ) (hf : Balanced (gatedNetwork d P) f) :
    routeFlow (gatedProjectionRoute d P) f = weightedBackFlow d (fun b => f (gatedBackArc d b)) := by
  apply circulation_determined_by_back d _ _ (gated_projection_balanced d P hP f hf)
    (weightedBackFlow_conservation d _)
  intro b
  rw [gated_projection_back, weightedBackFlow_back]

end TSP.Improvements20261105
