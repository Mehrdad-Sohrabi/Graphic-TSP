import TSP.Improvements20261105.FourBackNoncriticalBound

/-! A continuous paired inequality for a selected three-back source and
positive greedy target of arbitrary count. All rational cases are checked by Lean. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 6000000
set_option Elab.async false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

theorem four_back_greedy_positive_largetarget_scalar
    (q e z a o S I H g : ℝ) (hq : (1/4 : ℝ) ≤ q)
    (he0 : 0 ≤ e) (hem : e ≤ 4*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (hz0 : 0 ≤ z) (ha : 1 ≤ a)
    (hmass : q+o+z+a=2) (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hS : S ≤ max (192*q-48) (144*q-684/19+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hgate : q ≤ 9/25 ∨ 43/100 ≤ q ∨ q+e ≤ 91/100)
    (hH0 : 0 ≤ H)
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hzhi : z ≤ (3/4 : ℝ) := by linarith only [hq,hmass,ho0,ha]
  by_cases hc0 : z ≤ (1/10 : ℝ)
  · have ht := hIall (1/10 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc0
    rw [min_eq_left (by linarith : z ≤ 1-z)]
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [ho0,hz0,hg0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [ho0,hz0,hg0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [ho0,hz0,hg0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [ho0,hz0,hg0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hz0,hgap,hH0,hg,hS,ht,hmass]
  by_cases hc1 : z ≤ (1/5 : ℝ)
  · have ht := hIall (1/5 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc1
    rw [min_eq_left (by linarith : z ≤ 1-z)]
    have hlo : (1/10 : ℝ) ≤ z := (lt_of_not_ge hc0).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc2 : z ≤ (9/38 : ℝ)
  · have ht := hIall (9/38 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc2
    rw [min_eq_left (by linarith : z ≤ 1-z)]
    have hlo : (1/5 : ℝ) ≤ z := (lt_of_not_ge hc1).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc3 : z ≤ (1/4 : ℝ)
  · have ht := hIall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc3
    rw [min_eq_left (by linarith : z ≤ 1-z)]
    have hlo : (9/38 : ℝ) ≤ z := (lt_of_not_ge hc2).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc4 : z ≤ (3/10 : ℝ)
  · have ht := hIall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc4
    rw [min_eq_left (by linarith : z ≤ 1-z)]
    have hlo : (1/4 : ℝ) ≤ z := (lt_of_not_ge hc3).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc5 : z ≤ (13/40 : ℝ)
  · have ht := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc5
    rw [min_eq_left (by linarith : z ≤ 1-z)]
    have hlo : (3/10 : ℝ) ≤ z := (lt_of_not_ge hc4).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [ho0,hg0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc6 : z ≤ (7/20 : ℝ)
  · have ht := hIall (7/20 : ℝ) (4/7 : ℝ) (43/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc6
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc5]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (13/40 : ℝ) ≤ z := (lt_of_not_ge hc5).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc7 : z ≤ (3/8 : ℝ)
  · have ht := hIall (3/8 : ℝ) (2/3 : ℝ) (7/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc7
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc6]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (7/20 : ℝ) ≤ z := (lt_of_not_ge hc6).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc8 : z ≤ (2/5 : ℝ)
  · have ht := hIall (2/5 : ℝ) (3/4 : ℝ) (31/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc8
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc7]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (3/8 : ℝ) ≤ z := (lt_of_not_ge hc7).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
  by_cases hc9 : z ≤ (17/40 : ℝ)
  · have ht := hIall (17/40 : ℝ) (14/17 : ℝ) (143/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc9
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc8]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (2/5 : ℝ) ≤ z := (lt_of_not_ge hc8).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc10 : z ≤ (9/20 : ℝ)
  · have ht := hIall (9/20 : ℝ) (8/9 : ℝ) (9/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc10
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc9]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (17/40 : ℝ) ≤ z := (lt_of_not_ge hc9).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [hem,ho0,hgap,hH0,hlo,hg,hS,ht,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc11 : z ≤ (19/40 : ℝ)
  · have ht := hIall (19/40 : ℝ) (18/19 : ℝ) (181/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc11
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc10]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (9/20 : ℝ) ≤ z := (lt_of_not_ge hc10).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc12 : z ≤ (1/2 : ℝ)
  · have ht := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc12
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc11]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith : z ≤ 1-z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (19/40 : ℝ) ≤ z := (lt_of_not_ge hc11).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc13 : z ≤ (11/20 : ℝ)
  · have ht := hIall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc13
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc12]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith : 1-z ≤ z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (1/2 : ℝ) ≤ z := (lt_of_not_ge hc12).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc14 : z ≤ (3/5 : ℝ)
  · have ht := hIall (3/5 : ℝ) (7/6 : ℝ) (23/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc14
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc13]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith : 1-z ≤ z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (11/20 : ℝ) ≤ z := (lt_of_not_ge hc13).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [heq,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc15 : z ≤ (13/20 : ℝ)
  · have ht := hIall (13/20 : ℝ) (16/13 : ℝ) (157/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc15
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc14]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith : 1-z ≤ z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (3/5 : ℝ) ≤ z := (lt_of_not_ge hc14).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc15,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc15,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc15,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc15,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
    · linarith only [hem,ho0,hgap,hlo,hg,hS,ht,hL,hmass]
  by_cases hc16 : z ≤ (7/10 : ℝ)
  · have ht := hIall (7/10 : ℝ) (9/7 : ℝ) (44/35 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc16
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc15]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith : 1-z ≤ z)] at hL hR ⊢
    rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (13/20 : ℝ) ≤ z := (lt_of_not_ge hc15).le
    rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc16,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc16,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc16,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hc16,hlo,hg,hS,ht,hL,hR,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
    · linarith only [hem,ho0,ha,hgap,hlo,hS,ht,hL,hmass]
  have ht := hIall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by simpa using hzhi)
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc16]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  have hlo : (7/10 : ℝ) ≤ z := (lt_of_not_ge hc16).le
  rcases hgate with hg | hg | hg <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hzhi,hlo,hg,hS,ht,hL,hR,hmass]
  · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hzhi,hlo,hg,hS,ht,hL,hR,hmass]
  · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hzhi,hlo,hg,hS,ht,hL,hR,hmass]
  · linarith only [hq,he0,hem,heq,ho0,hoe,hz0,ha,hg0,hghalf,hgap,hH0,hzhi,hlo,hg,hS,ht,hL,hR,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]
  · linarith only [hem,ho0,ha,hghalf,hlo,hS,ht,hL,hmass]

end TSP.Improvements20261105
