import TSP.Improvements20261105.CanonicalDropExchange
import TSP.Improvements20261105.GatedDependencyCost

/-! Selected heads have more own backs than their base free capacity:
at least two at a nonroot head and at least three at the root. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def ownBackEdges (s : d.tree.Child) : Finset (BackEdge d) :=
  Finset.univ.filter (fun b => d.anchor b.1 = s)

theorem ownBackEdges_card (s : d.tree.Child) : (ownBackEdges d s).card = (d.backGroup s).card := by
  have he : (ownBackEdges d s).image Subtype.val = d.backGroup s := by
    ext e
    constructor
    · rintro h
      obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp h
      exact (back_anchor_iff_group d b s).mp (Finset.mem_filter.mp hb).2
    · intro he
      have hb : e ∈ d.backEdges := ((d.mem_backGroup_iff s e).mp he).1
      refine Finset.mem_image.mpr ⟨⟨e, hb⟩, ?_, rfl⟩
      simp only [ownBackEdges, Finset.mem_filter, Finset.mem_univ, true_and]
      exact (back_anchor_iff_group d ⟨e, hb⟩ s).mpr he
  rw [← he, Finset.card_image_of_injective _ Subtype.val_injective]

theorem canonical_selected_head_size (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) :
    gatedFreeBase d s < (d.backGroup s).card := by
  by_contra hsmall
  have hcard : (d.backGroup s).card ≤ gatedFreeBase d s := Nat.le_of_not_gt hsmall
  let B := ownBackEdges d s
  let S : Finset d.tree.Child := {s}
  let q := a.eraseBackDependencies d B S
  have hown : ∀ b : BackEdge d, d.anchor b.1 ∈ S → b ∈ B := by
    intro b hb
    simpa [S, B, ownBackEdges] using hb
  have hq := a.eraseBackDependencies_admissible d ha B S hown
  have hm := a.eraseBackDependencies_mono d ha B S
  have hrep : ∀ v, q.head v ≠ 0 → a.representative v ≤ q.representative v := by
    intro v hv
    by_cases hactive : (d.backGroup v).Nonempty
    · have hz := gated_optimal_active_representative_zero d P t ht f hf hb
        (a.potential d P) hcan.1.1 hcan.1.2 v hactive
      simp only [GatedDrops.potential_representative] at hz
      rw [hz]
      exact hq.representative_nonneg v
    · have hz := gated_optimal_inactive_head_zero d P hP t ht f hf hb
        (a.potential d P) hcan.1.1 hcan.1.2 v hactive
      simp only [GatedDrops.potential_headSelector] at hz
      have hmono := hm.2.2.2.1 v
      have hn := hq.head_nonneg v
      change q.head v ≤ a.head v at hmono
      change 0 ≤ q.head v at hn
      exact (hv (by omega)).elim
  have hout : ∀ v, q.head v ≠ 0 → a.outside v ≤ q.outside v := by
    intro v hv
    have hn : v ∉ S := by
      intro h
      exact hv (by simp [q, GatedDrops.eraseBackDependencies, h])
    simp [q, GatedDrops.eraseBackDependencies, hn]
  have hcost : a.deletionCost d q ≤ (gatedFreeBase d s : ℝ) := by
    have hc := a.eraseBackDependencies_cost_le d ha B S
    have hsum : (∑ b ∈ B, (a.pathCost d b + (a.tail (d.lower b.1) : ℝ))) ≤ (B.card : ℝ) := by
      calc
        _ ≤ ∑ b ∈ B, (1 : ℝ) := by
          apply Finset.sum_le_sum
          intro b hb
          have hanchor : d.anchor b.1 = s := (Finset.mem_filter.mp hb).2
          have hbc := ha.back b
          rw [hanchor, hsel] at hbc
          have ho : (0 : ℝ) ≤ if P.OutsideBack d b then (a.outside s : ℝ) else 0 := by
            split_ifs
            · exact_mod_cast ha.outside_nonneg s
            · exact le_rfl
          norm_num at hbc
          linarith
        _ = _ := by simp
    have hn : (B.card : ℝ) ≤ gatedFreeBase d s := by
      have hc' : B.card ≤ gatedFreeBase d s := by simpa [B, ownBackEdges_card] using hcard
      exact_mod_cast hc'
    exact hc.trans (hsum.trans hn)
  have hgain : (∑ v : d.tree.Child, ((gatedFreeBase d v : ℝ) + t v) *
      ((a.head v - q.head v : ℤ) : ℝ)) = (gatedFreeBase d s : ℝ) + t s := by
    rw [Finset.sum_eq_single s]
    · simp [q, S, GatedDrops.eraseBackDependencies, hsel]
    · intro v _ hv
      simp [q, S, GatedDrops.eraseBackDependencies, hv]
    · simp
  have hv := GatedDrops.exchange_value_bound d hP t ha hq hm.1 hm.2.1 hm.2.2.1
    hm.2.2.2.2.1 hm.2.2.2.1 hrep hout
  change a.value d P t + _ - a.deletionCost d q ≤ q.value d P t at hv
  rw [hgain] at hv
  have hbetter : a.value d P t ≤ q.value d P t := by linarith [ht s]
  exact canonical_drops_no_head_deletion d P hP t f hf hb a q ha hq hcan
    hm.1 hm.2.1 hm.2.2.1 hm.2.2.2.1 hbetter s hsel
      (by simp [q, S, GatedDrops.eraseBackDependencies])

end TSP.Improvements20261105
