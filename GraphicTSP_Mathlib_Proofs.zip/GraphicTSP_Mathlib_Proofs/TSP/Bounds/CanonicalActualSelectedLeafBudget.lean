import TSP.Improvements20261105.CanonicalNoUnpaidLeafBudget
import TSP.Improvements20261105.ActualSelectedCostIdentity
import TSP.Improvements20261105.AllocatedLeafHeads
import TSP.Improvements20261105.FixedProjectionPacking

/-! The actual fixed gates, critical rule, packing and coupons are
substituted in the leaf ledger. The remaining sum is exactly the local
selected-head cost used by the subsequent role estimates. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem canonical_actual_selected_leaf_budget (eligible : Finset (d).tree.Child) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d (fixedGatePlan d x)) f)
    (hb : RealFlowBounds (gatedLower d (fixedGatePlan d x)) (gatedAugmentedUpper d (fixedGatePlan d x) t) f)
    (a : GatedDrops d) (ha : a.Admissible d (fixedGatePlan d x)) (hcan : CanonicalGatedFor d (fixedGatePlan d x) t f (a.potential d (fixedGatePlan d x)))
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (heligible : ∀ s ∈ eligible, ScoredStar d x s)
    (T : Finset (d).tree.Child) (hTS : T ⊆ (fixedCriticalHeads d x z eligible))
    (hT : ∀ s ∈ T, 2 ≤ (a.componentHeads d (fixedGatePlan d x) (a.headComponent d (fixedGatePlan d x) s)).card)
    (hn : 2 ≤ Fintype.card V)
    (hprojection : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hrootStar : (d).centers rootStar = (d).tree.root)
    (R : E ⊕ (d).StarIndex → ℝ)
    (Q : E ⊕ (d).StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G (d).centers owner)
    (hrep : ∀ c, Q (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Q (.inl e) = 1-x e/2)
    (m : (d).StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x ((d).treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hmprojected : ∀ i ∈ projectedZeroTerminalHeads d z,
      (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
        max (x ((d).treeEdge i.1)-projectedZeroGuardCapacity d x z Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Q i)
    (hconn : FixedQConnectorValues d x hx hn hcap R)
    (hloss : ∀ i, edgeSum Q (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Q i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
      m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1)
    (hconnectors : ∀ i : (d).StarIndex, R (.inr i) = Q (.inr i))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1) :
    let L := a.paidLeafRoots d (fixedGatePlan d x) x
    let J := a.paidLeafHeads d (fixedGatePlan d x) x
    let KJ := pairStarHeads d (a.KLeafPairs d (fixedGatePlan d x) x z C)
    let ML := a.multiplePairLeafRoots d (fixedGatePlan d x) x z C
    let MJ := pairStarHeads d (a.matchingPairsForRoots d (fixedGatePlan d x) x z C ML)
    let LL := a.largeRemainingLeafRoots d (fixedGatePlan d x) x z C
    let LJ := a.componentStarUnion d (fixedGatePlan d x) LL
    let SL := a.solePairLeafRoots d (fixedGatePlan d x) x z C
    let SJ := a.componentStarUnion d (fixedGatePlan d x) SL
    let EL := a.oneExtraBackLeafRoots d (fixedGatePlan d x) x z C
    let EJ := a.componentStarUnion d (fixedGatePlan d x) EL
    let BL := a.twoBackSingleLeafRoots d (fixedGatePlan d x) x z C
    let BJ := a.componentStarUnion d (fixedGatePlan d x) BL
    let DL := a.twoBackTwoHeadLeafRoots d (fixedGatePlan d x) x z C
    let DJ := a.componentStarUnion d (fixedGatePlan d x) DL
    let NL := a.noPairLeafRoots d (fixedGatePlan d x) x z C
    let NJ := a.componentStarUnion d (fixedGatePlan d x) NL
    let U := projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x
    let J0 := a.componentStarUnion d (fixedGatePlan d x) (a.zeroLeafRoots d (fixedGatePlan d x) x)
    let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
    48*a.value d (fixedGatePlan d x) (fun _ => 0)+(∑ i : (d).StarIndex, cost i)-
      (704/5 : ℝ)*(∑ i ∈ U, m i) ≤
      (-24*((a.selectedRootHeads d).card : ℝ))-
      (162/19)*(∑ r ∈ a.internalComponents d (fixedGatePlan d x), (a.incidenceEdgeCount d (fixedGatePlan d x) z (fixedCriticalHeads d x z eligible) r : ℝ))+
      (1204/5)*(edgeSum x Finset.univ-Fintype.card V)-12*Chapter11.totalOverage d x+
      (4*∑ i ∈ KJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ MJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ LJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ SJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ EJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ BJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ DJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ NJ, (((d).backGroup i.1).card : ℝ))+
      (∑ i ∈ Finset.univ \ a.allocatedLeafHeads d (fixedGatePlan d x) x z C,
        currentSelectedHeadCost d x z C owner rootStar R eligible T a.head i)-
      (704/5 : ℝ)*(∑ i ∈ U \ (a.paidLeafGuardHeads d (fixedGatePlan d x) x ∪ NJ.filter (fun i => i ∈ U)), m i) := by
  have hP := fixedGatePlan_tree d x
  have hscore : ScoreComparisons d x (fixedCriticalHeads d x z eligible) :=
    (scoredDFS_comparisons G x hs hconnected root eligible heligible).restrict d (Finset.filter_subset _ _)
  have hq : ∀ s : (d).tree.Child, 0 ≤ x ((d).treeEdge s) := fun s => hx.1 _
  have hpack : ∀ s, edgeSum z ((d).backGroup s) ≤ 2-x ((d).treeEdge s) :=
    fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hprojection
  have hsmall := scoredDFS_small_projected_back G x z hs hconnected root hzx
  have hbcap : ∀ s, (projectedOutgoingCoupon d x z) s ≤ 1 := fun s =>
    projectedOutgoingCoupon_cap d x z s (by have h := hpack s; have hn := hq s; linarith)
  have hbout := fixedGatePlan_coupon_outside d x z hx.1 hzx
  have hledger := canonical_no_unpaid_leaf_budget G x z hs hconnected root hc
    x₀ hx₀ hpositive (fixedGatePlan d x) hP t ht f hf hb a ha hcan hx hcap hz hzx (fixedCriticalHeads d x z eligible) hscore T hTS hT
    (projectedOutgoingCoupon d x z) hbcap hbout (fun s => x ((d).treeEdge s)) hq hpack hsmall hn hprojection C owner ho rootStar hrootStar R Q hQ
    hrep hbacks m hm0 hm hmprojected hguarded hconn hloss hmpositive hconnectors hterminal
  have hcost := a.remaining_head_cost_identity d (fixedGatePlan d x) hP t ht f hf hb ha hcan x z C
    owner rootStar R eligible T (a.allocatedLeafHeads d (fixedGatePlan d x) x z C)
    (fun i hi => a.allocatedLeafHeads_unselected d hs hc x z hx hn hcap hprojection C (fixedGatePlan d x) hP t ht f hf hb ha hcan i hi)
  dsimp only at hledger ⊢
  simp only [canonicalHeadLoad,GatedDrops.allocatedLeafHeads] at hcost ⊢
  linarith only [hledger,hcost]

end TSP.Improvements20261105
