import TSP.Improvements20261105.ParityGauge

/-! A thinned finite cycle toggle preserves the genuine capacity-one
join polytope. Every changed marginal and every untouched edge is explicit. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Classical
open scoped BigOperators symmDiff
variable {V E I : Type} [Fintype V] [Fintype E] [Fintype I]
  [DecidableEq V] [DecidableEq E]

theorem even_toggle_join (G : Graph V E) (T : Finset V) (J C : Finset E)
    (hJ : G.IsJoin T J) (hC : ∀ v, Even (G.intDegree C v)) : G.IsJoin T (J ∆ C) := by
  apply (isJoin_iff_parity G _ _).mpr
  intro v
  have hj := (isJoin_iff_parity G _ _).mp hJ v
  have hc := hC v
  rw [Nat.even_iff] at hc
  have hi := symmetric_difference_degree_identity G J C v
  omega

noncomputable def thinnedCyclePoint (w : I → ℝ) (J : I → Finset E) (C : Finset E) (r : I → ℝ) : E → ℝ :=
  fun e => ∑ i, ((w i - r i) * incidence (J i) e + r i * incidence (J i ∆ C) e)

theorem thinnedCyclePoint_feasible (G : Graph V E) (T : Finset V)
    (w : I → ℝ) (J : I → Finset E) (C : Finset E) (r : I → ℝ)
    (hw : ∑ i, w i = 1) (hr : ∀ i, 0 ≤ r i ∧ r i ≤ w i)
    (hJ : ∀ i, G.IsJoin T (J i)) (hC : ∀ v, Even (G.intDegree C v)) :
    thinnedCyclePoint w J C r ∈ joinPolytope G T (G.intDegree Finset.univ) := by
  let weights : I ⊕ I → ℝ := Sum.elim (fun i => w i - r i) r
  let atoms : I ⊕ I → Finset E := Sum.elim J (fun i => J i ∆ C)
  apply mem_convexHull_iff_exists_fintype.mpr
  refine ⟨I ⊕ I, inferInstance, weights, fun i => incidence (atoms i), ?_, ?_, ?_, ?_⟩
  · intro i
    cases i with
    | inl i => exact sub_nonneg.mpr (hr i).2
    | inr i => exact (hr i).1
  · simp only [weights, Fintype.sum_sum_type, Sum.elim_inl, Sum.elim_inr, Finset.sum_sub_distrib]
    linarith
  · intro i
    refine ⟨atoms i, rfl, ?_, fun v => selected_degree_le_graph_degree G (atoms i) v⟩
    cases i with
    | inl i => exact hJ i
    | inr i => exact even_toggle_join G T (J i) C (hJ i) hC
  · funext e
    simp only [weights, atoms, Fintype.sum_sum_type, Sum.elim_inl, Sum.elim_inr,
      Pi.add_apply, Finset.sum_apply, Pi.smul_apply, smul_eq_mul, thinnedCyclePoint, Finset.sum_add_distrib]

theorem thinnedCyclePoint_difference (w : I → ℝ) (J : I → Finset E) (C : Finset E)
    (r : I → ℝ) (e : E) :
    thinnedCyclePoint w J C r e - (∑ i, w i * incidence (J i) e) =
      ∑ i, r i * (incidence (J i ∆ C) e - incidence (J i) e) := by
  unfold thinnedCyclePoint
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  ring

theorem thinnedCyclePoint_outside (w : I → ℝ) (J : I → Finset E) (C : Finset E)
    (r : I → ℝ) (e : E) (he : e ∉ C) :
    thinnedCyclePoint w J C r e = ∑ i, w i * incidence (J i) e := by
  unfold thinnedCyclePoint
  apply Finset.sum_congr rfl
  intro i _
  have hi : incidence (J i ∆ C) e = incidence (J i) e := by simp [incidence, Finset.mem_symmDiff, he]
  rw [hi]
  ring

theorem thinnedCyclePoint_selected (w : I → ℝ) (J : I → Finset E) (C : Finset E)
    (r : I → ℝ) (e : E) (he : e ∈ C) (hselected : ∀ i, r i ≠ 0 → e ∈ J i) :
    thinnedCyclePoint w J C r e = (∑ i, w i * incidence (J i) e) - ∑ i, r i := by
  have hd := thinnedCyclePoint_difference w J C r e
  have hz : (∑ i, r i * (incidence (J i ∆ C) e - incidence (J i) e)) = -∑ i, r i := by
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro i _
    by_cases hr : r i = 0
    · simp [hr]
    · have hi := hselected i hr
      simp [incidence, Finset.mem_symmDiff, he, hi]
  rw [hz] at hd
  linarith

theorem thinnedCyclePoint_change_bound (w : I → ℝ) (J : I → Finset E) (C : Finset E)
    (r : I → ℝ) (hr : ∀ i, 0 ≤ r i) (e : E) :
    |thinnedCyclePoint w J C r e - (∑ i, w i * incidence (J i) e)| ≤ ∑ i, r i := by
  rw [thinnedCyclePoint_difference]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro i _
  have hi : |incidence (J i ∆ C) e - incidence (J i) e| ≤ (1 : ℝ) := by
    by_cases h₁ : e ∈ J i ∆ C <;> by_cases h₂ : e ∈ J i <;> norm_num [incidence, h₁, h₂]
  rw [abs_mul, abs_of_nonneg (hr i)]
  simpa using mul_le_mul_of_nonneg_left hi (hr i)


theorem thinnedCyclePoint_selected_set (w : I → ℝ) (J : I → Finset E) (C S : Finset E)
    (r : I → ℝ) (hSC : S ⊆ C) (hselected : ∀ i, r i ≠ 0 → S ⊆ J i) :
    edgeSum (thinnedCyclePoint w J C r) S =
      edgeSum (fun e => ∑ i, w i * incidence (J i) e) S - (S.card : ℝ) * ∑ i, r i := by
  calc
    _ = ∑ e ∈ S, ((∑ i, w i * incidence (J i) e) - ∑ i, r i) :=
      Finset.sum_congr rfl (fun e he => thinnedCyclePoint_selected w J C r e (hSC he)
        (fun i hi => hselected i hi he))
    _ = _ := by simp [edgeSum, Finset.sum_sub_distrib]

theorem thinnedCyclePoint_set_loss (w : I → ℝ) (J : I → Finset E) (C S : Finset E)
    (r : I → ℝ) (hr : ∀ i, 0 ≤ r i) :
    edgeSum (fun e => ∑ i, w i * incidence (J i) e) S - edgeSum (thinnedCyclePoint w J C r) S ≤
      ((S ∩ C).card : ℝ) * ∑ i, r i := by
  have hstep : (∑ e ∈ S, ((∑ i, w i * incidence (J i) e) - thinnedCyclePoint w J C r e)) ≤
      ∑ e ∈ S, if e ∈ C then (∑ i, r i) else 0 := by
    apply Finset.sum_le_sum
    intro e he
    by_cases hc : e ∈ C
    · rw [if_pos hc]
      have hh := (abs_le.mp (thinnedCyclePoint_change_bound w J C r hr e)).1
      linarith
    · rw [if_neg hc, thinnedCyclePoint_outside w J C r e hc]
      simp
  simpa [edgeSum, Finset.sum_sub_distrib, Finset.sum_ite, Finset.filter_mem_eq_inter] using hstep

end TSP.Improvements20261105
