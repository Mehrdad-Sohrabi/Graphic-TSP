import Mathlib.Tactic

/-! Exact thinning of finite probability mass. No sampling procedure,
measure-theoretic existence result, or external numeric premise is used. -/
namespace TSP.Improvements20261105
open scoped BigOperators
open Classical
variable {I : Type} [Fintype I] [DecidableEq I]

theorem finite_event_thinning (w : I → ℝ) (S : Finset I) (m : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hm : 0 ≤ m) (hcap : m ≤ ∑ i ∈ S, w i) :
    ∃ r : I → ℝ, (∀ i, 0 ≤ r i ∧ r i ≤ w i) ∧
      (∀ i, i ∉ S → r i = 0) ∧ ∑ i, r i = m := by
  let W := ∑ i ∈ S, w i
  have hW : 0 ≤ W := Finset.sum_nonneg (fun i _ => hw i)
  by_cases hzero : W = 0
  · have hm0 : m = 0 := by change m ≤ W at hcap; linarith
    refine ⟨fun _ => 0, fun i => ⟨le_rfl, hw i⟩, fun _ _ => rfl, ?_⟩
    simp [hm0]
  · have hpos : 0 < W := lt_of_le_of_ne hW (Ne.symm hzero)
    have hratio0 : 0 ≤ m / W := div_nonneg hm hW
    have hratio1 : m / W ≤ 1 := (div_le_one hpos).mpr hcap
    let r : I → ℝ := fun i => if i ∈ S then (m / W) * w i else 0
    refine ⟨r, ?_, ?_, ?_⟩
    · intro i
      dsimp [r]
      split_ifs
      · exact ⟨mul_nonneg hratio0 (hw i), by simpa using mul_le_mul_of_nonneg_right hratio1 (hw i)⟩
      · exact ⟨le_rfl, hw i⟩
    · intro i hi
      simp [r, hi]
    · calc
        ∑ i, r i = ∑ i ∈ S, (m / W) * w i := by simp [r]
        _ = (m / W) * W := by rw [Finset.mul_sum]
        _ = m := div_mul_cancel₀ m hzero

end TSP.Improvements20261105
