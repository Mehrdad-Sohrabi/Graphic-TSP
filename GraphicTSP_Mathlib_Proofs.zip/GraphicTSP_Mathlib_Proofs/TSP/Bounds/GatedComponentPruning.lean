import TSP.Improvements20261105.GatedCutDependencies

/-! Pruning all selected heads in a true-cut component and all their
back-path dependencies preserves feasibility and causes no penalty to rise
in another component. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.componentHeads (P : GatePlan d) (a : GatedDrops d) (r : FlowVertex d) :
    Finset d.tree.Child := Finset.univ.filter (fun v => a.head v = 1 ∧ a.component d P (.inr v) = r)

noncomputable def GatedDrops.componentBacks (P : GatePlan d) (a : GatedDrops d) (r : FlowVertex d) :
    Finset (BackEdge d) := Finset.univ.filter (fun b => d.anchor b.1 ∈ a.componentHeads d P r)

noncomputable def GatedDrops.componentOutgoingCuts (P : GatePlan d) (a : GatedDrops d) (r : FlowVertex d) :
    Finset (expandedTree d).Child :=
  (a.trueCuts d P).filter (fun c => a.component d P ((expandedTree d).parent c) = r)

noncomputable def GatedDrops.pruneComponent (P : GatePlan d) (a : GatedDrops d) (r : FlowVertex d) :
    GatedDrops d := a.eraseBackDependencies d (a.componentBacks d P r) (a.componentHeads d P r)

@[simp] theorem GatedDrops.mem_componentHeads (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (v : d.tree.Child) :
    v ∈ a.componentHeads d P r ↔ a.head v = 1 ∧ a.component d P (.inr v) = r := by
  simp [componentHeads]

@[simp] theorem GatedDrops.mem_componentBacks (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (b : BackEdge d) :
    b ∈ a.componentBacks d P r ↔ d.anchor b.1 ∈ a.componentHeads d P r := by
  simp [componentBacks]

theorem GatedDrops.pruneComponent_admissible {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (r : FlowVertex d) : (a.pruneComponent d P r).Admissible d P :=
  a.eraseBackDependencies_admissible d ha _ _ (fun b hb => (a.mem_componentBacks d P r b).mpr hb)

theorem canonical_pruneComponent_penalty (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : FlowVertex d) (v : d.tree.Child) :
    (a.pruneComponent d P r).penalty d P v =
      if v ∈ a.componentHeads d P r then 0 else a.penalty d P v := by
  let q := a.pruneComponent d P r
  have hq := a.pruneComponent_admissible d ha r
  by_cases hv : v ∈ a.componentHeads d P r
  · rw [if_pos hv]
    exact q.penalty_zero_of_head_zero d hq v (by simp only [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, if_pos hv])
  · rw [if_neg hv]
    have hhead : q.head v = a.head v := by
      simp only [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, if_neg hv]
    by_cases hz : a.head v = 0
    · rw [a.penalty_zero_of_head_zero d ha v hz]
      exact q.penalty_zero_of_head_zero d hq v (hhead.trans hz)
    · have hsel := (a.head_binary d ha v).resolve_left hz
      have hrep := canonical_selected_rep_zero d P hP t ht f hf hb a hcan v hsel
      have hrepq : q.representative v = 0 := by
        simp [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, hrep]
      have hout : q.outside v = a.outside v := by
        simp only [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, if_neg hv]
      have htail : q.tail v = a.tail v := by
        by_cases hcover : backsUseTail d (a.componentBacks d P r) v
        · by_cases hzero : a.tail v = 0
          · simp [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, hzero]
          · have hpos : 0 < a.tail v := lt_of_le_of_ne (ha.tail_nonneg v) (Ne.symm hzero)
            obtain ⟨b, hb', hbottom⟩ := hcover
            have hbmem := (a.mem_componentHeads d P r (d.anchor b.1)).mp
              ((a.mem_componentBacks d P r b).mp hb')
            have hloc := canonical_positive_tail_dependency_local d P hP t ht f hf hb a ha hcan v hsel hpos b hbottom
            exact (hv ((a.mem_componentHeads d P r v).mpr ⟨hsel, hloc.trans hbmem.2⟩)).elim
        · simp [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, hcover]
      have hgate : P.UsesGate d v → q.pref (P.receiver v) = a.pref (P.receiver v) := by
        intro huse
        by_cases hcover : backsCoverConnector d (a.componentBacks d P r) (P.receiver v)
        · by_cases hzero : a.pref (P.receiver v) = 0
          · simp [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, hzero]
          · have hpos : 0 < a.pref (P.receiver v) :=
              lt_of_le_of_ne (ha.pref_nonneg _) (Ne.symm hzero)
            obtain ⟨b, hb', hpath⟩ := hcover
            have hbmem := (a.mem_componentHeads d P r (d.anchor b.1)).mp
              ((a.mem_componentBacks d P r b).mp hb')
            have hloc := canonical_positive_gate_dependency_local d hs hc P hP t ht f hf hb a ha hcan v huse hpos b hpath
            exact (hv ((a.mem_componentHeads d P r v).mpr ⟨hsel, hloc.2.trans hbmem.2⟩)).elim
        · simp [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, hcover]
      change q.penalty d P v = a.penalty d P v
      cases hk : P.kind v
      · simp [GatedDrops.penalty, hk]
      · simp [GatedDrops.penalty, hk, hhead, htail, hrep, hrepq]
      · simp [GatedDrops.penalty, hk, hhead, hrep, hrepq]
      · simp [GatedDrops.penalty, hk, hhead, htail, hrep, hrepq, hgate (Or.inl hk)]
      · simp [GatedDrops.penalty, hk, hhead, hout, hrep, hrepq, hgate (Or.inr hk)]

end TSP.Improvements20261105
