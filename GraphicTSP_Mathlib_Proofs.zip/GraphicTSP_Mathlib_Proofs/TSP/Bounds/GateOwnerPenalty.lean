import TSP.Improvements20261105.GatedConnectorShift

/-! Removing a prefix owned by an unselected head does not increase any
bypass penalty, including the shared-collector and outside-head cases. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem shifted_unselected_owner_bounds (P : GatePlan d) (hP : P.RespectsTree d)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (r v : d.tree.Child) (huse : P.UsesGate d v) (hrec : P.receiver v = r)
    (hpre : gatedPrefixDrop d p r = 1) (hhead : gatedHeadSelector d p v = 0) :
    shiftConnectorSubtree d p r (gatedTail d v) ≤ shiftConnectorSubtree d p r (gatedHead d v) ∧
    shiftConnectorSubtree d p r (gatedGate d (P.receiver v)) ≤ shiftConnectorSubtree d p r (gatedHead d v) := by
  have htail := gated_dual_tail d hp v
  have hrep := gated_dual_representative d hp v
  have hside := receiving_side_difference d P hP r v huse
  rw [if_pos hrec] at hside
  have hparent := hP v huse
  have hpre' : p (gatedCenter d v) - p (gatedGate d (P.receiver v)) = 1 := by
    rw [← hparent, hrec]
    exact hpre
  dsimp [gatedHeadSelector] at hhead
  simp only [shiftConnectorSubtree, gatedConnectorSide]
  constructor <;> omega

theorem shifted_nonowner_collector_bounds (P : GatePlan d) (hP : P.RespectsTree d)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (r v : d.tree.Child) (hk : P.kind v = .sharedGate) (hr : P.receiver v ≠ r) :
    max (shiftConnectorSubtree d p r (gatedTail d v))
      (shiftConnectorSubtree d p r (gatedGate d (P.receiver v))) ≤
      p (gatedCollector d v) + descendantBit d r v := by
  have hcol := gated_dual_collector_exits d hp v hk
  have ht := (le_max_left _ _).trans hcol
  have hg := (le_max_right _ _).trans hcol
  have hside := receiving_side_difference d P hP r v (Or.inl hk)
  rw [if_neg hr] at hside
  simp only [shiftConnectorSubtree, gatedConnectorSide]
  apply max_le <;> omega

theorem eraseGatePrefix_penalty_le (P : GatePlan d) (hP : P.RespectsTree d)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (r : d.tree.Child) (hpre : gatedPrefixDrop d p r = 1)
    (howner : ∀ v, P.UsesGate d v → P.receiver v = r → gatedHeadSelector d p v = 0)
    (v : d.tree.Child) :
    gatedBypassPenalty d P (eraseGatePrefix d P p r) v ≤ gatedBypassPenalty d P p v := by
  let q := shiftConnectorSubtree d p r
  cases hk : P.kind v with
  | disabled => simp [gatedBypassPenalty, hk]
  | outgoing =>
    simp only [gatedBypassPenalty, gatedBypassTarget, gatedBypassSource, hk]
    change max (((closeGatedCollectors d P q (gatedTail d v) : ℤ) : ℝ) -
      closeGatedCollectors d P q (gatedHead d v)) 0 ≤
      max ((p (gatedTail d v) : ℝ) - p (gatedHead d v)) 0
    rw [closeGatedCollectors_tail, closeGatedCollectors_head]
    apply max_le_max _ le_rfl
    have he : q (gatedTail d v) - q (gatedHead d v) = p (gatedTail d v) - p (gatedHead d v) := by
      dsimp [q, shiftConnectorSubtree, gatedConnectorSide]
      omega
    exact_mod_cast he.le
  | twoDirections =>
    simp only [gatedBypassPenalty, gatedBypassTarget, gatedBypassSource, hk]
    change max (((closeGatedCollectors d P q (gatedCenter d v) : ℤ) : ℝ) -
      closeGatedCollectors d P q (gatedHead d v)) 0 ≤
      max ((p (gatedCenter d v) : ℝ) - p (gatedHead d v)) 0
    rw [closeGatedCollectors_center, closeGatedCollectors_head]
    apply max_le_max _ le_rfl
    have he : q (gatedCenter d v) - q (gatedHead d v) = p (gatedCenter d v) - p (gatedHead d v) := by
      dsimp [q, shiftConnectorSubtree, gatedConnectorSide]
      omega
    exact_mod_cast he.le
  | sharedGate =>
    simp only [gatedBypassPenalty, gatedBypassTarget, gatedBypassSource, hk]
    change max (((closeGatedCollectors d P q (gatedCollector d v) : ℤ) : ℝ) -
      closeGatedCollectors d P q (gatedHead d v)) 0 ≤
      max ((p (gatedCollector d v) : ℝ) - p (gatedHead d v)) 0
    rw [closeGatedCollectors_shared d P q v hk, closeGatedCollectors_head]
    by_cases hr : P.receiver v = r
    · have he := shifted_unselected_owner_bounds d P hP p hp r v (Or.inl hk) hr hpre
        (howner v (Or.inl hk) hr)
      have hn : max (q (gatedTail d v)) (q (gatedGate d (P.receiver v))) - q (gatedHead d v) ≤ 0 :=
        sub_nonpos.mpr (max_le he.1 he.2)
      have hnR : (((max (q (gatedTail d v)) (q (gatedGate d (P.receiver v)))) : ℤ) : ℝ) -
          q (gatedHead d v) ≤ 0 := by exact_mod_cast hn
      rw [max_eq_right hnR]
      exact le_max_right _ _
    · have he := shifted_nonowner_collector_bounds d P hP p hp r v hk hr
      change max (q (gatedTail d v)) (q (gatedGate d (P.receiver v))) ≤
        p (gatedCollector d v) + descendantBit d r v at he
      apply max_le_max _ le_rfl
      have hh : max (q (gatedTail d v)) (q (gatedGate d (P.receiver v))) - q (gatedHead d v) ≤
          p (gatedCollector d v) - p (gatedHead d v) := by
        change _ - (p (gatedHead d v) + descendantBit d r v) ≤ _
        omega
      exact_mod_cast hh
  | outsideGate =>
    simp only [gatedBypassPenalty, gatedBypassTarget, gatedBypassSource, hk]
    change max (((closeGatedCollectors d P q (gatedGate d (P.receiver v)) : ℤ) : ℝ) -
      closeGatedCollectors d P q (gatedOutside d v)) 0 ≤
      max ((p (gatedGate d (P.receiver v)) : ℝ) - p (gatedOutside d v)) 0
    rw [closeGatedCollectors_gate, closeGatedCollectors_outside]
    by_cases hr : P.receiver v = r
    · have he := (shifted_unselected_owner_bounds d P hP p hp r v (Or.inr hk) hr hpre
        (howner v (Or.inr hk) hr)).2
      have hout := gated_dual_outside d hp v
      have hhead : q (gatedHead d v) ≤ q (gatedOutside d v) := by
        dsimp [q, shiftConnectorSubtree, gatedConnectorSide]
        omega
      have hnR : (q (gatedGate d (P.receiver v)) : ℝ) - q (gatedOutside d v) ≤ 0 := by
        exact_mod_cast sub_nonpos.mpr (he.trans hhead)
      rw [max_eq_right hnR]
      exact le_max_right _ _
    · have hside := receiving_side_difference d P hP r v (Or.inr hk)
      rw [if_neg hr] at hside
      apply max_le_max _ le_rfl
      have he : q (gatedGate d (P.receiver v)) - q (gatedOutside d v) =
          p (gatedGate d (P.receiver v)) - p (gatedOutside d v) := by
        dsimp [q, shiftConnectorSubtree, gatedConnectorSide]
        omega
      exact_mod_cast he.le

end TSP.Improvements20261105
