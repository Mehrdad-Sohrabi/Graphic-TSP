import TSP.Improvements20261105.JoinMixtureGuard

/-! A two-edge star intersection can increase its deficit only on an
atom containing the representative. This gives the sharp controlled cap. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Classical
open scoped BigOperators symmDiff
variable {E I : Type} [Fintype I] [DecidableEq E]

 theorem symmDiff_set_loss (J C S : Finset E) :
    edgeSum (incidence J) S - edgeSum (incidence (J ∆ C)) S =
      ∑ e ∈ S ∩ C, (2*incidence J e - 1) := by
  rw [edgeSum, edgeSum, ← Finset.sum_sub_distrib]
  calc
    _ = ∑ e ∈ S, (if e ∈ C then 2*incidence J e - 1 else 0) := by
      apply Finset.sum_congr rfl
      intro e _
      by_cases hc : e ∈ C <;> by_cases hj : e ∈ J <;>
        simp [incidence, Finset.mem_symmDiff, hc, hj] <;> norm_num
    _ = _ := by rw [← Finset.sum_filter]; rfl

 theorem cycle_pair_loss (J C S : Finset E) (e f : E) (hef : e ≠ f)
    (hSC : S ∩ C = {e,f}) :
    edgeSum (incidence J) S - edgeSum (incidence (J ∆ C)) S ≤ 2*incidence J e := by
  rw [symmDiff_set_loss, hSC]
  simp only [Finset.sum_insert (show e ∉ ({f} : Finset E) by simpa using hef), Finset.sum_singleton]
  have hf : incidence J f ≤ 1 := by simp [incidence]; split_ifs <;> norm_num
  linarith

 theorem thinnedCyclePoint_loss_identity (w : I → ℝ) (J : I → Finset E) (C S : Finset E) (r : I → ℝ) :
    edgeSum (fun e => ∑ i, w i * incidence (J i) e) S - edgeSum (thinnedCyclePoint w J C r) S =
      ∑ i, r i * (edgeSum (incidence (J i)) S - edgeSum (incidence (J i ∆ C)) S) := by
  simp only [edgeSum, Finset.mul_sum, Finset.sum_sub_distrib]
  rw [Finset.sum_comm (s := S)]
  unfold thinnedCyclePoint
  rw [Finset.sum_comm (s := S), ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i _
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum]
  ring

 theorem thinnedCyclePoint_pair_loss (w : I → ℝ) (J : I → Finset E) (C S : Finset E)
    (r : I → ℝ) (hr : ∀ i, 0 ≤ r i) (e f : E) (hef : e ≠ f) (hSC : S ∩ C = {e,f}) :
    edgeSum (fun e => ∑ i, w i * incidence (J i) e) S - edgeSum (thinnedCyclePoint w J C r) S ≤
      2*∑ i, r i * incidence (J i) e := by
  rw [thinnedCyclePoint_loss_identity, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  have hh := mul_le_mul_of_nonneg_left (cycle_pair_loss (J i) C S e f hef hSC) (hr i)
  nlinarith

end TSP.Improvements20261105
