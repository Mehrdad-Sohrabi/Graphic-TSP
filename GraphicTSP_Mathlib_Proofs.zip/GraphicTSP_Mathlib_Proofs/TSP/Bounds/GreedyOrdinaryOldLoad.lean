import TSP.Improvements20261105.GreedyActualPackingEnvelope

/-! The old incidence arm is paid for every integer count. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {I : Type} [DecidableEq I]

theorem greedy_old_ramp_mass_row (S : Finset I) (z : I → ℝ) (q : ℝ)
    (hq : 0 ≤ q) (hq1 : q ≤ 1) (hz : ∀ i ∈ S, 0 ≤ z i)
    (hcap : ∀ i ∈ S, z i ≤ q) (ha : 1 ≤ ∑ i ∈ S, z i)
    (hpack : (∑ i ∈ S, z i)+q ≤ 2) :
    (∑ i ∈ S, incidenceRamp (1/2) (z i)) ≤ (∑ i ∈ S, z i)-1+2*q := by
  have hc : 1 ≤ S.card := by
    by_contra hn
    have he : S=∅ := Finset.card_eq_zero.mp (by omega)
    norm_num [he] at ha
  have hm : (∑ i ∈ S, z i) ≤ (S.card : ℝ)*q := by
    have hh := Finset.sum_le_sum hcap
    simpa using hh
  obtain ⟨k,hk,hlo,hhi⟩ := exists_mass_interval S.card q (∑ i ∈ S, z i) hc hq
    (by linarith) hm
  have he := greedy_old_actual_envelope S z q k hz hcap
  by_cases hlow : q ≤ 1/4
  · rw [greedyOldEnvelope,if_pos hlow] at he
    linarith only [he,ha,hq]
  · rw [greedyOldEnvelope,if_neg hlow] at he
    exact he.trans (greedy_packed_old_rows q _ k (le_of_not_ge hlow) hq1 ha hpack hlo hhi).2.2

theorem integer_count_old_payment (t : ℕ) (a j q : ℝ) (ht : 1 ≤ t)
    (hcount : a ≤ (t : ℝ)*q) (hmass : a-1+j ≤ 2)
    (hj : j ≤ a-1+2*q) :
    24*(a-1)+24*j-84*q ≤ 4*(t : ℝ) := by
  have htR : (1 : ℝ) ≤ t := by exact_mod_cast ht
  have h1 : 24*(a-1)+24*j-84*q ≤ 48-84*q := by linarith only [hmass]
  have h2 : 24*(a-1)+24*j-84*q ≤ (48*(t : ℝ)-36)*q-48 := by
    linarith only [hj,hcount]
  have hscale := mul_le_mul_of_nonneg_left h1 (show 0 ≤ 48*(t : ℝ)-36 by linarith)
  have hweighted : ((t : ℝ)+1)*(24*(a-1)+24*j-84*q) ≤ 48*(t : ℝ)-120 := by
    nlinarith only [hscale,h2]
  have hdisc : 0 ≤ ((t : ℝ)-5)*((t : ℝ)-6) := by
    by_cases ht5 : t≤5
    · have hr : (t : ℝ) ≤ 5 := by exact_mod_cast ht5
      exact mul_nonneg_of_nonpos_of_nonpos (by linarith) (by linarith)
    · have hr : (6 : ℝ) ≤ t := by exact_mod_cast (show 6≤t by omega)
      exact mul_nonneg (by linarith) (by linarith)
  nlinarith only [hweighted,hdisc,htR]

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem greedy_ordinary_old_load (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : 0 ≤ q) (hq1 : q ≤ 1) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hcap : ∀ e ∈ d.backGroup s, z e ≤ q) (ha : 1 ≤ edgeSum z (d.backGroup s))
    (hpack : edgeSum z (d.backGroup s)+q ≤ 2) :
    24*(edgeSum z (d.backGroup s)-1)+24*oldIncidence d z s-84*q ≤
      4*(d.backGroup s).card := by
  have hj := greedy_old_ramp_mass_row (d.backGroup s) z q hq hq1 hz hcap ha hpack
  have hm := greedy_ramp_mass_bound (d.backGroup s) z q hq hz hcap hpack
  have hc : 1 ≤ (d.backGroup s).card := by
    by_contra hn
    have he : d.backGroup s=∅ := Finset.card_eq_zero.mp (by omega)
    norm_num [he,edgeSum] at ha
  have hcount : edgeSum z (d.backGroup s) ≤ ((d.backGroup s).card : ℝ)*q := by
    have hh := Finset.sum_le_sum hcap
    simpa [edgeSum] using hh
  have hh := integer_count_old_payment (d.backGroup s).card (edgeSum z (d.backGroup s))
    (starIncidenceRamp d (1/2) z s) q hc hcount hm hj
  have ho := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  unfold oldIncidence
  linarith only [hh,ho]

end TSP.Improvements20261105
