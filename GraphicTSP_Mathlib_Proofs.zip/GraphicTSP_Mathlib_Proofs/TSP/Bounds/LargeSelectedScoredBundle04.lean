import TSP.Improvements20261105.LargeSelectedScoredT7R4CapPointwise
import TSP.Improvements20261105.LargeSelectedGreedyScoredSourceEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_10
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4019/16000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1338392203/8936954:ℝ)*hBl + (112651/458:ℝ)*hzl + (12196434/108775:ℝ)*hR0 + (112651/458:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (26545455785/169802126:ℝ)*hBl + (41753675/165338:ℝ)*hzl + (47650446/413345:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_11
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (393/1600 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (3323/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (93076270/343729:ℝ)*hBl + (48139956/282815:ℝ)*hMu + (48139956/282815:ℝ)*hqM + (225302/1145:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (112651/2290:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-24571/2290:ℝ)*hmass
  · linear_combination (23848303250/84901063:ℝ)*hBl + (188147820/1074697:ℝ)*hMu + (188147820/1074697:ℝ)*hqM + (16701470/82669:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (8350735/165338:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-904695/165338:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_12
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (393/1600 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (347116373/2302534:ℝ)*hBl + (29141/118:ℝ)*hzl + (3155694/28025:ℝ)*hR0 + (29141/118:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (6870143095/43748146:ℝ)*hBl + (10787605/42598:ℝ)*hzl + (12312882/106495:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_13
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (2683950875/66422252:ℝ)*hMl + (4468492457/5109404:ℝ)*hzu + (107358035/5109404:ℝ)*hRo + (2683950875/66422252:ℝ)*hchoice + (10311316451/166055630:ℝ)*heq + (24/1:ℝ)*hgap + (1143962623/5109404:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-952843295/5109404:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (2683950875/66422252:ℝ)*hMl + (87572375755/97078676:ℝ)*hzu + (107358035/5109404:ℝ)*hRo + (2683950875/66422252:ℝ)*hchoice + (10311316451/166055630:ℝ)*heq + (24/1:ℝ)*hgap + (22403044605/97078676:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-952843295/5109404:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_14
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (77/320 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1621/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (1621/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_1 hBu
  have hCaffine := hAffine (1621/6400 : ℝ) (-284207097/31630573 : ℝ) (14324565/4995328 : ℝ) large_selected_scored_t7_r4_cap_point_affine_1 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_15
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (31233991620397/146218031245:ℝ)*hMl + (23978465686953/281188521625:ℝ)*hR0 + (442778/2255:ℝ)*hRo + (31233991620397/146218031245:ℝ)*hchoice + (38878154123/648416990:ℝ)*hg0 + (54440161883/648416990:ℝ)*hgap + (221389/4510:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-50269/4510:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (121677586920667/555628518731:ℝ)*hMl + (93876710007183/1068516382175:ℝ)*hR0 + (32844242/162811:ℝ)*hRo + (121677586920667/555628518731:ℝ)*hchoice + (38878154123/648416990:ℝ)*hg0 + (54440161883/648416990:ℝ)*hgap + (16422121/325622:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1878081/325622:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_16
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (7817018522219/29697498142:ℝ)*hMl + (112651/458:ℝ)*hzl + (3115031348553/28555286675:ℝ)*hR0 + (112651/458:ℝ)*hRo + (7817018522219/29697498142:ℝ)*hchoice + (38878154123/648416990:ℝ)*hg0 + (54440161883/648416990:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (152231832974905/564252464698:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (12179440452447/108510089365:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (152231832974905/564252464698:ℝ)*hchoice + (38878154123/648416990:ℝ)*hg0 + (54440161883/648416990:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_17
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_18
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (3323/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6727/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6727/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_3 hBu
  have hCaffine := hAffine (6727/25600 : ℝ) (-742963539/131263951 : ℝ) (48371655/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_3 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (63549411943553/296000209505:ℝ)*hBl + (1/1:ℝ)*hCaffine + (48221337471597/569231172125:ℝ)*hR0 + (442778/2255:ℝ)*hRo + (80123419927/1312639510:ℝ)*hg0 + (111626768167/1312639510:ℝ)*hgap + (221389/4510:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-50269/4510:ℝ)*hmass
  · linear_combination (247537447305383/1124800796119:ℝ)*hBl + (1/1:ℝ)*hCaffine + (188825404164267/2163078454075:ℝ)*hR0 + (32844242/162811:ℝ)*hRo + (80123419927/1312639510:ℝ)*hg0 + (111626768167/1312639510:ℝ)*hgap + (16422121/325622:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1878081/325622:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_19
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (6727/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4197/16000 : ℝ) (2581/13990 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2375948890/8800363:ℝ)*hBl + (10411304741964/61558539185:ℝ)*hMu + (10411304741964/61558539185:ℝ)*hqM + (442778/2255:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (221389/4510:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-50269/4510:ℝ)*hmass
  · linear_combination (46872477950/167206897:ℝ)*hBl + (40724317638804/233922448903:ℝ)*hMu + (40724317638804/233922448903:ℝ)*hqM + (32844242/162811:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (16422121/325622:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1878081/325622:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_20
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (3323/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4197/16000 : ℝ) (2581/13990 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1881215283997/12502798646:ℝ)*hBl + (112651/458:ℝ)*hzl + (1343559786114/12021921775:ℝ)*hR0 + (112651/458:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (37304379891215/237553174274:ℝ)*hBl + (41753675/165338:ℝ)*hzl + (5249646217566/45683302745:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_21
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (3323/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6727/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6727/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_3 hBu
  have hCaffine := hAffine (6727/25600 : ℝ) (-742963539/131263951 : ℝ) (48371655/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_3 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (63549411943553/296000209505:ℝ)*hMl + (48221337471597/569231172125:ℝ)*hR0 + (442778/2255:ℝ)*hRo + (63549411943553/296000209505:ℝ)*hchoice + (80123419927/1312639510:ℝ)*hg0 + (111626768167/1312639510:ℝ)*hgap + (221389/4510:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-50269/4510:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (247537447305383/1124800796119:ℝ)*hMl + (188825404164267/2163078454075:ℝ)*hR0 + (32844242/162811:ℝ)*hRo + (247537447305383/1124800796119:ℝ)*hchoice + (80123419927/1312639510:ℝ)*hg0 + (111626768167/1312639510:ℝ)*hgap + (16422121/325622:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1878081/325622:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_22
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (8483/32000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (179/512 : ℝ))
    (hBl : (6727/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (179/512 : ℝ) (102/179 : ℝ) (1097/1790 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3203296486373/14861978885:ℝ)*hBl + (1/1:ℝ)*hCaffine + (2402549979777/28580728625:ℝ)*hR0 + (175546/895:ℝ)*hRo + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (87773/1790:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-20333/1790:ℝ)*hmass
  · linear_combination (62398805134447/282377598815:ℝ)*hBl + (1/1:ℝ)*hCaffine + (47066454440403/543033843875:ℝ)*hR0 + (65129786/323095:ℝ)*hRo + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (32564893/646190:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-3824853/646190:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_23
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (8483/32000 : ℝ))
    (hzl : (179/512 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (6727/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3966799829717/14978217826:ℝ)*hBl + (1/1:ℝ)*hCaffine + (221389/902:ℝ)*hzl + (1551493341879/14402132525:ℝ)*hR0 + (221389/902:ℝ)*hRo + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (77282486237575/284586138694:ℝ)*hBl + (1/1:ℝ)*hCaffine + (82110605/325622:ℝ)*hzl + (1214457207021/10945620719:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_24
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (8483/32000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (6727/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (8078855080789/37445544565:ℝ)*hMl + (6060717946161/72010662625:ℝ)*hR0 + (442778/2255:ℝ)*hRo + (8078855080789/37445544565:ℝ)*hchoice + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (221389/4510:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-50269/4510:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (31464965096179/142293069347:ℝ)*hMl + (23737173539271/273640517975:ℝ)*hR0 + (32844242/162811:ℝ)*hRo + (31464965096179/142293069347:ℝ)*hchoice + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (16422121/325622:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-1878081/325622:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_25
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (3323/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (2018143217603/7605347854:ℝ)*hMl + (112651/458:ℝ)*hzl + (789614234961/7312834475:ℝ)*hR0 + (112651/458:ℝ)*hRo + (2018143217603/7605347854:ℝ)*hchoice + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (39294440477185/144501609226:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (3088200493719/27788771005:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (39294440477185/144501609226:ℝ)*hchoice + (10311316451/166055630:ℝ)*hg0 + (14296651571/166055630:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_26
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3323/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3323/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_2 hBu
  have hCaffine := hAffine (3323/12800 : ℝ) (-437125911/64841699 : ℝ) (25673595/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_2 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (2021602784629/7651320482:ℝ)*hMl + (29141/118:ℝ)*hzl + (806075483223/7357038925:ℝ)*hR0 + (29141/118:ℝ)*hRo + (2021602784629/7651320482:ℝ)*hchoice + (38878154123/648416990:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (39324051970535/145375089158:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (3147419057409/27956747915:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (39324051970535/145375089158:ℝ)*hchoice + (38878154123/648416990:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_27
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (3323/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (521907455773/1959456434:ℝ)*hBl + (1/1:ℝ)*hCaffine + (29141/118:ℝ)*hzl + (204337340751/1884092725:ℝ)*hR0 + (29141/118:ℝ)*hRo + (10311316451/166055630:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10150208798495/37229672246:ℝ)*hBl + (1/1:ℝ)*hCaffine + (10787605/42598:ℝ)*hzl + (798078861513/7159552355:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (10311316451/166055630:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_28
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1621/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (851/3200 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (851/3200 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_4 hBu
  have hCaffine := hAffine (851/3200 : ℝ) (-76459407/16605563 : ℝ) (5674515/2497664 : ℝ) large_selected_scored_t7_r4_cap_point_affine_4 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_29
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (469/2000 : ℝ) ≤ M) (hMu : M ≤ (1027/4000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (1027/4000 : ℝ) (1513/10270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (313506410/1151267:ℝ)*hBl + (12456396/72865:ℝ)*hMu + (12456396/72865:ℝ)*hqM + (58282/295:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (29141/590:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-5861/590:ℝ)*hmass
  · linear_combination (6168107950/21874073:ℝ)*hBl + (48619284/276887:ℝ)*hMu + (48619284/276887:ℝ)*hqM + (4315042/21299:ℝ)*hRo + (133669/2470:ℝ)*hg0 + (192949/2470:ℝ)*hgap + (2157521/42598:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-209001/42598:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_30
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3385530125/41816359:ℝ)*hBu + (301335483313/276631298:ℝ)*hzu + (44590795/3216643:ℝ)*hRo + (16416782833/83632718:ℝ)*hg0 + (18423968065/83632718:ℝ)*hgap + (1/1:ℝ)*hH0 + (63602112125/276631298:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-1245725255/6433286:ℝ)*hmass
  · linear_combination (3385530125/41816359:ℝ)*hBu + (5876842177283/5255994662:ℝ)*hzu + (44590795/3216643:ℝ)*hRo + (16416782833/83632718:ℝ)*hg0 + (18423968065/83632718:ℝ)*hgap + (1/1:ℝ)*hH0 + (1246307128959/5255994662:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-1245725255/6433286:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_31
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4197/16000 : ℝ) (2581/13990 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (194326230/721981:ℝ)*hBl + (852140024148/5050257095:ℝ)*hMu + (852140024148/5050257095:ℝ)*hqM + (36246/185:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (3837362450/13717639:ℝ)*hBl + (3335612674764/19190976961:ℝ)*hMu + (3335612674764/19190976961:ℝ)*hqM + (2690462/13357:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_32
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (75510863908/117157010847:ℝ)*hCaffine + (2862072037294004701/2696407656980654:ℝ)*hzu + (1166092114292000/58617557760449:ℝ)*hRo + (307650578818110179/1524056501771674:ℝ)*hg0 + (344227934860630355/1524056501771674:ℝ)*hgap + (1/1:ℝ)*hH0 + (605230367373871673/2696407656980654:ℝ)*htarget + (41646146939/117157010847:ℝ)*hC + (1/1:ℝ)*hI + (-21994102242002335/117235115520898:ℝ)*hmass
  · linear_combination (75510863908/117157010847:ℝ)*hCaffine + (2937991029997643069/2696407656980654:ℝ)*hzu + (1166092114292000/58617557760449:ℝ)*hRo + (307650578818110179/1524056501771674:ℝ)*hg0 + (344227934860630355/1524056501771674:ℝ)*hgap + (1/1:ℝ)*hH0 + (624210115549781265/2696407656980654:ℝ)*htarget + (41646146939/117157010847:ℝ)*hC + (1/1:ℝ)*hI + (-21994102242002335/117235115520898:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_33
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6889/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6889/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_5 hBu
  have hCaffine := hAffine (6889/25600 : ℝ) (-480386973/134425057 : ℝ) (42420585/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_5 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5380346279097/24868635545:ℝ)*hBl + (1/1:ℝ)*hCaffine + (3989597213253/47824299125:ℝ)*hR0 + (36246/185:ℝ)*hRo + (84857643289/1344250570:ℝ)*hg0 + (117119656969/1344250570:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (20965334241071/94500815071:ℝ)*hBl + (1/1:ℝ)*hCaffine + (15640486376979/181732336675:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (84857643289/1344250570:ℝ)*hg0 + (117119656969/1344250570:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_34
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (6889/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (181230/481:ℝ)*hBl + (1/1:ℝ)*hCaffine + (401117312469/2516103785:ℝ)*hMu + (401117312469/2516103785:ℝ)*hqM + (36246/185:ℝ)*hRo + (8722475497/136005610:ℝ)*hg0 + (11986610137/136005610:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (67261550/173641:ℝ)*hBl + (1/1:ℝ)*hCaffine + (1572811881987/9561194383:ℝ)*hMu + (1572811881987/9561194383:ℝ)*hqM + (2690462/13357:ℝ)*hRo + (8722475497/136005610:ℝ)*hg0 + (11986610137/136005610:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_35
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (194326230/721981:ℝ)*hBl + (1300093741236/7736026415:ℝ)*hMu + (1300093741236/7736026415:ℝ)*hqM + (36246/185:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (3837362450/13717639:ℝ)*hBl + (5089677795948/29396900377:ℝ)*hMu + (5089677795948/29396900377:ℝ)*hqM + (2690462/13357:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_36
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (27441625/563428:ℝ)*hMl + (25002290999/24227404:ℝ)*hzu + (14269645/563428:ℝ)*hRo + (27441625/563428:ℝ)*hchoice + (58280509/281714:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5292539275/24227404:ℝ)*htarget + (1/1:ℝ)*hI + (-102641665/563428:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (27441625/563428:ℝ)*hMl + (9277873185871/8746092844:ℝ)*hzu + (14269645/563428:ℝ)*hRo + (27441625/563428:ℝ)*hchoice + (58280509/281714:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1973618212083/8746092844:ℝ)*htarget + (1/1:ℝ)*hI + (-102641665/563428:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_37
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (546894099081/2516103785:ℝ)*hMl + (401117312469/4838661125:ℝ)*hR0 + (36246/185:ℝ)*hRo + (546894099081/2516103785:ℝ)*hchoice + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (2130810845663/9561194383:ℝ)*hMl + (1572811881987/18386912275:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (2130810845663/9561194383:ℝ)*hchoice + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_38
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (27441625/563428:ℝ)*hBl + (1/1:ℝ)*hCaffine + (254656583209/246218036:ℝ)*hzu + (14269645/563428:ℝ)*hRo + (58280509/281714:ℝ)*hg0 + (65041645/281714:ℝ)*hgap + (1/1:ℝ)*hH0 + (53927852117/246218036:ℝ)*htarget + (1/1:ℝ)*hI + (-102641665/563428:ℝ)*hmass
  · linear_combination (27441625/563428:ℝ)*hBl + (1/1:ℝ)*hCaffine + (261589001321/246218036:ℝ)*hzu + (14269645/563428:ℝ)*hRo + (58280509/281714:ℝ)*hg0 + (65041645/281714:ℝ)*hgap + (1/1:ℝ)*hH0 + (55660956645/246218036:ℝ)*htarget + (1/1:ℝ)*hI + (-102641665/563428:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_39
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (7051/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (7051/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_7 hBu
  have hCaffine := hAffine (7051/25600 : ℝ) (-217810407/137586163 : ℝ) (36469515/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_7 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5557535702523/25453440155:ℝ)*hBl + (1/1:ℝ)*hCaffine + (4032749036127/48948923375:ℝ)*hR0 + (36246/185:ℝ)*hRo + (89591866651/1375861630:ℝ)*hg0 + (122612545771/1375861630:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (21650882672189/96723072589:ℝ)*hBl + (1/1:ℝ)*hCaffine + (15815751262761/186005908825:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (89591866651/1375861630:ℝ)*hg0 + (122612545771/1375861630:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_40
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (7051/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (181230/481:ℝ)*hBl + (1/1:ℝ)*hCaffine + (53346380889/338761085:ℝ)*hMu + (53346380889/338761085:ℝ)*hqM + (36246/185:ℝ)*hRo + (93075889/1408570:ℝ)*hg0 + (126881569/1408570:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (67261550/173641:ℝ)*hBl + (1/1:ℝ)*hCaffine + (3975845926413/24458550337:ℝ)*hMu + (3975845926413/24458550337:ℝ)*hqM + (2690462/13357:ℝ)*hRo + (93075889/1408570:ℝ)*hg0 + (126881569/1408570:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_41
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (35/128 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (5714706897/26058545:ℝ)*hMl + (53346380889/651463625:ℝ)*hR0 + (36246/185:ℝ)*hRo + (5714706897/26058545:ℝ)*hchoice + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (422954940149/1881426949:ℝ)*hMl + (3975845926413/47035673725:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (422954940149/1881426949:ℝ)*hchoice + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_42
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (194326230/721981:ℝ)*hBl + (1300093741236/7736026415:ℝ)*hMu + (1300093741236/7736026415:ℝ)*hqM + (36246/185:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (3837362450/13717639:ℝ)*hBl + (5089677795948/29396900377:ℝ)*hMu + (5089677795948/29396900377:ℝ)*hqM + (2690462/13357:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_43
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (279/1000 : ℝ) (89/310 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (353225204/607061295:ℝ)*hCaffine + (5441614688681173/5224207621758:ℝ)*hzu + (1421482109600/60746600253:ℝ)*hRo + (107979200145821/526470535526:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1151305012878545/5224207621758:ℝ)*htarget + (253836091/607061295:ℝ)*hC + (1/1:ℝ)*hI + (-22366874885795/121493200506:ℝ)*hmass
  · linear_combination (353225204/607061295:ℝ)*hCaffine + (106251166152687343/99259944813402:ℝ)*hzu + (1421482109600/60746600253:ℝ)*hRo + (107979200145821/526470535526:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (22589917011628619/99259944813402:ℝ)*htarget + (253836091/607061295:ℝ)*hC + (1/1:ℝ)*hI + (-22366874885795/121493200506:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_44
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2911659918831/13165323535:ℝ)*hBl + (1/1:ℝ)*hCaffine + (2048738385219/25317929875:ℝ)*hR0 + (36246/185:ℝ)*hRo + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (11339602659433/50028229433:ℝ)*hBl + (1/1:ℝ)*hCaffine + (8039324295717/96208133525:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_45
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
    (hBl : (3647/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (181230/481:ℝ)*hBl + (1/1:ℝ)*hCaffine + (129394643541/841107865:ℝ)*hMu + (129394643541/841107865:ℝ)*hqM + (36246/185:ℝ)*hRo + (3169607033/45465290:ℝ)*hg0 + (4260773993/45465290:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (67261550/173641:ℝ)*hBl + (1/1:ℝ)*hCaffine + (507934796163/3196209887:ℝ)*hMu + (507934796163/3196209887:ℝ)*hqM + (2690462/13357:ℝ)*hRo + (3169607033/45465290:ℝ)*hg0 + (4260773993/45465290:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_46
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (4197/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (4197/16000 : ℝ) (2581/13990 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3265428775/8936954:ℝ)*hBl + (103350752778/480876871:ℝ)*hMu + (112651/458:ℝ)*hzl + (103350752778/480876871:ℝ)*hqM + (112651/458:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (64189308125/169802126:ℝ)*hBl + (26248231087830/118776587137:ℝ)*hMu + (41753675/165338:ℝ)*hzl + (26248231087830/118776587137:ℝ)*hqM + (41753675/165338:ℝ)*hRo + (14965471549/272986870:ℝ)*hg0 + (21517156429/272986870:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_47
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (8483/32000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6889/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (8483/32000 : ℝ) (17177/84830 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6889/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_5 hBu
  have hCaffine := hAffine (6889/25600 : ℝ) (-480386973/134425057 : ℝ) (42420585/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_5 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6413422225/17600726:ℝ)*hBl + (15983304948582/74653479329:ℝ)*hMu + (221389/902:ℝ)*hzl + (15983304948582/74653479329:ℝ)*hqM + (221389/902:ℝ)*hRo + (91309376033/1655287790:ℝ)*hg0 + (131036282993/1655287790:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (126178644875/334413794:ℝ)*hBl + (312485343746850/1418416107251:ℝ)*hMu + (82110605/325622:ℝ)*hzl + (312485343746850/1418416107251:ℝ)*hqM + (82110605/325622:ℝ)*hRo + (91309376033/1655287790:ℝ)*hg0 + (131036282993/1655287790:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_48
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (8483/32000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (179/512 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6889/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (179/512 : ℝ) (102/179 : ℝ) (1097/1790 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6889/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_5 hBu
  have hCaffine := hAffine (6889/25600 : ℝ) (-480386973/134425057 : ℝ) (42420585/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_5 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (12781892081471/48124170406:ℝ)*hBl + (1/1:ℝ)*hCaffine + (87773/358:ℝ)*hzl + (4954141005477/46273240775:ℝ)*hR0 + (87773/358:ℝ)*hRo + (84857643289/1344250570:ℝ)*hg0 + (117119656969/1344250570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (6744/179:ℝ)*hmass
  · linear_combination (249073745184469/914359237714:ℝ)*hBl + (1/1:ℝ)*hCaffine + (32564893/129238:ℝ)*hzl + (96998430936303/879191574725:ℝ)*hR0 + (32564893/129238:ℝ)*hRo + (84857643289/1344250570:ℝ)*hg0 + (117119656969/1344250570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2874004/64619:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_49
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (8483/32000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (179/512 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6889/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6889/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_5 hBu
  have hCaffine := hAffine (6889/25600 : ℝ) (-480386973/134425057 : ℝ) (42420585/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_5 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (32236953528463/121251401414:ℝ)*hBl + (1/1:ℝ)*hCaffine + (221389/902:ℝ)*hzl + (12497127989781/116587885975:ℝ)*hR0 + (221389/902:ℝ)*hRo + (84857643289/1344250570:ℝ)*hg0 + (117119656969/1344250570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (627990543808325/2303776626866:ℝ)*hBl + (1/1:ℝ)*hCaffine + (82110605/325622:ℝ)*hzl + (9783757458711/88606793341:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (84857643289/1344250570:ℝ)*hg0 + (117119656969/1344250570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_50
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (6889/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5534725/11726:ℝ)*hBl + (1/1:ℝ)*hCaffine + (30688559133/149606171:ℝ)*hMu + (221389/902:ℝ)*hzl + (30688559133/149606171:ℝ)*hqM + (221389/902:ℝ)*hRo + (8722475497/136005610:ℝ)*hg0 + (11986610137/136005610:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (2052765125/4233086:ℝ)*hBl + (1/1:ℝ)*hCaffine + (600723003735/2842517249:ℝ)*hMu + (82110605/325622:ℝ)*hzl + (600723003735/2842517249:ℝ)*hqM + (82110605/325622:ℝ)*hRo + (8722475497/136005610:ℝ)*hg0 + (11986610137/136005610:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_51
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (4197/16000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2894588267029/19151892422:ℝ)*hBl + (112651/458:ℝ)*hzl + (2051612798898/18415281175:ℝ)*hR0 + (112651/458:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (57388773491255/363885956018:ℝ)*hBl + (41753675/165338:ℝ)*hzl + (8016891382062/69978068465:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_52
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3265428775/8936954:ℝ)*hBl + (157816369146/736611247:ℝ)*hMu + (112651/458:ℝ)*hzl + (157816369146/736611247:ℝ)*hqM + (112651/458:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (64189308125/169802126:ℝ)*hBl + (40084456910310/181942978009:ℝ)*hMu + (41753675/165338:ℝ)*hzl + (40084456910310/181942978009:ℝ)*hqM + (41753675/165338:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_53
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (750675683339/4934330362:ℝ)*hBl + (29141/118:ℝ)*hzl + (530846879118/4744548425:ℝ)*hR0 + (29141/118:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (14852017276585/93752276878:ℝ)*hBl + (10787605/42598:ℝ)*hzl + (2071603921554/18029284015:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_54
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (6889/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (6889/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_5 hBu
  have hCaffine := hAffine (6889/25600 : ℝ) (-480386973/134425057 : ℝ) (42420585/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_5 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (32236953528463/121251401414:ℝ)*hMl + (221389/902:ℝ)*hzl + (12497127989781/116587885975:ℝ)*hR0 + (221389/902:ℝ)*hRo + (32236953528463/121251401414:ℝ)*hchoice + (84857643289/1344250570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (627990543808325/2303776626866:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (9783757458711/88606793341:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (627990543808325/2303776626866:ℝ)*hchoice + (84857643289/1344250570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_55
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (6889/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (79852459559/299212342:ℝ)*hBl + (1/1:ℝ)*hCaffine + (221389/902:ℝ)*hzl + (30688559133/287704175:ℝ)*hR0 + (221389/902:ℝ)*hRo + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (1555417555405/5685034498:ℝ)*hBl + (1/1:ℝ)*hCaffine + (82110605/325622:ℝ)*hzl + (120144600747/1093275865:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_56
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (1665625443721/6229056938:ℝ)*hMl + (112651/458:ℝ)*hzl + (640376506227/5989477825:ℝ)*hR0 + (112651/458:ℝ)*hRo + (1665625443721/6229056938:ℝ)*hchoice + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (32424738168515/118352081822:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (2505232699461/22760015735:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (32424738168515/118352081822:ℝ)*hchoice + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_57
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (35/128 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hBu,hMl,hchoice,hmass]

theorem large_selected_scored_t7_r4_cap_cell_58
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (7051/25600 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (7051/25600 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_7 hBu
  have hCaffine := hAffine (7051/25600 : ℝ) (-217810407/137586163 : ℝ) (36469515/19981312 : ℝ) large_selected_scored_t7_r4_cap_point_affine_7 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3022005755447/11282065366:ℝ)*hBl + (1/1:ℝ)*hCaffine + (221389/902:ℝ)*hzl + (1151590045389/10848139775:ℝ)*hR0 + (221389/902:ℝ)*hRo + (89591866651/1375861630:ℝ)*hg0 + (122612545771/1375861630:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (58859259238525/214359241954:ℝ)*hBl + (1/1:ℝ)*hCaffine + (82110605/325622:ℝ)*hzl + (901814278527/8244586229:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (89591866651/1375861630:ℝ)*hg0 + (122612545771/1375861630:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_59
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (7051/25600 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5534725/11726:ℝ)*hBl + (1/1:ℝ)*hCaffine + (167798312553/825844591:ℝ)*hMu + (221389/902:ℝ)*hzl + (167798312553/825844591:ℝ)*hqM + (221389/902:ℝ)*hRo + (93075889/1408570:ℝ)*hg0 + (126881569/1408570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (2052765125/4233086:ℝ)*hBl + (1/1:ℝ)*hCaffine + (62425355414625/298129897351:ℝ)*hMu + (82110605/325622:ℝ)*hzl + (62425355414625/298129897351:ℝ)*hqM + (82110605/325622:ℝ)*hRo + (93075889/1408570:ℝ)*hg0 + (126881569/1408570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t7_r4_cap_cell_60
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (17375873617/64512506:ℝ)*hBl + (1/1:ℝ)*hCaffine + (112651/458:ℝ)*hzl + (85402845327/806406325:ℝ)*hR0 + (112651/458:ℝ)*hRo + (93075889/1408570:ℝ)*hg0 + (126881569/1408570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (6425754606785/23289014666:ℝ)*hBl + (1/1:ℝ)*hCaffine + (41753675/165338:ℝ)*hzl + (6349762509867/58222536665:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (93075889/1408570:ℝ)*hg0 + (126881569/1408570:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_61
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (35/128 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (34154471863/127053014:ℝ)*hMl + (221389/902:ℝ)*hzl + (167798312553/1588162675:ℝ)*hR0 + (221389/902:ℝ)*hRo + (34154471863/127053014:ℝ)*hchoice + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (12638125106375/45866138054:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (2497014216585/22933069027:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (12638125106375/45866138054:ℝ)*hchoice + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_62
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (35/128 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (17375873617/64512506:ℝ)*hMl + (112651/458:ℝ)*hzl + (85402845327/806406325:ℝ)*hR0 + (112651/458:ℝ)*hRo + (17375873617/64512506:ℝ)*hchoice + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (6425754606785/23289014666:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (6349762509867/58222536665:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (6425754606785/23289014666:ℝ)*hchoice + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_63
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (851/3200 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (697/2560 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (697/2560 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_6 hBu
  have hCaffine := hAffine (697/2560 : ℝ) (-34909869/13600561 : ℝ) (19722525/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_6 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1/1:ℝ)*hCaffine + (430731372311/1604866198:ℝ)*hMl + (29141/118:ℝ)*hzl + (165724648557/1543140575:ℝ)*hR0 + (29141/118:ℝ)*hRo + (430731372311/1604866198:ℝ)*hchoice + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (1/1:ℝ)*hCaffine + (8375523683485/30492457762:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (647442366939/5863934185:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (8375523683485/30492457762:ℝ)*hchoice + (8722475497/136005610:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_64
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (697/2560 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (1783/6400 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (1783/6400 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_8 hBu
  have hCaffine := hAffine (1783/6400 : ℝ) (-87573/140857 : ℝ) (644115/384256 : ℝ) large_selected_scored_t7_r4_cap_point_affine_8 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4493287247/16621126:ℝ)*hBl + (1/1:ℝ)*hCaffine + (29141/118:ℝ)*hzl + (22102555857/207764075:ℝ)*hR0 + (29141/118:ℝ)*hRo + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (1659784678495/6000226486:ℝ)*hBl + (1/1:ℝ)*hCaffine + (10787605/42598:ℝ)*hzl + (1641054111669/15000566215:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (93075889/1408570:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_65
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (1027/4000 : ℝ) ≤ M) (hMu : M ≤ (2143/8000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (2143/8000 : ℝ) (4717/21430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (845716025/2302534:ℝ)*hBl + (530846879118/2467165181:ℝ)*hMu + (29141/118:ℝ)*hzl + (530846879118/2467165181:ℝ)*hqM + (29141/118:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (16597319875/43748146:ℝ)*hBl + (10358019607770/46876138439:ℝ)*hMu + (10787605/42598:ℝ)*hzl + (10358019607770/46876138439:ℝ)*hqM + (10787605/42598:ℝ)*hRo + (23206480693/418163590:ℝ)*hg0 + (33242406853/418163590:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_66
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (35/128 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hC := hCscore (35/128 : ℝ) (89/350 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3265428775/8936954:ℝ)*hBl + (2569705746/12030515:ℝ)*hMu + (112651/458:ℝ)*hzl + (2569705746/12030515:ℝ)*hqM + (112651/458:ℝ)*hRo + (76687213/1365910:ℝ)*hg0 + (109469053/1365910:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (64189308125/169802126:ℝ)*hBl + (652745075022/2971537205:ℝ)*hMu + (41753675/165338:ℝ)*hzl + (652745075022/2971537205:ℝ)*hqM + (41753675/165338:ℝ)*hRo + (76687213/1365910:ℝ)*hg0 + (109469053/1365910:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_67
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (35/128 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (17374863991049/64189847722:ℝ)*hBl + (1/1:ℝ)*hCaffine + (221389/902:ℝ)*hzl + (6461517131763/61721007425:ℝ)*hR0 + (221389/902:ℝ)*hRo + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (338321906673475/1219607106718:ℝ)*hBl + (1/1:ℝ)*hCaffine + (82110605/325622:ℝ)*hzl + (5062128235713/46907965643:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_68
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (35/128 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (1783/6400 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (3647/12800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (3647/12800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_9 hBu
  have hCaffine := hAffine (3647/12800 : ℝ) (88027221/71163911 : ℝ) (13771455/9990656 : ℝ) large_selected_scored_t7_r4_cap_point_affine_9 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (8839235914991/32593071238:ℝ)*hBl + (1/1:ℝ)*hCaffine + (112651/458:ℝ)*hzl + (3288733713717/31339491575:ℝ)*hR0 + (112651/458:ℝ)*hRo + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (172015548710245/619268353522:ℝ)*hBl + (1/1:ℝ)*hCaffine + (41753675/165338:ℝ)*hzl + (12872886542163/119090067985:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (48346600847/711639110:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t7_r4_cap_cell_69
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(13/25 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 7*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(3125/1027 : ℝ)*(7*(q+(13/25 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hJoint : ∀ U γ : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)-36/19-96/19)
    (hAffine : ∀ U γ β : ℝ,
      (∀ B b : ℝ, 0 ≤ b → b ≤ B → B ≤ U → (360/19)*max ((19/10)*b-9/20) 0+
        (96/19)*min ((3125/1027 : ℝ)*(B-b)) ((100/57)*b) ≤ γ*b+β) →
      q+(13/25 : ℝ)*R ≤ U → S ≤ γ*(1+e)+7*β-36/19-96/19)
    (htarget : a ≤ 4*z)
    (hMl : (2143/8000 : ℝ) ≤ M) (hMu : M ≤ (279/1000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
    (hBl : (3647/12800 : ℝ) ≤ q+(13/25 : ℝ)*R) (hBu : q+(13/25 : ℝ)*R ≤ (233/800 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hCjoint := hJoint (233/800 : ℝ) (3200/361 : ℝ) large_selected_scored_t7_r4_cap_point_linear_10 hBu
  have hCaffine := hAffine (233/800 : ℝ) (13707219/4546529 : ℝ) (674745/624416 : ℝ) large_selected_scored_t7_r4_cap_point_affine_10 hBu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2816275/5954:ℝ)*hBl + (1/1:ℝ)*hCaffine + (208259956563/1041155141:ℝ)*hMu + (112651/458:ℝ)*hzl + (208259956563/1041155141:ℝ)*hqM + (112651/458:ℝ)*hRo + (3169607033/45465290:ℝ)*hg0 + (4260773993/45465290:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1043841875/2149394:ℝ)*hBl + (1/1:ℝ)*hCaffine + (4076952520185/19781947679:ℝ)*hMu + (41753675/165338:ℝ)*hzl + (4076952520185/19781947679:ℝ)*hqM + (41753675/165338:ℝ)*hRo + (3169607033/45465290:ℝ)*hg0 + (4260773993/45465290:ℝ)*hgap + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

end TSP.Improvements20261105
