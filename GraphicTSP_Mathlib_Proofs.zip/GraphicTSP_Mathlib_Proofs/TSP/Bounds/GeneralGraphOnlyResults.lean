import TSP.Improvements20261105.GeneralAllPairPayments

namespace TSP.ImprovedMainResults
set_option autoImplicit false
open Graph Improvements20261105
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

/-- The graph-only general bound: the original uncapped subtour LP and
an actual spanning Eulerian edge-multiplicity tour. -/
theorem general_graphic_tsp_tour_bound (G : Graph V E) (hs : G.IsSimple) (hc : G.Connected) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ (14524/10481 : ℝ)*G.subtourLP :=
  general_connected_tour_of_local_pairs all_general_pair_payments G hs hc

theorem general_graphic_tsp_affine_tour_bound (G : Graph V E) (hs : G.IsSimple)
    (hc : G.Connected) (hn : 2 ≤ Fintype.card V) :
    ∃ c : E → ℕ, G.IsTour c ∧ (tourLength c : ℝ) ≤ (14524*G.subtourLP-8086)/10481 :=
  general_connected_affine_tour_of_local_pairs all_general_pair_payments G hs hc hn

theorem general_graphic_tsp_integralityGap_le (G : Graph V E) (hs : G.IsSimple)
    (hc : G.Connected) (hn : 2 ≤ Fintype.card V) :
    (G.tsp : ℝ)/G.subtourLP ≤ (14524/10481 : ℝ) :=
  general_subtour_ratio_of_local_pairs all_general_pair_payments G hs hc hn

end TSP.ImprovedMainResults
