import TSP.Improvements20261105.FixedGuardedQConstruction
import TSP.Improvements20261105.TerminalQDeficit

/-! The simultaneous zero and positive terminal guards preserve the
preliminary signed Q deficit at every head whose original own-back mass
exceeds one, including heads erased by the fixed projection. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem guarded_positive_Q_deficit (x : E → ℝ) (Y R : E ⊕ d.StarIndex → ℝ)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (i : d.StarIndex) (hi : 1 < edgeSum x (d.backGroup i.1)) :
    (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
      -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1 := by
  by_cases ht : i ∈ fixedPositiveTerminalHeads d x
  · exact hterminal i ht
  · have hz : i ∉ fixedZeroTerminalHeads d x :=
      fun h => (not_le_of_gt hi) (Finset.mem_filter.mp h).2.2
    have hn : i.1 ∉ fixedPositiveTerminalChildren d x := by
      intro h
      obtain ⟨j,hj,he⟩ := Finset.mem_image.mp h
      exact ht ((Subtype.ext he : j = i) ▸ hj)
    have hdef := raisedQ_deficit d x (fixedQIncrease d x (fixedPositiveTerminalChildren d x)) Y hrep hbacks i
    rw [fixedQIncrease, if_neg hn] at hdef
    have hl := hloss i
    simp only [if_neg hz, if_neg ht, mul_zero, add_zero] at hl
    linarith

end TSP.Improvements20261105
