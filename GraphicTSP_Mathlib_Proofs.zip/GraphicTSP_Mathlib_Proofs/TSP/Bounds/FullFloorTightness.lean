import TSP.Improvements20261105.MatchingEndpointSums

/-! Tight matched pairs and unchanged unmatched floors follow from the
constructed cover equality; neither is assumed as extra input. -/
namespace TSP.Improvements20261105
open Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem matching_cover_saturation (A B : E → V) (M : Finset E)
    (hloop : ∀ e ∈ M, A e ≠ B e)
    (hmatch : ∀ e ∈ M, ∀ f ∈ M, ∀ a, (a = A e ∨ a = B e) → (a = A f ∨ a = B f) → e = f)
    (price : V → ℝ) (w : E → ℝ) (hn : ∀ a, 0 ≤ price a)
    (hc : ∀ e, w e ≤ price (A e) + price (B e))
    (heq : (∑ a, price a) = ∑ e ∈ M, w e) :
    (∀ e ∈ M, w e = price (A e) + price (B e)) ∧
    (∀ a ∉ matchingEndpoints A B M, price a = 0) := by
  have hbound := matching_endpoint_sum_le A B M hloop hmatch price hn
  have hcover := Finset.sum_le_sum (s := M) (fun e _ => hc e)
  have hsum : (∑ e ∈ M, (price (A e) + price (B e) - w e)) ≤ 0 := by
    rw [Finset.sum_sub_distrib]
    linarith
  constructor
  · intro e he
    have hs := Finset.single_le_sum (s := M)
      (f := fun e => price (A e) + price (B e) - w e)
      (fun e _ => sub_nonneg.mpr (hc e)) he
    dsimp only at hs
    have h := hc e
    linarith
  · intro a ha
    have hsplit := Finset.sum_sdiff (f := price) (Finset.subset_univ (matchingEndpoints A B M))
    rw [matching_endpoint_sum A B M hloop hmatch] at hsplit
    have hs := Finset.single_le_sum (s := Finset.univ \ matchingEndpoints A B M)
      (f := price) (fun b _ => hn b) (Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, ha⟩)
    have hp := hn a
    linarith

theorem full_floor_tightness (A B : E → V) (M : Finset E)
    (hloop : ∀ e ∈ M, A e ≠ B e)
    (hmatch : ∀ e ∈ M, ∀ f ∈ M, ∀ a, (a = A e ∨ a = B e) → (a = A f ∨ a = B f) → e = f)
    (floor z : V → ℝ) (ell : E → ℝ) (hf : ∀ a, floor a ≤ z a)
    (hc : ∀ e, ell e ≤ z (A e) + z (B e))
    (heq : (∑ a, z a) = (∑ a, floor a) + ∑ e ∈ M, (ell e - floor (A e) - floor (B e))) :
    (∀ e ∈ M, z (A e) + z (B e) = ell e) ∧
    (∀ a ∉ matchingEndpoints A B M, z a = floor a) := by
  have hsum : (∑ a, (z a - floor a)) = ∑ e ∈ M, (ell e - floor (A e) - floor (B e)) := by
    rw [Finset.sum_sub_distrib]
    linarith
  obtain ⟨ht, hu⟩ := matching_cover_saturation A B M hloop hmatch
    (fun a => z a - floor a) (fun e => ell e - floor (A e) - floor (B e))
    (fun a => sub_nonneg.mpr (hf a)) (fun e => by dsimp only; have h := hc e; linarith) hsum
  constructor
  · intro e he; have h := ht e he; change ell e - floor (A e) - floor (B e) = (z (A e) - floor (A e)) + (z (B e) - floor (B e)) at h; linarith
  · intro a ha; exact sub_eq_zero.mp (hu a ha)

theorem full_floor_tightness_on (A B : E → V) (M : Finset E)
    (hloop : ∀ e ∈ M, A e ≠ B e)
    (hmatch : ∀ e ∈ M, ∀ f ∈ M, ∀ a, (a = A e ∨ a = B e) → (a = A f ∨ a = B f) → e = f)
    (floor z : V → ℝ) (ell : E → ℝ) (hf : ∀ a, floor a ≤ z a)
    (hc : ∀ e ∈ M, ell e ≤ z (A e) + z (B e))
    (heq : (∑ a, z a) = (∑ a, floor a) + ∑ e ∈ M, (ell e - floor (A e) - floor (B e))) :
    (∀ e ∈ M, z (A e) + z (B e) = ell e) ∧
    (∀ a ∉ matchingEndpoints A B M, z a = floor a) := by
  let ell' : E → ℝ := fun e => if e ∈ M then ell e else floor (A e) + floor (B e)
  have hc' (e : E) : ell' e ≤ z (A e) + z (B e) := by
    dsimp [ell']
    split_ifs with h
    · exact hc e h
    · exact add_le_add (hf _) (hf _)
  have hs : (∑ e ∈ M, (ell' e - floor (A e) - floor (B e))) =
      ∑ e ∈ M, (ell e - floor (A e) - floor (B e)) := by
    apply Finset.sum_congr rfl
    intro e he
    simp [ell', he]
  have heq' : (∑ a, z a) = (∑ a, floor a) + ∑ e ∈ M, (ell' e - floor (A e) - floor (B e)) := by
    rw [hs]; exact heq
  obtain ⟨ht, hu⟩ := full_floor_tightness A B M hloop hmatch floor z ell' hf hc' heq'
  exact ⟨fun e he => by simpa [ell', he] using ht e he, hu⟩

theorem full_floor_cost_partition (A B : E → V) (M : Finset E)
    (hloop : ∀ e ∈ M, A e ≠ B e)
    (hmatch : ∀ e ∈ M, ∀ f ∈ M, ∀ a, (a = A e ∨ a = B e) → (a = A f ∨ a = B f) → e = f)
    (floor z : V → ℝ) (ell : E → ℝ)
    (heq : (∑ a, z a) = (∑ a, floor a) + ∑ e ∈ M, (ell e - floor (A e) - floor (B e))) :
    (∑ a, z a) = (∑ a ∈ Finset.univ \ matchingEndpoints A B M, floor a) + ∑ e ∈ M, ell e := by
  have hs := Finset.sum_sdiff (f := floor) (Finset.subset_univ (matchingEndpoints A B M))
  rw [matching_endpoint_sum A B M hloop hmatch] at hs
  have hid : (∑ e ∈ M, (floor (A e) + floor (B e))) +
      (∑ e ∈ M, (ell e - floor (A e) - floor (B e))) = ∑ e ∈ M, ell e := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro e _
    ring
  linarith

end TSP.Improvements20261105
