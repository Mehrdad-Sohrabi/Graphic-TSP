import TSP.Improvements20261105.GatedPruningReward

/-! Canonical component pruning: an occupied component has strictly more
outgoing true cuts than the head prices and bypass penalties it contains. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.componentRemovalGain (P : GatePlan d) (t : d.tree.Child → ℝ)
    (a : GatedDrops d) (r : FlowVertex d) : ℝ :=
  ∑ v ∈ a.componentHeads d P r, ((gatedFreeBase d v : ℝ) + t v + (a.penalty d P v : ℝ))

theorem canonical_pruneComponent_value (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P)) (r : FlowVertex d) :
    (a.pruneComponent d P r).value d P t = a.value d P t -
      ((∑ v : d.tree.Child, (a.reward d P v : ℝ)) -
        ∑ v : d.tree.Child, ((a.pruneComponent d P r).reward d P v : ℝ)) +
      a.componentRemovalGain d P t r := by
  let q := a.pruneComponent d P r
  have hlocal (v : d.tree.Child) :
      (q.reward d P v : ℝ) - ((gatedFreeBase d v : ℝ) + t v) * (q.head v : ℝ) - (q.penalty d P v : ℝ) =
      ((a.reward d P v : ℝ) - ((gatedFreeBase d v : ℝ) + t v) * (a.head v : ℝ) - (a.penalty d P v : ℝ)) -
      ((a.reward d P v : ℝ) - (q.reward d P v : ℝ)) +
      (if v ∈ a.componentHeads d P r then (gatedFreeBase d v : ℝ) + t v + (a.penalty d P v : ℝ) else 0) := by
    have hpen := canonical_pruneComponent_penalty d hs hc P hP t ht f hf hb a ha hcan r v
    change q.penalty d P v = _ at hpen
    rw [hpen]
    have hhead : q.head v = if v ∈ a.componentHeads d P r then 0 else a.head v := rfl
    rw [hhead]
    by_cases hv : v ∈ a.componentHeads d P r
    · have hsel := ((a.mem_componentHeads d P r v).mp hv).1
      simp only [if_pos hv, hsel, Int.cast_zero, Int.cast_one]
      ring
    · simp only [if_neg hv]
      ring
  have hgain : (∑ v : d.tree.Child, if v ∈ a.componentHeads d P r then
      (gatedFreeBase d v : ℝ) + t v + (a.penalty d P v : ℝ) else 0) = a.componentRemovalGain d P t r := by
    unfold GatedDrops.componentRemovalGain
    rw [← Finset.sum_filter]
    simp only [Finset.filter_mem_eq_inter, Finset.univ_inter]
  change (∑ v : d.tree.Child, ((q.reward d P v : ℝ) -
    ((gatedFreeBase d v : ℝ) + t v) * (q.head v : ℝ) - (q.penalty d P v : ℝ))) = _
  simp_rw [hlocal]
  rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, Finset.sum_sub_distrib, hgain]
  simp only [GatedDrops.value, Finset.sum_sub_distrib, q]

theorem canonical_component_pruning (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : FlowVertex d) (hheads : (a.componentHeads d P r).Nonempty) :
    a.componentRemovalGain d P t r < ((a.componentOutgoingCuts d P r).card : ℝ) := by
  by_contra hnot
  have hbound : ((a.componentOutgoingCuts d P r).card : ℝ) ≤ a.componentRemovalGain d P t r := le_of_not_gt hnot
  let q := a.pruneComponent d P r
  have hq := a.pruneComponent_admissible d ha r
  have hv := canonical_pruneComponent_value d hs hc P hP t ht f hf hb a ha hcan r
  have hloss := a.pruneComponent_reward_loss d hs hc ha r
  have hbetter : a.value d P t ≤ q.value d P t := by
    change q.value d P t = _ at hv
    linarith
  have hm := a.eraseBackDependencies_mono d ha (a.componentBacks d P r) (a.componentHeads d P r)
  obtain ⟨s, hs'⟩ := hheads
  have hsel := ((a.mem_componentHeads d P r s).mp hs').1
  exact canonical_drops_no_head_deletion d P hP t f hf hb a q ha hq hcan
    hm.1 hm.2.1 hm.2.2.1 hm.2.2.2.1 hbetter s hsel
      (by simp only [q, GatedDrops.pruneComponent, GatedDrops.eraseBackDependencies, if_pos hs'])

theorem GatedDrops.componentRemovalGain_ge_heads (P : GatePlan d) (t : d.tree.Child → ℝ)
    (ht : ∀ v, 0 ≤ t v) (a : GatedDrops d) (r : FlowVertex d) :
    ((a.componentHeads d P r).card : ℝ) ≤ a.componentRemovalGain d P t r := by
  calc
    _ = ∑ v ∈ a.componentHeads d P r, (1 : ℝ) := by simp
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro v _
      have hbase : (1 : ℝ) ≤ gatedFreeBase d v := by unfold gatedFreeBase; split_ifs <;> norm_num
      have hpen : (0 : ℝ) ≤ a.penalty d P v := by exact_mod_cast a.penalty_nonneg d P v
      linarith [ht v]

theorem canonical_leaf_component_headless (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : FlowVertex d) (hleaf : a.componentOutgoingCuts d P r = ∅) :
    a.componentHeads d P r = ∅ := by
  by_contra hn
  have hnon := Finset.nonempty_iff_ne_empty.mpr hn
  have hp := canonical_component_pruning d hs hc P hP t ht f hf hb a ha hcan r hnon
  have hg := a.componentRemovalGain_ge_heads d P t ht r
  have hc0 : (0 : ℝ) ≤ (a.componentHeads d P r).card := Nat.cast_nonneg _
  rw [hleaf, Finset.card_empty, Nat.cast_zero] at hp
  linarith

end TSP.Improvements20261105
