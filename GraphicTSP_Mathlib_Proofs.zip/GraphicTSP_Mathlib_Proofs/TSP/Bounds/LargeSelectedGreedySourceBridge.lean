import TSP.Improvements20261105.GreedySourceUniformTail
import TSP.Improvements20261105.LargeSelectedGreedyActualNetTarget
import TSP.Improvements20261105.ActualGreedyGateComplement
import TSP.Improvements20261105.GoodPartitionMassBound
import TSP.Improvements20261105.UniformRampLinearEnvelope
import TSP.Improvements20261105.PairSourcePacking
import TSP.Improvements20261105.SelectedPositiveTargetNetPairCost
import TSP.Improvements20261105.MatchingTargetMassIdentity
/-! Instantiate the exact scalar hypotheses from actual greedy source and target stars. The scalar statement is explicit and is discharged by the finite-table theorem in the next module. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

/-- Exact real-variable inequality used by the finite scalar tables. -/
def LargeSelectedGreedyScalarStatement (t r bad : ℕ) : Prop :=
  ∀ (q e z a o S I H g : ℝ)
    (hq0 : 0 ≤ q) (hz0 : 0 ≤ z)
    (he0 : 0 ≤ e) (hem : e ≤ (t : ℝ)*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*((t : ℝ)+1)+2*(bad : ℝ))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ (r : ℝ)*z)
    (hgood : t%2=0 → bad=0 → e+(1-(t : ℝ)/2)*q ≤ 0)
    (hgate : t ≤ 25 → q ≤ ScoredParameters.lower t ∨ ScoredParameters.upper t ≤ q ∨
      q+e ≤ 1-ScoredParameters.incomingThreshold t),
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤
      4*((t : ℝ)+(r : ℝ))+2*(bad : ℝ)

theorem scoredDFS_large_greedy_source_pair_of_scalar
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (ν : (d).tree.Child → ℤ)
    (i j : (d).StarIndex) (hi : i.1 ∈ C.matching) (hj : j.1 = unaryNext d i.1)

    (hsel : ν i.1=1) (hjsel : ν j.1=1)
    (hcount5 : 5 ≤ ((d).backGroup i.1).card)
    (hnot : ¬ScoredStar d x i.1) (hnotT : ¬ScoredStar d x j.1)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup i.1).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent i.1))
    (htargetcount : 3 ≤ ((d).backGroup j.1).card)
    (hpositive : 1 < edgeSum z ((d).backGroup j.1))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge i.1)-survivingExcess d x i.1) (1/2)) 
    (hsource : (415/2 : ℝ)*(survivingExcess d x i.1-outgoingBackMass d x i.1)-(704/5)+
      24*survivingExcess d x i.1+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T i.1+24*δ ≤
      4*((((d).backGroup i.1).card : ℝ)+1)+2*(bad : ℝ))
    (hscalar : LargeSelectedGreedyScalarStatement ((d).backGroup i.1).card ((d).backGroup j.1).card bad) :
    currentSelectedHeadCost d x z C owner rootStar R eligible T ν i+
      currentSelectedHeadCost d x z C owner rootStar R eligible T ν j-24*retainedSelectedResidual d x z ν j+24*δ-162/19 ≤
      4*((((d).backGroup i.1).card : ℝ)+((d).backGroup j.1).card)+2*(bad : ℝ) := by
  have hl := C.link_subset hi
  have hpos := (Finset.mem_filter.mp hl).2.2.1
  have hgS := scoredDFS_not_scored_greedy G x hs hc root i.1 hnot
  have hmassS := survivingExcess_back_bound d x hx hn i.1 hpos (x ((d).treeEdge i.1)) hgS
  have hcapT (e : E) (he : e ∈ (d).backGroup j.1) : z e ≤ x ((d).treeEdge j.1) :=
    (hzx e).trans (scoredDFS_not_scored_greedy G x hs hc root j.1 hnotT e he)
  have hcapS (e : E) (he : e ∈ (d).backGroup i.1) : z e ≤ x ((d).treeEdge i.1) :=
    (hzx e).trans (hgS e he)
  have hsourceMass := projectionLink_source_positive d hs x z hx hn hm i.1 hl
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  rw [max_eq_left (by linarith only [hsourceMass])] at he
  have hEs : edgeSum z ((d).backGroup i.1)=1+survivingExcess d x i.1 := by linarith only [he]
  have hIs := refined_fixed_incidence_le_noncritical d x z eligible T i.1
  have hSall (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
      (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20)
      (hU : x ((d).treeEdge i.1) ≤ U) :
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T i.1 ≤
        max (24*A*(1+survivingExcess d x i.1))
          ((360/19)*(B*(1+survivingExcess d x i.1)-1/10)+(96/19)*((100/57)*(1+survivingExcess d x i.1)-1)) := by
    have hh := hIs.trans (noncritical_uniform_linear_envelope d z i.1 U A B hA hAd hAU hB hBd hBU
      (fun e _ => hz e) (fun e he => (hcapS e he).trans hU))
    simpa only [hEs] using hh
  have hIt := refined_fixed_incidence_le_noncritical d x z eligible T j.1
  have hIall (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
      (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20)
      (hU : x ((d).treeEdge j.1) ≤ U) :=
    hIt.trans (noncritical_uniform_linear_envelope d z j.1 U A B hA hAd hAU hB hBd hBU
      (fun e _ => hz e) (fun e he => (hcapT e he).trans hU))
  have hGeq := positiveMatchingTargetGain_mass_formula d hs x z hm C i.1 j.1 hi hj
  have hGL (hforce : (13/40 : ℝ) ≤ x ((d).treeEdge j.1)) :
      (415/2)*(1-edgeSum z ((d).backGroup j.1))+
        (704/5)*(2-x ((d).treeEdge j.1)-edgeSum z ((d).backGroup j.1))-
        max (24*min (x ((d).treeEdge j.1)) (1-x ((d).treeEdge j.1))-4) 0 ≤
        positiveMatchingTargetGain d x z i.1 j.1 := by
    rw [hGeq,if_pos hforce]
    exact (le_max_left _ _).trans (le_max_right _ _)
  have hGR (hforce : (13/40 : ℝ) ≤ x ((d).treeEdge j.1)) :
      (415/2)*(x ((d).treeEdge j.1)-1)+(704/5)*(survivingExcess d x i.1+x ((d).treeEdge i.1))-
        max (24*min (x ((d).treeEdge j.1)) (1-x ((d).treeEdge j.1))-4) 0 ≤
        positiveMatchingTargetGain d x z i.1 j.1 := by
    rw [hGeq,if_pos hforce]
    exact (le_max_right _ _).trans (le_max_right _ _)
  have hecap := (survivingExcess_bounds d hs hx hcap i.1).2
  have ho0 : 0 ≤ outgoingBackMass d x i.1 := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hgate (hcount : ((d).backGroup i.1).card ≤ 25) :
      x ((d).treeEdge i.1) ≤ ScoredParameters.lower ((d).backGroup i.1).card ∨
      ScoredParameters.upper ((d).backGroup i.1).card ≤ x ((d).treeEdge i.1) ∨
      x ((d).treeEdge i.1)+survivingExcess d x i.1 ≤ 1-ScoredParameters.incomingThreshold ((d).backGroup i.1).card := by
    have hg := scoredDFS_positive_greedy_gate_complement G x z hs hc root hx hn hm i.1
      (Finset.mem_filter.mp hl).2.1 hnot hsourceMass (by omega) hcount
    rw [hEs] at hg
    rcases hg with hg | hg | hg
    · exact Or.inl hg
    · exact Or.inr (Or.inl hg)
    · exact Or.inr (Or.inr (by linarith only [hg]))
  have hgoodR (hpar : ((d).backGroup i.1).card%2=0) (hb : bad=0) :
      survivingExcess d x i.1+(1-(((d).backGroup i.1).card : ℝ)/2)*x ((d).treeEdge i.1) ≤ 0 := by
    have hn2 : ((d).backGroup i.1).card=2*(((d).backGroup i.1).card/2) := by omega
    have hu := unitPartCapacities_star_even_bound d hs x z hx.1 hz hzx htree i.1 (hgood hpar hb)
      (((d).backGroup i.1).card/2) hn2
    rw [scoredDFS_unscored_maximum G x hs hc root i.1 hnot,hEs] at hu
    have hnR : (((d).backGroup i.1).card : ℝ)=2*((((d).backGroup i.1).card/2 : ℕ) : ℝ) := by exact_mod_cast hn2
    rw [hnR]
    nlinarith only [hu]
  have htargetMass : edgeSum z ((d).backGroup j.1) ≤ (((d).backGroup j.1).card : ℝ)*x ((d).treeEdge j.1) := by
    have hh := Finset.sum_le_sum (s := (d).backGroup j.1) hcapT
    simpa [edgeSum] using hh
  have hrow := hscalar
    (x ((d).treeEdge i.1)) (survivingExcess d x i.1) (x ((d).treeEdge j.1))
    (edgeSum z ((d).backGroup j.1)) (outgoingBackMass d x i.1)
    (refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T i.1)
    (refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T j.1)
    (positiveMatchingTargetGain d x z i.1 j.1) δ (hx.1 _) (hx.1 _) hpos.le hmassS
    (by linarith only [hecap]) ho0 (C.source_excess i.1 hi).le hpositive.le hδ0
    (hδ.trans (min_le_right _ _)) (by have hh:=hδ.trans (min_le_left _ _); linarith only [hh])
    (matching_target_mass_identity d hs x z hm C i.1 j.1 hi hj)
    (positiveMatchingTargetGain_nonnegative d x z i.1 j.1) hsource hSall hIall hGL hGR htargetMass hgoodR hgate
  have hpair := scoredDFS_selected_positive_target_net_pair_cost G x z hs hc root hx hn hcap hz hzx hm C owner ho
    rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T ν i j hi hj (Or.inr hsel) hjsel hpositive
  rw [hsel] at hpair
  norm_num only [Int.cast_one,one_mul,Int.reduceEq,if_false,add_zero] at hpair
  have hLi := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun c => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz c) i.1
  have hcoupon : min (x ((d).treeEdge j.1)) (1-x ((d).treeEdge j.1)) ≤ projectedOutgoingCoupon d x z j.1 := by
    rw [projectedOutgoingCoupon,if_pos hpositive,projectedOutgoingCoupon_positive_base d x z j.1 hpositive]
    exact le_max_left _ _
  linarith only [hrow,hpair,hLi,hcoupon,hEs]

theorem scoredDFS_large_greedy_source_pair_tail
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (ν : (d).tree.Child → ℤ)
    (i j : (d).StarIndex) (hi : i.1 ∈ C.matching) (hj : j.1 = unaryNext d i.1)

    (hsel : ν i.1=1) (hjsel : ν j.1=1)
    (hcount32 : 32 ≤ ((d).backGroup i.1).card)
    (hnot : ¬ScoredStar d x i.1) (hnotT : ¬ScoredStar d x j.1)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup i.1).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent i.1))
    (htargetcount : 3 ≤ ((d).backGroup j.1).card)
    (hpositive : 1 < edgeSum z ((d).backGroup j.1))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge i.1)-survivingExcess d x i.1) (1/2)) :
    currentSelectedHeadCost d x z C owner rootStar R eligible T ν i+
      currentSelectedHeadCost d x z C owner rootStar R eligible T ν j-24*retainedSelectedResidual d x z ν j+24*δ-162/19 ≤
      4*((((d).backGroup i.1).card : ℝ)+((d).backGroup j.1).card)+2*(bad : ℝ) := by
  have hl := C.link_subset hi
  have hsourceMass := projectionLink_source_positive d hs x z hx hn hm i.1 hl
  have hS := scoredDFS_greedy_source_uniform_uncouponed G x z hs hc root hx hn hcap hz hzx hm
    eligible T i.1 hnot hsourceMass δ hδ0 hδ
  have hT := scoredDFS_positive_greedy_target_net_42 G x z hs hc root hx hn hcap hz hzx hm
    eligible T j.1 hnotT hpositive
  have hpair := scoredDFS_selected_positive_target_net_pair_cost G x z hs hc root hx hn hcap hz hzx hm C owner ho
    rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T ν i j hi hj (Or.inr hsel) hjsel hpositive
  rw [hsel] at hpair
  norm_num only [Int.cast_one,one_mul,Int.reduceEq,if_false,add_zero] at hpair
  have hLi := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun c => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz c) i.1
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  rw [max_eq_left (by linarith only [hsourceMass])] at he
  have hEs : edgeSum z ((d).backGroup i.1)=1+survivingExcess d x i.1 := by linarith only [he]
  have hH := positiveMatchingTargetGain_nonnegative d x z i.1 j.1
  have htR : (32 : ℝ) ≤ (((d).backGroup i.1).card : ℝ) := by exact_mod_cast hcount32
  have hrR : (3 : ℝ) ≤ (((d).backGroup j.1).card : ℝ) := by exact_mod_cast htargetcount
  have hb0 : (0 : ℝ) ≤ (bad : ℝ) := Nat.cast_nonneg _
  linarith only [hS,hT,hpair,hLi,hEs,hH,htR,hrR,hb0]

end TSP.Improvements20261105
