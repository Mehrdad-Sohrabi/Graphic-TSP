import TSP.Improvements20261105.LargeSelectedGreedyScoredSourceEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/4 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource

theorem large_selected_scored_t6_r4_cap_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1228842006663/2744584865:ℝ)*hMu + (1213214866839/10978339460:ℝ)*hR0 + (26073/110:ℝ)*hRo + (827708114439/5489169730:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (23127506845653/52147112435:ℝ)*hMu + (23492065031829/208588449740:ℝ)*hR0 + (9580257/39710:ℝ)*hRo + (16167436736229/104294224870:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass
  · linear_combination (1228842006663/2744584865:ℝ)*hMu + (1213214866839/10978339460:ℝ)*hR0 + (26073/110:ℝ)*hRo + (827708114439/5489169730:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (23127506845653/52147112435:ℝ)*hMu + (23492065031829/208588449740:ℝ)*hR0 + (9580257/39710:ℝ)*hRo + (16167436736229/104294224870:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (19911467441/99803086:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1711762909/249507715:ℝ)*hMu + (511/2:ℝ)*hzl + (23902087313/199606172:ℝ)*hR0 + (511/2:ℝ)*hRo + (16892873633/99803086:ℝ)*hchoice + (24/1:ℝ)*hgap + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (14453883911/4740646585:ℝ)*hMu + (187223/722:ℝ)*hzl + (461367503491/3792517268:ℝ)*hR0 + (187223/722:ℝ)*hRo + (328192443571/1896258634:ℝ)*hchoice + (24/1:ℝ)*hgap + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (1711762909/249507715:ℝ)*hMu + (511/2:ℝ)*hzl + (23902087313/199606172:ℝ)*hR0 + (511/2:ℝ)*hRo + (16892873633/99803086:ℝ)*hchoice + (24/1:ℝ)*hgap + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (14453883911/4740646585:ℝ)*hMu + (187223/722:ℝ)*hzl + (461367503491/3792517268:ℝ)*hR0 + (187223/722:ℝ)*hRo + (328192443571/1896258634:ℝ)*hchoice + (24/1:ℝ)*hgap + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (3797/11200 : ℝ) (1994/3797 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (803232040506/45852645715:ℝ)*hR0 + (1649129626452/45852645715:ℝ)*hRo + (1446843107892/45852645715:ℝ)*hchoice + (57497393856/45852645715:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (482281035964/45852645715:ℝ)*hgood + (2395724744/45852645715:ℝ)*hC + (1/1:ℝ)*hI + (43456920971/45852645715:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (29338509269219082/1373882823558545:ℝ)*hR0 + (725727734529468/16552805103115:ℝ)*hRo + (52846771283245524/1373882823558545:ℝ)*hchoice + (110532903486528/72309622292555:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (17615590427748508/1373882823558545:ℝ)*hgood + (4605537645272/72309622292555:ℝ)*hC + (1/1:ℝ)*hI + (67704084647283/72309622292555:ℝ)*hsource + (2045432/66785:ℝ)*hmass
  · linear_combination (803232040506/45852645715:ℝ)*hR0 + (1649129626452/45852645715:ℝ)*hRo + (1446843107892/45852645715:ℝ)*hchoice + (57497393856/45852645715:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (482281035964/45852645715:ℝ)*hgood + (2395724744/45852645715:ℝ)*hC + (1/1:ℝ)*hI + (43456920971/45852645715:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (29338509269219082/1373882823558545:ℝ)*hR0 + (725727734529468/16552805103115:ℝ)*hRo + (52846771283245524/1373882823558545:ℝ)*hchoice + (110532903486528/72309622292555:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (17615590427748508/1373882823558545:ℝ)*hgood + (4605537645272/72309622292555:ℝ)*hC + (1/1:ℝ)*hI + (67704084647283/72309622292555:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (5243/16000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (5243/16000 : ℝ) (2486/5243 : ℝ) (27617/52430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (5243/16000 : ℝ) (27617/52430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1532370431309/3485299979:ℝ)*hMu + (3744/59:ℝ)*hzl + (1603364843741/13941199916:ℝ)*hR0 + (29141/118:ℝ)*hRo + (1126808358701/6970599958:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (23681069047/118145762:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (28698879075523/66220699601:ℝ)*hMu + (1485436/21299:ℝ)*hzl + (31296250269775/264882798404:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (22241677054015/132441399202:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (23681069047/118145762:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (1532370431309/3485299979:ℝ)*hMu + (3744/59:ℝ)*hzl + (1603364843741/13941199916:ℝ)*hR0 + (29141/118:ℝ)*hRo + (1126808358701/6970599958:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (23681069047/118145762:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (28698879075523/66220699601:ℝ)*hMu + (1485436/21299:ℝ)*hzl + (31296250269775/264882798404:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (22241677054015/132441399202:ℝ)*hchoice + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (23681069047/118145762:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (5243/16000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (3797/11200 : ℝ) (1994/3797 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (14304/229:ℝ)*hzl + (126336925228158/4710925605973:ℝ)*hR0 + (3125114834292/56758139831:ℝ)*hRo + (227567751684156/4710925605973:ℝ)*hchoice + (9043518662208/4710925605973:ℝ)*hgap + (1/1:ℝ)*hH0 + (75855917228052/4710925605973:ℝ)*hgood + (376813277592/4710925605973:ℝ)*hC + (1/1:ℝ)*hI + (4334112328381/4710925605973:ℝ)*hsource + (8808/229:ℝ)*hmass
  · linear_combination (5707076/82669:ℝ)*hzl + (53400874132940145/1700644143756253:ℝ)*hR0 + (1320942896272230/20489688478991:ℝ)*hRo + (96189746920429890/1700644143756253:ℝ)*hchoice + (201187920370080/89507586513487:ℝ)*hgap + (1/1:ℝ)*hH0 + (32063248973476630/1700644143756253:ℝ)*hgood + (8382830015420/89507586513487:ℝ)*hC + (1/1:ℝ)*hI + (81124756498067/89507586513487:ℝ)*hsource + (3723020/82669:ℝ)*hmass
  · linear_combination (14304/229:ℝ)*hzl + (126336925228158/4710925605973:ℝ)*hR0 + (3125114834292/56758139831:ℝ)*hRo + (227567751684156/4710925605973:ℝ)*hchoice + (9043518662208/4710925605973:ℝ)*hgap + (1/1:ℝ)*hH0 + (75855917228052/4710925605973:ℝ)*hgood + (376813277592/4710925605973:ℝ)*hC + (1/1:ℝ)*hI + (4334112328381/4710925605973:ℝ)*hsource + (8808/229:ℝ)*hmass
  · linear_combination (5707076/82669:ℝ)*hzl + (53400874132940145/1700644143756253:ℝ)*hR0 + (1320942896272230/20489688478991:ℝ)*hRo + (96189746920429890/1700644143756253:ℝ)*hchoice + (201187920370080/89507586513487:ℝ)*hgap + (1/1:ℝ)*hH0 + (32063248973476630/1700644143756253:ℝ)*hgood + (8382830015420/89507586513487:ℝ)*hC + (1/1:ℝ)*hI + (81124756498067/89507586513487:ℝ)*hsource + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (5243/16000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (3797/11200 : ℝ) (1994/3797 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (29141/118:ℝ)*hzl + (134512528417170/1213731924683:ℝ)*hR0 + (3491398930668/14623276201:ℝ)*hRo + (191353491314148/1213731924683:ℝ)*hchoice + (139891159251648/6068659623415:ℝ)*hgap + (63784497104716/1213731924683:ℝ)*hgood + (5828798302152/6068659623415:ℝ)*hC + (1/1:ℝ)*hI + (239861321263/6068659623415:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10787605/42598:ℝ)*hzl + (50478919456559247/438157224810563:ℝ)*hR0 + (1307886257249946/5279002708561:ℝ)*hRo + (72536875430078142/438157224810563:ℝ)*hchoice + (2694098102672352/115304532844885:ℝ)*hgap + (24178958476692714/438157224810563:ℝ)*hgood + (112254087611348/115304532844885:ℝ)*hC + (1/1:ℝ)*hI + (3050445233537/115304532844885:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass
  · linear_combination (29141/118:ℝ)*hzl + (134512528417170/1213731924683:ℝ)*hR0 + (3491398930668/14623276201:ℝ)*hRo + (191353491314148/1213731924683:ℝ)*hchoice + (139891159251648/6068659623415:ℝ)*hgap + (63784497104716/1213731924683:ℝ)*hgood + (5828798302152/6068659623415:ℝ)*hC + (1/1:ℝ)*hI + (239861321263/6068659623415:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10787605/42598:ℝ)*hzl + (50478919456559247/438157224810563:ℝ)*hR0 + (1307886257249946/5279002708561:ℝ)*hRo + (72536875430078142/438157224810563:ℝ)*hchoice + (2694098102672352/115304532844885:ℝ)*hgap + (24178958476692714/438157224810563:ℝ)*hgood + (112254087611348/115304532844885:ℝ)*hC + (1/1:ℝ)*hI + (3050445233537/115304532844885:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_8
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (39239/112000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (39239/112000 : ℝ) (22478/39239 : ℝ) (241541/392390 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (39239/112000 : ℝ) (241541/392390 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (8808/229:ℝ)*hMl + (14304/229:ℝ)*hzl + (4404/229:ℝ)*hR0 + (8808/229:ℝ)*hRo + (8808/229:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (8808/229:ℝ)*hmass
  · linear_combination (3723020/82669:ℝ)*hMl + (5707076/82669:ℝ)*hzl + (1861510/82669:ℝ)*hR0 + (3723020/82669:ℝ)*hRo + (3723020/82669:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (3723020/82669:ℝ)*hmass
  · linear_combination (8808/229:ℝ)*hMl + (14304/229:ℝ)*hzl + (4404/229:ℝ)*hR0 + (8808/229:ℝ)*hRo + (8808/229:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (8808/229:ℝ)*hmass
  · linear_combination (3723020/82669:ℝ)*hMl + (5707076/82669:ℝ)*hzl + (1861510/82669:ℝ)*hR0 + (3723020/82669:ℝ)*hRo + (3723020/82669:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_9
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (39239/112000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (39239/112000 : ℝ) (22478/39239 : ℝ) (241541/392390 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (39239/112000 : ℝ) (241541/392390 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1325973574590344/10544419284929:ℝ)*hMl + (29141/118:ℝ)*hzl + (53041904454020/620259957937:ℝ)*hR0 + (1940212249375112/10544419284929:ℝ)*hRo + (1325973574590344/10544419284929:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (502598352124170396/3806535361859369:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (19851712557814638/223913844815257:ℝ)*hR0 + (724338513721471644/3806535361859369:ℝ)*hRo + (502598352124170396/3806535361859369:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass
  · linear_combination (1325973574590344/10544419284929:ℝ)*hMl + (29141/118:ℝ)*hzl + (53041904454020/620259957937:ℝ)*hR0 + (1940212249375112/10544419284929:ℝ)*hRo + (1325973574590344/10544419284929:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (502598352124170396/3806535361859369:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (19851712557814638/223913844815257:ℝ)*hR0 + (724338513721471644/3806535361859369:ℝ)*hRo + (502598352124170396/3806535361859369:ℝ)*hchoice + (14939639632896/893594854655:ℝ)*hgap + (622484984704/893594854655:ℝ)*hC + (1/1:ℝ)*hI + (271109869951/893594854655:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_10
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (39239/112000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_11
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (3797/11200 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (3797/11200 : ℝ) (1994/3797 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (3797/11200 : ℝ) (21743/37970 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (25623171088290/226289002907:ℝ)*hR0 + (60400846692/247852139:ℝ)*hRo + (36656985233412/226289002907:ℝ)*hchoice + (26276308992192/1131445014535:ℝ)*hgap + (12218995077804/226289002907:ℝ)*hgood + (1094846208008/1131445014535:ℝ)*hC + (1/1:ℝ)*hI + (36598806527/1131445014535:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (9551004656910903/81690330049427:ℝ)*hR0 + (22481671948254/89474622179:ℝ)*hRo + (13775427796912398/81690330049427:ℝ)*hchoice + (504920713437408/21497455276165:ℝ)*hgap + (4591809265637466/81690330049427:ℝ)*hgood + (21038363059892/21497455276165:ℝ)*hC + (1/1:ℝ)*hI + (459092216273/21497455276165:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (5509/22:ℝ)*hzl + (25623171088290/226289002907:ℝ)*hR0 + (60400846692/247852139:ℝ)*hRo + (36656985233412/226289002907:ℝ)*hchoice + (26276308992192/1131445014535:ℝ)*hgap + (12218995077804/226289002907:ℝ)*hgood + (1094846208008/1131445014535:ℝ)*hC + (1/1:ℝ)*hI + (36598806527/1131445014535:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (9551004656910903/81690330049427:ℝ)*hR0 + (22481671948254/89474622179:ℝ)*hRo + (13775427796912398/81690330049427:ℝ)*hchoice + (504920713437408/21497455276165:ℝ)*hgap + (4591809265637466/81690330049427:ℝ)*hgood + (21038363059892/21497455276165:ℝ)*hC + (1/1:ℝ)*hI + (459092216273/21497455276165:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_12
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (147899294789656/1157466967075:ℝ)*hMl + (12439/50:ℝ)*hzl + (99443806793228/1157466967075:ℝ)*hR0 + (214458844268056/1157466967075:ℝ)*hRo + (147899294789656/1157466967075:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (55797139568719764/417845575114075:ℝ)*hMl + (4594391/18050:ℝ)*hzl + (37101961327182282/417845575114075:ℝ)*hR0 + (79825136930422164/417845575114075:ℝ)*hRo + (55797139568719764/417845575114075:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass
  · linear_combination (147899294789656/1157466967075:ℝ)*hMl + (12439/50:ℝ)*hzl + (99443806793228/1157466967075:ℝ)*hR0 + (214458844268056/1157466967075:ℝ)*hRo + (147899294789656/1157466967075:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (55797139568719764/417845575114075:ℝ)*hMl + (4594391/18050:ℝ)*hzl + (37101961327182282/417845575114075:ℝ)*hR0 + (79825136930422164/417845575114075:ℝ)*hRo + (55797139568719764/417845575114075:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_13
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (3797/11200 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (25/64 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (65905362029448/509285465513:ℝ)*hMl + (5509/22:ℝ)*hzl + (44170111150020/509285465513:ℝ)*hR0 + (95191563799944/509285465513:ℝ)*hRo + (65905362029448/509285465513:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (24763552360829532/183852053050193:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (16431268459256622/183852053050193:ℝ)*hR0 + (35335871199978588/183852053050193:ℝ)*hRo + (24763552360829532/183852053050193:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (65905362029448/509285465513:ℝ)*hMl + (5509/22:ℝ)*hzl + (44170111150020/509285465513:ℝ)*hR0 + (95191563799944/509285465513:ℝ)*hRo + (65905362029448/509285465513:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (24763552360829532/183852053050193:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (16431268459256622/183852053050193:ℝ)*hR0 + (35335871199978588/183852053050193:ℝ)*hRo + (24763552360829532/183852053050193:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_14
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (21523/56000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (21523/56000 : ℝ) (15046/21523 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (21523/56000 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass
  · linear_combination (4648/185:ℝ)*hMl + (2324/185:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (1022716/66785:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_15
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (21523/56000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (21523/56000 : ℝ) (15046/21523 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (21523/56000 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_16
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (21523/56000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (1164/59:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (487130/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_17
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (21523/56000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (21523/56000 : ℝ) (15046/21523 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (21523/56000 : ℝ) (156937/215230 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (141431497339752/1089804112837:ℝ)*hMl + (5509/22:ℝ)*hzl + (93512168928180/1089804112837:ℝ)*hR0 + (202629633002856/1089804112837:ℝ)*hRo + (141431497339752/1089804112837:ℝ)*hchoice + (8194547868672/495365505835:ℝ)*hgap + (341439494528/495365505835:ℝ)*hC + (1/1:ℝ)*hI + (153926011307/495365505835:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (53136116786943468/393419284734157:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (34797566106719478/393419284734157:ℝ)*hR0 + (75228643761324012/393419284734157:ℝ)*hRo + (53136116786943468/393419284734157:ℝ)*hchoice + (8194547868672/495365505835:ℝ)*hgap + (341439494528/495365505835:ℝ)*hC + (1/1:ℝ)*hI + (153926011307/495365505835:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (141431497339752/1089804112837:ℝ)*hMl + (5509/22:ℝ)*hzl + (93512168928180/1089804112837:ℝ)*hR0 + (202629633002856/1089804112837:ℝ)*hRo + (141431497339752/1089804112837:ℝ)*hchoice + (8194547868672/495365505835:ℝ)*hgap + (341439494528/495365505835:ℝ)*hC + (1/1:ℝ)*hI + (153926011307/495365505835:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (53136116786943468/393419284734157:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (34797566106719478/393419284734157:ℝ)*hR0 + (75228643761324012/393419284734157:ℝ)*hRo + (53136116786943468/393419284734157:ℝ)*hchoice + (8194547868672/495365505835:ℝ)*hgap + (341439494528/495365505835:ℝ)*hC + (1/1:ℝ)*hI + (153926011307/495365505835:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_18
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (21523/56000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2697361975368/20732808833:ℝ)*hMl + (5509/22:ℝ)*hzl + (76618102140/901426471:ℝ)*hR0 + (3837073900104/20732808833:ℝ)*hRo + (2697361975368/20732808833:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1013305872361212/7484543988713:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (28519095725874/325414956031:ℝ)*hR0 + (1424741877190908/7484543988713:ℝ)*hRo + (1013305872361212/7484543988713:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (2697361975368/20732808833:ℝ)*hMl + (5509/22:ℝ)*hzl + (76618102140/901426471:ℝ)*hR0 + (3837073900104/20732808833:ℝ)*hRo + (2697361975368/20732808833:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (1013305872361212/7484543988713:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (28519095725874/325414956031:ℝ)*hR0 + (1424741877190908/7484543988713:ℝ)*hRo + (1013305872361212/7484543988713:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_19
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (6373797562236/55226560867:ℝ)*hR0 + (13788036447288/55226560867:ℝ)*hRo + (9340648368504/55226560867:ℝ)*hchoice + (6440768111232/276132804335:ℝ)*hgap + (3113549456168/55226560867:ℝ)*hgood + (268365337968/276132804335:ℝ)*hC + (1/1:ℝ)*hI + (7767466367/276132804335:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (2353704105705012/19936788472987:ℝ)*hR0 + (5086050996761640/19936788472987:ℝ)*hRo + (3467534533831656/19936788472987:ℝ)*hchoice + (6492957424512/276132804335:ℝ)*hgap + (1155844844610552/19936788472987:ℝ)*hgood + (270539892688/276132804335:ℝ)*hC + (1/1:ℝ)*hI + (5592911647/276132804335:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (6373797562236/55226560867:ℝ)*hR0 + (13788036447288/55226560867:ℝ)*hRo + (9340648368504/55226560867:ℝ)*hchoice + (6440768111232/276132804335:ℝ)*hgap + (3113549456168/55226560867:ℝ)*hgood + (268365337968/276132804335:ℝ)*hC + (1/1:ℝ)*hI + (7767466367/276132804335:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (2353704105705012/19936788472987:ℝ)*hR0 + (5086050996761640/19936788472987:ℝ)*hRo + (3467534533831656/19936788472987:ℝ)*hchoice + (6492957424512/276132804335:ℝ)*hgap + (1155844844610552/19936788472987:ℝ)*hgood + (270539892688/276132804335:ℝ)*hC + (1/1:ℝ)*hI + (5592911647/276132804335:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_20
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_21
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1343795072568/11218043735:ℝ)*hR0 + (2929822481136/11218043735:ℝ)*hRo + (2046781217136/11218043735:ℝ)*hchoice + (52826906880/2243608747:ℝ)*hgap + (682260405712/11218043735:ℝ)*hgood + (2201121120/2243608747:ℝ)*hC + (1/1:ℝ)*hI + (42487627/2243608747:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (487993820186682/4049713788335:ℝ)*hR0 + (1063621647450324/4049713788335:ℝ)*hRo + (744157922431284/4049713788335:ℝ)*hchoice + (5029353231936/213142830965:ℝ)*hgap + (248052640810428/4049713788335:ℝ)*hgood + (209556384664/213142830965:ℝ)*hC + (1/1:ℝ)*hI + (3586446301/213142830965:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1343795072568/11218043735:ℝ)*hR0 + (2929822481136/11218043735:ℝ)*hRo + (2046781217136/11218043735:ℝ)*hchoice + (52826906880/2243608747:ℝ)*hgap + (682260405712/11218043735:ℝ)*hgood + (2201121120/2243608747:ℝ)*hC + (1/1:ℝ)*hI + (42487627/2243608747:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (487993820186682/4049713788335:ℝ)*hR0 + (1063621647450324/4049713788335:ℝ)*hRo + (744157922431284/4049713788335:ℝ)*hchoice + (5029353231936/213142830965:ℝ)*hgap + (248052640810428/4049713788335:ℝ)*hgood + (209556384664/213142830965:ℝ)*hC + (1/1:ℝ)*hI + (3586446301/213142830965:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_22
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

theorem large_selected_scored_t6_r4_cap_cell_23
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/4 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource

theorem large_selected_scored_t6_r4_cap_cell_24
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (7589/28000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (7589/28000 : ℝ) (1178/7589 : ℝ) (18191/75890 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (7589/28000 : ℝ) (18191/75890 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9665089501/7930505:ℝ)*hMu + (30189952/619685:ℝ)*hqM + (230404491/1239370:ℝ)*hR0 + (26073/110:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (182999588791/150679595:ℝ)*hMu + (523825552/11774015:ℝ)*hqM + (4477252401/23548030:ℝ)*hR0 + (9580257/39710:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass
  · linear_combination (9665089501/7930505:ℝ)*hMu + (30189952/619685:ℝ)*hqM + (230404491/1239370:ℝ)*hR0 + (26073/110:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (736/55:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1624/55:ℝ)*hmass
  · linear_combination (182999588791/150679595:ℝ)*hMu + (523825552/11774015:ℝ)*hqM + (4477252401/23548030:ℝ)*hR0 + (9580257/39710:ℝ)*hRo + (33347191081/171010526:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (286684/19855:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (670216/19855:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_25
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (253/896 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (253/896 : ℝ) (58/253 : ℝ) (155/506 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (253/896 : ℝ) (155/506 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1094455259/889295:ℝ)*hMu + (110725504/2084395:ℝ)*hqM + (756641957/4168790:ℝ)*hR0 + (86071/370:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (4648/185:ℝ)*hmass
  · linear_combination (20701671409/16896605:ℝ)*hMu + (1885854704/39603505:ℝ)*hqM + (14812056927/79207010:ℝ)*hR0 + (31806639/133570:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2045432/66785:ℝ)*hmass
  · linear_combination (1094455259/889295:ℝ)*hMu + (110725504/2084395:ℝ)*hqM + (756641957/4168790:ℝ)*hR0 + (86071/370:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (4648/185:ℝ)*hmass
  · linear_combination (20701671409/16896605:ℝ)*hMu + (1885854704/39603505:ℝ)*hqM + (14812056927/79207010:ℝ)*hR0 + (31806639/133570:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_26
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (253/896 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6892491060/185308349:ℝ)*hMu + (874975147/968962:ℝ)*hzu + (6892491060/185308349:ℝ)*hqM + (576000/11267:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (186676655/968962:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (6892491060/185308349:ℝ)*hMu + (17155077777/18410278:ℝ)*hzu + (6892491060/185308349:ℝ)*hqM + (576000/11267:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (3679493941/18410278:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (6892491060/185308349:ℝ)*hMu + (874975147/968962:ℝ)*hzu + (6892491060/185308349:ℝ)*hqM + (576000/11267:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (186676655/968962:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (6892491060/185308349:ℝ)*hMu + (17155077777/18410278:ℝ)*hzu + (6892491060/185308349:ℝ)*hqM + (576000/11267:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (3679493941/18410278:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_27
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (253/896 : ℝ) ≤ M) (hMu : M ≤ (9217/32000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (9217/32000 : ℝ) (2434/9217 : ℝ) (31123/92170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (9217/32000 : ℝ) (31123/92170 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (22435557132/226784285:ℝ)*hR0 + (36246/185:ℝ)*hRo + (12338153519364/134483081005:ℝ)*hchoice + (2056358919894/134483081005:ℝ)*hem + (18490265023/453568570:ℝ)*hg0 + (29375910703/453568570:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (87964944596/861780283:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (49295374929852/511035707819:ℝ)*hchoice + (8215895821642/511035707819:ℝ)*hem + (344540466701/8617802830:ℝ)*hg0 + (551367734621/8617802830:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass
  · linear_combination (22435557132/226784285:ℝ)*hR0 + (36246/185:ℝ)*hRo + (12338153519364/134483081005:ℝ)*hchoice + (2056358919894/134483081005:ℝ)*hem + (18490265023/453568570:ℝ)*hg0 + (29375910703/453568570:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (87964944596/861780283:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (49295374929852/511035707819:ℝ)*hchoice + (8215895821642/511035707819:ℝ)*hem + (344540466701/8617802830:ℝ)*hg0 + (551367734621/8617802830:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_28
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (9217/32000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6131596678001/8524184054:ℝ)*hzu + (6892491060/185308349:ℝ)*hR0 + (16365963060/185308349:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1330060801213/8524184054:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-44171038715/370616698:ℝ)*hmass
  · linear_combination (6371600249169/8524184054:ℝ)*hzu + (6892491060/185308349:ℝ)*hR0 + (16365963060/185308349:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1390061694005/8524184054:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-44171038715/370616698:ℝ)*hmass
  · linear_combination (6131596678001/8524184054:ℝ)*hzu + (6892491060/185308349:ℝ)*hR0 + (16365963060/185308349:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1330060801213/8524184054:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-44171038715/370616698:ℝ)*hmass
  · linear_combination (6371600249169/8524184054:ℝ)*hzu + (6892491060/185308349:ℝ)*hR0 + (16365963060/185308349:ℝ)*hRo + (73170125963/370616698:ℝ)*hg0 + (82064926715/370616698:ℝ)*hgap + (1/1:ℝ)*hH0 + (1390061694005/8524184054:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-44171038715/370616698:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_29
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (9217/32000 : ℝ) ≤ M) (hMu : M ≤ (130307/448000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (130307/448000 : ℝ) (36614/130307 : ℝ) (459833/1303070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (130307/448000 : ℝ) (459833/1303070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (29150445446274/271611259265:ℝ)*hMl + (24754515807237/271611259265:ℝ)*hR0 + (36246/185:ℝ)*hRo + (29150445446274/271611259265:ℝ)*hchoice + (827244411163/14681689690:ℝ)*hg0 + (1179604963723/14681689690:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (116451250261982/1032122785207:ℝ)*hMl + (96906938850571/1032122785207:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (116451250261982/1032122785207:ℝ)*hchoice + (827244411163/14681689690:ℝ)*hg0 + (1179604963723/14681689690:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass
  · linear_combination (29150445446274/271611259265:ℝ)*hMl + (24754515807237/271611259265:ℝ)*hR0 + (36246/185:ℝ)*hRo + (29150445446274/271611259265:ℝ)*hchoice + (827244411163/14681689690:ℝ)*hg0 + (1179604963723/14681689690:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (116451250261982/1032122785207:ℝ)*hMl + (96906938850571/1032122785207:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (116451250261982/1032122785207:ℝ)*hchoice + (827244411163/14681689690:ℝ)*hg0 + (1179604963723/14681689690:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_30
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (130307/448000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3688983251754/34282044565:ℝ)*hMl + (3119602471977/34282044565:ℝ)*hR0 + (36246/185:ℝ)*hRo + (3688983251754/34282044565:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (14734994877622/130271769347:ℝ)*hMl + (12212918653991/130271769347:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (14734994877622/130271769347:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass
  · linear_combination (3688983251754/34282044565:ℝ)*hMl + (3119602471977/34282044565:ℝ)*hR0 + (36246/185:ℝ)*hRo + (3688983251754/34282044565:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (18123/370:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-4283/370:ℝ)*hmass
  · linear_combination (14734994877622/130271769347:ℝ)*hMl + (12212918653991/130271769347:ℝ)*hR0 + (2690462/13357:ℝ)*hRo + (14734994877622/130271769347:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1345231/26714:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-162231/26714:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_31
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (253/896 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (253/896 : ℝ) (58/253 : ℝ) (155/506 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (253/896 : ℝ) (155/506 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (344977377/283613:ℝ)*hMu + (3744/59:ℝ)*hzl + (25784352/664753:ℝ)*hqM + (260363647/1329506:ℝ)*hR0 + (29141/118:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (6520705607/5388647:ℝ)*hMu + (1485436/21299:ℝ)*hzl + (410528452/12630307:ℝ)*hqM + (5105657765/25260614:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (344977377/283613:ℝ)*hMu + (3744/59:ℝ)*hzl + (25784352/664753:ℝ)*hqM + (260363647/1329506:ℝ)*hR0 + (29141/118:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (6520705607/5388647:ℝ)*hMu + (1485436/21299:ℝ)*hzl + (410528452/12630307:ℝ)*hqM + (5105657765/25260614:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (1118916065/5701102:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_32
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (253/896 : ℝ) ≤ M) (hMu : M ≤ (9217/32000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (9217/32000 : ℝ) (2434/9217 : ℝ) (31123/92170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (9217/32000 : ℝ) (31123/92170 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (112651/458:ℝ)*hzl + (35798400086/280722169:ℝ)*hR0 + (112651/458:ℝ)*hRo + (22412488380027/166468246217:ℝ)*hchoice + (7470829460009/332936492434:ℝ)*hem + (47186350999/1403610845:ℝ)*hg0 + (80873011279/1403610845:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (41753675/165338:ℝ)*hzl + (700201165810/5333721211:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (443655355555065/3162896678123:ℝ)*hchoice + (147885118518355/6325793356246:ℝ)*hem + (871501213761/26668606055:ℝ)*hg0 + (1511547759081/26668606055:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass
  · linear_combination (112651/458:ℝ)*hzl + (35798400086/280722169:ℝ)*hR0 + (112651/458:ℝ)*hRo + (22412488380027/166468246217:ℝ)*hchoice + (7470829460009/332936492434:ℝ)*hem + (47186350999/1403610845:ℝ)*hg0 + (80873011279/1403610845:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (41753675/165338:ℝ)*hzl + (700201165810/5333721211:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (443655355555065/3162896678123:ℝ)*hchoice + (147885118518355/6325793356246:ℝ)*hem + (871501213761/26668606055:ℝ)*hg0 + (1511547759081/26668606055:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_33
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (9217/32000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (26263131396641/167148130798:ℝ)*hMl + (221389/902:ℝ)*hzl + (38697185268881/334296261596:ℝ)*hR0 + (221389/902:ℝ)*hRo + (26263131396641/167148130798:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (520350685495675/3175814485162:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (756597709068235/6351628970324:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (520350685495675/3175814485162:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass
  · linear_combination (26263131396641/167148130798:ℝ)*hMl + (221389/902:ℝ)*hzl + (38697185268881/334296261596:ℝ)*hR0 + (221389/902:ℝ)*hRo + (26263131396641/167148130798:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (520350685495675/3175814485162:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (756597709068235/6351628970324:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (520350685495675/3175814485162:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_34
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (9217/32000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13379559741719/84871223842:ℝ)*hMl + (112651/458:ℝ)*hzl + (19693081552679/169742447684:ℝ)*hR0 + (112651/458:ℝ)*hRo + (13379559741719/84871223842:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (264809946237805/1612553252998:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (384766860646045/3225106505996:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (264809946237805/1612553252998:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass
  · linear_combination (13379559741719/84871223842:ℝ)*hMl + (112651/458:ℝ)*hzl + (19693081552679/169742447684:ℝ)*hR0 + (112651/458:ℝ)*hRo + (13379559741719/84871223842:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (264809946237805/1612553252998:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (384766860646045/3225106505996:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (264809946237805/1612553252998:ℝ)*hchoice + (104936474423/1853083490:ℝ)*hg0 + (149410478183/1853083490:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_35
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (253/896 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (29141/118:ℝ)*hzl + (16499785366/129059609:ℝ)*hR0 + (29141/118:ℝ)*hRo + (10406660871387/76532348137:ℝ)*hchoice + (3468886957129/153064696274:ℝ)*hem + (21917646839/645298045:ℝ)*hg0 + (37404799919/645298045:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10787605/42598:ℝ)*hzl + (322301777330/2452132571:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (205559364913305/1454114614603:ℝ)*hchoice + (68519788304435/2908229229206:ℝ)*hem + (405427970721/12260662855:ℝ)*hg0 + (699683879241/12260662855:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass
  · linear_combination (29141/118:ℝ)*hzl + (16499785366/129059609:ℝ)*hR0 + (29141/118:ℝ)*hRo + (10406660871387/76532348137:ℝ)*hchoice + (3468886957129/153064696274:ℝ)*hem + (21917646839/645298045:ℝ)*hg0 + (37404799919/645298045:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10787605/42598:ℝ)*hzl + (322301777330/2452132571:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (205559364913305/1454114614603:ℝ)*hchoice + (68519788304435/2908229229206:ℝ)*hem + (405427970721/12260662855:ℝ)*hg0 + (699683879241/12260662855:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_36
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (34163/112000 : ℝ) (12326/34163 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13901704740/384914521:ℝ)*hMu + (874975147/968962:ℝ)*hzu + (13901704740/384914521:ℝ)*hqM + (576000/11267:ℝ)*hRo + (152815995727/769829042:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (186676655/968962:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (13901704740/384914521:ℝ)*hMu + (17155077777/18410278:ℝ)*hzu + (13901704740/384914521:ℝ)*hqM + (576000/11267:ℝ)*hRo + (152815995727/769829042:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3679493941/18410278:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (13901704740/384914521:ℝ)*hMu + (874975147/968962:ℝ)*hzu + (13901704740/384914521:ℝ)*hqM + (576000/11267:ℝ)*hRo + (152815995727/769829042:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (186676655/968962:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (13901704740/384914521:ℝ)*hMu + (17155077777/18410278:ℝ)*hzu + (13901704740/384914521:ℝ)*hqM + (576000/11267:ℝ)*hRo + (152815995727/769829042:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3679493941/18410278:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_37
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (67057/224000 : ℝ) (22114/67057 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (25094950465631/173772180370:ℝ)*hMl + (37830826421231/347544360740:ℝ)*hR0 + (1014631/4370:ℝ)*hRo + (25094950465631/173772180370:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (53928/2185:ℝ)*hmass
  · linear_combination (26073482688639/173772180370:ℝ)*hMl + (2042597823381/18291808460:ℝ)*hR0 + (1039239/4370:ℝ)*hRo + (26073482688639/173772180370:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (66232/2185:ℝ)*hmass
  · linear_combination (25094950465631/173772180370:ℝ)*hMl + (37830826421231/347544360740:ℝ)*hR0 + (1014631/4370:ℝ)*hRo + (25094950465631/173772180370:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (53928/2185:ℝ)*hmass
  · linear_combination (26073482688639/173772180370:ℝ)*hMl + (2042597823381/18291808460:ℝ)*hR0 + (1039239/4370:ℝ)*hRo + (26073482688639/173772180370:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (66232/2185:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_38
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (26569/89600 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (26569/89600 : ℝ) (8338/26569 : ℝ) (101611/265690 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (26569/89600 : ℝ) (101611/265690 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3474897531249/22152116302:ℝ)*hMl + (2272/37:ℝ)*hzl + (5110494403809/44304232604:ℝ)*hR0 + (18123/74:ℝ)*hRo + (3474897531249/22152116302:ℝ)*hchoice + (118367350301/598705846:ℝ)*hg0 + (132736290605/598705846:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (68918142478315/420890209738:ℝ)*hMl + (912068/13357:ℝ)*hzl + (99994483056955/841780419476:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (68918142478315/420890209738:ℝ)*hchoice + (118367350301/598705846:ℝ)*hg0 + (132736290605/598705846:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (3474897531249/22152116302:ℝ)*hMl + (2272/37:ℝ)*hzl + (5110494403809/44304232604:ℝ)*hR0 + (18123/74:ℝ)*hRo + (3474897531249/22152116302:ℝ)*hchoice + (118367350301/598705846:ℝ)*hg0 + (132736290605/598705846:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (68918142478315/420890209738:ℝ)*hMl + (912068/13357:ℝ)*hzl + (99994483056955/841780419476:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (68918142478315/420890209738:ℝ)*hchoice + (118367350301/598705846:ℝ)*hg0 + (132736290605/598705846:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_39
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (26569/89600 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (67057/224000 : ℝ) (22114/67057 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (462391572963/2942595274:ℝ)*hMl + (2272/37:ℝ)*hzl + (12883069541577/111818620412:ℝ)*hR0 + (18123/74:ℝ)*hRo + (462391572963/2942595274:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (174230219552995/1062276893914:ℝ)*hMl + (912068/13357:ℝ)*hzl + (252085183003315/2124553787828:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (174230219552995/1062276893914:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (462391572963/2942595274:ℝ)*hMl + (2272/37:ℝ)*hzl + (12883069541577/111818620412:ℝ)*hR0 + (18123/74:ℝ)*hRo + (462391572963/2942595274:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (174230219552995/1062276893914:ℝ)*hMl + (912068/13357:ℝ)*hzl + (252085183003315/2124553787828:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (174230219552995/1062276893914:ℝ)*hchoice + (299156247653/1511062438:ℝ)*hg0 + (335421746165/1511062438:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_40
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (67057/224000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (34163/112000 : ℝ) (12326/34163 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (12831757109629/88530339830:ℝ)*hMl + (1011923225791/9318983140:ℝ)*hR0 + (1014631/4370:ℝ)*hRo + (12831757109629/88530339830:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (53928/2185:ℝ)*hmass
  · linear_combination (13330282190301/88530339830:ℝ)*hMl + (19725066370701/177060679660:ℝ)*hR0 + (1039239/4370:ℝ)*hRo + (13330282190301/88530339830:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (66232/2185:ℝ)*hmass
  · linear_combination (12831757109629/88530339830:ℝ)*hMl + (1011923225791/9318983140:ℝ)*hR0 + (1014631/4370:ℝ)*hRo + (12831757109629/88530339830:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (53928/2185:ℝ)*hmass
  · linear_combination (13330282190301/88530339830:ℝ)*hMl + (19725066370701/177060679660:ℝ)*hR0 + (1039239/4370:ℝ)*hRo + (13330282190301/88530339830:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (66232/2185:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_41
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (67057/224000 : ℝ) ≤ M) (hMu : M ≤ (135383/448000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (135383/448000 : ℝ) (46766/135383 : ℝ) (556277/1353830 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (135383/448000 : ℝ) (556277/1353830 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (480196537539/3050720522:ℝ)*hMl + (2272/37:ℝ)*hzl + (36955627521/321128476:ℝ)*hR0 + (18123/74:ℝ)*hRo + (480196537539/3050720522:ℝ)*hchoice + (31830959953/160564238:ℝ)*hg0 + (35684501665/160564238:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (9522436914065/57963689918:ℝ)*hMl + (912068/13357:ℝ)*hzl + (13739684235905/115927379836:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (9522436914065/57963689918:ℝ)*hchoice + (31830959953/160564238:ℝ)*hg0 + (35684501665/160564238:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (480196537539/3050720522:ℝ)*hMl + (2272/37:ℝ)*hzl + (36955627521/321128476:ℝ)*hR0 + (18123/74:ℝ)*hRo + (480196537539/3050720522:ℝ)*hchoice + (31830959953/160564238:ℝ)*hg0 + (35684501665/160564238:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (9522436914065/57963689918:ℝ)*hMl + (912068/13357:ℝ)*hzl + (13739684235905/115927379836:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (9522436914065/57963689918:ℝ)*hchoice + (31830959953/160564238:ℝ)*hg0 + (35684501665/160564238:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_42
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (135383/448000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (34163/112000 : ℝ) (12326/34163 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4490916001323/28483674554:ℝ)*hMl + (2272/37:ℝ)*hzl + (6548368302843/56967349108:ℝ)*hR0 + (18123/74:ℝ)*hRo + (4490916001323/28483674554:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (89049973133705/541189816526:ℝ)*hMl + (912068/13357:ℝ)*hzl + (128141566862585/1082379633052:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (89049973133705/541189816526:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (4490916001323/28483674554:ℝ)*hMl + (2272/37:ℝ)*hzl + (6548368302843/56967349108:ℝ)*hR0 + (18123/74:ℝ)*hRo + (4490916001323/28483674554:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (89049973133705/541189816526:ℝ)*hMl + (912068/13357:ℝ)*hzl + (128141566862585/1082379633052:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (89049973133705/541189816526:ℝ)*hchoice + (152815995727/769829042:ℝ)*hg0 + (171291892735/769829042:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_43
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (43/128 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (43/128 : ℝ) (22/43 : ℝ) (241/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1752303420/49901543:ℝ)*hMu + (874975147/968962:ℝ)*hzu + (1752303420/49901543:ℝ)*hqM + (576000/11267:ℝ)*hRo + (19911467441/99803086:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (186676655/968962:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (1752303420/49901543:ℝ)*hMu + (17155077777/18410278:ℝ)*hzu + (1752303420/49901543:ℝ)*hqM + (576000/11267:ℝ)*hRo + (19911467441/99803086:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3679493941/18410278:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (1752303420/49901543:ℝ)*hMu + (874975147/968962:ℝ)*hzu + (1752303420/49901543:ℝ)*hqM + (576000/11267:ℝ)*hRo + (19911467441/99803086:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (186676655/968962:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass
  · linear_combination (1752303420/49901543:ℝ)*hMu + (17155077777/18410278:ℝ)*hzu + (1752303420/49901543:ℝ)*hqM + (576000/11267:ℝ)*hRo + (19911467441/99803086:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3679493941/18410278:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (-3523805/22534:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_44
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (13919/44800 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (13919/44800 : ℝ) (5438/13919 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (13919/44800 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5246415594577/36069835790:ℝ)*hMl + (7815067747777/72139671580:ℝ)*hR0 + (1014631/4370:ℝ)*hRo + (5246415594577/36069835790:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (53928/2185:ℝ)*hmass
  · linear_combination (5449529214513/36069835790:ℝ)*hMl + (8018181367713/72139671580:ℝ)*hR0 + (1039239/4370:ℝ)*hRo + (5449529214513/36069835790:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (66232/2185:ℝ)*hmass
  · linear_combination (5246415594577/36069835790:ℝ)*hMl + (7815067747777/72139671580:ℝ)*hR0 + (1014631/4370:ℝ)*hRo + (5246415594577/36069835790:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (53928/2185:ℝ)*hmass
  · linear_combination (5449529214513/36069835790:ℝ)*hMl + (8018181367713/72139671580:ℝ)*hR0 + (1039239/4370:ℝ)*hRo + (5449529214513/36069835790:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (66232/2185:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_45
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (19703/64000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (19703/64000 : ℝ) (7406/19703 : ℝ) (86357/197030 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (19703/64000 : ℝ) (86357/197030 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2594293731663/16427533874:ℝ)*hMl + (2272/37:ℝ)*hzl + (3772448610783/32855067748:ℝ)*hR0 + (18123/74:ℝ)*hRo + (2594293731663/16427533874:ℝ)*hchoice + (88248532387/443987402:ℝ)*hg0 + (98904230035/443987402:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (2707290370295/16427533874:ℝ)*hMl + (912068/13357:ℝ)*hzl + (3885445249415/32855067748:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (2707290370295/16427533874:ℝ)*hchoice + (88248532387/443987402:ℝ)*hg0 + (98904230035/443987402:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (2594293731663/16427533874:ℝ)*hMl + (2272/37:ℝ)*hzl + (3772448610783/32855067748:ℝ)*hR0 + (18123/74:ℝ)*hRo + (2594293731663/16427533874:ℝ)*hchoice + (88248532387/443987402:ℝ)*hg0 + (98904230035/443987402:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (2707290370295/16427533874:ℝ)*hMl + (912068/13357:ℝ)*hzl + (3885445249415/32855067748:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (2707290370295/16427533874:ℝ)*hchoice + (88248532387/443987402:ℝ)*hg0 + (98904230035/443987402:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_46
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (19703/64000 : ℝ) ≤ M) (hMu : M ≤ (13919/44800 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (13919/44800 : ℝ) (5438/13919 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (13919/44800 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1835644823799/11605077602:ℝ)*hMl + (2272/37:ℝ)*hzl + (2662080733959/23210155204:ℝ)*hR0 + (18123/74:ℝ)*hRo + (1835644823799/11605077602:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (36393934596365/220496474438:ℝ)*hMl + (912068/13357:ℝ)*hzl + (52096216889405/440992948876:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (36393934596365/220496474438:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (1835644823799/11605077602:ℝ)*hMl + (2272/37:ℝ)*hzl + (2662080733959/23210155204:ℝ)*hR0 + (18123/74:ℝ)*hRo + (1835644823799/11605077602:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (36393934596365/220496474438:ℝ)*hMl + (912068/13357:ℝ)*hzl + (52096216889405/440992948876:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (36393934596365/220496474438:ℝ)*hchoice + (62421547051/313650746:ℝ)*hg0 + (69949164955/313650746:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_47
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (13919/44800 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (43/128 : ℝ) ≤ z) (hzu : z ≤ (437/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (437/1280 : ℝ) (234/437 : ℝ) (2543/4370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (53928/2185:ℝ)*hMl + (26964/2185:ℝ)*hR0 + (53928/2185:ℝ)*hRo + (53928/2185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (53928/2185:ℝ)*hmass
  · linear_combination (66232/2185:ℝ)*hMl + (33116/2185:ℝ)*hR0 + (66232/2185:ℝ)*hRo + (66232/2185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (66232/2185:ℝ)*hmass
  · linear_combination (53928/2185:ℝ)*hMl + (26964/2185:ℝ)*hR0 + (53928/2185:ℝ)*hRo + (53928/2185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (26592/2185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (53928/2185:ℝ)*hmass
  · linear_combination (66232/2185:ℝ)*hMl + (33116/2185:ℝ)*hR0 + (66232/2185:ℝ)*hRo + (66232/2185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (29668/2185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (66232/2185:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_48
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (13919/44800 : ℝ) ≤ M) (hMu : M ≤ (140459/448000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (140459/448000 : ℝ) (56918/140459 : ℝ) (652721/1404590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (140459/448000 : ℝ) (652721/1404590 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (18552840354339/117108814922:ℝ)*hMl + (2272/37:ℝ)*hzl + (26834474403699/234217629844:ℝ)*hR0 + (18123/74:ℝ)*hRo + (18552840354339/117108814922:ℝ)*hchoice + (630691214311/3165103106:ℝ)*hg0 + (706653688855/3165103106:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (367809072678065/2225067483518:ℝ)*hMl + (912068/13357:ℝ)*hzl + (525160119615905/4450134967036:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (367809072678065/2225067483518:ℝ)*hchoice + (630691214311/3165103106:ℝ)*hg0 + (706653688855/3165103106:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (18552840354339/117108814922:ℝ)*hMl + (2272/37:ℝ)*hzl + (26834474403699/234217629844:ℝ)*hR0 + (18123/74:ℝ)*hRo + (18552840354339/117108814922:ℝ)*hchoice + (630691214311/3165103106:ℝ)*hg0 + (706653688855/3165103106:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (367809072678065/2225067483518:ℝ)*hMl + (912068/13357:ℝ)*hzl + (525160119615905/4450134967036:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (367809072678065/2225067483518:ℝ)*hchoice + (630691214311/3165103106:ℝ)*hg0 + (706653688855/3165103106:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_49
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (140459/448000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (437/1280 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (585913514709/3692714182:ℝ)*hMl + (2272/37:ℝ)*hzl + (845254420869/7385428364:ℝ)*hR0 + (18123/74:ℝ)*hRo + (585913514709/3692714182:ℝ)*hchoice + (19911467441/99803086:ℝ)*hg0 + (22306741505/99803086:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (11614962481015/70161569458:ℝ)*hMl + (912068/13357:ℝ)*hzl + (16542439698055/140323138916:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (11614962481015/70161569458:ℝ)*hchoice + (19911467441/99803086:ℝ)*hg0 + (22306741505/99803086:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (585913514709/3692714182:ℝ)*hMl + (2272/37:ℝ)*hzl + (845254420869/7385428364:ℝ)*hR0 + (18123/74:ℝ)*hRo + (585913514709/3692714182:ℝ)*hchoice + (19911467441/99803086:ℝ)*hg0 + (22306741505/99803086:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (11614962481015/70161569458:ℝ)*hMl + (912068/13357:ℝ)*hzl + (16542439698055/140323138916:ℝ)*hR0 + (6726155/26714:ℝ)*hRo + (11614962481015/70161569458:ℝ)*hchoice + (19911467441/99803086:ℝ)*hg0 + (22306741505/99803086:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r4_cap_cell_50
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (451/1280 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (67057/224000 : ℝ) (22114/67057 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (451/1280 : ℝ) (262/451 : ℝ) (2809/4510 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5655437422709/35867850502:ℝ)*hMl + (221389/902:ℝ)*hzl + (157400094126911/1362978319076:ℝ)*hR0 + (221389/902:ℝ)*hRo + (5655437422709/35867850502:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (2128665057591925/12948294031222:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (3077653936405285/25896588062444:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (2128665057591925/12948294031222:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass
  · linear_combination (5655437422709/35867850502:ℝ)*hMl + (221389/902:ℝ)*hzl + (157400094126911/1362978319076:ℝ)*hR0 + (221389/902:ℝ)*hRo + (5655437422709/35867850502:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (17112/451:ℝ)*hmass
  · linear_combination (2128665057591925/12948294031222:ℝ)*hMl + (82110605/325622:ℝ)*hzl + (3077653936405285/25896588062444:ℝ)*hR0 + (82110605/325622:ℝ)*hRo + (2128665057591925/12948294031222:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (7272020/162811:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_51
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (67057/224000 : ℝ))
    (hzl : (451/1280 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (67057/224000 : ℝ) (22114/67057 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (67057/224000 : ℝ) (266083/670570 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2881087984931/18212278858:ℝ)*hMl + (112651/458:ℝ)*hzl + (80101676877449/692066596604:ℝ)*hR0 + (112651/458:ℝ)*hRo + (2881087984931/18212278858:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1083283740273955/6574632667738:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (1565142838385395/13149265335476:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (1083283740273955/6574632667738:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass
  · linear_combination (2881087984931/18212278858:ℝ)*hMl + (112651/458:ℝ)*hzl + (80101676877449/692066596604:ℝ)*hR0 + (112651/458:ℝ)*hRo + (2881087984931/18212278858:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (1083283740273955/6574632667738:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (1565142838385395/13149265335476:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (1083283740273955/6574632667738:ℝ)*hchoice + (431993281913/7555312190:ℝ)*hg0 + (613320774473/7555312190:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_52
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (67057/224000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (34163/112000 : ℝ) (12326/34163 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (27981552230251/176290850618:ℝ)*hMl + (112651/458:ℝ)*hzl + (40715513772091/352581701236:ℝ)*hR0 + (112651/458:ℝ)*hRo + (27981552230251/176290850618:ℝ)*hchoice + (222120333067/3849145210:ℝ)*hg0 + (314499818107/3849145210:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (553663847798345/3349526161742:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (795609117093305/6699052323484:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (553663847798345/3349526161742:ℝ)*hchoice + (222120333067/3849145210:ℝ)*hg0 + (314499818107/3849145210:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass
  · linear_combination (27981552230251/176290850618:ℝ)*hMl + (112651/458:ℝ)*hzl + (40715513772091/352581701236:ℝ)*hR0 + (112651/458:ℝ)*hRo + (27981552230251/176290850618:ℝ)*hchoice + (222120333067/3849145210:ℝ)*hg0 + (314499818107/3849145210:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (553663847798345/3349526161742:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (795609117093305/6699052323484:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (553663847798345/3349526161742:ℝ)*hchoice + (222120333067/3849145210:ℝ)*hg0 + (314499818107/3849145210:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_53
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (34163/112000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (34163/112000 : ℝ) (12326/34163 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (34163/112000 : ℝ) (145097/341630 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1124839044606248/9016143747893:ℝ)*hMl + (29141/118:ℝ)*hzl + (793388005535380/9016143747893:ℝ)*hR0 + (1682743830225704/9016143747893:ℝ)*hRo + (1124839044606248/9016143747893:ℝ)*hchoice + (13007031493632/764079978635:ℝ)*hgap + (541959645568/764079978635:ℝ)*hC + (1/1:ℝ)*hI + (222120333067/764079978635:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (426521621762905932/3254827892989373:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (296640433328297382/3254827892989373:ℝ)*hR0 + (627925249371529548/3254827892989373:ℝ)*hRo + (426521621762905932/3254827892989373:ℝ)*hchoice + (13007031493632/764079978635:ℝ)*hgap + (541959645568/764079978635:ℝ)*hC + (1/1:ℝ)*hI + (222120333067/764079978635:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass
  · linear_combination (1124839044606248/9016143747893:ℝ)*hMl + (29141/118:ℝ)*hzl + (793388005535380/9016143747893:ℝ)*hR0 + (1682743830225704/9016143747893:ℝ)*hRo + (1124839044606248/9016143747893:ℝ)*hchoice + (13007031493632/764079978635:ℝ)*hgap + (541959645568/764079978635:ℝ)*hC + (1/1:ℝ)*hI + (222120333067/764079978635:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (426521621762905932/3254827892989373:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (296640433328297382/3254827892989373:ℝ)*hR0 + (627925249371529548/3254827892989373:ℝ)*hRo + (426521621762905932/3254827892989373:ℝ)*hchoice + (13007031493632/764079978635:ℝ)*hgap + (541959645568/764079978635:ℝ)*hC + (1/1:ℝ)*hI + (222120333067/764079978635:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_54
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (13919/44800 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (13919/44800 : ℝ) (5438/13919 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (13919/44800 : ℝ) (62861/139190 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (11437107441463/71826020834:ℝ)*hMl + (112651/458:ℝ)*hzl + (16552075642183/143652041668:ℝ)*hR0 + (112651/458:ℝ)*hRo + (11437107441463/71826020834:ℝ)*hchoice + (91297610071/1568253730:ℝ)*hg0 + (128935699591/1568253730:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (226274330183885/1364694395846:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (323458725997565/2729388791692:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (226274330183885/1364694395846:ℝ)*hchoice + (91297610071/1568253730:ℝ)*hg0 + (128935699591/1568253730:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass
  · linear_combination (11437107441463/71826020834:ℝ)*hMl + (112651/458:ℝ)*hzl + (16552075642183/143652041668:ℝ)*hR0 + (112651/458:ℝ)*hRo + (11437107441463/71826020834:ℝ)*hchoice + (91297610071/1568253730:ℝ)*hg0 + (128935699591/1568253730:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (226274330183885/1364694395846:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (323458725997565/2729388791692:ℝ)*hR0 + (41753675/165338:ℝ)*hRo + (226274330183885/1364694395846:ℝ)*hchoice + (91297610071/1568253730:ℝ)*hg0 + (128935699591/1568253730:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_55
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (13919/44800 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (565597906943144/4559726043989:ℝ)*hMl + (112651/458:ℝ)*hzl + (395798692735060/4559726043989:ℝ)*hR0 + (843109159192232/4559726043989:ℝ)*hRo + (565597906943144/4559726043989:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (214999381834128396/1646061101880029:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (148292596791183366/1646061101880029:ℝ)*hR0 + (315180943896049164/1646061101880029:ℝ)*hRo + (214999381834128396/1646061101880029:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass
  · linear_combination (565597906943144/4559726043989:ℝ)*hMl + (112651/458:ℝ)*hzl + (395798692735060/4559726043989:ℝ)*hR0 + (843109159192232/4559726043989:ℝ)*hRo + (565597906943144/4559726043989:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (8808/229:ℝ)*hmass
  · linear_combination (214999381834128396/1646061101880029:ℝ)*hMl + (41753675/165338:ℝ)*hzl + (148292596791183366/1646061101880029:ℝ)*hR0 + (315180943896049164/1646061101880029:ℝ)*hRo + (214999381834128396/1646061101880029:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_56
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (34163/112000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2489666688776/19911467441:ℝ)*hMl + (29141/118:ℝ)*hzl + (1738281987460/19911467441:ℝ)*hR0 + (3701506218248/19911467441:ℝ)*hRo + (2489666688776/19911467441:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (943942382104284/7188039746201:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (650106151201134/7188039746201:ℝ)*hR0 + (1381416452243676/7188039746201:ℝ)*hRo + (943942382104284/7188039746201:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass
  · linear_combination (2489666688776/19911467441:ℝ)*hMl + (29141/118:ℝ)*hzl + (1738281987460/19911467441:ℝ)*hR0 + (3701506218248/19911467441:ℝ)*hRo + (2489666688776/19911467441:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (943942382104284/7188039746201:ℝ)*hMl + (10787605/42598:ℝ)*hzl + (650106151201134/7188039746201:ℝ)*hR0 + (1381416452243676/7188039746201:ℝ)*hRo + (943942382104284/7188039746201:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_57
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (7589/28000 : ℝ) ≤ M) (hMu : M ≤ (16447/56000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (16447/56000 : ℝ) (4894/16447 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (16447/56000 : ℝ) (60493/164470 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (3123687734/24061961:ℝ)*hR0 + (5509/22:ℝ)*hRo + (1982437521963/14268742873:ℝ)*hchoice + (660812507321/28537485746:ℝ)*hem + (4027020231/120309805:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (60730825490/457177259:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (38894497642185/271106114587:ℝ)*hchoice + (12964832547395/542212229174:ℝ)*hem + (74787436209/2285886295:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (5509/22:ℝ)*hzl + (3123687734/24061961:ℝ)*hR0 + (5509/22:ℝ)*hRo + (1982437521963/14268742873:ℝ)*hchoice + (660812507321/28537485746:ℝ)*hem + (4027020231/120309805:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (60730825490/457177259:ℝ)*hR0 + (2030725/7942:ℝ)*hRo + (38894497642185/271106114587:ℝ)*hchoice + (12964832547395/542212229174:ℝ)*hem + (74787436209/2285886295:ℝ)*heq + (24/1:ℝ)*hgap + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_58
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (63148820176712/497786686025:ℝ)*hMl + (12439/50:ℝ)*hzl + (43910626165156/497786686025:ℝ)*hR0 + (93444808413512/497786686025:ℝ)*hRo + (63148820176712/497786686025:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (23831244286157628/179700993655025:ℝ)*hMl + (4594391/18050:ℝ)*hzl + (16368996146803614/179700993655025:ℝ)*hR0 + (34768096039642428/179700993655025:ℝ)*hRo + (23831244286157628/179700993655025:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass
  · linear_combination (63148820176712/497786686025:ℝ)*hMl + (12439/50:ℝ)*hzl + (43910626165156/497786686025:ℝ)*hR0 + (93444808413512/497786686025:ℝ)*hRo + (63148820176712/497786686025:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (1032/25:ℝ)*hmass
  · linear_combination (23831244286157628/179700993655025:ℝ)*hMl + (4594391/18050:ℝ)*hzl + (16368996146803614/179700993655025:ℝ)*hR0 + (34768096039642428/179700993655025:ℝ)*hRo + (23831244286157628/179700993655025:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (424508/9025:ℝ)*hmass

theorem large_selected_scored_t6_r4_cap_cell_59
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (16447/56000 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (25/64 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (28142294374296/219026141851:ℝ)*hMl + (5509/22:ℝ)*hzl + (19499082260940/219026141851:ℝ)*hR0 + (41472529198488/219026141851:ℝ)*hRo + (28142294374296/219026141851:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (10577270147772564/79068437208211:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (7248119635525194/79068437208211:ℝ)*hR0 + (15389484919305876/79068437208211:ℝ)*hRo + (10577270147772564/79068437208211:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (28142294374296/219026141851:ℝ)*hMl + (5509/22:ℝ)*hzl + (19499082260940/219026141851:ℝ)*hR0 + (41472529198488/219026141851:ℝ)*hRo + (28142294374296/219026141851:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (10577270147772564/79068437208211:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (7248119635525194/79068437208211:ℝ)*hR0 + (15389484919305876/79068437208211:ℝ)*hRo + (10577270147772564/79068437208211:ℝ)*hchoice + (1686272941056/99557337205:ℝ)*hgap + (70261372544/99557337205:ℝ)*hC + (1/1:ℝ)*hI + (29295964661/99557337205:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

end TSP.Improvements20261105
