import TSP.Improvements20261105.UnaryPrefixFloor
import TSP.Improvements20261105.EnlargedUnaryErasedPrefixFloor
import TSP.Improvements20261105.ProjectedLeafQFloor
import TSP.Improvements20261105.GuardedPositiveDeficits
import TSP.Improvements20261105.ActualZeroLeafCost

/-! A common justified half-Q floor for every projected-zero unary
first head. Originally small and erased-positive heads use distinct
proved arguments; neither case assumes the other case's Q envelope. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (P : GatePlan d) (hP : P.RespectsTree d)
variable (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
variable (hf : Chapter06.Balanced (gatedNetwork d P) f)
variable (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
variable (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

include hs hP ht hf hb ha hcan in
theorem GatedDrops.enlarged_unary_projected_zero_prefix_floor (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hR : FixedQConnectorValues d x hx hn hcap R)
    (hY : Y ∈ projectedFrameworkTwo G d.centers owner)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hguard : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (r : FlowVertex d) (i : d.StarIndex) (hicomp : a.component d P (.inr i.1) = r)
    (hfirst : ∀ j ∈ a.actualComponentStars d P r, d.tree.Ancestor i.1 j.1)
    (v : d.tree.Child) (hv : d.centers i = (v : V)) (hunary : childCount d v = 1)
    (hzero : edgeSum z (d.backGroup i.1) ≤ 1) :
    guardedNormalizedHeadCost d x z C owner rootStar R a i ≤
      -(352/5 : ℝ)*max (x (d.treeEdge i.1)+edgeSum z (d.backGroup i.1)-1-degreeExcess G x (d.centers i)/2) 0 := by
  have hguardOriginal : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i := by
    intro i hi
    apply hguard i
    have hrem := (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) i.1).1
    rw [hm i.1]
    linarith only [hi,hrem]
  have hxi := degreeExcess_nonnegative G hx hn (d.centers i)
  by_cases hpositive : 1 < edgeSum x (d.backGroup i.1)
  · have hfloor := a.enlarged_unary_erased_prefix_floor d hs P hP t ht f hf hb ha hcan x z hx hn hcap hm C
      owner ho rootStar hroot Y R hR hrep hbacks hloss hterminal r i hicomp hfirst v hv hunary hpositive hzero
    have hmax := max_le_max_right (0 : ℝ) (show
      x (d.treeEdge i.1)+edgeSum z (d.backGroup i.1)-1-degreeExcess G x (d.centers i)/2 ≤
        x (d.treeEdge i.1)+edgeSum z (d.backGroup i.1)-1 by linarith only [hxi])
    linarith only [hfloor,hmax]
  · have heta := (fixedQIncrease_admissible d hs hx hn hcap (fixedPositiveTerminalChildren d x)
      (fixedPositiveTerminalChildren_admissible d x)).2.2.1
    have hfloor := a.unary_prefix_guarded_floor d hs P hP t ht f hf hb ha hcan x z hx hn hcap hm C
      (fixedQIncrease d x (fixedPositiveTerminalChildren d x)) heta owner ho rootStar hroot
      Y R hY hrep hbacks hguardOriginal r i hicomp hfirst v hv hunary (le_of_not_gt hpositive)
    have hrem := (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) i.1).1
    have hmass := hm i.1
    have hmax := max_le_max_right (0 : ℝ) (show
      x (d.treeEdge i.1)+edgeSum z (d.backGroup i.1)-1-degreeExcess G x (d.centers i)/2 ≤
        x (d.treeEdge i.1)+edgeSum x (d.backGroup i.1)-1-degreeExcess G x (d.centers i)/2 by
          linarith only [hrem,hmass])
    have h0 := le_max_right (x (d.treeEdge i.1)+edgeSum x (d.backGroup i.1)-1-degreeExcess G x (d.centers i)/2) 0
    linarith only [hfloor,hmax,h0]

end TSP.Improvements20261105
