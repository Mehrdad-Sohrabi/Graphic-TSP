import TSP.Chapter03.Auxiliary
import TSP.Improvements20261105.CycleGuardMixture

/-! A connector-free represented even subgraph remains even after the
actual star splits exactly when every selected star intersection is even. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Classical
open scoped BigOperators
variable {V E I : Type} [Fintype V] [Fintype E] [Fintype I]
  [DecidableEq V] [DecidableEq E] [DecidableEq I]

theorem represented_even_subgraph (G : Graph V E) (stars : I → Finset E)
    (center : I → V) (owner : E → Option I)
    (hloop : ∀ e, G.src e ≠ G.dst e)
    (hinc : ∀ i e, e ∈ stars i → G.incident (center i) e)
    (howner : ValidOwner stars owner) (C : Finset E)
    (hC : ∀ v, Even (G.intDegree C v)) (hstars : ∀ i, Even (C ∩ stars i).card) :
    ∀ v, Even ((auxiliaryGraph G center owner).intDegree (C.map Function.Embedding.inl) v) := by
  let K : Finset (E ⊕ I) := C.map Function.Embedding.inl
  have hproj : projectEdges K = C := by ext e; simp [projectEdges, K]
  have haux (i : I) : Even ((auxiliaryGraph G center owner).intDegree K (.inr i)) := by
    rw [auxiliary_intDegree G stars center owner hloop hinc howner K i, hproj]
    simpa [K] using hstars i
  intro v
  cases v with
  | inr i => exact haux i
  | inl v =>
    have hsum : (∑ i ∈ Finset.univ.filter (fun i => center i = v),
        (auxiliaryGraph G center owner).intDegree K (.inr i)) % 2 = 0 := by
      rw [Finset.sum_nat_mod]
      have hh : ∀ i, (auxiliaryGraph G center owner).intDegree K (.inr i) % 2 = 0 :=
        fun i => Nat.even_iff.mp (haux i)
      simp_rw [hh]
      simp
    have hc := contracted_intDegree G center owner K v
    rw [collapse_degree_sum, hproj] at hc
    have hconn : selectedConnectorsAt center K v = 0 := by simp [selectedConnectorsAt, K]
    rw [hconn, mul_zero, add_zero] at hc
    have hpar := Nat.even_iff.mp (hC v)
    rw [Nat.even_iff]
    change (auxiliaryGraph G center owner).intDegree K (.inl v) % 2 = 0
    omega

end TSP.Improvements20261105
