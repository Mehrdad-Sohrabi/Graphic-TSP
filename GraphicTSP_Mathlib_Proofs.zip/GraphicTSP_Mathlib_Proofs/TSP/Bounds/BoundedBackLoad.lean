import TSP.Improvements20261105.GreedyHeadLoads

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem bounded_back_noncritical_load (z : E → ℝ) (s : d.tree.Child)
    (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hzcap : ∀ e ∈ d.backGroup s, z e ≤ 43/100)
    (hpack : edgeSum z (d.backGroup s) ≤ 2) :
    24*(edgeSum z (d.backGroup s)-1)+noncriticalIncidence d z s ≤ 68 := by
  have hr1 : ∀ e ∈ d.backGroup s, incidenceRamp (1/2) (z e) ≤ (21/25)*z e := by
    intro e he
    unfold incidenceRamp
    norm_num only
    apply max_le <;> linarith [hz e he, hzcap e he]
  have hr2 : ∀ e ∈ d.backGroup s, incidenceRamp (9/20) (z e) ≤ (43/50)*z e := by
    intro e he
    unfold incidenceRamp
    norm_num only
    apply max_le <;> linarith [hz e he, hzcap e he]
  have ho := Finset.sum_le_sum hr1
  have hn := Finset.sum_le_sum hr2
  simp only [← Finset.mul_sum] at ho hn
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (starIncidenceRamp d (1/2) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h3 := min_le_right (((d.backGroup s).card : ℝ)-1)
    (ScoredParameters.massSlope*edgeSum z (d.backGroup s)-1)
  unfold noncriticalIncidence
  rw [add_max]
  apply max_le
  · unfold oldIncidence
    simp only [starIncidenceRamp, edgeSum] at h1 hpack ⊢
    linarith
  · unfold mixedNoncriticalIncidence
    simp only [signedStarIncidence, starIncidenceRamp, edgeSum, ScoredParameters.massSlope] at h2 h3 hpack ⊢
    norm_num only at h2 h3 ⊢
    linarith

end TSP.Improvements20261105
