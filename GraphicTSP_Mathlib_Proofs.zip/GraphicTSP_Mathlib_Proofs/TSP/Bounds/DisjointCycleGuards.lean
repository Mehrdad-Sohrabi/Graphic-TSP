import TSP.Improvements20261105.JoinMixtureGuard

/-! A finite family of edge-disjoint even-cycle guards can be applied
simultaneously. Correlation of their original events is unrestricted. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Classical
open scoped BigOperators
variable {V E A : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E] [DecidableEq A]

 theorem JoinMixture.disjoint_guards {G : Graph V E} {T : Finset V}
    (F : Finset A) (C N : A → Finset E) (m : A → ℝ)
    (M : JoinMixture G T)
    (hC : ∀ a ∈ F, ∀ v, Even (G.intDegree (C a) v))
    (hNC : ∀ a ∈ F, N a ⊆ C a)
    (hdis : ∀ a ∈ F, ∀ b ∈ F, a ≠ b → Disjoint (C a) (C b))
    (hm : ∀ a ∈ F, 0 ≤ m a) (hevent : ∀ a ∈ F, m a ≤ M.eventMass (N a)) :
    ∃ R : JoinMixture G T,
      (∀ e, (∀ a ∈ F, e ∉ C a) → R.point e = M.point e) ∧
      (∀ a ∈ F, ∀ e ∈ N a, R.point e = M.point e - m a) ∧
      (∀ S : Finset E, edgeSum M.point S - edgeSum R.point S ≤
        ∑ a ∈ F, (((S ∩ C a).card : ℝ)*m a)) ∧
      (∀ S : Finset E, (∀ a ∈ F, Disjoint S (C a)) → R.eventMass S = M.eventMass S) := by
  induction F using Finset.induction_on with
  | empty =>
    refine ⟨M, ?_, ?_, ?_, ?_⟩
    · simp
    · simp
    · intro S; simp
    · simp
  | @insert a F ha ih =>
    have hi := ih (fun b hb => hC b (Finset.mem_insert_of_mem hb))
      (fun b hb => hNC b (Finset.mem_insert_of_mem hb))
      (fun b hb c hc hbc => hdis b (Finset.mem_insert_of_mem hb) c (Finset.mem_insert_of_mem hc) hbc)
      (fun b hb => hm b (Finset.mem_insert_of_mem hb))
      (fun b hb => hevent b (Finset.mem_insert_of_mem hb))
    obtain ⟨R, hout, hpath, hloss, hpres⟩ := hi
    have had : ∀ b ∈ F, Disjoint (C a) (C b) := by
      intro b hb
      exact hdis a (Finset.mem_insert_self _ _) b (Finset.mem_insert_of_mem hb) (fun h => ha (h ▸ hb))
    have hmass : m a ≤ R.eventMass (N a) := by
      rw [hpres (N a) (fun b hb => (had b hb).mono_left (hNC a (Finset.mem_insert_self _ _)))]
      exact hevent a (Finset.mem_insert_self _ _)
    obtain ⟨Z, hzout, hzpath, hzloss, hzpres⟩ := R.guard (C a) (N a)
      (hC a (Finset.mem_insert_self _ _)) (hNC a (Finset.mem_insert_self _ _))
      (m a) (hm a (Finset.mem_insert_self _ _)) hmass
    refine ⟨Z, ?_, ?_, ?_, ?_⟩
    · intro e he
      rw [hzout e (he a (Finset.mem_insert_self _ _))]
      exact hout e (fun b hb => he b (Finset.mem_insert_of_mem hb))
    · intro b hb e he
      rcases Finset.mem_insert.mp hb with hba | hb
      · subst b
        rw [hzpath e he]
        have heout : ∀ b ∈ F, e ∉ C b := by
          intro b hb hc
          exact Finset.disjoint_left.mp (had b hb) (hNC a (Finset.mem_insert_self _ _) he) hc
        rw [hout e heout]
      · have heout : e ∉ C a := by
          intro hca
          exact Finset.disjoint_left.mp (had b hb) hca (hNC b (Finset.mem_insert_of_mem hb) he)
        rw [hzout e heout]
        exact hpath b hb e he
    · intro S
      rw [Finset.sum_insert ha]
      linarith [hloss S, hzloss S]
    · intro S hS
      rw [hzpres S (hS a (Finset.mem_insert_self _ _))]
      exact hpres S (fun b hb => hS b (Finset.mem_insert_of_mem hb))

end TSP.Improvements20261105
