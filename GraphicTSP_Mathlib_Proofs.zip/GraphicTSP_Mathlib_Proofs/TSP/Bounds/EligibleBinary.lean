import TSP.Improvements20261105.EligibleGeometry

/-! The binary-parent cases in the original-vector half-rank count. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter10
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem tight_binary_partition (G : Graph V E) (x : E → ℝ) (A : Finset V) (v : V)
    (hv : v ∈ A) (hA : edgeSum x (G.cut A) = 2)
    (hB : edgeSum x (G.cut (A.erase v)) = 2) (hV : edgeSum x (G.cut {v}) = 2) :
    PartitionableVertex G x v := by
  let F := G.cut (A.erase v) ∩ G.cut {v}
  have hF : F ⊆ G.cut {v} := Finset.inter_subset_right
  have hid := cut_insert_weight_identity G x (A.erase v) v (Finset.not_mem_erase _ _)
  rw [Finset.insert_erase hv, hA, hB, hV] at hid
  have hm : edgeSum x F = 1 := by dsimp [F]; linarith
  have hs : edgeSum x (G.cut {v} \ F) + edgeSum x F = edgeSum x (G.cut {v}) :=
    Finset.sum_sdiff hF
  exact ⟨F, hF, hm, by linarith⟩

theorem root_pair_edges_are_ancestor {G : Graph V E} (d : DFSData G) (v : V)
    (hv : v ≠ d.tree.root) :
    G.cut {d.tree.root} ∩ G.cut {v} ⊆ ancestorIncidentEdges d v := by
  intro e he
  have hs : (d.upper e = v ∧ d.lower e = d.tree.root) ∨
      (d.lower e = v ∧ d.upper e = d.tree.root) := by
    rcases d.oriented e with h | h
    · simp only [Finset.mem_inter, cut, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_singleton, h.1, h.2] at he
      aesop
    · simp only [Finset.mem_inter, cut, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_singleton, h.1, h.2] at he
      aesop
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
  rcases hs with h | h
  · have hd := edge_depth_strict d e
    rw [h.2, d.tree.root_depth] at hd
    omega
  · exact h.1

/-- A counted singleton at a nontight artificial top cannot have a tight
sibling: its edge mass directly to the root would already be at least one. -/
theorem top_erase_tight_ineligible {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (v : V)
    (hv : v ≠ d.tree.root)
    (hB : edgeSum x (G.cut (({d.tree.root}ᶜ : Finset V).erase v)) = 2) :
    1 ≤ ancestorMass d x v := by
  have hset : (({d.tree.root}ᶜ : Finset V).erase v)ᶜ = insert v {d.tree.root} := by
    ext w
    simp only [Finset.mem_compl, Finset.mem_erase, Finset.mem_singleton, Finset.mem_insert]
    tauto
  have hcut : edgeSum x (G.cut (insert v {d.tree.root})) = 2 := by
    rw [← hset, cut_complement]
    exact hB
  have hid := cut_insert_weight_identity G x {d.tree.root} v (by simpa using hv)
  rw [hcut] at hid
  have hr := hx.2 {d.tree.root} (Finset.singleton_nonempty _)
    (singleton_compl_nonempty hn d.tree.root)
  have hvcut := hx.2 {v} (Finset.singleton_nonempty _) (singleton_compl_nonempty hn v)
  have hlo : 1 ≤ edgeSum x (G.cut {d.tree.root} ∩ G.cut {v}) := by linarith
  exact hlo.trans (Finset.sum_le_sum_of_subset_of_nonneg (root_pair_edges_are_ancestor d v hv)
    (fun e _ _ => hx.1 e))

end TSP.Improvements20261105
