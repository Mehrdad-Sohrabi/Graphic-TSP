import TSP.Improvements20261105.NoPairLeafOwners

/-! Actual leaf coverage removes the entire unpaid-leaf count except
for the unique possible root component. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.all_leaf_count_bound (P : GatePlan d) (a : GatedDrops d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    (a.headfulLeafComponents d P).card ≤
      (a.paidLeafRoots d P x).card+(a.KLeafRoots d P x z C).card+
      (a.multiplePairLeafRoots d P x z C).card+(a.largeRemainingLeafRoots d P x z C).card+
      (a.solePairLeafRoots d P x z C).card+(a.oneExtraBackLeafRoots d P x z C).card+
      (a.twoBackSingleLeafRoots d P x z C).card+(a.twoBackTwoHeadLeafRoots d P x z C).card+
      (a.noPairLeafRoots d P x z C).card+1 := by
  have hcover : (a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d)) ⊆
      insert (.inl d.tree.root) (a.priorNoPairLeafRoots d P x z C ∪ a.noPairLeafRoots d P x z C) := by
    intro v hv
    obtain ⟨r,hr,rfl⟩ := Finset.mem_image.mp hv
    by_cases he : (r : FlowVertex d)=.inl d.tree.root
    · exact Finset.mem_insert.mpr (Or.inl he)
    · exact Finset.mem_insert.mpr (Or.inr (a.headful_leaf_cases_covered d P x z C r he hr))
  have hcard := Finset.card_le_card hcover
  have himage : ((a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d))).card =
      (a.headfulLeafComponents d P).card := Finset.card_image_iff.mpr (fun r _ s _ h => Subtype.ext h)
  rw [himage] at hcard
  have hins := Finset.card_insert_le (.inl d.tree.root) (a.priorNoPairLeafRoots d P x z C ∪ a.noPairLeafRoots d P x z C)
  have hunion := Finset.card_union_le (a.priorNoPairLeafRoots d P x z C) (a.noPairLeafRoots d P x z C)
  have hprior : (a.priorNoPairLeafRoots d P x z C).card ≤
      (a.paidLeafRoots d P x).card+(a.KLeafRoots d P x z C).card+
      (a.multiplePairLeafRoots d P x z C).card+(a.largeRemainingLeafRoots d P x z C).card+
      (a.solePairLeafRoots d P x z C).card+(a.oneExtraBackLeafRoots d P x z C).card+
      (a.twoBackSingleLeafRoots d P x z C).card+(a.twoBackTwoHeadLeafRoots d P x z C).card := by
    unfold priorNoPairLeafRoots
    exact (Finset.card_union_le _ _).trans (Nat.add_le_add_right
      ((Finset.card_union_le _ _).trans (Nat.add_le_add_right
        ((Finset.card_union_le _ _).trans (Nat.add_le_add_right
          ((Finset.card_union_le _ _).trans (Nat.add_le_add_right
            ((Finset.card_union_le _ _).trans (Nat.add_le_add_right
              ((Finset.card_union_le _ _).trans (Nat.add_le_add_right (Finset.card_union_le _ _) _)) _)) _)) _)) _)) _)
  omega

end TSP.Improvements20261105
