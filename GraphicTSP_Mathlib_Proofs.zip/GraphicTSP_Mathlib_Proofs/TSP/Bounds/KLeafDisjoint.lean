import TSP.Improvements20261105.KLeafOwners

/-! Whole leaves containing a protected unmatched pair are selected
from the actual canonical components. Multiple pairs in one leaf retain
disjoint head budgets, while its leaf charge is counted only once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.KLeafRoots_disjoint_paid (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
:
    Disjoint (a.KLeafRoots d P x z C) (a.paidLeafRoots d P x) := by
  apply Finset.disjoint_left.mpr
  intro r hr hp
  obtain ⟨p,hpair,rfl⟩ := Finset.mem_image.mp hr
  exact KStarPair_component_not_paid d hs x z hx hn hcap hm C P hP t ht f hf hb a ha hcan
    p (Finset.mem_filter.mp hpair).1 hp

theorem GatedDrops.KLeafHeads_subset_starUnion (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
:
    pairStarHeads d (a.KLeafPairs d P x z C) ⊆ a.componentStarUnion d P (a.KLeafRoots d P x z C) := by
  intro i hi
  rcases Finset.mem_union.mp hi with hfirst | hsecond
  · obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hfirst
    exact Finset.mem_biUnion.mpr ⟨a.component d P (.inr p.1.1),Finset.mem_image.mpr ⟨p,hp,rfl⟩,
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,rfl⟩⟩
  · obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hsecond
    have hsame := KStarPair_same_component d hs x z hx hn C P hP t ht f hf hb a ha hcan p
      (Finset.mem_filter.mp hp).1
    exact Finset.mem_biUnion.mpr ⟨a.component d P (.inr p.1.1),Finset.mem_image.mpr ⟨p,hp,rfl⟩,
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,hsame.symm⟩⟩

theorem GatedDrops.KLeafHeads_disjoint_paid (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
:
    Disjoint (pairStarHeads d (a.KLeafPairs d P x z C)) (a.paidLeafHeads d P x) := by
  rw [a.paidLeafHeads_eq_starUnion d P x]
  have hdis := a.componentStarUnion_disjoint d P _ _
    (a.KLeafRoots_disjoint_paid d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan)
  exact hdis.mono_left (a.KLeafHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan)

end TSP.Improvements20261105
