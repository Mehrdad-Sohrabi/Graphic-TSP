import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r4_cap_cell_80
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (25/56 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (25/56 : ℝ) (22/25 : ℝ) (223/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (12184352/394085:ℝ)*hem + (84119296/394085:ℝ)*ho0 + (1420800/78817:ℝ)*hgap + (59200/78817:ℝ)*hS + (1/1:ℝ)*hI + (19617/78817:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (4419858456/142264685:ℝ)*hem + (30533319744/142264685:ℝ)*ho0 + (513356160/28452937:ℝ)*hgap + (21389840/28452937:ℝ)*hS + (1/1:ℝ)*hI + (7063097/28452937:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (4481728288/145199365:ℝ)*hem + (30536103424/145199365:ℝ)*ho0 + (512908800/29039873:ℝ)*hgap + (21371200/29039873:ℝ)*hS + (1/1:ℝ)*hI + (7668673/29039873:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1625752170264/52416970765:ℝ)*hem + (11084645038336/52416970765:ℝ)*ho0 + (513356160/29039873:ℝ)*hgap + (21389840/29039873:ℝ)*hS + (1/1:ℝ)*hI + (7650033/29039873:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t7_r4_cap_cell_81
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (25/56 : ℝ) ≤ q) (hqu : q ≤ (3/4 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3347/5:ℝ)*hql + (2651/10:ℝ)*hzl + (3067/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (479/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (1210131/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (1109051/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (479/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass
  · linear_combination (1210967/1805:ℝ)*hql + (2651/10:ℝ)*hzl + (3067/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (173999/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (1212831/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (1109051/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (173999/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass

theorem large_selected_greedy_t7_r4_cap_cell_82
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (3/4 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (6/7 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hS := hSall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (6/7 : ℝ) (17/12 : ℝ) (11/8 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (16797/10:ℝ)*hzl + (527/2:ℝ)*hem + (2052/1:ℝ)*ho0 + (7191/5:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3689/2:ℝ)*hmass
  · linear_combination (16797/10:ℝ)*hzl + (527/2:ℝ)*hem + (2052/1:ℝ)*ho0 + (2594296/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3689/2:ℝ)*hmass
  · linear_combination (6101517/3610:ℝ)*hzl + (191327/722:ℝ)*hem + (744552/361:ℝ)*ho0 + (2614851/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1339289/722:ℝ)*hmass
  · linear_combination (6101517/3610:ℝ)*hzl + (191327/722:ℝ)*hem + (744552/361:ℝ)*ho0 + (2613196/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1339289/722:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (19/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (487/2:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (42781/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (487/2:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15373053/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (176051/722:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15466145/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (176051/722:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (15395257/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (19/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (487/2:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3265/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (487/2:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1175913/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (176051/722:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1180373/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (176051/722:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1177621/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_2
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (19/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (487/2:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (16229/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (487/2:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5854941/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (176051/722:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5867209/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (176051/722:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5863481/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_3
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (19/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (6/7 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (6/7 : ℝ) (17/12 : ℝ) (11/8 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (17077/10:ℝ)*hzl + (535/2:ℝ)*hem + (2080/1:ℝ)*ho0 + (7331/5:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3745/2:ℝ)*hmass
  · linear_combination (17077/10:ℝ)*hzl + (535/2:ℝ)*hem + (2080/1:ℝ)*ho0 + (2644836/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3745/2:ℝ)*hmass
  · linear_combination (6173337/3610:ℝ)*hzl + (193379/722:ℝ)*hem + (751734/361:ℝ)*ho0 + (2650761/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1353653/722:ℝ)*hmass
  · linear_combination (6173337/3610:ℝ)*hzl + (193379/722:ℝ)*hem + (751734/361:ℝ)*ho0 + (2649106/1805:ℝ)*ha + (24/1:ℝ)*hghalf + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1353653/722:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_4
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hqu,hgate,hmass]

theorem large_selected_greedy_t7_r5_all_cell_5
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (24/1:ℝ)*ho0 + (1/1:ℝ)*hH0 + (24/1:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (11864/361:ℝ)*ho0 + (1/1:ℝ)*hH0 + (11864/361:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_6
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (13/28 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (24/1:ℝ)*ho0 + (1/1:ℝ)*hH0 + (24/1:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (159020/4693:ℝ)*ho0 + (1/1:ℝ)*hH0 + (159020/4693:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_7
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (13/28 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (456/13:ℝ)*ho0 + (1/1:ℝ)*hH0 + (456/13:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (200060/4693:ℝ)*ho0 + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_8
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (13/28 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (4/7 : ℝ) (9/8 : ℝ) (89/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7633/26:ℝ)*hql + (768/13:ℝ)*hzl + (469/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2826401/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (469/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (1391569/4693:ℝ)*hql + (768/13:ℝ)*hzl + (85717/361:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (1427013/4693:ℝ)*hql + (312692/4693:ℝ)*hzl + (85717/361:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_9
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (4/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_10
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hqu,hgate,hmass]

theorem large_selected_greedy_t7_r5_all_cell_11
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (13/28 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (736/11:ℝ)*hzl + (472/11:ℝ)*ho0 + (1/1:ℝ)*hH0 + (472/11:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (191380/3971:ℝ)*ho0 + (1/1:ℝ)*hH0 + (191380/3971:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_12
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (13/28 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (13/28 : ℝ) (12/13 : ℝ) (121/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (1046224/5971:ℝ)*ho0 + (439296/29855:ℝ)*hgap + (1215184/5971:ℝ)*hgate + (18304/29855:ℝ)*hS + (1/1:ℝ)*hI + (11551/29855:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (385902960/2155531:ℝ)*ho0 + (439296/29855:ℝ)*hgap + (446897520/2155531:ℝ)*hgate + (18304/29855:ℝ)*hS + (1/1:ℝ)*hI + (11551/29855:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (379644880/2196323:ℝ)*ho0 + (158585856/10981615:ℝ)*hgap + (2231914768/10981615:ℝ)*hgate + (6607744/10981615:ℝ)*hS + (1/1:ℝ)*hI + (4373871/10981615:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (140073942128/792872603:ℝ)*ho0 + (158585856/10981615:ℝ)*hgap + (820831933488/3964363015:ℝ)*hgate + (6607744/10981615:ℝ)*hS + (1/1:ℝ)*hI + (4373871/10981615:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_13
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (13/28 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (4/7 : ℝ) (9/8 : ℝ) (89/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3274/5:ℝ)*hql + (511/2:ℝ)*hzl + (469/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1188794/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (469/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (2374453/3610:ℝ)*hql + (511/2:ℝ)*hzl + (85717/361:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (2388213/3610:ℝ)*hql + (187223/722:ℝ)*hzl + (85717/361:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_14
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (4/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_15
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (4059/10:ℝ)*ho0 + (4059/10:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1469027/3610:ℝ)*ho0 + (1469027/3610:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_16
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (46/125 : ℝ) ≤ q)
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (6/7 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t7_r5_all_cell_17
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/16:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2809/16:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (190871/5776:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1007649/5776:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (192239/5776:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1068425/5776:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (198639/5776:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1062025/5776:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_18
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (59/224 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (59/224 : ℝ) (6/59 : ℝ) (113/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (30437/118:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (24773/118:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (11365357/42598:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (24773/118:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (11415973/42598:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9371269/42598:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (11793573/42598:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9371269/42598:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_19
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (59/224 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/640 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/640 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (16129/62:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (6020969/22382:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (6033281/22382:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (6231681/22382:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_20
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (13/640 : ℝ) ≤ z) (hzu : z ≤ (13/320 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/320 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (16129/62:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (6020969/22382:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (6033281/22382:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (6231681/22382:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_21
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (31/112 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/320 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/320 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (8975/34:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (3348775/12274:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (3341935/12274:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (3450735/12274:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_22
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (13/320 : ℝ) ≤ z) (hzu : z ≤ (13/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (13/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hql + (48/1:ℝ)*hzl + (24/1:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (11864/361:ℝ)*hql + (20528/361:ℝ)*hzl + (11864/361:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_23
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (5/14 : ℝ) (3/5 : ℝ) (16/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2699/10:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2219/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1006339/3610:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2219/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (998131/3610:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (824851/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (1030131/3610:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (824851/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_24
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (13/160 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hql + (48/1:ℝ)*hzl + (24/1:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (11864/361:ℝ)*hql + (20528/361:ℝ)*hzl + (11864/361:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_25
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/16:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2809/16:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (2490899/75088:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13089861/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (192239/5776:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1068425/5776:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (2591883/75088:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13796749/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_26
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6931/208:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (36229/208:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2572979/75088:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13007781/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2603075/75088:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13785557/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2673963/75088:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13714669/75088:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_27
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24/1:ℝ)*hql + (48/1:ℝ)*hzl + (24/1:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (159020/4693:ℝ)*hql + (271652/4693:ℝ)*hzl + (159020/4693:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_28
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (91/320 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hI := hIall (91/320 : ℝ) (22/91 : ℝ) (289/910 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2712/91:ℝ)*hql + (4896/91:ℝ)*hzl + (2712/91:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2712/91:ℝ)*hmass
  · linear_combination (1277300/32851:ℝ)*hql + (2065724/32851:ℝ)*hzl + (1277300/32851:ℝ)*ho0 + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1277300/32851:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_29
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (91/320 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (218605/806:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (81113933/290966:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (81655661/290966:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (83853189/290966:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_30
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (31/112 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (91/320 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (121571/442:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (45092227/159562:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (45212611/159562:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (46417707/159562:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_31
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (5/14 : ℝ) (3/5 : ℝ) (16/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (36527/130:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2219/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (13540687/46930:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2219/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (13495543/46930:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (824851/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (13849983/46930:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (824851/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_32
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (4/7 : ℝ) (9/8 : ℝ) (89/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (565/2:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (469/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (210365/722:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (469/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (103045/361:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85717/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (106245/361:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85717/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_33
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (5/14 : ℝ) ≤ q) (hqu : q ≤ (13/28 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (13/28 : ℝ) (12/13 : ℝ) (121/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7507/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5971/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2780915/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5971/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2750819/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2196323/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2821707/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2196323/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_34
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (13/28 : ℝ) ≤ q) (hqu : q ≤ (4/7 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (4/7 : ℝ) (9/8 : ℝ) (89/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7633/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (469/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2826401/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (469/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (1391569/4693:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85717/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (1427013/4693:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (85717/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_35
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (4/7 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_36
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (11/56 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (11/56 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (30483/22:ℝ)*hqu + (736/11:ℝ)*hzl + (415/2:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (10962387/7942:ℝ)*hqu + (286684/3971:ℝ)*hzl + (415/2:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (11497163/7942:ℝ)*hqu + (736/11:ℝ)*hzl + (156215/722:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (11455187/7942:ℝ)*hqu + (286684/3971:ℝ)*hzl + (156215/722:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_37
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (11/56 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3744/59:ℝ)*hzl + (31973/944:ℝ)*hem + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (163907/944:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (11809957/340784:ℝ)*hem + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (58902723/340784:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (3744/59:ℝ)*hzl + (12000565/340784:ℝ)*hem + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (62378611/340784:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (12268269/340784:ℝ)*hem + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (62110907/340784:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_38
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (11/56 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (736/11:ℝ)*hzl + (6037/176:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (30483/176:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2221333/63536:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (10962387/63536:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (736/11:ℝ)*hzl + (2264805/63536:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11602499/63536:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2306781/63536:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11560523/63536:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_39
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/7 : ℝ) ≤ q) (hqu : q ≤ (11/56 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (11/56 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2761/2:ℝ)*hqu + (72/1:ℝ)*hzl + (415/2:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (993969/722:ℝ)*hqu + (27368/361:ℝ)*hzl + (415/2:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (1041521/722:ℝ)*hqu + (72/1:ℝ)*hzl + (156215/722:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (1038769/722:ℝ)*hqu + (27368/361:ℝ)*hzl + (156215/722:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_cell_40
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (11/56 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (73/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (73/160 : ℝ) (66/73 : ℝ) (667/730 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (36967/146:ℝ)*hzl + (40471/1168:ℝ)*hem + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (187173/5840:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3336/73:ℝ)*hmass
  · linear_combination (13581095/52706:ℝ)*hzl + (14846039/421648:ℝ)*hem + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (66389413/2108240:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1322300/26353:ℝ)*hmass
  · linear_combination (36967/146:ℝ)*hzl + (15177095/421648:ℝ)*hem + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (87416693/2108240:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (3336/73:ℝ)*hmass
  · linear_combination (13581095/52706:ℝ)*hzl + (15413103/421648:ℝ)*hem + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (86236653/2108240:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (1322300/26353:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_41
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (11/56 : ℝ) ≤ q) (hqu : q ≤ (1/4 : ℝ))
    (hzl : (73/160 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (559/16:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (2541/80:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (204551/5776:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (903541/28880:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (209567/5776:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1189181/28880:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (212319/5776:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1175421/28880:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_42
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (627525/2294:ℝ)*hql + (2272/37:ℝ)*hzl + (18123/74:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (232232837/828134:ℝ)*hql + (912068/13357:ℝ)*hzl + (6726155/26714:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass
  · linear_combination (234332869/828134:ℝ)*hql + (2272/37:ℝ)*hzl + (18123/74:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1384/37:ℝ)*hmass
  · linear_combination (240029181/828134:ℝ)*hql + (912068/13357:ℝ)*hzl + (6726155/26714:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (591500/13357:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_43
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1008155/3658:ℝ)*hql + (3744/59:ℝ)*hzl + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (372242779/1320538:ℝ)*hql + (1485436/21299:ℝ)*hzl + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (376375963/1320538:ℝ)*hql + (3744/59:ℝ)*hzl + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (384674787/1320538:ℝ)*hql + (1485436/21299:ℝ)*hzl + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_44
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (31/112 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (560533/2006:ℝ)*hql + (3744/59:ℝ)*hzl + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (206903381/724166:ℝ)*hql + (1485436/21299:ℝ)*hzl + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (208368053/724166:ℝ)*hql + (3744/59:ℝ)*hzl + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (212919021/724166:ℝ)*hql + (1485436/21299:ℝ)*hzl + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_45
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (25/64 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (25/64 : ℝ) (18/25 : ℝ) (187/250 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (430009/1550:ℝ)*hql + (1632/25:ℝ)*hzl + (12439/50:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1032/25:ℝ)*hmass
  · linear_combination (158454521/559550:ℝ)*hql + (641108/9025:ℝ)*hzl + (4594391/18050:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (424508/9025:ℝ)*hmass
  · linear_combination (160501049/559550:ℝ)*hql + (1632/25:ℝ)*hzl + (12439/50:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1032/25:ℝ)*hmass
  · linear_combination (163722321/559550:ℝ)*hql + (641108/9025:ℝ)*hzl + (4594391/18050:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (424508/9025:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_46
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (25/64 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (190315/682:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (70004971/246202:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (13153/62:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (71021547/246202:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (72322803/246202:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4958945/22382:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_47
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (31/112 : ℝ) ≤ q) (hqu : q ≤ (17/56 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (17/56 : ℝ) (6/17 : ℝ) (71/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (105797/374:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (38906309/135014:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7343/34:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (39314277/135014:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (40027869/135014:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2752783/12274:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_48
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (17/56 : ℝ) ≤ q) (hqu : q ≤ (5/14 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (5/14 : ℝ) (3/5 : ℝ) (16/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (31769/110:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2219/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (11678489/39710:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2219/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (11730321/39710:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (824851/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (11940201/39710:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (824851/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t7_r5_all_cell_49
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/4 : ℝ) ≤ q) (hqu : q ≤ (31/112 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (139/320 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hS := hSall (31/112 : ℝ) (6/31 : ℝ) (17/62 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (139/320 : ℝ) (118/139 : ℝ) (1201/1390 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2417515/8618:ℝ)*hql + (70021/278:ℝ)*hzl + (70021/278:ℝ)*ho0 + (24/1:ℝ)*hgap + (22117/310:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (6168/139:ℝ)*hmass
  · linear_combination (887846699/3111098:ℝ)*hql + (25765445/100358:ℝ)*hzl + (25765445/100358:ℝ)*ho0 + (24/1:ℝ)*hgap + (22117/310:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2470580/50179:ℝ)*hmass
  · linear_combination (902011883/3111098:ℝ)*hql + (70021/278:ℝ)*hzl + (70021/278:ℝ)*ho0 + (24/1:ℝ)*hgap + (9037797/111910:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (6168/139:ℝ)*hmass
  · linear_combination (917135667/3111098:ℝ)*hql + (25765445/100358:ℝ)*hzl + (25765445/100358:ℝ)*ho0 + (24/1:ℝ)*hgap + (9037797/111910:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (2470580/50179:ℝ)*hmass

end TSP.Improvements20261105
