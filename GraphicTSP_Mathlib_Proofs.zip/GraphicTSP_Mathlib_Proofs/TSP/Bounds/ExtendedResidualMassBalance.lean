import TSP.Improvements20261105.ExtendedResidualFamilyPayment

/-! Exact residual conservation for the disjoint union of unpaid unmatched
heads and matching targets. Matching sources are deliberately not donors. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def extendedResidualDonors (x z : E → ℝ) (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) : Finset d.StarIndex :=
  (H ∪ M).filter (fun i => ν i.1=1 ∧ 1 < edgeSum z (d.backGroup i.1))

noncomputable def extendedResidualInside (x z : E → ℝ) (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) : Finset (d.StarIndex × d.StarIndex) :=
  (couponResidualStarPairs d x z (extendedResidualDonors d x z ν H M)).filter (fun p => p.2 ∈ H)

noncomputable def extendedResidualOutside (x z : E → ℝ) (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) : Finset (d.StarIndex × d.StarIndex) :=
  (couponResidualStarPairs d x z (extendedResidualDonors d x z ν H M)).filter (fun p => p.2 ∉ H)

theorem actualCouponResidual_pair_sum (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (F : Finset d.StarIndex) :
    (∑ p ∈ couponResidualStarPairs d x z F, actualCouponResidual d x z p.1)=
      ∑ i ∈ F, actualCouponResidual d x z i := by
  rw [← Finset.sum_image (fun p hp q hq he => couponResidualStarPairs_fst_injective d hs x z hx hcap F hp hq he)]
  rw [couponResidualStarPairs_fst_image d hs x z hx hcap F,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro i hi
  by_cases hp : 0 < actualCouponResidual d x z i
  · rw [if_pos hp]
  · rw [if_neg hp]
    exact (le_antisymm (le_of_not_gt hp) (actualCouponResidual_nonnegative d x z i)).symm

theorem extendedResidual_mass_balance (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (ν : d.tree.Child → ℤ)
    (H M : Finset d.StarIndex) (hdis : Disjoint H M) :
    (∑ p ∈ extendedResidualInside d x z ν H M, actualCouponResidual d x z p.1)+
      (∑ p ∈ extendedResidualOutside d x z ν H M, actualCouponResidual d x z p.1)=
      (∑ i ∈ H, retainedSelectedResidual d x z ν i)+
      (∑ i ∈ M, retainedSelectedResidual d x z ν i) := by
  unfold extendedResidualInside extendedResidualOutside
  rw [Finset.sum_filter_add_sum_filter_not,actualCouponResidual_pair_sum d hs x z hx hcap]
  unfold extendedResidualDonors
  rw [Finset.sum_filter]
  change (∑ i ∈ H ∪ M, retainedSelectedResidual d x z ν i)=_
  exact Finset.sum_union hdis

end TSP.Improvements20261105
