import TSP.Improvements20261105.FixedProjectedCover
import TSP.Improvements20261105.EnlargedRepairPoint

/-! Choose all P representative increases from the fixed cover intervals. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def coveredPIncrease (x : E → ℝ) (P Q : ℝ) (c : d.tree.Child → ℝ) (s : d.tree.Child) : ℝ :=
  if d.tree.parent s = d.tree.root then 0 else
  if s ∈ projectionLinks d x then min (survivingExcess d x s)
    (outgoingBackMass d x s + (c (unaryNext d s) + Q * (1 - x (d.treeEdge s) - outgoingBackMass d x s)) / P)
  else survivingExcess d x s

theorem coveredPIncrease_link (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (s : d.tree.Child) (hlink : s ∈ projectionLinks d x) :
    0 ≤ coveredPIncrease d x P Q C.cover s ∧
      coveredPIncrease d x P Q C.cover s ≤ survivingExcess d x s ∧
      P * (survivingExcess d x s - coveredPIncrease d x P Q C.cover s) -
        Q * (x (d.treeEdge s) + preliminaryQIncrease d x s) ≤ C.cover s ∧
      P * (coveredPIncrease d x P Q C.cover s - outgoingBackMass d x s) -
        Q * (1 - x (d.treeEdge s) - outgoingBackMass d x s) ≤ C.cover (unaryNext d s) := by
  have hfS := (fixedCoverFloor_positive_lower d hs x z hx hcap Q hQ s
    (projectionLink_source_positive d hs x z hx hn hm s hlink)).trans (C.floor_bound s)
  have hfR := (projectionLink_receiver_floor d hs x z hx hn hcap hm Q hQ s hlink).trans
    (C.floor_bound (unaryNext d s))
  have he := C.edge_bound s hlink
  have ho : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  rw [coveredPIncrease, if_neg (Finset.mem_filter.mp hlink).2.1, if_pos hlink]
  exact full_floor_maximal_increase P Q (survivingExcess d x s) (x (d.treeEdge s))
    (outgoingBackMass d x s) (preliminaryQIncrease d x s) (C.cover s) (C.cover (unaryNext d s))
    hP (survivingExcess_bounds d hs hx hcap s).1 ho hfS hfR he

theorem coveredPIncrease_bounds (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q) (s : d.tree.Child) :
    0 ≤ coveredPIncrease d x P Q C.cover s ∧
      coveredPIncrease d x P Q C.cover s ≤ survivingExcess d x s := by
  by_cases hr : d.tree.parent s = d.tree.root
  · rw [coveredPIncrease, if_pos hr]
    exact ⟨le_rfl, (survivingExcess_bounds d hs hx hcap s).1⟩
  · by_cases hl : s ∈ projectionLinks d x
    · have h := coveredPIncrease_link d hs x z hx hn hcap hm P Q hP hQ C s hl
      exact ⟨h.1, h.2.1⟩
    · rw [coveredPIncrease, if_neg hr, if_neg hl]
      exact ⟨(survivingExcess_bounds d hs hx hcap s).1, le_rfl⟩

theorem coveredPIncrease_admissible (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q) :
    AdmissibleAdjustment d x (fun i => coveredPIncrease d x P Q C.cover i.1) := by
  intro i _
  have hb := coveredPIncrease_bounds d hs x z hx hn hcap hm P Q hP hQ C i.1
  have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent i.1)
  have ha : 0 ≤ edgeSum x (d.backGroup i.1) := Finset.sum_nonneg (fun e _ => hx.1 e)
  have he : survivingExcess d x i.1 ≤ edgeSum x (d.backGroup i.1) := by
    unfold survivingExcess
    exact max_le (by linarith) ha
  exact ⟨hb.1, le_min (hb.2.trans he) (hb.2.trans (survivingExcess_bounds d hs hx hcap i.1).2)⟩

end TSP.Improvements20261105
