import TSP.Improvements20261105.GuardedZeroComponentCost
import TSP.Improvements20261105.FixedQFloorBound

/-! An actual-zero head retains its fixed cover floor in the signed
arm even in a mixed component. This uses the actual guarded Q envelope,
not a full negative floor incorrectly assigned to erased-positive heads. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem actual_zero_cover_floor_lower (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (Q : ℝ) (hQ : 0 ≤ Q) (i : d.StarIndex) (hi : edgeSum x (d.backGroup i.1) ≤ 1) :
    -Q*x (d.treeEdge i.1) ≤ fixedCoverFloor d x z Q i.1 := by
  have hr := (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) i.1).1
  have hz : edgeSum z (d.backGroup i.1) ≤ 1 := by rw [hm]; linarith
  have hzero : -Q*x (d.treeEdge i.1) ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (by linarith) (hx.1 _)
  have hg : max (x (d.treeEdge i.1)+edgeSum z (d.backGroup i.1)-1) 0 ≤ x (d.treeEdge i.1) :=
    max_le (by linarith) (hx.1 _)
  unfold fixedCoverFloor
  split_ifs with hroot hev hpositive htarget
  · exact hzero
  · exact (not_lt_of_ge hz hpositive).elim
  · exact mul_le_mul_of_nonpos_left hg (by linarith)
  · exact hzero
  · exact hzero

theorem zeroQCredit_cover_floor (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (Q : ℝ) (hQ : 0 ≤ Q) (i : d.StarIndex) (hi : edgeSum x (d.backGroup i.1) ≤ 1) :
    -Q*zeroQCredit d x Y i ≤ fixedCoverFloor d x z Q i.1 := by
  have hconn := fixedQ_connector_floor_bound d hs x z hx hn hcap hm Y hY Q hQ i
  have hrep := actual_zero_cover_floor_lower d hs x z hx hn hcap hm Q hQ i hi
  have hmass := star_lp_sum d x i
  unfold zeroQCredit zeroQEnvelope
  rcases le_total (Y (.inr i)) ((edgeSum x (d.backGroup i.1)-x (d.treeEdge i.1))/2) with h | h
  · rw [max_eq_right h]
    nlinarith only [hrep,congrArg (fun v : ℝ => Q*v) hmass]
  · rw [max_eq_left h]
    nlinarith only [hconn]

theorem guarded_actual_zero_deficit_floor (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (p q : ℝ) (hp : 0 ≤ p) (hq : 0 ≤ q)
    (delta : d.StarIndex → ℝ) (hd : AdmissibleAdjustment d x delta)
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root)
    (hi : edgeSum x (d.backGroup i.1) ≤ 1)
    (hguard : max (R (.inr i)-edgeSum x (d.stars i)/2)
      ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
        -zeroQCredit d x Y i) :
    pqDeficitArm d x p q (generalPoint d owner rootStar x delta) R i ≤ fixedCoverFloor d x z q i.1 := by
  have hpd := zero_head_P_deficit d x delta hd owner rootStar i hnr hi
  have hqd := mul_le_mul_of_nonneg_left ((le_max_right _ _).trans hguard) hq
  have hfloor := zeroQCredit_cover_floor d hs x z hx hn hcap hm Y hY q hq i hi
  unfold pqDeficitArm
  nlinarith [mul_le_mul_of_nonneg_left hpd hp]

end TSP.Improvements20261105
