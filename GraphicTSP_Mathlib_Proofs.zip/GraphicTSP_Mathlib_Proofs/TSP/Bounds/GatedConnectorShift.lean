import TSP.Improvements20261105.GatedRepresentativeShift
import TSP.Improvements20261105.GatedCollectorClosure

/-! Raise the complete subtree below a receiving prefix, then close shared
collectors. Head selectors and every true cut reward remain unchanged. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def gatedConnectorSide (r : d.tree.Child) : GatedVertex d → ℤ
  | .inl (.inl v) => descendantBit d r v
  | .inl (.inr v) => descendantBit d r v
  | .inr (.inl v) => descendantBit d r v
  | .inr (.inr (v, _)) => descendantBit d r v

noncomputable def shiftConnectorSubtree (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (w : GatedVertex d) : ℤ := p w + gatedConnectorSide d r w

noncomputable def eraseGatePrefix (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) : GatedVertex d → ℤ := closeGatedCollectors d P (shiftConnectorSubtree d p r)

theorem descendantBit_self (r : d.tree.Child) : descendantBit d r r = 1 := by
  simp [descendantBit, show d.tree.Ancestor r r from .refl]

theorem descendantBit_parent_self (r : d.tree.Child) : descendantBit d r (d.tree.parent r) = 0 := by
  unfold descendantBit
  apply if_neg
  intro h
  have hh := d.tree.ancestor_depth_le h
  have hd := d.tree.parent_depth r r.2
  omega

theorem gatedConnectorSide_free_incoming (P : GatePlan d) (r : d.tree.Child)
    (a : GatedArc d) (ha : gatedUpper d P a = none)
    (hex : ∀ v, a ≠ gatedExitTailArc d v ∧ a ≠ gatedExitGateArc d v) :
    gatedConnectorSide d r ((gatedNetwork d P).dst a) -
      gatedConnectorSide d r ((gatedNetwork d P).src a) ≤
      if a = gatedPrefixArc d r then 1 else 0 := by
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · simp [gatedNetwork, gatedConnectorSide]
  · simp [gatedNetwork, gatedConnectorSide]
  · have hh := descendantBit_mono d r (d.anchor_spec b.1).2
    by_cases ho : P.OutsideBack d b <;>
      simpa [gatedNetwork, gatedConnectorSide, ho, sub_nonpos] using hh
  · simp [gatedNetwork, gatedConnectorSide]
  · fin_cases k
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedConnectorSide] using
        le_of_eq (descendantBit_child_difference d r v)
    · simp [gatedUpper] at ha
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedConnectorSide]
    · have hh := descendantBit_mono d r
        (show d.tree.Ancestor (d.tree.parent v) v from .single ⟨v.2, rfl⟩)
      by_cases ho : P.IsReceiver d v <;>
        simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedConnectorSide, ho, sub_nonpos] using hh
    · simp [gatedUpper] at ha
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedConnectorSide]
    · exact ((hex v).1 rfl).elim
    · exact ((hex v).2 rfl).elim

theorem eraseGatePrefix_feasible (P : GatePlan d) (p : GatedVertex d → ℤ)
    (hp : GatedDualFeasible d P p) (r : d.tree.Child) (hr : gatedPrefixDrop d p r = 1) :
    GatedDualFeasible d P (eraseGatePrefix d P p r) := by
  apply closeGatedCollectors_feasible
  intro a ha hex
  have ho := hp a ha
  have hb := gatedConnectorSide_free_incoming d P r a ha hex
  by_cases he : a = gatedPrefixArc d r
  · subst a
    simp only [shiftConnectorSubtree, gatedNetwork, gatedExtraSrc, gatedExtraDst,
      gatedCost, Sum.elim_inl, Sum.elim_inr]
    norm_num [show (0 : Fin 8) ≠ 3 by decide]
    have hdiff : gatedConnectorSide d r (gatedGate d r) -
        gatedConnectorSide d r (gatedCenter d (d.tree.parent r)) = 1 := by
      simp [gatedConnectorSide, descendantBit_self, descendantBit_parent_self]
    dsimp [gatedPrefixDrop] at hr
    omega
  · rw [if_neg he] at hb
    dsimp only [shiftConnectorSubtree]
    omega

theorem eraseGatePrefix_head (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedHeadSelector d (eraseGatePrefix d P p r) v =
      gatedHeadSelector d p v := by
  simp [gatedHeadSelector, eraseGatePrefix, shiftConnectorSubtree, gatedConnectorSide]

theorem eraseGatePrefix_representative (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedRepresentativeDrop d (eraseGatePrefix d P p r) v =
      gatedRepresentativeDrop d p v := by
  simp [gatedRepresentativeDrop, eraseGatePrefix, shiftConnectorSubtree, gatedConnectorSide]

theorem eraseGatePrefix_suffix (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedSuffixDrop d (eraseGatePrefix d P p r) v =
      gatedSuffixDrop d p v := by
  simp [gatedSuffixDrop, eraseGatePrefix, shiftConnectorSubtree, gatedConnectorSide]

theorem eraseGatePrefix_prefix (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) : gatedPrefixDrop d (eraseGatePrefix d P p r) v =
      gatedPrefixDrop d p v - (if v = r then 1 else 0) := by
  have hh := descendantBit_child_difference d r v
  simp only [gatedPrefixDrop, eraseGatePrefix, closeGatedCollectors_center,
    closeGatedCollectors_gate, shiftConnectorSubtree, gatedConnectorSide]
  omega

theorem eraseGatePrefix_reward (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (hr : P.IsReceiver d r) (v : d.tree.Child) :
    gatedTrueReward d P (eraseGatePrefix d P p r) v = gatedTrueReward d P p v := by
  unfold gatedTrueReward
  rw [eraseGatePrefix_suffix, eraseGatePrefix_representative, eraseGatePrefix_prefix]
  by_cases hv : v = r
  · subst v
    simp [hr]
  · simp [hv]

theorem receiving_side_difference (P : GatePlan d) (hP : P.RespectsTree d)
    (r v : d.tree.Child) (hv : P.UsesGate d v) :
    descendantBit d r (P.receiver v) - descendantBit d r v =
      if P.receiver v = r then 1 else 0 := by
  simpa only [hP v hv] using descendantBit_child_difference d r (P.receiver v)

end TSP.Improvements20261105
