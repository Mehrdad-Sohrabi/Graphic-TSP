import TSP.Improvements20261105.GatedDualFormula

/-! A shared collector may be placed exactly at the larger of its two
exit potentials. Its only incoming arc is capacity-bounded. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def closeGatedCollectors (P : GatePlan d) (p : GatedVertex d → ℤ) : GatedVertex d → ℤ
  | .inr (.inr (v, k)) => if k = 3 ∧ P.kind v = .sharedGate then
      max (p (gatedTail d v)) (p (gatedGate d (P.receiver v))) else p (.inr (.inr (v, k)))
  | w => p w

@[simp] theorem closeGatedCollectors_center (P : GatePlan d) (p : GatedVertex d → ℤ) (v : V) :
    closeGatedCollectors d P p (gatedCenter d v) = p (gatedCenter d v) := rfl
@[simp] theorem closeGatedCollectors_tail (P : GatePlan d) (p : GatedVertex d → ℤ) (v : V) :
    closeGatedCollectors d P p (gatedTail d v) = p (gatedTail d v) := rfl
@[simp] theorem closeGatedCollectors_aux (P : GatePlan d) (p : GatedVertex d → ℤ) (v : d.tree.Child) :
    closeGatedCollectors d P p (gatedAux d v) = p (gatedAux d v) := rfl
@[simp] theorem closeGatedCollectors_head (P : GatePlan d) (p : GatedVertex d → ℤ) (v : d.tree.Child) :
    closeGatedCollectors d P p (gatedHead d v) = p (gatedHead d v) := by simp [closeGatedCollectors]
@[simp] theorem closeGatedCollectors_gate (P : GatePlan d) (p : GatedVertex d → ℤ) (v : d.tree.Child) :
    closeGatedCollectors d P p (gatedGate d v) = p (gatedGate d v) := by simp [closeGatedCollectors]
@[simp] theorem closeGatedCollectors_outside (P : GatePlan d) (p : GatedVertex d → ℤ) (v : d.tree.Child) :
    closeGatedCollectors d P p (gatedOutside d v) = p (gatedOutside d v) := by simp [closeGatedCollectors]

theorem closeGatedCollectors_shared (P : GatePlan d) (p : GatedVertex d → ℤ)
    (v : d.tree.Child) (hv : P.kind v = .sharedGate) :
    closeGatedCollectors d P p (gatedCollector d v) =
      max (p (gatedTail d v)) (p (gatedGate d (P.receiver v))) := by
  simp [closeGatedCollectors, hv]

theorem closeGatedCollectors_feasible (P : GatePlan d) (p : GatedVertex d → ℤ)
    (hp : ∀ a, gatedUpper d P a = none →
      (∀ v, a ≠ gatedExitTailArc d v ∧ a ≠ gatedExitGateArc d v) →
      p ((gatedNetwork d P).dst a) - p ((gatedNetwork d P).src a) ≤ (gatedCost d a : ℤ)) :
    GatedDualFeasible d P (closeGatedCollectors d P p) := by
  intro a ha
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · simpa [gatedNetwork, gatedCost] using hp (gatedSuffixArc d v) ha (by intro; simp)
  · simpa [gatedNetwork, gatedCost] using hp (gatedRepArc d v) ha (by intro; simp)
  · have hh := hp (gatedBackArc d b) ha (by intro; simp)
    by_cases ho : P.OutsideBack d b <;> simpa [gatedNetwork, gatedCost, ho] using hh
  · simpa [gatedNetwork, gatedCost] using hp (gatedTailArc d v) ha (by intro; simp)
  · fin_cases k
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost] using
        hp (gatedPrefixArc d v) ha (by intro; simp)
    · simp [gatedUpper] at ha
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost] using
        hp (gatedReverseArc d v) ha (by intro; simp)
    · have hh := hp (gatedPaidArc d v) ha (by intro; simp)
      by_cases ho : P.IsReceiver d v <;>
        simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, ho] using hh
    · simp [gatedUpper] at ha
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost] using
        hp (gatedFeedArc d v) ha (by intro; simp)
    · have hk : P.kind v = .sharedGate := by simpa [gatedUpper] using ha
      simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost,
        closeGatedCollectors, hk, sub_nonpos] using
        le_max_left (p (gatedTail d v)) (p (gatedGate d (P.receiver v)))
    · have hk : P.kind v = .sharedGate := by simpa [gatedUpper] using ha
      simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost,
        closeGatedCollectors, hk, sub_nonpos] using
        le_max_right (p (gatedTail d v)) (p (gatedGate d (P.receiver v)))

theorem gated_dual_collector_exits {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) (hv : P.kind v = .sharedGate) :
    max (p (gatedTail d v)) (p (gatedGate d (P.receiver v))) ≤ p (gatedCollector d v) := by
  have ht := hp (gatedExitTailArc d v) (by simp [gatedUpper, hv])
  have hg := hp (gatedExitGateArc d v) (by simp [gatedUpper, hv])
  simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, hv] at ht hg
  exact max_le ht hg

theorem closeGatedCollectors_original_feasible (P : GatePlan d) (p : GatedVertex d → ℤ)
    (hp : GatedDualFeasible d P p) : GatedDualFeasible d P (closeGatedCollectors d P p) :=
  closeGatedCollectors_feasible d P p (fun a ha _ => hp a ha)

@[simp] theorem closeGatedCollectors_headSelector (P : GatePlan d) (p : GatedVertex d → ℤ)
    (v : d.tree.Child) : gatedHeadSelector d (closeGatedCollectors d P p) v =
      gatedHeadSelector d p v := by simp [gatedHeadSelector]

@[simp] theorem closeGatedCollectors_trueReward (P : GatePlan d) (p : GatedVertex d → ℤ)
    (v : d.tree.Child) : gatedTrueReward d P (closeGatedCollectors d P p) v =
      gatedTrueReward d P p v := by
  simp [gatedTrueReward, gatedPrefixDrop, gatedSuffixDrop, gatedRepresentativeDrop]

theorem closeGatedCollectors_penalty_le (P : GatePlan d) (p : GatedVertex d → ℤ)
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    gatedBypassPenalty d P (closeGatedCollectors d P p) v ≤ gatedBypassPenalty d P p v := by
  cases hk : P.kind v <;>
    simp [gatedBypassPenalty, gatedBypassTarget, gatedBypassSource, hk, closeGatedCollectors]
  have hh := gated_dual_collector_exits d hp v hk
  have ht := (le_max_left _ _).trans hh
  have hg := (le_max_right _ _).trans hh
  rcases le_total (p (gatedHead d v)) (p (gatedCollector d v)) with h | h
  · exact Or.inl ⟨⟨ht, hg⟩, h⟩
  · exact Or.inr ⟨ht.trans h, hg.trans h⟩

end TSP.Improvements20261105
