import TSP.Improvements20261105.ActualHighQFamilyPayment
import TSP.Improvements20261105.SelectedHighQFamilyOwnership
import TSP.Improvements20261105.ActualHighQGroupPayment

/-! The actual local high-q proofs sum with each original back budget
appearing in only one group. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem canonical_selected_high_q_family_payment
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (a : GatedDrops d)
    (ha : a.Admissible d (fixedGatePlan d x)) :
    (∑ k ∈ a.selectedHighQHeads d x z C,
      currentSelectedHeadCost d x z C owner rootStar R eligible T a.head k) ≤
      4*(∑ k ∈ a.selectedHighQHeads d x z C, (((d).backGroup k.1).card:ℝ)) := by
  exact actual_high_q_family_payment G x z hs hc root hx hn hcap hm hz hzx C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero eligible T a.head (a.head_binary d ha)
    (a.selectedHighQOwners d x z C)
    (fun i hi => (Finset.mem_filter.mp hi).2.1)
    (fun i hi => (Finset.mem_filter.mp hi).2.2.1)
    (fun i hi => (Finset.mem_filter.mp hi).2.2.2.1)

end TSP.Improvements20261105
