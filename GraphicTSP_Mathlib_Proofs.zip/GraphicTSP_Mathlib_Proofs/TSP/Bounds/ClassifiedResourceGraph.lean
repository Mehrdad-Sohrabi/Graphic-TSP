import TSP.Improvements20261105.ClassifiedGeometry
import TSP.Improvements20261105.ResourceMatching

/-! Actual original edges joining two classified minor blocks. The resource
graph keeps original centers as vertices (unclassified centers are isolated),
so its looplessness and half-degree bound are proved directly from G and x. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def internalResourceEdges {G : Graph V E} (d : DFSData G) (x : E → ℝ) : Finset E :=
  Finset.univ.filter (fun e => e ∈ minorBoundary d x (G.src e) ∧ e ∈ minorBoundary d x (G.dst e))

noncomputable def internalResourceGraph {G : Graph V E} (d : DFSData G) (x : E → ℝ) :
    Graph V (internalResourceEdges d x) := G.restrictTo (internalResourceEdges d x)

theorem internal_resource_incidence {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (u : V) (e : E) (he : e ∈ internalResourceEdges d x) (hi : G.incident u e) :
    e ∈ minorBoundary d x u := by
  have hh := (Finset.mem_filter.mp he).2
  rcases hi with hs | hd
  · simpa [hs] using hh.1
  · simpa [hd] using hh.2

theorem internal_resource_cut_subset {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (u : V) : G.cut {u} ∩ internalResourceEdges d x ⊆ minorBoundary d x u := by
  intro e he
  exact internal_resource_incidence d x u e (Finset.mem_inter.mp he).2
    ((loopless_incident_iff_cut G hsimple.1 u e).mpr (Finset.mem_inter.mp he).1)

theorem internal_resource_degree_lt_half {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : ∀ e, 0 ≤ x e) (u : V) :
    (internalResourceGraph d x).degree (fun e => x e.1 / 2) u < 1 / 2 := by
  have hloop : ∀ e, (internalResourceGraph d x).src e ≠ (internalResourceGraph d x).dst e :=
    fun e => hsimple.1 e.1
  rw [loopless_degree_eq_cut _ hloop]
  change edgeSum (restrictEdgeVector (internalResourceEdges d x) (fun e => x e / 2))
    ((G.restrictTo (internalResourceEdges d x)).cut {u}) < _
  rw [restrictEdgeVector_edgeSum, includeEdges_restrict_cut]
  have hsum : edgeSum x (G.cut {u} ∩ internalResourceEdges d x) ≤ edgeSum x (minorBoundary d x u) :=
    Finset.sum_le_sum_of_subset_of_nonneg (internal_resource_cut_subset d hsimple x u)
      (fun e _ _ => hx e)
  have hh := minorBoundary_mass_lt_one d hsimple x u
  simp only [edgeSum, ← Finset.sum_div]
  change edgeSum x (G.cut {u} ∩ internalResourceEdges d x) / 2 < _
  linarith

/-- A single fixed distribution simultaneously realizes every internal
original marginal x_e/2, and no atom uses two internal edges at one block. -/
theorem classified_resource_distribution {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : ∀ e, 0 ≤ x e) :
    ∃ (I : Type) (_ : Fintype I) (w : I → ℝ) (J : I → Finset (internalResourceEdges d x)),
      (∀ i, 0 ≤ w i) ∧ (∑ i, w i = 1) ∧
      (∀ i, Chapter02.IsBMatching (internalResourceGraph d x) (fun _ => 1) (J i)) ∧
      ∀ e, ∑ i, w i * incidence (J i) e = x e.1 / 2 := by
  exact resource_matching_distribution (internalResourceGraph d x) (fun e => hsimple.1 e.1)
    (fun e => x e.1 / 2) (fun e => div_nonneg (hx e.1) (by norm_num))
    (fun u => (internal_resource_degree_lt_half d hsimple hx u).le)

end TSP.Improvements20261105
