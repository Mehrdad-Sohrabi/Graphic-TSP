import TSP.Improvements20261105.ClassifiedMarginals

/-! Assemble a feasible classified point from local incidence pairs.
All global consistency and minor-cut obligations are discharged here. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter05 Classical
open scoped BigOperators
variable {V E J : Type} [Fintype V] [Fintype E] [Fintype J]
  [DecidableEq V] [DecidableEq E] [DecidableEq J]

noncomputable def localAnchorMarginal {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) (v : V → J → ℝ) (P : V → J → Finset E)
    (i : ClassifiedStarIndex d x) : ℝ :=
  ∑ j, v (partialCenter d x i) j *
    (if Odd (P (partialCenter d x i) j ∩
      anchorIncidences G (partialStars d x) (partialCenter d x)
        (partialMain d hx hn hcap) i).card then 1 else 0)

theorem exists_classified_point_of_local_pairs {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (T : Finset (V ⊕ ClassifiedStarIndex d x))
    (hT : T ⊆ classifiedMajorSet d hx hn hcap) (hTeven : Even T.card)
    (m : E → ℝ) (hmBox : ∀ e, x e / 2 ≤ m e ∧ m e ≤ 1 - x e / 2)
    (hinternal : ∀ e ∈ internalResourceEdges d x, m e = x e / 2)
    (v : V → J → ℝ) (P : V → J → Finset E)
    (hv : ∀ u j, 0 ≤ v u j) (hvs : ∀ u, ∑ j, v u j = 1)
    (hP : ∀ u j, P u j ⊆ minorBoundary d x u)
    (hone : ∀ u j, (P u j ∩ internalResourceEdges d x).card ≤ 1)
    (hm : ∀ u e, e ∈ minorBoundary d x u → ∑ j, v u j * incidence (P u j) e = m e)
    (hanchor : ∀ i : ClassifiedStarIndex d x,
      classifiedCapacity d hx hn hcap (Sum.inr i) / 2 ≤ localAnchorMarginal d hx hn hcap v P i ∧
      localAnchorMarginal d hx hn hcap v P i ≤ 1 - classifiedCapacity d hx hn hcap (Sum.inr i) / 2) :
    ∃ M : (E ⊕ ClassifiedStarIndex d x) → ℝ,
      BlossomConstraints (classifiedExpansion d x) (targetParity T) M ∧
      (∀ e, classifiedCapacity d hx hn hcap e / 2 ≤ M e ∧ M e ≤ 1 - classifiedCapacity d hx hn hcap e / 2) ∧
      (∀ e, M (Sum.inl e) = m e) ∧
      (∀ i, M (Sum.inr i) = localAnchorMarginal d hx hn hcap v P i) := by
  have hmb : ∀ e, 0 ≤ m e ∧ m e ≤ 1 := by
    intro e
    have hh := hmBox e
    have hx0 := hx.1 e
    constructor <;> linarith
  obtain ⟨K, hK, w, choice, S, hw, hs, hchoice, hpoint, hagree⟩ :=
    exists_global_block_distribution d hsimple hx.1 m hmb hinternal v P hv hvs hP hone hm
  letI := hK
  let M := classifiedLiftMixture d hx hn hcap w S
  have hrep : ∀ e, M (Sum.inl e) = m e := by
    intro e
    exact (classified_lift_representative d hx hn hcap w S e).trans (hpoint e)
  have hanc : ∀ i, M (Sum.inr i) = localAnchorMarginal d hx hn hcap v P i := by
    intro i
    exact classified_lift_connector_marginal d hsimple hx hn hcap w choice S v P hw hchoice hagree i
  have hbox : ∀ e, classifiedCapacity d hx hn hcap e / 2 ≤ M e ∧
      M e ≤ 1 - classifiedCapacity d hx hn hcap e / 2 := by
    intro e
    cases e with
    | inl e => rw [hrep, classified_representative_capacity]; exact hmBox e
    | inr i => rw [hanc]; exact hanchor i
  exact ⟨M, classified_lift_mixture_blossom_of_box d hsimple hx hn hcap T hT hTeven
    w S hw hs hbox, hbox, hrep, hanc⟩

theorem exists_canonical_classified_point {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (T : Finset (V ⊕ ClassifiedStarIndex d x))
    (hT : T ⊆ classifiedMajorSet d hx hn hcap) (hTeven : Even T.card) :
    ∃ M : (E ⊕ ClassifiedStarIndex d x) → ℝ,
      BlossomConstraints (classifiedExpansion d x) (targetParity T) M ∧
      (∀ e, M (Sum.inl e) = x e / 2) ∧
      (∀ i, M (Sum.inr i) = classifiedCapacity d hx hn hcap (Sum.inr i) / 2) := by
  let v := fun u => canonicalPairWeight (minorBoundary d x u) x
  let P := fun u => canonicalPairSet (minorBoundary d x u)
  have hanc : ∀ i, localAnchorMarginal d hx hn hcap v P i =
      classifiedCapacity d hx hn hcap (Sum.inr i) / 2 := by
    intro i
    rw [classified_anchor_capacity_eq_mass d hsimple hx hn hcap i]
    exact canonicalPair_parity_marginal _ _ x
      (classified_anchor_incidences_subset d hsimple hx hn hcap i)
  obtain ⟨M, hM, _, hrep, ha⟩ := exists_classified_point_of_local_pairs d hsimple hx hn hcap T hT hTeven
    (fun e => x e / 2) (fun e => ⟨le_rfl, by have hh := hcap e; linarith⟩)
    (fun _ _ => rfl) v P
    (fun u => canonicalPairWeight_nonneg _ x hx.1 (by
      have hh := minorBoundary_mass_lt_one d hsimple x u; linarith))
    (fun u => canonicalPairWeight_sum _ x)
    (fun u => canonicalPairSet_subset _)
    (fun u j => (Finset.card_le_card Finset.inter_subset_left).trans (canonicalPairSet_card _ j))
    (fun u e he => by simpa only [if_pos he] using canonicalPair_incidence_marginal (minorBoundary d x u) x e)
    (fun i => by
      rw [hanc]
      have hh := (classified_anchor_capacity_bounds d hsimple hx hn hcap i).2
      exact ⟨le_rfl, by linarith⟩)
  exact ⟨M, hM, hrep, fun i => (ha i).trans (hanc i)⟩

end TSP.Improvements20261105
