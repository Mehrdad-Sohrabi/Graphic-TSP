import TSP.Improvements20261105.ProjectedNonfrozenPairSurplus
import TSP.Improvements20261105.ProjectedRemainingLeafHeadCost
import TSP.Improvements20261105.OneExtraBackResidual
import TSP.Improvements20261105.SinglePairOtherHeads

/-! An actual leaf with exactly one matching pair and exactly one other
original back edge pays its entire fee. Graph cuts, scored-DFS greediness,
and the real guarded points discharge every local scalar premise. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem enlarged_scoredDFS_one_extra_back_leaf_cost
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hYfeasible : Y ∈ projectedFrameworkTwo G (d).centers owner)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : (r : FlowVertex d) ≠ .inl (d).tree.root)
    (hleaf : r ∈ a.headfulLeafComponents d P) (hnotK : (r : FlowVertex d) ∉ a.KLeafRoots d P x z C)
    (hone : (a.matchingPairsAt d P x z C r).card = 1)
    (hextra : (∑ i ∈ a.actualComponentStars d P r \ pairStarHeads d (a.matchingPairsAt d P x z C r),
      ((d).backGroup i.1).card) = 1) :
    (∑ i ∈ a.actualComponentStars d P r, guardedNormalizedHeadCost d x z C owner rootStar R a i)+
      24*(2-componentEntryCoverage d x r) ≤
        4*(∑ i ∈ a.actualComponentStars d P r, (((d).backGroup i.1).card : ℝ))+
          a.componentOwnedError d P x r := by
  have hguardOriginal : ∀ i : (d).StarIndex, edgeSum x ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i := by
    intro i hi
    apply hzero i
    have hrem := (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) i.1).1
    rw [hm i.1]
    linarith only [hi,hrem]
  obtain ⟨p,hp⟩ := Finset.card_eq_one.mp hone
  have hpmem : p ∈ a.matchingPairsAt d P x z C r := by rw [hp]; exact Finset.mem_singleton_self _
  have hpair := (Finset.mem_filter.mp (Finset.mem_filter.mp hpmem).1).2
  have hnf := a.single_matching_pair_nonfrozen d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan r p hpmem hone
  have hcost := scoredDFS_projected_nonfrozen_pair_leaf_surplus G x z hs hc root hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero p.1 p.2 hpair.1 hpair.2.symm hnf
  have hgamma := (survivingExcess_bounds d hs hx hcap p.1.1).2
  have htarget : (1 : ℝ) ≤ ((d).backGroup p.2.1).card := by exact_mod_cast Finset.card_pos.mpr p.2.2
  have hj1 := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.1)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.1)
    (a.head p.1.1) (by exact_mod_cast ha.head_nonneg p.1.1)
  have hj2 := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.2)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R p.2)
    (a.head p.2.1) (by exact_mod_cast ha.head_nonneg p.2.1)
  have hpaircost : guardedNormalizedHeadCost d x z C owner rootStar R a p.1+
      guardedNormalizedHeadCost d x z C owner rootStar R a p.2+
      24*(1-x ((d).treeEdge p.1.1)-survivingExcess d x p.1.1)+(61/5 : ℝ) ≤
        4*(((d).backGroup p.1.1).card+((d).backGroup p.2.1).card : ℝ) := by
    unfold guardedNormalizedHeadCost
    linarith only [hcost,hj1,hj2,htarget]
  have hrest := a.projected_remaining_leaf_head_sum_nonpositive d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero P hP t ht f hf hb ha hcan r hr hleaf hnotK
  have hIeq := a.sourceOtherLeafStars_eq_pair_complement d P r p.1 p.2 hpair.2.symm
  rw [← hp] at hIeq
  have hIcount : (∑ i ∈ a.sourceOtherLeafStars d P r p.1.1, ((d).backGroup i.1).card) = 1 := by
    rwa [hIeq]
  obtain ⟨w,hw,hcw,_⟩ := a.one_extra_back_star d P r p.1.1 hIcount
  have hwcost : guardedNormalizedHeadCost d x z C owner rootStar R a w ≤ 0 := by
    rwa [← hIeq,hw,Finset.sum_singleton] at hrest
  have hout : a.componentOutgoingCuts d P r = ∅ :=
    Finset.not_nonempty_iff_eq_empty.mp (Finset.mem_filter.mp hleaf).2.1
  have heta := (fixedQIncrease_admissible d hs hx hn hcap (fixedPositiveTerminalChildren d x)
    (fixedPositiveTerminalChildren_admissible d x)).2.2.1
  have hresidual := a.one_extra_back_residual d hs P hP t ht f hf hb ha hcan x z hx hn hcap hm C
    (fixedQIncrease d x (fixedPositiveTerminalChildren d x)) heta owner ho rootStar hroot
    Y R hYfeasible hrep hbacks hguardOriginal r hr r.2 hout p.1.1 (C.link_subset hpair.1)
    (Finset.mem_filter.mp hpmem).2 w hw hcw
    (scoredDFS_small_back_greedy G x hs hc root w.1 (by omega)) hwcost
  have hpaid := one_extra_pair_payment _ _ _ _ _ _ hpaircost hresidual
  have hsub : pairStarHeads d (a.matchingPairsAt d P x z C r) ⊆ a.actualComponentStars d P r := by
    simpa only [GatedDrops.matchingPairsForRoots,GatedDrops.componentStarUnion,Finset.singleton_biUnion] using
      a.matchingPairHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan {(r : FlowVertex d)}
  have hJ : a.matchingPairsAt d P x z C r ⊆ fixedMatchingStarPairs d x z C := Finset.filter_subset _ _
  have hcostsum := Finset.sum_sdiff hsub (f := guardedNormalizedHeadCost d x z C owner rootStar R a)
  have hbacksum := Finset.sum_sdiff hsub (f := fun i => (((d).backGroup i.1).card : ℝ))
  have hcostpair := fixedMatchingStarPair_family_sum d x z C _ hJ (guardedNormalizedHeadCost d x z C owner rootStar R a)
  have hbackpair := fixedMatchingStarPair_family_sum d x z C _ hJ (fun i => (((d).backGroup i.1).card : ℝ))
  rw [hp,Finset.sum_singleton] at hcostpair hbackpair
  rw [← hp] at hcostpair hbackpair
  rw [← hIeq,hw,Finset.sum_singleton] at hcostsum hbacksum
  rw [hcw,Nat.cast_one] at hbacksum
  linarith only [hpaid,hcostsum,hbacksum,hcostpair,hbackpair]

end TSP.Improvements20261105
