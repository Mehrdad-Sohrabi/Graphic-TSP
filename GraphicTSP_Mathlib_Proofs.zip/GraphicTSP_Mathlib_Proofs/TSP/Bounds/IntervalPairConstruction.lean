import TSP.Improvements20261105.LocalPairMarginals

/-! Actual local pair distributions for the entire classified external
parent interval. Every marginal and the total probability are proved. -/
namespace TSP.Improvements20261105
open Graph Classical
open scoped BigOperators
variable {E : Type} [Fintype E] [DecidableEq E]

theorem exists_interval_pair_distribution (B : Finset E) (p : E) (hp : p ∈ B)
    (x : E → ℝ) (hx : ∀ e, 0 ≤ x e) (hB : edgeSum x B ≤ 1)
    (t : ℝ) (ht : 0 ≤ t) (htop : t ≤ 1 - x p) :
    ∃ w : PairOutcome E → ℝ,
      (∀ o, 0 ≤ w o) ∧ (∑ o, w o = 1) ∧
      (∀ o, externalPairSet B p o ⊆ B) ∧
      (∀ L : Finset E, p ∉ L → ∀ o, (externalPairSet B p o ∩ L).card ≤ 1) ∧
      (∀ e, ∑ o, w o * incidence (externalPairSet B p o) e =
        if e ∈ B then x e / 2 + (if e = p then t else 0) else 0) ∧
      ((∑ o, w o * (if Odd (externalPairSet B p o).card then 1 else 0)) =
        edgeSum x B / 2 + max (t - (edgeSum x B - x p)) 0) ∧
      (∀ L : Finset E, L ⊆ B → p ∉ L →
        (∑ o, w o * (if Odd (externalPairSet B p o ∩ L).card then 1 else 0)) = edgeSum x L / 2) := by
  have hsplit : edgeSum x (B.erase p) + x p = edgeSum x B := Finset.sum_erase_add B x hp
  have hc : x p + edgeSum x (B.erase p) ≤ 1 := by linarith
  obtain ⟨alpha, beta, a, hab, ha, hout, hcoord, hinc, hmain, htotal, hlower, hupper, hbeta⟩ :=
    external_parent_pair_weights (B.erase p) x hx (x p) t (hx p) hc ht htop
  let w := externalPairWeight B p alpha beta a
  have hm : ∀ e, (∑ o, w o * incidence (externalPairSet B p o) e) =
      if e ∈ B then x e / 2 + (if e = p then t else 0) else 0 := by
    intro e
    rw [externalPair_incidence_marginal B p hp]
    by_cases he : e = p
    · subst e
      simpa only [if_pos rfl, if_pos hp] using hinc
    · by_cases hb : e ∈ B
      · have heA : e ∈ B.erase p := Finset.mem_erase.mpr ⟨he, hb⟩
        simpa only [if_neg he, if_pos heA, if_pos hb, add_zero] using hcoord e
      · simp [he, hb]
  refine ⟨w, externalPairWeight_nonneg B p alpha beta a hab ha htotal,
    externalPairWeight_sum B p alpha beta a, externalPairSet_subset B p hp,
    fun L hpL => externalPairSet_inter_card B L p hpL, hm, ?_, ?_⟩
  · rw [externalPair_main_marginal B p hp, hmain]
    have he : edgeSum x (B.erase p) = edgeSum x B - x p := by linarith
    rw [he]
    congr 1 <;> ring
  · intro L hL hpL
    rw [single_incidence_parity_marginal w (externalPairSet B p)
      (fun e => if e ∈ B then x e / 2 + (if e = p then t else 0) else 0)
      hm L (externalPairSet_inter_card B L p hpL)]
    simp only [edgeSum, Finset.sum_div]
    apply Finset.sum_congr rfl
    intro e he
    have hep : e ≠ p := fun hh => hpL (hh ▸ he)
    simp [hL he, hep]

end TSP.Improvements20261105
