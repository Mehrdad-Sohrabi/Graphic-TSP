import TSP.Improvements20261105.MonotoneRounding

/-! Common-threshold rounding preserves every integer difference constraint.
All positive-part penalties with integer breakpoints have exactly preserved
expectations, even when objective coefficients are real. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Classical
open scoped BigOperators
variable {V : Type} [Fintype V] [DecidableEq V]

noncomputable def roundedPotential (p : V → ℝ) (S : Finset V) (v : V) : ℤ :=
  ⌊p v⌋ + if v ∈ S then 1 else 0

theorem roundedPotential_difference_le (p : V → ℝ) (S : Finset V)
    (hS : UpwardSet (fun v => Int.fract (p v)) S) (u v : V) (c : ℤ)
    (hc : p v - p u ≤ (c : ℝ)) :
    roundedPotential p S v - roundedPotential p S u ≤ c := by
  have hfloor : ⌊p v⌋ ≤ ⌊p u⌋ + c := by
    rw [← Int.floor_add_intCast]
    exact Int.floor_mono (by linarith)
  by_cases hv : v ∈ S <;> by_cases hu : u ∈ S
  · simp only [roundedPotential, if_pos hv, if_pos hu]
    omega
  · have hstrict : ⌊p v⌋ < ⌊p u⌋ + c := by
      apply lt_of_le_of_ne hfloor
      intro heq
      have hfr : Int.fract (p v) ≤ Int.fract (p u) := by
        have heqR : (⌊p v⌋ : ℝ) = (⌊p u⌋ : ℝ) + c := by exact_mod_cast heq
        unfold Int.fract
        linarith
      exact hu (hS v u hv hfr)
    simp only [roundedPotential, if_pos hv, if_neg hu]
    omega
  · simp only [roundedPotential, if_neg hv, if_pos hu]
    omega
  · simp only [roundedPotential, if_neg hv, if_neg hu]
    omega

theorem roundedPotential_difference_ge (p : V → ℝ) (S : Finset V)
    (hS : UpwardSet (fun v => Int.fract (p v)) S) (u v : V) (c : ℤ)
    (hc : (c : ℝ) ≤ p v - p u) :
    c ≤ roundedPotential p S v - roundedPotential p S u := by
  have hh := roundedPotential_difference_le p S hS v u (-c) (by push_cast; linarith)
  omega

theorem roundedPotential_mean {ι : Type} [Fintype ι]
    (p : V → ℝ) (w : ι → ℝ) (S : ι → Finset V) (hsum : ∑ i, w i = 1)
    (hmean : ∀ v, ∑ i, w i * (if v ∈ S i then (1 : ℝ) else 0) = Int.fract (p v)) (v : V) :
    ∑ i, w i * (roundedPotential p (S i) v : ℝ) = p v := by
  have hcast (i : ι) : (roundedPotential p (S i) v : ℝ) =
      (⌊p v⌋ : ℝ) + (if v ∈ S i then 1 else 0) := by
    unfold roundedPotential
    push_cast
    rfl
  simp_rw [hcast, mul_add]
  rw [Finset.sum_add_distrib, ← Finset.sum_mul, hsum, one_mul, hmean]
  unfold Int.fract
  ring

theorem roundedPotential_penalty_mean {ι : Type} [Fintype ι]
    (p : V → ℝ) (w : ι → ℝ) (S : ι → Finset V) (hsum : ∑ i, w i = 1)
    (hS : ∀ i, UpwardSet (fun v => Int.fract (p v)) (S i))
    (hmean : ∀ v, ∑ i, w i * (roundedPotential p (S i) v : ℝ) = p v)
    (u v : V) (c : ℤ) :
    (∑ i, w i * max ((roundedPotential p (S i) v : ℝ) -
      (roundedPotential p (S i) u : ℝ) - c) 0) = max (p v - p u - c) 0 := by
  by_cases hc : p v - p u ≤ (c : ℝ)
  · have hh (i : ι) : max ((roundedPotential p (S i) v : ℝ) -
        (roundedPotential p (S i) u : ℝ) - c) 0 = 0 := by
      apply max_eq_right
      have hr : (roundedPotential p (S i) v : ℝ) -
          (roundedPotential p (S i) u : ℝ) ≤ c := by
        exact_mod_cast roundedPotential_difference_le p (S i) (hS i) u v c hc
      linarith
    simp only [hh, mul_zero, Finset.sum_const_zero, max_eq_right (by linarith : p v - p u - c ≤ 0)]
  · have hh (i : ι) : max ((roundedPotential p (S i) v : ℝ) -
        (roundedPotential p (S i) u : ℝ) - c) 0 =
        (roundedPotential p (S i) v : ℝ) - (roundedPotential p (S i) u : ℝ) - c := by
      apply max_eq_left
      have hr : (c : ℝ) ≤ (roundedPotential p (S i) v : ℝ) -
          (roundedPotential p (S i) u : ℝ) := by
        exact_mod_cast roundedPotential_difference_ge p (S i) (hS i) u v c (le_of_not_ge hc)
      linarith
    simp_rw [hh, mul_sub]
    rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib, hmean, hmean,
      ← Finset.sum_mul, hsum, one_mul, max_eq_left (by linarith : 0 ≤ p v - p u - c)]

theorem finite_integral_potential_rounding (p : V → ℝ) :
    ∃ (ι : Type) (_ : Fintype ι) (w : ι → ℝ) (P : ι → V → ℤ),
      (∀ i, 0 ≤ w i) ∧ (∑ i, w i = 1) ∧
      (∀ i u v (c : ℤ), p v - p u ≤ (c : ℝ) → P i v - P i u ≤ c) ∧
      (∀ v, ∑ i, w i * (P i v : ℝ) = p v) ∧
      (∀ u v (c : ℤ), (∑ i, w i * max ((P i v : ℝ) - (P i u : ℝ) - c) 0) =
        max (p v - p u - c) 0) := by
  obtain ⟨ι, hi, w, S, hw, hsum, hS, hm⟩ := finite_monotone_rounding
    (fun v => Int.fract (p v)) (fun v => ⟨Int.fract_nonneg _, le_of_lt (Int.fract_lt_one _)⟩)
  have hpmean := roundedPotential_mean p w S hsum hm
  exact ⟨ι, hi, w, fun i => roundedPotential p (S i), hw, hsum,
    fun i u v c hc => roundedPotential_difference_le p (S i) (hS i) u v c hc,
    hpmean, roundedPotential_penalty_mean p w S hsum hS hpmean⟩

end TSP.Improvements20261105
