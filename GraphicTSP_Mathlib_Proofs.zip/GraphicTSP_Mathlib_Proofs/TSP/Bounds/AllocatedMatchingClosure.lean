import TSP.Improvements20261105.MatchingAllocationClosure

/-! Closure of the completed leaf allocation under actual matching pairs. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.componentStarUnion_same_membership (a : GatedDrops d) (P : GatePlan d)
    (L : Finset (FlowVertex d)) (i j : d.StarIndex)
    (he : a.component d P (.inr i.1)=a.component d P (.inr j.1)) :
    i ∈ a.componentStarUnion d P L ↔ j ∈ a.componentStarUnion d P L := by
  simp only [componentStarUnion,Finset.mem_biUnion,actualComponentStars,Finset.mem_filter,Finset.mem_univ,true_and,he]

theorem KStarHeads_not_matched (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (J : Finset (d.StarIndex × d.StarIndex)) (hJ : J ⊆ KUnmatchedStarPairs d x z C)
    (i : d.StarIndex) (hi : i.1 ∈ matchingEndpoints id (unaryNext d) C.matching) :
    i ∉ pairStarHeads d J := by
  intro hh
  have hK : i.1 ∈ matchingEndpoints id (unaryNext d) (KUnmatchedOrigins d x z (415/2) (704/5) 60 C) := by
    rcases Finset.mem_union.mp hh with hh | hh
    · obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hh
      have hm := (Finset.mem_filter.mp (hJ hp)).2.1
      simpa only [matchingEndpoints,Finset.image_id] using (Finset.mem_union.mpr (Or.inl hm) :
        p.1.1 ∈ KUnmatchedOrigins d x z (415/2) (704/5) 60 C ∪
          (KUnmatchedOrigins d x z (415/2) (704/5) 60 C).image (unaryNext d))
    · obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hh
      have hm := (Finset.mem_filter.mp (hJ hp)).2
      simpa only [matchingEndpoints,Finset.image_id] using (Finset.mem_union.mpr (Or.inr
        (Finset.mem_image.mpr ⟨p.1.1,hm.1,hm.2⟩)) :
        p.2.1 ∈ KUnmatchedOrigins d x z (415/2) (704/5) 60 C ∪
          (KUnmatchedOrigins d x z (415/2) (704/5) 60 C).image (unaryNext d))
  exact Finset.disjoint_left.mp (KUnmatchedOrigins_no_matching_budget d x z (415/2) (704/5) 60 C) hK hi

theorem GatedDrops.allocatedLeafHeads_matching_closed (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (p : d.StarIndex × d.StarIndex) (hp : p ∈ fixedMatchingStarPairs d x z C) :
    p.1 ∈ a.allocatedLeafHeads d P x z C ↔ p.2 ∈ a.allocatedLeafHeads d P x z C := by
  have hpair := (Finset.mem_filter.mp hp).2
  have hsC := fixed_pair_same_component d hs x z hx hn hcap hm (415/2) (704/5) C
    P hP t ht f hf hb a ha hcan p.1.1 hpair.1
  rw [hpair.2] at hsC
  have hcomp : a.component d P (.inr p.1.1)=a.component d P (.inr p.2.1) := congrArg Subtype.val hsC
  have hu (L : Finset (FlowVertex d)) : p.1 ∈ a.componentStarUnion d P L ↔ p.2 ∈ a.componentStarUnion d P L :=
    a.componentStarUnion_same_membership d P L p.1 p.2 hcomp
  have hpaid : p.1 ∈ a.paidLeafHeads d P x ↔ p.2 ∈ a.paidLeafHeads d P x := by
    rw [a.paidLeafHeads_eq_starUnion d P x]
    exact hu _
  have hm1 : p.1.1 ∈ matchingEndpoints id (unaryNext d) C.matching := by
    simp only [matchingEndpoints,Finset.image_id]
    exact Finset.mem_union.mpr (Or.inl hpair.1)
  have hm2 : p.2.1 ∈ matchingEndpoints id (unaryNext d) C.matching := by
    simp only [matchingEndpoints,Finset.image_id]
    exact Finset.mem_union.mpr (Or.inr (Finset.mem_image.mpr ⟨p.1.1,hpair.1,hpair.2⟩))
  have hk1 := KStarHeads_not_matched d x z C _ (a.KLeafPairs_subset d P x z C) p.1 hm1
  have hk2 := KStarHeads_not_matched d x z C _ (a.KLeafPairs_subset d P x z C) p.2 hm2
  have hk : p.1 ∈ pairStarHeads d (a.KLeafPairs d P x z C) ↔ p.2 ∈ pairStarHeads d (a.KLeafPairs d P x z C) := iff_of_false hk1 hk2
  have hmat : p.1 ∈ pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)) ↔
      p.2 ∈ pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C)) :=
    (fixedMatchingStarPairs_first_mem_heads d x z C _ (a.matchingPairsForRoots_subset d P x z C _) p hp).trans
      (fixedMatchingStarPairs_second_mem_heads d x z C _ (a.matchingPairsForRoots_subset d P x z C _) p hp).symm
  simpa only [allocatedLeafHeads,Finset.mem_union] using
    (or_congr (or_congr (or_congr (or_congr (or_congr (or_congr (or_congr (or_congr hpaid hk) hmat)
      (hu (a.largeRemainingLeafRoots d P x z C))) (hu (a.solePairLeafRoots d P x z C)))
      (hu (a.oneExtraBackLeafRoots d P x z C))) (hu (a.twoBackSingleLeafRoots d P x z C)))
      (hu (a.twoBackTwoHeadLeafRoots d P x z C))) (hu (a.noPairLeafRoots d P x z C)))

end TSP.Improvements20261105
