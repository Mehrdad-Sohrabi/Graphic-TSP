import TSP.Improvements20261105.RefinedIncidenceCharge
import TSP.Improvements20261105.MatchingStarPairOwners

/-! The raw critical upper bound in a both-selected actual matching pair.
The fixed critical test is unchanged; multiselected membership follows
from the actual canonical components. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem refined_incidence_raw_of_critical_refined (x z : E → ℝ)
    (eligible T : Finset d.tree.Child) (s : d.tree.Child)
    (he : s ∈ eligible) (ht : s ∈ fixedCriticalHeads d x z eligible → s ∈ T)
    (hn : 1 ≤ (d.backGroup s).card) (hmass : edgeSum z (d.backGroup s) ≤ 2) :
    refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s ≤ rawCriticalIncidence d x z s := by
  have hmem : s ∈ fixedCriticalHeads d x z eligible ↔ rawCriticalIncidence d x z s ≤ noncriticalIncidence d z s := by
    simp only [fixedCriticalHeads,Finset.mem_filter,he,true_and]
    exact critical_floor_membership_eq_raw d x z s hn hmass
  by_cases hc : s ∈ fixedCriticalHeads d x z eligible
  · simp only [refinedIncidenceCharge,if_pos hc,if_pos (ht hc),le_refl]
  · rw [refinedIncidenceCharge_noncritical d x z (fixedCriticalHeads d x z eligible) T s hc]
    exact le_of_not_ge (fun hh => hc (hmem.mpr hh))

theorem canonical_both_selected_pair_raw_incidence
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (eligible T : Finset d.tree.Child)
    (hTall : ∀ s ∈ fixedCriticalHeads d x z eligible,
      2 ≤ (a.componentHeads d P (a.headComponent d P s)).card → s ∈ T)
    (i j : d.StarIndex) (hi : i.1 ∈ C.matching) (hj : j.1=unaryNext d i.1)
    (hsi : a.head i.1=1) (hsj : a.head j.1=1)
    (hmi : edgeSum z (d.backGroup i.1) ≤ 2) (hmj : edgeSum z (d.backGroup j.1) ≤ 2) :
    (i.1 ∈ eligible → refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T i.1 ≤ rawCriticalIncidence d x z i.1) ∧
    (j.1 ∈ eligible → refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T j.1 ≤ rawCriticalIncidence d x z j.1) := by
  have hpar : d.tree.parent j.1=(i.1 : V) := by rw [hj]; exact projectionLinks_parent d x i.1 (C.link_subset hi)
  have htwo := canonical_selected_link_two_heads d P hP t ht f hf hb a ha hcan i.1 j.1 hpar hsi hsj
  have hsame := canonical_selected_link_same_component d P hP t ht f hf hb a ha hcan i.1 j.1 hpar hsi hsj
  constructor
  · intro hel
    exact refined_incidence_raw_of_critical_refined d x z eligible T i.1 hel
      (fun hc => hTall i.1 hc htwo) (Finset.card_pos.mpr i.2) hmi
  · intro hel
    apply refined_incidence_raw_of_critical_refined d x z eligible T j.1 hel
      (fun hc => hTall j.1 hc ?_) (Finset.card_pos.mpr j.2) hmj
    rwa [← hsame]

end TSP.Improvements20261105
