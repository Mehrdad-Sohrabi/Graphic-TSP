import TSP.Chapter05.GreedyCertificate

/-! DFS with a score that may depend on the current search state. This supplies
the structural search needed for the recovered scored construction. It does
not yet establish that the proposed gates give the required role estimates. -/
namespace TSP.Improvements20261105.AdaptiveDFS
open Graph Chapter05 Chapter05.GreedySearch
variable {V E W : Type} [Fintype V] [Fintype E] [DecidableEq V]
  [LinearOrder E] [LinearOrder W]

/-- Unlike the older fixed-weight search, the score is evaluated afresh at
each decision and can inspect the active stack and the current visited set. -/
def run [Fintype V] (G : Graph V E) (score : State V E → V → E → W) (s : State V E) : State V E :=
  match hs : s.stack with
  | [] => s
  | u :: tail =>
    match he : pickEdge G (score s u) s.seen u with
    | none => run G score {s with stack := tail}
    | some e => run G score (push G s u e)
termination_by remaining s
decreasing_by
  · simp only [remaining, hs, List.length_cons]
    omega
  · exact push_decreases G s u e (pickEdge_mem G (score s u) s.seen u he)

theorem run_of_nil (G : Graph V E) (score : State V E → V → E → W) (s : State V E)
    (hs : s.stack = []) : run G score s = s := by
  rw [run, hs]

theorem run_of_none (G : Graph V E) (score : State V E → V → E → W) (s : State V E)
    (u : V) (tail : List V) (hs : s.stack = u :: tail)
    (he : pickEdge G (score s u) s.seen u = none) :
    run G score s = run G score {s with stack := tail} := by
  rw [run, hs]
  dsimp only
  rw [he]

theorem run_of_some (G : Graph V E) (score : State V E → V → E → W) (s : State V E)
    (u : V) (tail : List V) (hs : s.stack = u :: tail)
    (e : E) (he : pickEdge G (score s u) s.seen u = some e) :
    run G score s = run G score (push G s u e) := by
  rw [run, hs]
  dsimp only
  rw [he]

theorem run_empty_stack (G : Graph V E) (score : State V E → V → E → W) (s : State V E) :
    (run G score s).stack = [] := by
  induction s using run.induct G score with
  | case1 s hs => simpa only [run_of_nil G score s hs] using hs
  | case2 s u tail hs he ih => simpa only [run_of_none G score s u tail hs he] using ih
  | case3 s u tail hs e he ih => simpa only [run_of_some G score s u tail hs e he] using ih

theorem run_seen_mono (G : Graph V E) (score : State V E → V → E → W) (s : State V E) :
    s.seen ⊆ (run G score s).seen := by
  induction s using run.induct G score with
  | case1 s hs => rw [run_of_nil G score s hs]
  | case2 s u tail hs he ih => simpa only [run_of_none G score s u tail hs he] using ih
  | case3 s u tail hs e he ih =>
    rw [run_of_some G score s u tail hs e he]
    exact (Finset.subset_insert _ _).trans ih

def Invariants (G : Graph V E) (root : V) (s : State V E) : Prop :=
  ClosedFinished G s ∧ TreeInvariant G root s ∧ StackPath root s s.stack ∧ SeenComparable G root s

theorem run_invariants (G : Graph V E) (score : State V E → V → E → W)
    (root : V) (s : State V E) (hinv : Invariants G root s) :
    Invariants G root (run G score s) := by
  induction s using run.induct G score with
  | case1 s hs => simpa only [run_of_nil G score s hs] using hinv
  | case2 s u tail hs he ih =>
    rw [run_of_none G score s u tail hs he]
    obtain ⟨hc, ht, hp, hcomp⟩ := hinv
    exact ih ⟨pop_closed G s u tail hs hc ((pickEdge_none G (score s u) s.seen u).mp he),
      pop_tree G root s tail ht, pop_stack root s u tail hs hp, pop_comparable G root s tail hcomp⟩
  | case3 s u tail hs e he ih =>
    rw [run_of_some G score s u tail hs e he]
    obtain ⟨hc, ht, hp, hcomp⟩ := hinv
    have hu := hc.1 u (by rw [hs]; exact List.mem_cons_self)
    have hem := pickEdge_mem G (score s u) s.seen u he
    exact ih ⟨push_closed G s u e hc, push_tree G root s u e ht hu hem,
      push_stack G root s u tail e hs hc ht hp hem,
      push_comparable G root s u tail e hs hc ht hp hcomp hem⟩

theorem initial_invariants (G : Graph V E) (root : V) :
    Invariants G root (initial root) :=
  ⟨initial_closed G root, initial_tree G root, StackPath.single, initial_comparable G root⟩

theorem run_initial_spanning (G : Graph V E) (score : State V E → V → E → W)
    (hconn : G.Connected) (root : V) : (run G score (initial root)).seen = Finset.univ := by
  let s := run G score (initial (E := E) root)
  have hs : ClosedFinished G s := (run_invariants G score root _ (initial_invariants G root)).1
  have he : s.stack = [] := run_empty_stack G score _
  have hr : root ∈ s.seen := run_seen_mono G score _ (Finset.mem_singleton_self root)
  have hall : ∀ v, Relation.ReflTransGen (G.AdjOn Finset.univ) root v → v ∈ s.seen := by
    intro v hv
    induction hv with
    | refl => exact hr
    | @tail a b hab hlast ih => exact closed_seen_adj G s hs he ih hlast
  exact Finset.eq_univ_of_forall (fun v => hall v (hconn.2 root v))

/-- The actual state-dependent search produces a spanning DFS with the chosen
root. Its edge choices are those in `run`, not arbitrary DFS witnesses. -/
noncomputable def searchDFS (G : Graph V E) (score : State V E → V → E → W)
    (hsimple : G.IsSimple) (hconn : G.Connected) (root : V) : DFSData G :=
  let s := run G score (initial root)
  let hi := run_invariants G score root _ (initial_invariants G root)
  toDFSData G hsimple root s hi.2.1 (run_initial_spanning G score hconn root) hi.2.2.2

theorem searchDFS_root (G : Graph V E) (score : State V E → V → E → W)
    (hsimple : G.IsSimple) (hconn : G.Connected) (root : V) :
    (searchDFS G score hsimple hconn root).tree.root = root := rfl

end TSP.Improvements20261105.AdaptiveDFS
