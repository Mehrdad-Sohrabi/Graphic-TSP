import TSP.Improvements20261105.NormalizedFixedQ
import TSP.Improvements20261105.ProjectedCoverFloors

/-! Every claimed cover floor dominates the actual normalized Q connector.
Projected-zero negative floors are used only for full unary overrides. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem fixedQ_connector_floor_bound (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (Q : ℝ) (hQ : 0 ≤ Q) (i : d.StarIndex) :
    Q * (Y (.inr i) - edgeSum x (d.stars i) / 2) ≤ fixedCoverFloor d x z Q i.1 := by
  have hnon := mul_nonpos_of_nonneg_of_nonpos hQ
    (fixedQ_connector_nonpositive d hs x hx hn hcap Y hY i)
  have hxi := degreeExcess_nonnegative G hx hn (d.centers i)
  unfold fixedCoverFloor
  split_ifs with hr hev hp ht
  · exact hnon
  · have hfull := surviving_full_removal_identity d hs x z hx hn _ hm i.1 hp
    have hheavy : 1 < x (d.treeEdge i.1) + edgeSum z (d.backGroup i.1) := by
      have hq := hx.1 (d.treeEdge i.1); linarith
    have hnorm := fixedQ_full_removal_connector d hs x z hx hn hcap Y hY i hfull hheavy
    have hev' : Even (G.intDegree d.treeEdges (d.centers i)) := hev
    rw [if_pos hev'] at hnorm
    have he := fixed_projected_excess_eq d hs x z hx hn _ hm i.1
    rw [max_eq_left (by linarith : 0 ≤ edgeSum z (d.backGroup i.1) - 1)] at he
    have heta := (preliminaryQIncrease_bounds d hs hx hcap i.1).2.2.2
    have hle : Y (.inr i) - edgeSum x (d.stars i) / 2 ≤
        -(x (d.treeEdge i.1) + preliminaryQIncrease d x i.1) := by linarith
    simpa only [mul_neg, neg_mul] using mul_le_mul_of_nonneg_left hle hQ
  · have hfull := override_full_removal_identity d hs x z hm i.1 ht
    have hheavy := override_projected_heavy d hs x z hm i.1 ht
    have hnorm := fixedQ_full_removal_connector d hs x z hx hn hcap Y hY i hfull hheavy
    have hev' : Even (G.intDegree d.treeEdges (d.centers i)) := hev
    rw [if_pos hev'] at hnorm
    rw [max_eq_left (by linarith : 0 ≤ x (d.treeEdge i.1) + edgeSum z (d.backGroup i.1) - 1)]
    have hle : Y (.inr i) - edgeSum x (d.stars i) / 2 ≤
        -(x (d.treeEdge i.1) + edgeSum z (d.backGroup i.1) - 1) := by linarith
    simpa only [mul_neg, neg_mul] using mul_le_mul_of_nonneg_left hle hQ
  · exact hnon
  · exact hnon

end TSP.Improvements20261105
