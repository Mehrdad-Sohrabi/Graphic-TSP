import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t6_r3_cap_cell_40
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (31/96 : ℝ) ≤ q) (hqu : q ≤ (17/48 : ℝ))
    (hzl : (11/24 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (17/48 : ℝ) (10/17 : ℝ) (107/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9983/34:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (13739/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (3650647/12274:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (13739/170:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (3685759/12274:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (5369259/61370:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (3732543/12274:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (5369259/61370:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_41
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (17/48 : ℝ) ≤ q) (hqu : q ≤ (5/12 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2987/10:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (859/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1092067/3610:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (859/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (1097083/3610:ℝ)*hql + (511/2:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (65775/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (1110843/3610:ℝ)*hql + (187223/722:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (65775/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_42
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (5/12 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (23757/40:ℝ)*hql + (21597/40:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (13297/40:ℝ)*hmass
  · linear_combination (8617557/14440:ℝ)*hql + (7837797/14440:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4841497/14440:ℝ)*hmass
  · linear_combination (8606237/14440:ℝ)*hql + (21597/40:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (13297/40:ℝ)*hmass
  · linear_combination (8647517/14440:ℝ)*hql + (7837797/14440:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4841497/14440:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_43
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/6 : ℝ) ≤ q) (hqu : q ≤ (7/24 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (7/24 : ℝ) (2/7 : ℝ) (5/14 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hzl + (4093/98:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (7789/245:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (1488059/35378:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (2785614/88445:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hzl + (1521917/35378:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (3476989/88445:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (1532403/35378:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (3450774/88445:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_44
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (7/24 : ℝ) ≤ q) (hqu : q ≤ (5/12 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (7/12 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (7/12 : ℝ) (8/7 : ℝ) (79/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (16435096/79345:ℝ)*hql + (3625/14:ℝ)*hzl + (2861240/15869:ℝ)*ho0 + (33792/2267:ℝ)*hgap + (1408/2267:ℝ)*hS + (1/1:ℝ)*hI + (859/2267:ℝ)*hsource + (1/1:ℝ)*hR + (360/7:ℝ)*hmass
  · linear_combination (6013820196/28643545:ℝ)*hql + (1322873/5054:ℝ)*hzl + (1049057748/5728709:ℝ)*ho0 + (33792/2267:ℝ)*hgap + (1408/2267:ℝ)*hS + (1/1:ℝ)*hI + (859/2267:ℝ)*hsource + (1/1:ℝ)*hR + (137084/2527:ℝ)*hmass
  · linear_combination (6059394584/29300705:ℝ)*hql + (3625/14:ℝ)*hzl + (1039667000/5860141:ℝ)*ho0 + (12198912/837163:ℝ)*hgap + (508288/837163:ℝ)*hS + (1/1:ℝ)*hI + (328875/837163:ℝ)*hsource + (1/1:ℝ)*hR + (360/7:ℝ)*hmass
  · linear_combination (2217261190884/10577554505:ℝ)*hql + (1322873/5054:ℝ)*hzl + (381283736212/2115510901:ℝ)*ho0 + (12198912/837163:ℝ)*hgap + (508288/837163:ℝ)*hS + (1/1:ℝ)*hI + (328875/837163:ℝ)*hsource + (1/1:ℝ)*hR + (137084/2527:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_45
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (7/24 : ℝ) ≤ q) (hqu : q ≤ (5/12 : ℝ))
    (hzl : (7/12 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2377018/11335:ℝ)*hql + (523/2:ℝ)*hzl + (414578/2267:ℝ)*ho0 + (33792/2267:ℝ)*hgap + (1408/2267:ℝ)*hS + (1/1:ℝ)*hI + (859/2267:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (866593413/4091935:ℝ)*hql + (190301/722:ℝ)*hzl + (151360641/818387:ℝ)*ho0 + (33792/2267:ℝ)*hgap + (1408/2267:ℝ)*hS + (1/1:ℝ)*hI + (859/2267:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (876391322/4185815:ℝ)*hql + (523/2:ℝ)*hzl + (150676562/837163:ℝ)*ho0 + (12198912/837163:ℝ)*hgap + (508288/837163:ℝ)*hS + (1/1:ℝ)*hI + (328875/837163:ℝ)*hsource + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (319512442677/1511079215:ℝ)*hql + (190301/722:ℝ)*hzl + (55021273969/302215843:ℝ)*ho0 + (12198912/837163:ℝ)*hgap + (508288/837163:ℝ)*hS + (1/1:ℝ)*hI + (328875/837163:ℝ)*hsource + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_46
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (1/6 : ℝ) ≤ q) (hqu : q ≤ (5/12 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1208912/33405:ℝ)*hem + (7335728/33405:ℝ)*ho0 + (41728/2227:ℝ)*hgap + (5216/6681:ℝ)*hS + (1/1:ℝ)*hI + (1465/6681:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (146176692/4019735:ℝ)*hem + (887528364/4019735:ℝ)*ho0 + (15078720/803947:ℝ)*hgap + (628280/803947:ℝ)*hS + (1/1:ℝ)*hI + (175667/803947:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (445730128/12340845:ℝ)*hem + (2664420272/12340845:ℝ)*ho0 + (15063808/822723:ℝ)*hgap + (1882976/2468169:ℝ)*hS + (1/1:ℝ)*hI + (585193/2468169:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (53896270708/1485015015:ℝ)*hem + (322384841036/1485015015:ℝ)*ho0 + (5026240/274241:ℝ)*hgap + (628280/822723:ℝ)*hS + (1/1:ℝ)*hI + (194443/822723:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t6_r3_cap_cell_47
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (91/100 : ℝ))
    (hql : (5/12 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3337/5:ℝ)*hql + (2651/10:ℝ)*hzl + (3067/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (1206521/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (1109051/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (475/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass
  · linear_combination (1208402/1805:ℝ)*hql + (2651/10:ℝ)*hzl + (3067/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (1210266/1805:ℝ)*hql + (960739/3610:ℝ)*hzl + (1109051/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (172973/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass

end TSP.Improvements20261105
