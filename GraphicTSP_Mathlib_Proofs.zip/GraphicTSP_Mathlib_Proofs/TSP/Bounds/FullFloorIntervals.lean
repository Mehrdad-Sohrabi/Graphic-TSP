import Mathlib.Tactic

/-! Exact simultaneous-coordinate interval arithmetic for negative floors. -/
namespace TSP.Improvements20261105

theorem full_floor_maximal_increase (P Q E q o eta zS zR : ℝ)
    (hP : 0 < P) (hE : 0 ≤ E) (ho : 0 ≤ o)
    (hfS : -Q * (q + eta) ≤ zS)
    (hfR : -Q * (1 - q - o) ≤ zR)
    (hedge : P * E - Q - (P - Q) * o - Q * eta ≤ zS + zR) :
    let d := min E (o + (zR + Q * (1 - q - o)) / P)
    0 ≤ d ∧ d ≤ E ∧
      P * (E - d) - Q * (q + eta) ≤ zS ∧
      P * (d - o) - Q * (1 - q - o) ≤ zR := by
  let b := o + (zR + Q * (1 - q - o)) / P
  have hb0 : 0 ≤ b := add_nonneg ho (div_nonneg (by linarith) (le_of_lt hP))
  have hid : P * b = P * o + zR + Q * (1 - q - o) := by
    dsimp [b]
    field_simp
    ring
  change 0 ≤ min E b ∧ min E b ≤ E ∧ _ ∧ _
  refine ⟨le_min hE hb0, min_le_left _ _, ?_, ?_⟩
  · by_cases h : E ≤ b
    · rw [min_eq_left h]
      nlinarith
    · rw [min_eq_right (le_of_lt (lt_of_not_ge h))]
      nlinarith
  · have hm := mul_le_mul_of_nonneg_left (min_le_right E b) (le_of_lt hP)
    nlinarith

theorem positive_shifted_edge_positive_receiver (P Q ES ER qS qR o etaS etaR fS fR : ℝ)
    (hP : 0 < P) (hQ : 0 ≤ Q)
    (hfS : -Q * (qS + etaS) ≤ fS) (hfR : -Q * (qR + etaR) ≤ fR)
    (hid : 1 - qS - qR = ER + o) (heta : etaR ≤ ER)
    (hw : 0 < P * ES - Q - (P - Q) * o - Q * etaS - fS - fR) : o < ES := by
  have he := mul_le_mul_of_nonneg_left heta hQ
  have hi := congrArg (fun x : ℝ => Q * x) hid
  nlinarith

theorem positive_shifted_edge_zero_receiver (P Q ES qS qR aR o etaS fS fR : ℝ)
    (hP : 0 < P)
    (hfS : -Q * (qS + etaS) ≤ fS) (hfR : -Q * (qR + aR - 1) ≤ fR)
    (hid : qR + aR = 2 - qS - o)
    (hw : 0 < P * ES - Q - (P - Q) * o - Q * etaS - fS - fR) : o < ES := by
  have hi := congrArg (fun x : ℝ => Q * x) hid
  dsimp only at hi
  nlinarith

theorem full_floor_matched_raw_sum (P Q E o : ℝ) (ho : o < E) :
    P * E - Q - (P - Q) * o - Q * min E o = P * E - Q - P * o := by
  rw [min_eq_right (le_of_lt ho)]
  ring

end TSP.Improvements20261105
