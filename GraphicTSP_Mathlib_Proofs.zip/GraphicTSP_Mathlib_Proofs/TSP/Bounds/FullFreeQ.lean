import TSP.Improvements20261105.ClassifiedGauge

/-! Split the remaining unclassified stars after the simultaneous
classified construction. The old complementary even-center bound is
deliberately not asserted at a changed unclassified receiver. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem treeIntervalValue_unclassified_star {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (t : d.tree.Child → ℝ)
    (hsource : ∀ v, t v ≠ 0 → SurvivingPositive d x v)
    (i : d.StarIndex) (hu : ¬ClassifiedCenter d x (d.centers i))
    (e : E) (he : e ∈ d.stars i) : treeIntervalValue d x t e = x e / 2 := by
  by_cases htree : e ∈ d.treeEdges
  · obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp htree
    have hv := (d.mem_group i.1 _).mp he
    rw [d.anchor_treeEdge] at hv
    have ht : t v = 0 := by
      by_contra hne
      have hc := surviving_center_classified d hx.1 v (hsource v hne)
      apply hu
      simpa only [hv] using hc
    rw [treeIntervalValue_tree, ht, add_zero]
  · exact treeIntervalValue_off_tree d x t e htree

theorem exists_full_free_Q {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (owner : E → Option d.StarIndex) (howner : ValidOwner d.stars owner)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (htop : ∀ v, t v ≤ 1 - x (d.treeEdge v))
    (hsource : ∀ v, t v ≠ 0 → SurvivingPositive d x v)
    (hfree : ∀ v : d.tree.Child, ClassifiedCenter d x v →
      t v ≤ edgeSum x (minorBoundary d x v) - x (d.treeEdge v)) :
    ∃ Q : (E ⊕ d.StarIndex) → ℝ,
      Q ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ e, Q (Sum.inl e) = halfComplementPoint d.treeEdges (fun e => 2 * treeIntervalValue d x t e) e) ∧
      (∀ i : ClassifiedStarIndex d x, Q (Sum.inr i.1) =
        if partialMain d hx hn hcap (partialCenter d x i) ≠ some i ∨
          Even (G.intDegree d.treeEdges (partialCenter d x i))
        then classifiedCapacity d hx hn hcap (Sum.inr i) / 2
        else 1 - classifiedCapacity d hx hn hcap (Sum.inr i) / 2) ∧
      (∀ i : d.StarIndex, ¬ClassifiedCenter d x (d.centers i) →
        Q (Sum.inr i) ≤ edgeSum x (d.stars i) / 2) := by
  obtain ⟨q, hq, hrep, hconn⟩ := exists_free_partial_Q d hsimple hx hn hcap t ht htop hsource hfree
  let P := fun i : d.StarIndex => ClassifiedCenter d x (d.centers i)
  have heq := restricted_star_join_polytope P G d.stars d.centers owner (partialOwner d x)
    hsimple.1 (fun i e he => d.group_incident i.1 e he) howner (partialOwner_valid d x)
  have hmem : q ∈ restrictStarsVector P '' joinPolytope (auxiliaryGraph G d.centers owner)
      ((auxiliaryGraph G d.centers owner).oddVertices Finset.univ)
      ((auxiliaryGraph G d.centers owner).intDegree Finset.univ) := by
    rw [heq]
    exact hq
  obtain ⟨Q, hQ, hres⟩ := hmem
  have hfull : Q ∈ projectedFrameworkTwo G d.centers owner := by
    rw [projectedFrameworkTwo_eq_oddJoinPolytope]
    exact hQ
  have hr : ∀ e, Q (Sum.inl e) = halfComplementPoint d.treeEdges (fun e => 2 * treeIntervalValue d x t e) e := by
    intro e
    exact (congrFun hres (Sum.inl e)).trans (hrep e)
  refine ⟨Q, hfull, hr, ?_, ?_⟩
  · intro i
    exact (congrFun hres (Sum.inr i)).trans (hconn i)
  · intro i hu
    have hh := connector_bound_57 d hsimple owner howner
      (fun e => 2 * treeIntervalValue d x t e) hfull hr i
    rw [← star_lp_sum d (fun e => 2 * treeIntervalValue d x t e) i] at hh
    have hm : edgeSum (fun e => 2 * treeIntervalValue d x t e) (d.stars i) =
        edgeSum x (d.stars i) := by
      apply Finset.sum_congr rfl
      intro e he
      change 2 * treeIntervalValue d x t e = x e
      rw [treeIntervalValue_unclassified_star d hx t hsource i hu e he]
      ring
    rwa [hm] at hh

end TSP.Improvements20261105
