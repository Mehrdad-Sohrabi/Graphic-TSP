import TSP.Improvements20261105.CanonicalHeadLoad

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem high_q_source_coupon (x z : E → ℝ) (s : d.tree.Child)
    (hq : 1/2 ≤ x (d.treeEdge s)) (hpos : 1 < edgeSum z (d.backGroup s))
    (ho : outgoingBackMass d x s ≤ 1-x (d.treeEdge s)) :
    projectedOutgoingCoupon d x z s = 1-x (d.treeEdge s) := by
  have hb := projectedOutgoingCoupon_positive_base d x z s hpos
  rw [min_eq_right (by linarith)] at hb
  unfold projectedOutgoingCoupon
  rw [if_pos hpos, hb]
  exact max_eq_left ((min_le_right _ _).trans ho)

theorem effective_source_load (x z : E → ℝ) (S T : Finset d.tree.Child) (s : d.tree.Child)
    (hnr : d.tree.parent s ≠ d.tree.root) (hu : childCount d s=1)
    (hq : 1/2 ≤ x (d.treeEdge s)) (hpos : 1 < edgeSum z (d.backGroup s))
    (ho : outgoingBackMass d x s ≤ 1-x (d.treeEdge s)) :
    canonicalHeadLoad d (fixedGatePlan d x) x z S T (projectedOutgoingCoupon d x z) s =
      24*(edgeSum z (d.backGroup s)-1)+refinedIncidenceCharge d x z S T s-
        24*outgoingBackMass d x s := by
  have hc : (Chapter11.childSet d s).card ≤ 1 := by change childCount d s ≤ 1; omega
  have hk : (fixedGatePlan d x).kind s = .outgoing := by
    simp [fixedGatePlan, fixedBypassKind, hnr, hc]
  have hp : payableCoupon d (fixedGatePlan d x) (fun e => x e.1) (projectedOutgoingCoupon d x z) s =
      outgoingBackMass d x s := by
    rw [payableCoupon, hk, tailBackMass_original, high_q_source_coupon d x z s hq hpos ho]
    exact min_eq_right ho
  have he := coupon_payment_split d (fixedGatePlan d x) (fun e => x e.1)
    (projectedOutgoingCoupon d x z) s
  rw [hp] at he
  unfold canonicalHeadLoad
  simp only [gatedFreeBase, if_neg hnr, Nat.cast_one]
  linarith

end TSP.Improvements20261105
