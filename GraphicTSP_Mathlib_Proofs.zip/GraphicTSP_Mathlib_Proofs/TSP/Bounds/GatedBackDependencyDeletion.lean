import TSP.Improvements20261105.GatedDropMonotonicity

/-! Delete the dependencies of a specified finite set of original back
edges. The operation is verified on every actual back-path constraint. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def backConnectorPath (b : BackEdge d) (v : d.tree.Child) : Prop :=
  d.tree.OnPath (d.anchor b.1) (d.lower b.1) v ∧ v ≠ d.anchor b.1

def backRepresentativePath (b : BackEdge d) (v : d.tree.Child) : Prop :=
  d.tree.OnPath (d.anchor b.1) (d.lower b.1) v

def backsCoverConnector (B : Finset (BackEdge d)) (v : d.tree.Child) : Prop :=
  ∃ b ∈ B, backConnectorPath d b v

def backsCoverRepresentative (B : Finset (BackEdge d)) (v : d.tree.Child) : Prop :=
  ∃ b ∈ B, backRepresentativePath d b v

def backsUseTail (B : Finset (BackEdge d)) (v : V) : Prop :=
  ∃ b ∈ B, d.lower b.1 = v

noncomputable def GatedDrops.eraseBackDependencies (a : GatedDrops d)
    (B : Finset (BackEdge d)) (S : Finset d.tree.Child) : GatedDrops d where
  pref := fun v => if backsCoverConnector d B v then 0 else a.pref v
  suffix := fun v => if backsCoverConnector d B v then 0 else a.suffix v
  representative := fun v => if backsCoverRepresentative d B v then 0 else a.representative v
  head := fun v => if v ∈ S then 0 else a.head v
  tail := fun v => if backsUseTail d B v then 0 else a.tail v
  outside := fun v => if v ∈ S then 0 else a.outside v

theorem GatedDrops.eraseBackDependencies_mono {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (B : Finset (BackEdge d)) (S : Finset d.tree.Child) :
    (∀ v, (a.eraseBackDependencies d B S).pref v ≤ a.pref v) ∧
    (∀ v, (a.eraseBackDependencies d B S).suffix v ≤ a.suffix v) ∧
    (∀ v, (a.eraseBackDependencies d B S).representative v ≤ a.representative v) ∧
    (∀ v, (a.eraseBackDependencies d B S).head v ≤ a.head v) ∧
    (∀ v, (a.eraseBackDependencies d B S).tail v ≤ a.tail v) ∧
    (∀ v, (a.eraseBackDependencies d B S).outside v ≤ a.outside v) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  all_goals intro v; simp only [eraseBackDependencies]; split_ifs
  all_goals first | exact le_rfl | exact ha.pref_nonneg v | exact ha.suffix_nonneg v |
    exact ha.representative_nonneg v | exact ha.head_nonneg v | exact ha.tail_nonneg v |
    exact ha.outside_nonneg v

theorem GatedDrops.eraseBackDependencies_path_zero (a : GatedDrops d)
    (B : Finset (BackEdge d)) (S : Finset d.tree.Child) (b : BackEdge d) (hb : b ∈ B) :
    (a.eraseBackDependencies d B S).pathCost d b = 0 := by
  apply Finset.sum_eq_zero
  intro v _
  have hc : backConnectorPath d b v → backsCoverConnector d B v := fun h => ⟨b, hb, h⟩
  have hr : backRepresentativePath d b v → backsCoverRepresentative d B v := fun h => ⟨b, hb, h⟩
  have hcp : backCycle d b (.inl (.inl v)) = if backConnectorPath d b v then 1 else 0 := by
    simp [backCycle, backConnectorPath]
  have hrp : backCycle d b (.inl (.inr v)) = if backRepresentativePath d b v then 1 else 0 := by
    simp [backCycle, backRepresentativePath]
  rw [hcp, hrp]
  by_cases hp : backConnectorPath d b v <;> by_cases hq : backRepresentativePath d b v <;>
    simp [eraseBackDependencies, hp, hq, hc, hr]

theorem GatedDrops.eraseBackDependencies_admissible {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (B : Finset (BackEdge d)) (S : Finset d.tree.Child)
    (hown : ∀ b : BackEdge d, d.anchor b.1 ∈ S → b ∈ B) :
    (a.eraseBackDependencies d B S).Admissible d P := by
  let q := a.eraseBackDependencies d B S
  have hm := a.eraseBackDependencies_mono d ha B S
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro v; dsimp [q, eraseBackDependencies]; split_ifs <;> first | exact le_rfl | exact ha.pref_nonneg v
  · intro v; dsimp [q, eraseBackDependencies]; split_ifs <;> first | exact le_rfl | exact ha.suffix_nonneg v
  · intro v; dsimp [q, eraseBackDependencies]; split_ifs <;> first | exact le_rfl | exact ha.representative_nonneg v
  · intro v; dsimp [q, eraseBackDependencies]; split_ifs <;> first | exact le_rfl | exact ha.head_nonneg v
  · intro v; dsimp [q, eraseBackDependencies]; split_ifs <;> first | exact le_rfl | exact ha.tail_nonneg v
  · intro v; dsimp [q, eraseBackDependencies]; split_ifs <;> first | exact le_rfl | exact ha.outside_nonneg v
  · intro v
    have hpaid := ha.paid v
    have hp := hm.1 v
    have hs := hm.2.1 v
    have hh := hm.2.2.2.1 v
    split_ifs at hpaid ⊢ <;> omega
  · intro b
    by_cases hb : d.anchor b.1 ∈ S
    · have hmemb := hown b hb
      have htail : backsUseTail d B (d.lower b.1) := ⟨b, hmemb, rfl⟩
      rw [a.eraseBackDependencies_path_zero d B S b hmemb]
      simp [eraseBackDependencies, hb, htail]
    · have hpath := a.pathCost_mono d q hm.1 hm.2.1 hm.2.2.1 b
      have htail : (q.tail (d.lower b.1) : ℝ) ≤ a.tail (d.lower b.1) := by
        exact_mod_cast hm.2.2.2.2.1 (d.lower b.1)
      have hout : q.outside (d.anchor b.1) = a.outside (d.anchor b.1) := by simp [q, eraseBackDependencies, hb]
      have hhead : q.head (d.anchor b.1) = a.head (d.anchor b.1) := by simp [q, eraseBackDependencies, hb]
      change q.pathCost d b + (q.tail (d.lower b.1) : ℝ) +
        (if P.OutsideBack d b then (q.outside (d.anchor b.1) : ℝ) else 0) ≤ (q.head (d.anchor b.1) : ℝ)
      rw [hout, hhead]
      exact (add_le_add_right (add_le_add hpath htail) _).trans (ha.back b)

end TSP.Improvements20261105
