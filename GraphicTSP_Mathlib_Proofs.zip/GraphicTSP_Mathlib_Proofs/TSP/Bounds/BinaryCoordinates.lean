import TSP.Improvements20261105.BinaryBypassGadgets

/-! Exact representative and connector coordinates of the binary Z point. -/
namespace TSP.Improvements20261105
open Graph Chapter03 Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem binaryRetained_tree_iff (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (v : d.tree.Child) :
    d.treeEdge v ∈ binaryRetained d B R ↔ BackCovered d B v ∧ v ∉ R := by
  have hn : d.treeEdge v ∉ B := by
    intro h
    exact (Finset.mem_sdiff.mp (hB h)).2 (Finset.mem_image.mpr ⟨v, Finset.mem_univ _, rfl⟩)
  simp only [binaryRetained, Finset.mem_union, hn, false_or, Finset.mem_image,
    Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨w, hw, heq⟩
    exact d.treeEdge_injective heq ▸ hw
  · intro hv
    exact ⟨v, hv, rfl⟩

theorem binaryRetained_back_iff (B : Finset E) (R : Finset d.tree.Child)
    (b : E) (hb : b ∈ d.backEdges) : b ∈ binaryRetained d B R ↔ b ∈ B := by
  constructor
  · intro h
    rcases Finset.mem_union.mp h with hB | hT
    · exact hB
    · obtain ⟨v, _, heq⟩ := Finset.mem_image.mp hT
      exact ((Finset.mem_sdiff.mp hb).2 (Finset.mem_image.mpr ⟨v, Finset.mem_univ _, heq⟩)).elim
  · exact Finset.mem_union_left _

theorem expanded_original_coverage_iff (B : Finset E) (v : d.tree.Child) :
    BackCovered (expandedDFS d) (expandedChosenBacks d B) (originalNode d v) ↔
      SelectedTreeCover d B v := by
  unfold BackCovered SelectedTreeCover
  simp only [expandedChosenBacks, Finset.mem_map]
  constructor
  · rintro ⟨_, ⟨b, hb, rfl⟩, hc⟩
    have hh := (backCovers_iff_fundamental_cut (expandedDFS d) _ (originalNode d v)).mp hc
    change Sum.inl b ∈ (allGroupGraph d).cut ((expandedTree d).descendantShore (Sum.inl (v : V))) at hh
    rw [original_fundamental_cut] at hh
    exact ⟨b, Finset.mem_inter.mpr ⟨hb, by simpa using hh⟩⟩
  · rintro ⟨b, hb⟩
    refine ⟨Sum.inl b, ⟨b, (Finset.mem_inter.mp hb).1, rfl⟩, ?_⟩
    apply (backCovers_iff_fundamental_cut (expandedDFS d) _ (originalNode d v)).mpr
    change Sum.inl b ∈ (allGroupGraph d).cut ((expandedTree d).descendantShore (Sum.inl (v : V)))
    rw [original_fundamental_cut]
    exact Finset.mem_map.mpr ⟨b, (Finset.mem_inter.mp hb).2, rfl⟩

theorem expanded_auxiliary_coverage_iff (B : Finset E) (v : d.tree.Child) :
    BackCovered (expandedDFS d) (expandedChosenBacks d B) (auxiliaryNode d v) ↔
      SelectedForeignCover d B v := by
  unfold BackCovered SelectedForeignCover
  simp only [expandedChosenBacks, Finset.mem_map]
  constructor
  · rintro ⟨_, ⟨b, hb, rfl⟩, hc⟩
    have hh := (backCovers_iff_fundamental_cut (expandedDFS d) _ (auxiliaryNode d v)).mp hc
    change Sum.inl b ∈ (allGroupGraph d).cut ((expandedTree d).descendantShore (Sum.inr v)) at hh
    exact ⟨b, Finset.mem_inter.mpr ⟨hb, (auxiliary_fundamental_rep_iff d v b).mp hh⟩⟩
  · rintro ⟨b, hb⟩
    refine ⟨Sum.inl b, ⟨b, (Finset.mem_inter.mp hb).1, rfl⟩, ?_⟩
    apply (backCovers_iff_fundamental_cut (expandedDFS d) _ (auxiliaryNode d v)).mpr
    exact (auxiliary_fundamental_rep_iff d v b).mpr (Finset.mem_inter.mp hb).2

theorem expanded_deleted_original_iff (R : Finset d.tree.Child) (v : d.tree.Child) :
    originalNode d v ∈ expandedDeletedReps d R ↔ v ∈ R := by
  constructor
  · rintro h
    obtain ⟨w, hw, heq⟩ := Finset.mem_image.mp h
    have hh := Sum.inl.inj (congrArg Subtype.val heq)
    exact Subtype.ext hh ▸ hw
  · intro hv
    exact Finset.mem_image.mpr ⟨v, hv, rfl⟩

theorem expanded_deleted_auxiliary_not (R : Finset d.tree.Child) (v : d.tree.Child) :
    auxiliaryNode d v ∉ expandedDeletedReps d R := by
  rintro h
  obtain ⟨w, _, heq⟩ := Finset.mem_image.mp h
  have hh := congrArg Subtype.val heq
  exact Sum.noConfusion hh

theorem expandedBinaryPoint_tree (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (v : d.tree.Child) :
    expandedBinaryPoint d B R (Sum.inl (d.treeEdge v)) =
      if SelectedTreeCover d B v ∧ v ∉ R then 1 / 3 else 1 := by
  change binaryRepairPoint _ ((expandedDFS d).treeEdge (originalNode d v)) = _
  simp only [binaryRepairPoint, binaryRetained_tree_iff (expandedDFS d) _ (expandedChosenBacks_subset d B hB),
    expanded_original_coverage_iff, expanded_deleted_original_iff]

theorem expandedBinaryPoint_connector (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (v : d.tree.Child) :
    expandedBinaryPoint d B R (Sum.inr v) = if SelectedForeignCover d B v then 1 / 3 else 1 := by
  change binaryRepairPoint _ ((expandedDFS d).treeEdge (auxiliaryNode d v)) = _
  simp only [binaryRepairPoint, binaryRetained_tree_iff (expandedDFS d) _ (expandedChosenBacks_subset d B hB),
    expanded_auxiliary_coverage_iff]
  simp only [expanded_deleted_auxiliary_not, not_false_eq_true, and_true]

theorem expandedBinaryPoint_back (B : Finset E) (R : Finset d.tree.Child)
    (b : E) (hb : b ∈ d.backEdges) :
    expandedBinaryPoint d B R (Sum.inl b) = if b ∈ B then 1 / 3 else 1 := by
  have hb' : Sum.inl b ∈ (expandedDFS d).backEdges :=
    expandedChosenBacks_subset d d.backEdges (fun _ h => h) (Finset.mem_map.mpr ⟨b, hb, rfl⟩)
  unfold expandedBinaryPoint
  simp only [binaryRepairPoint, binaryRetained_back_iff (expandedDFS d) _ _ _ hb']
  simp [expandedChosenBacks]

theorem expandedBinaryPoint_root_connector (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (v : d.tree.Child) (hv : d.tree.parent v = d.tree.root) :
    expandedBinaryPoint d B R (Sum.inr v) = 1 := by
  rw [expandedBinaryPoint_connector d B hB]
  apply if_neg
  rintro ⟨b, hb⟩
  have hh := ((deletedSubtreeCut_iff d v b).mp (Finset.mem_inter.mp hb).2).2
  rw [hv, d.tree.root_depth] at hh
  omega

end TSP.Improvements20261105
