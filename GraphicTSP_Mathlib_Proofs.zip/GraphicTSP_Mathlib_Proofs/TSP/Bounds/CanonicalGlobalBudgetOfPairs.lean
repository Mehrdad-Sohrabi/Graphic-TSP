import TSP.Improvements20261105.CanonicalExtendedRemainingRootMatchingBudget
import TSP.Improvements20261105.GlobalRoleBackBudget
import TSP.Improvements20261105.OriginalMatchingBadLabels
import TSP.Improvements20261105.MatchingAdjacencyCredit
/-! Conditional assembly: the only remaining combinatorial cost input is
explicitly the per-pair payment. This is not the final graph-only theorem. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem canonical_global_budget_of_pair_payments (eligible : Finset (d).tree.Child) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d (fixedGatePlan d x)) f)
    (hb : RealFlowBounds (gatedLower d (fixedGatePlan d x)) (gatedAugmentedUpper d (fixedGatePlan d x) t) f)
    (a : GatedDrops d) (ha : a.Admissible d (fixedGatePlan d x)) (hcan : CanonicalGatedFor d (fixedGatePlan d x) t f (a.potential d (fixedGatePlan d x)))
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (heligible : ∀ s ∈ eligible, ScoredStar d x s)
    (heligibleAll : ∀ s, ScoredStar d x s → s ∈ eligible)
    (T : Finset (d).tree.Child) (hTS : T ⊆ (fixedCriticalHeads d x z eligible))
    (hT : ∀ s ∈ T, 2 ≤ (a.componentHeads d (fixedGatePlan d x) (a.headComponent d (fixedGatePlan d x) s)).card)
    (hn : 2 ≤ Fintype.card V)
    (hprojection : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hrootStar : (d).centers rootStar = (d).tree.root)
    (R : E ⊕ (d).StarIndex → ℝ)
    (Q : E ⊕ (d).StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G (d).centers owner)
    (hrep : ∀ c, Q (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Q (.inl e) = 1-x e/2)
    (m : (d).StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x ((d).treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hmprojected : ∀ i ∈ projectedZeroTerminalHeads d z,
      (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
        max (x ((d).treeEdge i.1)-projectedZeroGuardCapacity d x z Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Q i)
    (hconn : FixedQConnectorValues d x hx hn hcap R)
    (hloss : ∀ i, edgeSum Q (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Q i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
      m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1)
    (hconnectors : ∀ i : (d).StarIndex, R (.inr i) = Q (.inr i))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hdom : ∀ e, min (x₀ e) 1 ≤ x e)
    (hmU : ∀ i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x, 0 ≤ m i)
    (hpair : ∀ p ∈ a.internalMatchingPairs d (fixedGatePlan d x) x z C,
      currentSelectedHeadCost d x z C owner rootStar R eligible T a.head p.1+
        currentSelectedHeadCost d x z C owner rootStar R eligible T a.head p.2-
        24*retainedSelectedResidual d x z a.head p.2+
        24*extendedResidualIncomingDebt d x z a.head
          (a.internalUnmatchedHeads d (fixedGatePlan d x) x z C)
          (a.internalMatchingTargets d (fixedGatePlan d x) x z C) p.1 ≤
      4*((((d).backGroup p.1.1).card : ℝ)+((d).backGroup p.2.1).card)+
        2*(originalMatchingBadLabel d x₀ p.1.1 : ℝ)+
        (162/19)*(matchingPairCreditIndicator d a.head p : ℝ)) :
    48*a.value d (fixedGatePlan d x) (fun _ => 0)+
      (∑ i : (d).StarIndex, guardedNormalizedHeadCost d x z C owner rootStar R a i)-
      (704/5 : ℝ)*(∑ i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x, m i) ≤
      (415/2 : ℝ)+4*((Fintype.card V : ℝ)-3)+
      (1204/5)*(edgeSum x Finset.univ-Fintype.card V)-12*Chapter11.totalOverage d x-
      2*((degreeSlackVertices G x₀).card : ℝ) := by
  let P := fixedGatePlan d x
  let J := a.internalMatchingPairs d P x z C
  have hP := fixedGatePlan_tree d x
  have hJ : J ⊆ fixedMatchingStarPairs d x z C := Finset.filter_subset _ _
  have hledger := canonical_extended_remaining_root_matching_budget G x z hs hconnected root eligible hc
    x₀ hx₀ hpositive t ht f hf hb a ha hcan hx hcap hz hzx heligible heligibleAll T hTS hT
    hn hprojection C owner ho rootStar hrootStar R Q hQ hrep hbacks m hm0 hm hmprojected
    hguarded hconn hloss hmpositive hconnectors hterminal
  have hroles := a.global_role_back_budget d hs hc x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hbadNat := original_matching_rank_budget d hs x₀ x z hx₀ hpositive hx hcap hdom hc.1
    (scoredDFS_unit_priority G x hs hconnected root hcap) hprojection C J hJ
  have hbad : 2*((d).backEdges.card : ℝ)+(∑ p ∈ J, (originalMatchingBadLabel d x₀ p.1.1 : ℝ))+
      ((degreeSlackVertices G x₀).card : ℝ)+4 ≤ 2*(Fintype.card V : ℝ) := by exact_mod_cast hbadNat
  have hcredit := canonical_matching_adjacency_credit_real d hs hc P hP t ht f hf hb a ha hcan
    x z hz (fun e => (hzx e).trans (hcap e)) C (fixedCriticalHeads d x z eligible)
    (fun s => x ((d).treeEdge s)) (fun _ => hx.1 _)
    (fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hprojection)
    (scoredDFS_small_projected_back G x z hs hconnected root hzx) J hJ
  have hpairs := Finset.sum_le_sum hpair
  have hbacks := fixedMatchingStarPair_family_sum d x z C J hJ
    (fun i => (((d).backGroup i.1).card : ℝ))
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at hpairs
  change (∑ i ∈ pairStarHeads d J, (((d).backGroup i.1).card : ℝ))=_ at hbacks
  have hguards : 0 ≤ ∑ i ∈ (projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x) \
      (a.paidLeafGuardHeads d P x ∪ (a.componentStarUnion d P (a.noPairLeafRoots d P x z C)).filter
        (fun i => i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x)), m i :=
    Finset.sum_nonneg (fun i hi => hmU i (Finset.mem_sdiff.mp hi).1)
  dsimp only at hledger
  change _ ≤ _ at hroles
  dsimp only [P,J] at hroles hbad hcredit hbacks hguards
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at hledger hroles hbacks
  linarith only [hledger,hroles,hpairs,hbacks,hbad,hcredit,hguards]

end TSP.Improvements20261105
