import TSP.Chapter05.DFSData
import TSP.Chapter10.GeneralSparsity

/-! Original-vector eligibility and the geometry of tight shores. These
definitions use all ancestor incidences, including the incoming tree edge. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter10
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def ancestorIncidentEdges {G : Graph V E} (d : DFSData G) (v : V) : Finset E :=
  Finset.univ.filter (fun e => d.lower e = v)

noncomputable def ancestorMass {G : Graph V E} (d : DFSData G) (x : E → ℝ) (v : V) : ℝ :=
  edgeSum x (ancestorIncidentEdges d v)

def EligibleVertex {G : Graph V E} (d : DFSData G) (x : E → ℝ) (v : V) : Prop :=
  v ≠ d.tree.root ∧ ancestorMass d x v < 1

def PartitionableVertex (G : Graph V E) (x : E → ℝ) (v : V) : Prop :=
  ∃ A : Finset E, A ⊆ G.cut {v} ∧ edgeSum x A = 1 ∧ edgeSum x (G.cut {v} \ A) = 1

theorem edge_depth_strict {G : Graph V E} (d : DFSData G) (e : E) :
    d.tree.depth (d.upper e) < d.tree.depth (d.lower e) := by
  have hle := d.tree.ancestor_depth_le (d.edge_ancestor e)
  have hne : d.tree.depth (d.upper e) ≠ d.tree.depth (d.lower e) := fun h =>
    d.edge_strict e (d.tree.ancestors_eq_of_depth_eq (d.edge_ancestor e) .refl h)
  omega

theorem deepest_internal_edges_are_ancestor {G : Graph V E} (d : DFSData G)
    (A : Finset V) (v : V) (hmax : ∀ w ∈ A, d.tree.depth w ≤ d.tree.depth v) :
    G.cut (A.erase v) ∩ G.cut {v} ⊆ ancestorIncidentEdges d v := by
  intro e he
  have hs : (d.upper e = v ∧ d.lower e ∈ A) ∨ (d.lower e = v ∧ d.upper e ∈ A) := by
    rcases d.oriented e with h | h
    · simp only [Finset.mem_inter, cut, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_erase, Finset.mem_singleton, h.1, h.2] at he
      tauto
    · simp only [Finset.mem_inter, cut, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_erase, Finset.mem_singleton, h.1, h.2] at he
      tauto
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
  rcases hs with h | h
  · have hd := edge_depth_strict d e
    have hm := hmax (d.lower e) h.2
    rw [h.1] at hd
    omega
  · exact h.1

/-- Every proper tight shore with at least two vertices contains a vertex
whose ORIGINAL ancestor mass is at least one; no coordinate cap is assumed. -/
theorem tight_shore_has_ineligible {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (A : Finset V) (hcard : 2 ≤ A.card)
    (hproper : Aᶜ.Nonempty) (htight : edgeSum x (G.cut A) = 2) :
    ∃ v ∈ A, 1 ≤ ancestorMass d x v := by
  obtain ⟨v, hv, hmax⟩ := A.exists_max_image d.tree.depth (Finset.card_pos.mp (by omega))
  have herase : (A.erase v).Nonempty := by
    apply Finset.card_pos.mp
    have hc := Finset.card_erase_add_one hv
    omega
  have hp : (A.erase v)ᶜ.Nonempty := ⟨v, by simp⟩
  have hs : ({v}ᶜ : Finset V).Nonempty := by
    obtain ⟨w, hw⟩ := herase
    exact ⟨w, by simpa using (Finset.mem_erase.mp hw).1⟩
  have hA := hx.2 (A.erase v) herase hp
  have hvcut := hx.2 {v} (Finset.singleton_nonempty _) hs
  have hid := cut_insert_weight_identity G x (A.erase v) v (Finset.not_mem_erase _ _)
  rw [Finset.insert_erase hv, htight] at hid
  have hlower : 1 ≤ edgeSum x (G.cut (A.erase v) ∩ G.cut {v}) := by linarith
  refine ⟨v, hv, hlower.trans ?_⟩
  exact Finset.sum_le_sum_of_subset_of_nonneg (deepest_internal_edges_are_ancestor d A v hmax)
    (fun e _ _ => hx.1 e)

theorem deepest_cut_edges_are_ancestor {G : Graph V E} (d : DFSData G) (v : V)
    (hmax : ∀ w, d.tree.depth w ≤ d.tree.depth v) :
    G.cut {v} ⊆ ancestorIncidentEdges d v := by
  intro e he
  have hends : d.upper e = v ∨ d.lower e = v := by
    rcases d.oriented e with h | h
    · simp only [cut, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton,
        h.1, h.2] at he
      tauto
    · simp only [cut, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton,
        h.1, h.2] at he
      tauto
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
  rcases hends with h | h
  · have hd := edge_depth_strict d e
    have hm := hmax (d.lower e)
    rw [h] at hd
    omega
  · exact h

/-- The artificial top shore also cannot consist entirely of eligible
vertices, even when the root's cut is not tight. -/
theorem top_shore_has_ineligible {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) :
    ∃ v ∈ ({d.tree.root}ᶜ : Finset V), 1 ≤ ancestorMass d x v := by
  have ht := singleton_compl_nonempty hn d.tree.root
  obtain ⟨v, hv, hmax⟩ := ({d.tree.root}ᶜ : Finset V).exists_max_image d.tree.depth ht
  have hall : ∀ w, d.tree.depth w ≤ d.tree.depth v := by
    intro w
    by_cases hr : w = d.tree.root
    · subst w
      rw [d.tree.root_depth]
      exact Nat.zero_le _
    · exact hmax w (by simpa using hr)
  have hc := hx.2 {v} (Finset.singleton_nonempty _) (singleton_compl_nonempty hn v)
  have hle : edgeSum x (G.cut {v}) ≤ ancestorMass d x v :=
    Finset.sum_le_sum_of_subset_of_nonneg (deepest_cut_edges_are_ancestor d v hall)
      (fun e _ _ => hx.1 e)
  exact ⟨v, hv, by linarith⟩

end TSP.Improvements20261105
