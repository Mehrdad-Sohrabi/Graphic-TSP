import TSP.Improvements20261105.CanonicalHeadSize
import TSP.Improvements20261105.RootedCutComponents

/-! The true cuts are actual parent edges of the expanded DFS tree.
Unrewarded gate prefixes are excluded explicitly. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def expandedConnectorChild (v : d.tree.Child) : (expandedTree d).Child :=
  ⟨.inr v, by simp [expandedTree]⟩

def expandedRepresentativeChild (v : d.tree.Child) : (expandedTree d).Child :=
  ⟨.inl v, by simp [expandedTree, v.2]⟩

def expandedTreeRoles : (d.tree.Child ⊕ d.tree.Child) ≃ (expandedTree d).Child where
  toFun := Sum.elim (expandedConnectorChild d) (expandedRepresentativeChild d)
  invFun := fun w => match w with
    | ⟨.inl v, h⟩ => .inr ⟨v, fun hv => h (congrArg Sum.inl hv)⟩
    | ⟨.inr v, _⟩ => .inl v
  left_inv := by intro w; cases w <;> rfl
  right_inv := by rintro ⟨v | v, h⟩ <;> rfl

theorem expanded_connector_back_path (b : BackEdge d) (v : d.tree.Child) :
    ((expandedTree d).OnPath (.inr (d.anchor b.1)) (.inl (d.lower b.1)) (expandedConnectorChild d v) ∧
      ((expandedConnectorChild d v : (expandedTree d).Child) : FlowVertex d) ≠ .inr (d.anchor b.1)) ↔
        backConnectorPath d b v := by
  change (((expandedTree d).Ancestor (.inr (d.anchor b.1)) (.inr v) ∧
    (expandedTree d).Ancestor (.inr v) (.inl (d.lower b.1))) ∧
      (Sum.inr v : FlowVertex d) ≠ .inr (d.anchor b.1)) ↔ _
  rw [expanded_auxiliary_ancestor_iff, expanded_auxiliary_original_iff]
  simp only [ne_eq, Sum.inr.injEq]
  constructor
  · rintro ⟨⟨he | hp, hl⟩, hn⟩
    · exact (hn he.symm).elim
    · exact ⟨⟨(Relation.ReflTransGen.single ⟨v.2, rfl⟩).trans hp, hl⟩, hn⟩
  · rintro ⟨⟨hp, hl⟩, hn⟩
    refine ⟨⟨Or.inr ?_, hl⟩, hn⟩
    exact d.tree.ancestor_parent_of_ne hp (fun h => hn (Subtype.ext h))

theorem expanded_representative_back_path (b : BackEdge d) (v : d.tree.Child) :
    ((expandedTree d).OnPath (.inr (d.anchor b.1)) (.inl (d.lower b.1)) (expandedRepresentativeChild d v) ∧
      ((expandedRepresentativeChild d v : (expandedTree d).Child) : FlowVertex d) ≠ .inr (d.anchor b.1)) ↔
        backRepresentativePath d b v := by
  change (((expandedTree d).Ancestor (.inr (d.anchor b.1)) (.inl (v : V)) ∧
    (expandedTree d).Ancestor (.inl (v : V)) (.inl (d.lower b.1))) ∧
      (Sum.inl (v : V) : FlowVertex d) ≠ .inr (d.anchor b.1)) ↔ _
  rw [expanded_auxiliary_original_iff, expanded_original_ancestor_iff]
  simp [backRepresentativePath, RootedTree.OnPath]

noncomputable def GatedDrops.trueRoleWeight (P : GatePlan d) (a : GatedDrops d) :
    d.tree.Child ⊕ d.tree.Child → ℤ
  | .inl v => if d.tree.parent v = d.tree.root then 0 else
      a.suffix v + if P.IsReceiver d v then 0 else a.pref v
  | .inr v => if (d.backGroup v).Nonempty then 0 else a.representative v

noncomputable def GatedDrops.physicalRoleWeight (a : GatedDrops d) : d.tree.Child ⊕ d.tree.Child → ℤ
  | .inl v => a.pref v + a.suffix v
  | .inr v => a.representative v

noncomputable def GatedDrops.trueCutWeight (P : GatePlan d) (a : GatedDrops d)
    (w : (expandedTree d).Child) : ℤ := a.trueRoleWeight d P ((expandedTreeRoles d).symm w)

noncomputable def GatedDrops.trueCuts (P : GatePlan d) (a : GatedDrops d) : Finset (expandedTree d).Child :=
  Finset.univ.filter (fun w => 0 < a.trueCutWeight d P w)

theorem GatedDrops.trueRoleWeight_bounds {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (w : d.tree.Child ⊕ d.tree.Child) :
    0 ≤ a.trueRoleWeight d P w ∧ a.trueRoleWeight d P w ≤ a.physicalRoleWeight d w := by
  cases w with
  | inl v =>
    have hp := ha.pref_nonneg v
    have hs := ha.suffix_nonneg v
    simp only [trueRoleWeight, physicalRoleWeight]
    split_ifs <;> omega
  | inr v =>
    have hr := ha.representative_nonneg v
    simp only [trueRoleWeight, physicalRoleWeight]
    split_ifs <;> omega

theorem GatedDrops.trueCutWeight_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (w : (expandedTree d).Child) : 0 ≤ a.trueCutWeight d P w :=
  (a.trueRoleWeight_bounds d ha _).1

theorem GatedDrops.trueRoleWeight_reward (P : GatePlan d) (a : GatedDrops d) :
    (∑ w : d.tree.Child ⊕ d.tree.Child, a.trueRoleWeight d P w) =
      ∑ v : d.tree.Child, a.reward d P v := by
  rw [Fintype.sum_sum_type, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro v _
  by_cases hr : d.tree.parent v = d.tree.root <;> by_cases hg : P.IsReceiver d v <;>
    simp [trueRoleWeight, reward, hr, hg] <;> omega

end TSP.Improvements20261105
