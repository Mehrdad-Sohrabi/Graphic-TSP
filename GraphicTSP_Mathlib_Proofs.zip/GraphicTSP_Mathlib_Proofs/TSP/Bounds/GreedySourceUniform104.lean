import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000

theorem greedy_source_uniform_104 (q a I g : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (ha : 1 ≤ a) (hpack : a+q ≤ 2)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+a ≤ 2)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1))) :
    (415/2)*(a-1)-(704/5)+24*(a-1+g)+I ≤ 104 := by
  by_cases hc0 : q ≤ (1/20 : ℝ)
  · have hh := hIall (1/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc0
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc0]
  by_cases hc1 : q ≤ (1/10 : ℝ)
  · have hh := hIall (1/10 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc1
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc1,hc0]
  by_cases hc2 : q ≤ (3/20 : ℝ)
  · have hh := hIall (3/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc2
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc2,hc1]
  by_cases hc3 : q ≤ (1/5 : ℝ)
  · have hh := hIall (1/5 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc3
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc3,hc2]
  by_cases hc4 : q ≤ (9/38 : ℝ)
  · have hh := hIall (9/38 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc4
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc4,hc3]
  by_cases hc5 : q ≤ (1/4 : ℝ)
  · have hh := hIall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc5
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc5,hc4]
  by_cases hc6 : q ≤ (3/10 : ℝ)
  · have hh := hIall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc6
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc6,hc5]
  by_cases hc7 : q ≤ (7/20 : ℝ)
  · have hh := hIall (7/20 : ℝ) (4/7 : ℝ) (43/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc7
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc7,hc6]
  by_cases hc8 : q ≤ (2/5 : ℝ)
  · have hh := hIall (2/5 : ℝ) (3/4 : ℝ) (31/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc8
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc8,hc7]
  by_cases hc9 : q ≤ (9/20 : ℝ)
  · have hh := hIall (9/20 : ℝ) (8/9 : ℝ) (9/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc9
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc9,hc8]
  by_cases hc10 : q ≤ (1/2 : ℝ)
  · have hh := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc10
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc10,hc9]
  by_cases hc11 : q ≤ (11/20 : ℝ)
  · have hh := hIall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc11
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc11,hc10]
  by_cases hc12 : q ≤ (3/5 : ℝ)
  · have hh := hIall (3/5 : ℝ) (7/6 : ℝ) (23/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc12
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc12,hc11]
  by_cases hc13 : q ≤ (13/20 : ℝ)
  · have hh := hIall (13/20 : ℝ) (16/13 : ℝ) (157/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc13
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc13,hc12]
  by_cases hc14 : q ≤ (7/10 : ℝ)
  · have hh := hIall (7/10 : ℝ) (9/7 : ℝ) (44/35 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc14
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc14,hc13]
  by_cases hc15 : q ≤ (3/4 : ℝ)
  · have hh := hIall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc15
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc15,hc14]
  by_cases hc16 : q ≤ (4/5 : ℝ)
  · have hh := hIall (4/5 : ℝ) (11/8 : ℝ) (107/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc16
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc16,hc15]
  by_cases hc17 : q ≤ (17/20 : ℝ)
  · have hh := hIall (17/20 : ℝ) (24/17 : ℝ) (233/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc17
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc17,hc16]
  by_cases hc18 : q ≤ (9/10 : ℝ)
  · have hh := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc18
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc18,hc17]
  by_cases hc19 : q ≤ (19/20 : ℝ)
  · have hh := hIall (19/20 : ℝ) (28/19 : ℝ) (271/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc19
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc19,hc18]
  have hh := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by simpa using hq1)
  rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hg0,hghalf,hgap,hh,hc19]

theorem greedy_source_uniform_84 (q a I g : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (ha : 1 ≤ a) (hpack : a+q ≤ 2) (hcount : a ≤ 24*q)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+a ≤ 2)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1))) :
    (415/2)*(a-1)-(704/5)+24*(a-1+g)+I ≤ 84 := by
  by_cases hc0 : q ≤ (1/20 : ℝ)
  · have hh := hIall (1/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc0
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc0]
  by_cases hc1 : q ≤ (1/10 : ℝ)
  · have hh := hIall (1/10 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc1
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc1,hc0]
  by_cases hc2 : q ≤ (3/20 : ℝ)
  · have hh := hIall (3/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc2
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc2,hc1]
  by_cases hc3 : q ≤ (1/5 : ℝ)
  · have hh := hIall (1/5 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc3
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc3,hc2]
  by_cases hc4 : q ≤ (9/38 : ℝ)
  · have hh := hIall (9/38 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc4
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc4,hc3]
  by_cases hc5 : q ≤ (1/4 : ℝ)
  · have hh := hIall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc5
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc5,hc4]
  by_cases hc6 : q ≤ (3/10 : ℝ)
  · have hh := hIall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc6
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc6,hc5]
  by_cases hc7 : q ≤ (7/20 : ℝ)
  · have hh := hIall (7/20 : ℝ) (4/7 : ℝ) (43/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc7
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc7,hc6]
  by_cases hc8 : q ≤ (2/5 : ℝ)
  · have hh := hIall (2/5 : ℝ) (3/4 : ℝ) (31/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc8
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc8,hc7]
  by_cases hc9 : q ≤ (9/20 : ℝ)
  · have hh := hIall (9/20 : ℝ) (8/9 : ℝ) (9/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc9
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc9,hc8]
  by_cases hc10 : q ≤ (1/2 : ℝ)
  · have hh := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc10
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc10,hc9]
  by_cases hc11 : q ≤ (11/20 : ℝ)
  · have hh := hIall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc11
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc11,hc10]
  by_cases hc12 : q ≤ (3/5 : ℝ)
  · have hh := hIall (3/5 : ℝ) (7/6 : ℝ) (23/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc12
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc12,hc11]
  by_cases hc13 : q ≤ (13/20 : ℝ)
  · have hh := hIall (13/20 : ℝ) (16/13 : ℝ) (157/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc13
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc13,hc12]
  by_cases hc14 : q ≤ (7/10 : ℝ)
  · have hh := hIall (7/10 : ℝ) (9/7 : ℝ) (44/35 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc14
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc14,hc13]
  by_cases hc15 : q ≤ (3/4 : ℝ)
  · have hh := hIall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc15
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc15,hc14]
  by_cases hc16 : q ≤ (4/5 : ℝ)
  · have hh := hIall (4/5 : ℝ) (11/8 : ℝ) (107/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc16
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc16,hc15]
  by_cases hc17 : q ≤ (17/20 : ℝ)
  · have hh := hIall (17/20 : ℝ) (24/17 : ℝ) (233/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc17
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc17,hc16]
  by_cases hc18 : q ≤ (9/10 : ℝ)
  · have hh := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc18
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc18,hc17]
  by_cases hc19 : q ≤ (19/20 : ℝ)
  · have hh := hIall (19/20 : ℝ) (28/19 : ℝ) (271/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc19
    rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc19,hc18]
  have hh := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by simpa using hq1)
  rcases le_max_iff.mp hh with hh | hh <;> linarith only [hq0,hq1,ha,hpack,hcount,hg0,hghalf,hgap,hh,hc19]

end TSP.Improvements20261105
