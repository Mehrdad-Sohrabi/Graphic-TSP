import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r4_all_cell_40
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7711/26:ℝ)*hql + (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (10111/130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (2803145/9386:ℝ)*hql + (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (10111/130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (2854559/9386:ℝ)*hql + (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (4004511/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (2874033/9386:ℝ)*hql + (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (4004511/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_41
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (39023/650:ℝ)*hgood + (5766/325:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (14135767/234650:ℝ)*hgood + (2057294/117325:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (489831464/2066135:ℝ)*ho0 + (214451328/10330675:ℝ)*hgap + (566014312/10330675:ℝ)*hgood + (8935472/10330675:ℝ)*hS + (1/1:ℝ)*hI + (1395203/10330675:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (177780929486/745874735:ℝ)*ho0 + (214742112/10330675:ℝ)*hgap + (205320228798/3729373675:ℝ)*hgood + (8947588/10330675:ℝ)*hS + (1/1:ℝ)*hI + (1383087/10330675:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_42
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (34681/110:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (10217/110:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (12560849/39710:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (10217/110:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (12646121/39710:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3814617/39710:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (12687129/39710:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (3814617/39710:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_43
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (11/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t10_r4_all_cell_44
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (9/10 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1453/6:ℝ)*hzl + (155848/7233:ℝ)*hem + (1424984/7233:ℝ)*ho0 + (192896/12055:ℝ)*hgap + (24112/36165:ℝ)*hS + (1/1:ℝ)*hI + (12053/36165:ℝ)*hsource + (1/1:ℝ)*hR + (176/3:ℝ)*hmass
  · linear_combination (175367/722:ℝ)*hzl + (18817344/870371:ℝ)*hem + (172157376/870371:ℝ)*ho0 + (69666816/4351855:ℝ)*hgap + (2902784/4351855:ℝ)*hS + (1/1:ℝ)*hI + (1449071/4351855:ℝ)*hsource + (1/1:ℝ)*hR + (21440/361:ℝ)*hmass
  · linear_combination (1453/6:ℝ)*hzl + (281670664/13073865:ℝ)*hem + (171544648/871591:ℝ)*ho0 + (69635456/4357955:ℝ)*hgap + (8704432/13073865:ℝ)*hS + (1/1:ℝ)*hI + (4369433/13073865:ℝ)*hsource + (1/1:ℝ)*hR + (176/3:ℝ)*hmass
  · linear_combination (175367/722:ℝ)*hzl + (34009389888/1573221755:ℝ)*hem + (62174969536/314644351:ℝ)*ho0 + (69666816/4357955:ℝ)*hgap + (2902784/4357955:ℝ)*hS + (1/1:ℝ)*hI + (1455171/4357955:ℝ)*hsource + (1/1:ℝ)*hR + (21440/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_45
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (377/2750 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (487/2:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (30887/13:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (487/2:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11114763/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (176051/722:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11166067/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (176051/722:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11130623/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_46
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (377/2750 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (487/2:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2363/1:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (487/2:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (851667/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (176051/722:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (854263/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (176051/722:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (852887/361:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_47
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (377/2750 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (487/2:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (11767/5:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (487/2:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4246023/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (176051/722:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4253987/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (176051/722:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4252123/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_48
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q ≤ (377/2750 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (9/10 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1453/6:ℝ)*hzl + (1027/10:ℝ)*hem + (1597/6:ℝ)*ho0 + (24/1:ℝ)*hgap + (12053/15:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (176/3:ℝ)*hmass
  · linear_combination (175367/722:ℝ)*hzl + (1027/10:ℝ)*hem + (192695/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1449071/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (21440/361:ℝ)*hmass
  · linear_combination (1453/6:ℝ)*hzl + (371967/3610:ℝ)*hem + (1597/6:ℝ)*ho0 + (24/1:ℝ)*hgap + (4369433/5415:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (176/3:ℝ)*hmass
  · linear_combination (175367/722:ℝ)*hzl + (371967/3610:ℝ)*hem + (192695/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1455171/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (21440/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_49
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  linarith only [hqu,hgate,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r4_all_cell_50
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (5141/22:ℝ)*heq + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6197/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (5141/22:ℝ)*heq + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2307517/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (1881157/7942:ℝ)*heq + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2262373/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (1881157/7942:ℝ)*heq + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2332773/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_51
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (5141/22:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (83729/286:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (5141/22:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (31005937/103246:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (1881157/7942:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (30554497/103246:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (1881157/7942:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (31334265/103246:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_52
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (11/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (487/2:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (487/2:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (176051/722:ℝ)*heq + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (176051/722:ℝ)*heq + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_53
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  linarith only [hqu,hgate,hmass]

theorem large_selected_greedy_t10_r4_all_cell_54
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (7/16 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (7/16 : ℝ) (6/7 : ℝ) (61/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (3193/14:ℝ)*hg0 + (3529/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (4201/14:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (3193/14:ℝ)*hg0 + (3529/14:ℝ)*hgap + (1/1:ℝ)*hH0 + (1535825/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (1176953/5054:ℝ)*hg0 + (1298249/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1540841/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (1176953/5054:ℝ)*hg0 + (1298249/5054:ℝ)*hgap + (1/1:ℝ)*hH0 + (1560105/5054:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_55
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (7/16 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (35969/55:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (5141/22:ℝ)*hg0 + (5669/22:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (13060489/19855:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (5141/22:ℝ)*hg0 + (5669/22:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (13047949/19855:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (1881157/7942:ℝ)*hg0 + (2071765/7942:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (13123629/19855:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (1881157/7942:ℝ)*hg0 + (2071765/7942:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_56
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (11/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (487/2:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (487/2:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (176051/722:ℝ)*heq + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (176051/722:ℝ)*heq + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_57
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (4059/10:ℝ)*ho0 + (4059/10:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (4059/10:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (1469027/3610:ℝ)*ho0 + (1469027/3610:ℝ)*hgate + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (1/1:ℝ)*hL + (1469027/3610:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_58
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (9/10 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t10_r4_all_cell_59
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/22:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2027/11:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (190871/7942:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (728547/3971:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (190871/7942:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (763747/3971:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (197271/7942:ℝ)*hem + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (760547/3971:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r4_all_cell_60
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (43/160 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (43/160 : ℝ) (6/43 : ℝ) (97/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (22261/86:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (8311421/31046:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (8340149/31046:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (8615349/31046:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_61
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (43/160 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/160 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6931/26:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2585291/9386:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (2572979/9386:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2656179/9386:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_62
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (13/160 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6931/26:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2585291/9386:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (2572979/9386:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2656179/9386:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_63
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (511/22:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2027/11:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (2490899/103246:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9466323/51623:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (190871/7942:ℝ)*hem + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (763747/3971:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (234009/9386:ℝ)*hem + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (898393/4693:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_64
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (6931/286:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (26207/143:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2572979/103246:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9425283/51623:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2585291/103246:ℝ)*hem + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9876727/51623:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (2656179/103246:ℝ)*hem + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9841283/51623:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_65
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6931/26:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2594867/9386:ℝ)*hql + (271652/4693:ℝ)*hzl + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass
  · linear_combination (2572979/9386:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2665755/9386:ℝ)*hql + (271652/4693:ℝ)*hzl + (2265635/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (159020/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_66
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (43/160 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (43/160 : ℝ) (6/43 : ℝ) (97/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (301777/1118:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (111989681/403598:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (112892561/403598:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (115940745/403598:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_67
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (43/160 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7219/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (205919/722:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (205919/722:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2747835/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_68
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6197/22:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5141/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2307517/7942:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5141/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass
  · linear_combination (2262373/7942:ℝ)*hql + (48/1:ℝ)*hzl + (463/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1881157/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (24/1:ℝ)*hmass
  · linear_combination (2332773/7942:ℝ)*hql + (20528/361:ℝ)*hzl + (173543/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1881157/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11864/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_69
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (83729/286:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5141/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (31005937/103246:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5141/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (30554497/103246:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1881157/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (31334265/103246:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1881157/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r4_all_cell_70
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (11/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7867/26:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2910875/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass
  · linear_combination (2843159/9386:ℝ)*hql + (768/13:ℝ)*hzl + (6307/26:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (456/13:ℝ)*hmass
  · linear_combination (2914047/9386:ℝ)*hql + (312692/4693:ℝ)*hzl + (2347715/9386:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (200060/4693:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_71
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (5/32 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (5/32 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (22089/11:ℝ)*hqu + (736/11:ℝ)*hzl + (415/2:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (7953141/3971:ℝ)*hqu + (286684/3971:ℝ)*hzl + (415/2:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (8326129/3971:ℝ)*hqu + (736/11:ℝ)*hzl + (156215/722:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (8305141/3971:ℝ)*hqu + (286684/3971:ℝ)*hzl + (156215/722:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_72
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (5/32 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3744/59:ℝ)*hzl + (31973/1298:ℝ)*hem + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (118681/649:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (11809957/468578:ℝ)*hem + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (42709989/234289:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (3744/59:ℝ)*hzl + (1083623/42598:ℝ)*hem + (29141/118:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (4066531/21299:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (12187557/468578:ℝ)*hem + (10787605/42598:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (44597989/234289:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_73
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (5/32 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (736/11:ℝ)*hzl + (6037/242:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (22089/121:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2221333/87362:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (7953141/43681:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (736/11:ℝ)*hzl + (2249757/87362:ℝ)*hem + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (8326129/43681:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (286684/3971:ℝ)*hzl + (2291733/87362:ℝ)*hem + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (8305141/43681:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_74
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (5/32 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (5/32 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2003/1:ℝ)*hqu + (72/1:ℝ)*hzl + (415/2:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (721707/361:ℝ)*hqu + (27368/361:ℝ)*hzl + (415/2:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (755083/361:ℝ)*hqu + (72/1:ℝ)*hzl + (156215/722:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (753707/361:ℝ)*hqu + (27368/361:ℝ)*hzl + (156215/722:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_75
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (5/32 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (73/160 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (73/160 : ℝ) (66/73 : ℝ) (667/730 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5088/73:ℝ)*hzl + (40471/1606:ℝ)*hem + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (146387/803:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (3336/73:ℝ)*hmass
  · linear_combination (1954772/26353:ℝ)*hzl + (14846039/579766:ℝ)*hem + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (52727703/289883:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1322300/26353:ℝ)*hmass
  · linear_combination (5088/73:ℝ)*hzl + (15077231/579766:ℝ)*hem + (36967/146:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (55181707/289883:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (3336/73:ℝ)*hmass
  · linear_combination (1954772/26353:ℝ)*hzl + (15313239/579766:ℝ)*hem + (13581095/52706:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (55063703/289883:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1322300/26353:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_76
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (5/32 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (73/160 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (559/22:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (2271/55:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (204551/7942:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (812951/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (208199/7942:ℝ)*hem + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (979831/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (210951/7942:ℝ)*hem + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (972951/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_77
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (43/160 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (43/160 : ℝ) (6/43 : ℝ) (97/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (262759/946:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (96660967/341506:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (98199207/341506:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (100004175/341506:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_78
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (43/160 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (81649/286:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (30020977/103246:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass
  · linear_combination (30255057/103246:ℝ)*hql + (736/11:ℝ)*hzl + (5509/22:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (472/11:ℝ)*hmass
  · linear_combination (30800745/103246:ℝ)*hql + (286684/3971:ℝ)*hzl + (2030725/7942:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (191380/3971:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_79
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (43/160 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (43/160 : ℝ) (6/43 : ℝ) (97/430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (24325/86:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (8899661/31046:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18133/86:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (9085253/31046:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (9203589/31046:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6849941/31046:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r4_all_cell_80
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (43/160 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7555/26:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2763131/9386:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5683/26:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (2798243/9386:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2834019/9386:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2122451/9386:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_81
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (6725/22:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5141/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2457997/7942:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (5141/22:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass
  · linear_combination (2452981/7942:ℝ)*hql + (72/1:ℝ)*hzl + (511/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1881157/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (48/1:ℝ)*hmass
  · linear_combination (2483253/7942:ℝ)*hql + (27368/361:ℝ)*hzl + (187223/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1881157/7942:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (18704/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_82
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (11/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3319/5:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205039/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (487/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass
  · linear_combination (1198769/1805:ℝ)*hql + (511/2:ℝ)*hzl + (3019/5:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (3963/10:ℝ)*hmass
  · linear_combination (1205649/1805:ℝ)*hql + (187223/722:ℝ)*hzl + (1096739/1805:ℝ)*ho0 + (24/1:ℝ)*hgap + (176051/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hL + (1444403/3610:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_83
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (17/80 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (17/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (523/2:ℝ)*hzl + (571/22:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (2241/55:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (207629/7942:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (805256/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (523/2:ℝ)*hzl + (19321/722:ℝ)*hem + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (88091/1805:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (190301/722:ℝ)*hzl + (214029/7942:ℝ)*hem + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (965256/19855:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_84
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (17/80 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (2/3 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (7711/26:ℝ)*hql + (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (10111/130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (2803145/9386:ℝ)*hql + (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (10111/130:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass
  · linear_combination (2854559/9386:ℝ)*hql + (523/2:ℝ)*hzl + (523/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (4004511/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (54/1:ℝ)*hmass
  · linear_combination (2874033/9386:ℝ)*hql + (190301/722:ℝ)*hzl + (190301/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (4004511/46930:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (20243/361:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_85
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (13/40 : ℝ))
    (hzl : (2/3 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (39023/1430:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (36099/715:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (14135767/516230:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (13007507/258115:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1132028624/52498115:ℝ)*hem + (10845432944/52498115:ℝ)*ho0 + (904660224/52498115:ℝ)*hgap + (37694176/52498115:ℝ)*hS + (1/1:ℝ)*hI + (14803939/52498115:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (410640457596/18951819515:ℝ)*hem + (3936587748596/18951819515:ℝ)*ho0 + (905241792/52498115:ℝ)*hgap + (37718408/52498115:ℝ)*hS + (1/1:ℝ)*hI + (14779707/52498115:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_86
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (13/40 : ℝ) ≤ q) (hqu : q ≤ (11/20 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (34681/110:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (10217/110:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (12560849/39710:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (10217/110:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (12646121/39710:ℝ)*hql + (2651/10:ℝ)*hzl + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3814617/39710:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (12687129/39710:ℝ)*hql + (960739/3610:ℝ)*hzl + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (3814617/39710:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t10_r4_all_cell_87
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (11/20 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  linarith only [hql,hzl,ho0,ha,hmass]

theorem large_selected_greedy_t10_r4_all_cell_88
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/10 : ℝ) ≤ q) (hqu : q ≤ (1/1 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (9/10 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hS := hSall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1453/6:ℝ)*hzl + (155848/7233:ℝ)*hem + (1424984/7233:ℝ)*ho0 + (192896/12055:ℝ)*hgap + (24112/36165:ℝ)*hS + (1/1:ℝ)*hI + (12053/36165:ℝ)*hsource + (1/1:ℝ)*hR + (176/3:ℝ)*hmass
  · linear_combination (175367/722:ℝ)*hzl + (18817344/870371:ℝ)*hem + (172157376/870371:ℝ)*ho0 + (69666816/4351855:ℝ)*hgap + (2902784/4351855:ℝ)*hS + (1/1:ℝ)*hI + (1449071/4351855:ℝ)*hsource + (1/1:ℝ)*hR + (21440/361:ℝ)*hmass
  · linear_combination (1453/6:ℝ)*hzl + (281670664/13073865:ℝ)*hem + (171544648/871591:ℝ)*ho0 + (69635456/4357955:ℝ)*hgap + (8704432/13073865:ℝ)*hS + (1/1:ℝ)*hI + (4369433/13073865:ℝ)*hsource + (1/1:ℝ)*hR + (176/3:ℝ)*hmass
  · linear_combination (175367/722:ℝ)*hzl + (34009389888/1573221755:ℝ)*hem + (62174969536/314644351:ℝ)*ho0 + (69666816/4357955:ℝ)*hgap + (2902784/4357955:ℝ)*hS + (1/1:ℝ)*hI + (1455171/4357955:ℝ)*hsource + (1/1:ℝ)*hR + (21440/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t11_r3_cap_cell_0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q ≤ (16/125 : ℝ))
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (475/2:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (5117/2:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (475/2:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (1845173/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass
  · linear_combination (172973/722:ℝ)*hem + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (1863715/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (172973/722:ℝ)*hem + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (1861651/722:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q ≤ (16/125 : ℝ))
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (168/5:ℝ)*hzl + (475/2:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (25309/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (475/2:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9132821/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass
  · linear_combination (168/5:ℝ)*hzl + (172973/722:ℝ)*hem + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9218939/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (288/5:ℝ)*hmass
  · linear_combination (62512/1805:ℝ)*hzl + (172973/722:ℝ)*hem + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (9215211/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_2
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q ≤ (16/125 : ℝ))
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (10/11 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (10/11 : ℝ) (29/20 : ℝ) (281/200 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2423/10:ℝ)*hzl + (967/10:ℝ)*hem + (2663/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (8401/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (294/5:ℝ)*hmass
  · linear_combination (877177/3610:ℝ)*hzl + (967/10:ℝ)*hem + (963817/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (3030287/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (107371/1805:ℝ)*hmass
  · linear_combination (2423/10:ℝ)*hzl + (356577/3610:ℝ)*hem + (2663/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3115151/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (294/5:ℝ)*hmass
  · linear_combination (877177/3610:ℝ)*hzl + (356577/3610:ℝ)*hem + (963817/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (3112677/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (107371/1805:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_3
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1533/8:ℝ)*ho0 + (967/10:ℝ)*hg0 + (1207/10:ℝ)*hgap + (511/8:ℝ)*htarget + (1965/8:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (561669/2888:ℝ)*ho0 + (967/10:ℝ)*hg0 + (1207/10:ℝ)*hgap + (187223/2888:ℝ)*htarget + (717621/2888:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (1533/8:ℝ)*ho0 + (356577/3610:ℝ)*hg0 + (443217/3610:ℝ)*hgap + (511/8:ℝ)*htarget + (715357/2888:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (561669/2888:ℝ)*ho0 + (356577/3610:ℝ)*hg0 + (443217/3610:ℝ)*hgap + (187223/2888:ℝ)*htarget + (723613/2888:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_4
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (2/3 : ℝ) (5/4 : ℝ) (49/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (967/10:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (3191/10:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (967/10:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1155679/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (356577/3610:ℝ)*heq + (2651/10:ℝ)*ho0 + (24/1:ℝ)*hgap + (1159441/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (356577/3610:ℝ)*heq + (960739/3610:ℝ)*ho0 + (24/1:ℝ)*hgap + (1163169/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_5
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : (2/5 : ℝ) ≤ q)
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (2/3 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (10/11 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  linarith only [hzl,ho0,ha,hgate,hmass]

theorem large_selected_greedy_t11_r3_cap_cell_6
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (1/11 : ℝ) ≤ q) (hqu : q ≤ (31/132 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (31/132 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (575/32:ℝ)*hem + (1533/8:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (7797/160:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (210327/11552:ℝ)*hem + (561669/2888:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (2800957/57760:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (648325/34656:ℝ)*hem + (1533/8:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (9852151/173280:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (656581/34656:ℝ)*hem + (561669/2888:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (9810871/173280:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_7
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (31/132 : ℝ) ≤ q) (hqu : q ≤ (25/66 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (25/66 : ℝ) (17/25 : ℝ) (89/125 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1008/25:ℝ)*hql + (4678/5:ℝ)*hzu + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2507/10:ℝ)*htarget + (11191/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (-415/2:ℝ)*hmass
  · linear_combination (1008/25:ℝ)*hql + (1716922/1805:ℝ)*hzu + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (923803/3610:ℝ)*htarget + (11191/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (-415/2:ℝ)*hmass
  · linear_combination (418352/9025:ℝ)*hql + (4678/5:ℝ)*hzu + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (2507/10:ℝ)*htarget + (4148879/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (-415/2:ℝ)*hmass
  · linear_combination (418352/9025:ℝ)*hql + (1716922/1805:ℝ)*hzu + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (923803/3610:ℝ)*htarget + (4148879/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (-415/2:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_8
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (31/132 : ℝ) ≤ q) (hqu : q ≤ (27/88 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (27/88 : ℝ) (10/27 : ℝ) (13/30 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (16165/72:ℝ)*hql + (1533/8:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (6803/90:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (5909869/25992:ℝ)*hql + (561669/2888:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (6803/90:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (672037/2888:ℝ)*hql + (1533/8:ℝ)*ho0 + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (302427/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (680293/2888:ℝ)*hql + (561669/2888:ℝ)*ho0 + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (302427/3610:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_greedy_t11_r3_cap_cell_9
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgate : q+e ≤ (22/25 : ℝ))
    (hql : (27/88 : ℝ) ≤ q) (hqu : q ≤ (25/66 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ)) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hS := hSall (25/66 : ℝ) (17/25 : ℝ) (89/125 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hqu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (13891/50:ℝ)*hql + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (11191/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (5066251/18050:ℝ)*hql + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (11191/50:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass
  · linear_combination (5123579/18050:ℝ)*hql + (475/2:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (18/1:ℝ)*htarget + (4148879/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (30/1:ℝ)*hmass
  · linear_combination (5175179/18050:ℝ)*hql + (173539/722:ℝ)*ho0 + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (6842/361:ℝ)*htarget + (4148879/18050:ℝ)*hgate + (1/1:ℝ)*hS + (1/1:ℝ)*hI + (11862/361:ℝ)*hmass

end TSP.Improvements20261105
