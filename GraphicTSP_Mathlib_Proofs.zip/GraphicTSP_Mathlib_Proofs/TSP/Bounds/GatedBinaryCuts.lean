import TSP.Improvements20261105.GatedNoRepresentativeDrop

/-! Foreign backs in actual vertex-deleted subtree cuts bound every
nonroot tree drop by one. Thus the lower-bound cuts are genuinely binary. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def gatedPrefixDrop (p : GatedVertex d → ℤ) (v : d.tree.Child) : ℤ :=
  p (gatedCenter d (d.tree.parent v)) - p (gatedGate d v)

def gatedSuffixDrop (p : GatedVertex d → ℤ) (v : d.tree.Child) : ℤ :=
  p (gatedGate d v) - p (gatedAux d v)

def gatedConnectorDrop (p : GatedVertex d → ℤ) (v : d.tree.Child) : ℤ :=
  p (gatedCenter d (d.tree.parent v)) - p (gatedAux d v)

theorem gated_split_drop_identity (p : GatedVertex d → ℤ) (v : d.tree.Child) :
    gatedPrefixDrop d p v + gatedSuffixDrop d p v = gatedConnectorDrop d p v := by
  unfold gatedPrefixDrop gatedSuffixDrop gatedConnectorDrop
  omega

theorem foreign_anchor_above_parent (v : d.tree.Child) (b : E)
    (hb : b ∈ deletedSubtreeCut d v) : d.tree.Ancestor (d.anchor b) (d.tree.parent v) := by
  have hcut := (deletedSubtreeCut_iff d v b).mp hb
  have hp : d.tree.Ancestor (d.tree.parent v) (d.lower b) :=
    hcut.1.trans (.single ⟨v.2, rfl⟩)
  have ha := d.anchor_spec b
  have hd := d.tree.parent_depth (d.anchor b) (d.anchor b).2
  rw [ha.1] at hd
  exact d.tree.common_ancestor_of_depth_le ha.2 hp (by omega)

theorem gated_foreign_parent_drop_bound {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) (b : E)
    (hb : b ∈ deletedSubtreeCut d v) :
    p (gatedCenter d (d.tree.parent v)) - p (gatedCenter d v) ≤
      gatedHeadSelector d p (d.anchor b) := by
  have hhead := gated_dual_back d hp ⟨b, deletedSubtreeCut_back d v hb⟩
  change p (gatedHead d (d.anchor b)) ≤ p (gatedTail d (d.lower b)) at hhead
  have htail := gated_dual_tail d hp (d.lower b)
  have hlo := gated_dual_ancestor d hp ((deletedSubtreeCut_iff d v b).mp hb).1
  have hhi := gated_dual_ancestor d hp (foreign_anchor_above_parent d v b hb)
  have haux := gated_dual_representative d hp (d.anchor b)
  unfold gatedHeadSelector
  omega

theorem gated_nonroot_parent_drop_le_one (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {p : GatedVertex d → ℤ} (hp : GatedDualFeasible d P p)
    (v : d.tree.Child) (hv : d.tree.parent v ≠ d.tree.root) :
    p (gatedCenter d (d.tree.parent v)) - p (gatedCenter d v) ≤ 1 := by
  have hcard := deletedSubtreeCut_card d hs (two_connected_as_k hc) v hv
  obtain ⟨b, hb⟩ := Finset.card_pos.mp (show 0 < (deletedSubtreeCut d v).card by omega)
  have hh := gated_foreign_parent_drop_bound d hp v b hb
  have hbin := gated_head_selector_binary d P p hp (d.anchor b)
  omega

theorem gated_nonroot_split_drop_bounds (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {p : GatedVertex d → ℤ} (hp : GatedDualFeasible d P p)
    (v : d.tree.Child) (hv : d.tree.parent v ≠ d.tree.root) :
    0 ≤ gatedPrefixDrop d p v ∧ 0 ≤ gatedSuffixDrop d p v ∧
      0 ≤ gatedRepresentativeDrop d p v ∧
      gatedPrefixDrop d p v + gatedSuffixDrop d p v + gatedRepresentativeDrop d p v ≤ 1 := by
  have hpref := gated_dual_prefix d hp v
  have hsuff := gated_dual_suffix d hp v
  have hrep := gated_dual_representative d hp v
  have htop := gated_nonroot_parent_drop_le_one d hs hc hp v hv
  unfold gatedPrefixDrop gatedSuffixDrop gatedRepresentativeDrop
  omega

theorem gated_nonroot_cuts_binary (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {p : GatedVertex d → ℤ} (hp : GatedDualFeasible d P p)
    (v : d.tree.Child) (hv : d.tree.parent v ≠ d.tree.root) :
    (gatedPrefixDrop d p v = 0 ∨ gatedPrefixDrop d p v = 1) ∧
    (gatedSuffixDrop d p v = 0 ∨ gatedSuffixDrop d p v = 1) ∧
    (gatedRepresentativeDrop d p v = 0 ∨ gatedRepresentativeDrop d p v = 1) ∧
    (gatedConnectorDrop d p v = 0 ∨ gatedConnectorDrop d p v = 1) := by
  have hb := gated_nonroot_split_drop_bounds d hs hc hp v hv
  have he := gated_split_drop_identity d p v
  omega

theorem gated_head_suffix_exclusive {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) :
    gatedHeadSelector d p v + gatedSuffixDrop d p v ≤ 1 := by
  have hh := hp (gatedPaidArc d v) (by simp [gatedUpper])
  have hpre := gated_dual_prefix d hp v
  simp only [gatedNetwork, gatedCost, gatedExtraSrc, gatedExtraDst,
    Sum.elim_inl, Sum.elim_inr] at hh
  norm_num at hh
  unfold gatedHeadSelector gatedSuffixDrop
  split_ifs at hh <;> omega

theorem gated_head_connector_exclusive {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) (v : d.tree.Child) (hv : ¬P.IsReceiver d v) :
    gatedHeadSelector d p v + gatedConnectorDrop d p v ≤ 1 := by
  have hh := hp (gatedPaidArc d v) (by simp [gatedUpper])
  simp [gatedNetwork, gatedCost, gatedExtraSrc, gatedExtraDst, hv] at hh
  unfold gatedHeadSelector gatedConnectorDrop
  omega

end TSP.Improvements20261105
