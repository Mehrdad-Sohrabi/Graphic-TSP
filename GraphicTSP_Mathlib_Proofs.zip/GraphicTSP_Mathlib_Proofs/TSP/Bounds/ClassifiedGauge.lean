import TSP.Improvements20261105.FreeClassifiedPoint
import TSP.Improvements20261105.ParityGauge
import TSP.Chapter10.ConnectorBounds

/-! The fixed tree-parity gauge. Its target is supported on majors because
the canonical binary tree lift is even at every minor vertex. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def classifiedTreeGauge {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) := classifiedMinorLift d hx hn hcap d.treeEdges

theorem classifiedTreeGauge_rep {G : Graph V E} (d : DFSData G)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V)
    (hcap : ∀ e, x e ≤ 1) (e : E) :
    Sum.inl e ∈ classifiedTreeGauge d hx hn hcap ↔ e ∈ d.treeEdges := by
  simp [classifiedTreeGauge, classifiedMinorLift, minorParityLift]

theorem classifiedTreeGauge_connector {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) (i : ClassifiedStarIndex d x) :
    Sum.inr i ∈ classifiedTreeGauge d hx hn hcap ↔
      (partialMain d hx hn hcap (partialCenter d x i) ≠ some i ∨
        Even (G.intDegree d.treeEdges (partialCenter d x i))) := by
  change Sum.inr i ∈ minorParityLift G (partialStars d x) (partialCenter d x)
    (partialMain d hx hn hcap) d.treeEdges ↔ _
  rw [minorParityLift_connector]
  by_cases hi : partialMain d hx hn hcap (partialCenter d x i) = some i
  · simp only [hi, ne_eq, not_true_eq_false, false_or, anchorIncidences, if_pos rfl, if_true]
    have hh := selected_star_complement_card G (partialStars d x) (partialCenter d x)
      (fun j => group_subset_center_cut d hsimple j.1.1) d.treeEdges i
    have htree : d.treeEdges ∩ partialStars d x i = {d.treeEdge i.1.1} := by
      rw [Finset.inter_comm]
      exact star_tree_inter d i.1
    rw [htree, Finset.card_singleton] at hh
    rw [loopless_intDegree G hsimple.1, Nat.even_iff, Nat.odd_iff]
    omega
  · simp only [anchorIncidences, if_neg hi, hi, ne_eq, not_false_eq_true, true_or,
      iff_true, if_false]
    have htree : d.treeEdges ∩ partialStars d x i = {d.treeEdge i.1.1} := by
      rw [Finset.inter_comm]
      exact star_tree_inter d i.1
    rw [htree]
    simp

theorem classifiedTreeGauge_target_subset {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) :
    (classifiedExpansion d x).oddVertices (classifiedTreeGauge d hx hn hcap) ⊆
      classifiedMajorSet d hx hn hcap := by
  intro v hv
  by_contra hm
  have he := classified_minor_lift_even d hsimple hx hn hcap d.treeEdges v hm
  have ho : Odd ((classifiedExpansion d x).intDegree (classifiedTreeGauge d hx hn hcap) v) :=
    (Finset.mem_filter.mp hv).2
  exact (Nat.not_even_iff_odd.mpr ho) he

theorem exists_free_partial_Q {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (htop : ∀ v, t v ≤ 1 - x (d.treeEdge v))
    (hsource : ∀ v, t v ≠ 0 → SurvivingPositive d x v)
    (hfree : ∀ v : d.tree.Child, ClassifiedCenter d x v →
      t v ≤ edgeSum x (minorBoundary d x v) - x (d.treeEdge v)) :
    ∃ Q : (E ⊕ ClassifiedStarIndex d x) → ℝ,
      Q ∈ joinPolytope (classifiedExpansion d x)
        ((classifiedExpansion d x).oddVertices Finset.univ)
        ((classifiedExpansion d x).intDegree Finset.univ) ∧
      (∀ e, Q (Sum.inl e) = halfComplementPoint d.treeEdges (fun e => 2 * treeIntervalValue d x t e) e) ∧
      (∀ i, Q (Sum.inr i) =
        if partialMain d hx hn hcap (partialCenter d x i) ≠ some i ∨
          Even (G.intDegree d.treeEdges (partialCenter d x i))
        then classifiedCapacity d hx hn hcap (Sum.inr i) / 2
        else 1 - classifiedCapacity d hx hn hcap (Sum.inr i) / 2) := by
  let B := classifiedTreeGauge d hx hn hcap
  let T := (classifiedExpansion d x).oddVertices B
  obtain ⟨M, hM, hbox, hrep, hanc⟩ := exists_free_classified_point d hsimple hx hn hcap T
    (classifiedTreeGauge_target_subset d hsimple hx hn hcap)
    (odd_vertices_card_even _ B) t ht htop hsource hfree
  have hnon : ∀ e, 0 ≤ classifiedCapacity d hx hn hcap e := by
    intro e
    cases e with
    | inl e => rw [classified_representative_capacity]; exact hx.1 e
    | inr i => exact (classified_anchor_capacity_bounds d hsimple hx hn hcap i).1
  have hMb : BoxConstraints M := by
    intro e
    have hb := hbox e
    have hn := hnon e
    constructor <;> linarith
  have hjoin := bounded_join_of_box_blossom (classifiedExpansion d x) T M hMb hM
  refine ⟨fullParityGauge B M, fullParityGauge_mem_oddJoin _ B M hjoin, ?_, ?_⟩
  · intro e
    simp only [fullParityGauge, B, classifiedTreeGauge_rep, hrep, halfComplementPoint]
    split_ifs <;> ring
  · intro i
    simp only [fullParityGauge, B, classifiedTreeGauge_connector d hsimple hx hn hcap i, hanc]

end TSP.Improvements20261105
