import TSP.Improvements20261105.CoveredPQConnector
import TSP.Improvements20261105.CoveredPQDeficit

/-! One actual P point and one actual Q point are constructed together
from the fixed cover. Every nonroot arm has the same shared reserve. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def pqConnectorArm (x : E → ℝ) (P Q : ℝ)
    (A Y : E ⊕ d.StarIndex → ℝ) (i : d.StarIndex) : ℝ :=
  (3 * P / 2) * (A (.inr i) - 1 / 3) + Q * (Y (.inr i) - edgeSum x (d.stars i) / 2)

noncomputable def pqDeficitArm (x : E → ℝ) (P Q : ℝ)
    (A Y : E ⊕ d.StarIndex → ℝ) (i : d.StarIndex) : ℝ :=
  (3 * P / 2) * ((d.stars i).card - 1 - edgeSum A (starRepresentatives d.stars i) - 1 / 3) +
    Q * ((d.stars i).card - 1 - edgeSum Y (starRepresentatives d.stars i) - edgeSum x (d.stars i) / 2)

theorem exists_fixed_PQ_base_points (hs : G.IsSimple) (hc : IsTwoVertexConnected G) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hPQ : Q ≤ P)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root) :
    ∃ C : ProjectedCoverWitness d x z P Q, ∃ A Y : E ⊕ d.StarIndex → ℝ,
      A ∈ projectedFrameworkTwo G d.centers owner ∧ Y ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ i : d.StarIndex, d.centers i ≠ d.tree.root →
        max (pqConnectorArm d x P Q A Y i) (pqDeficitArm d x P Q A Y i) ≤
          C.cover i.1 + P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1) := by
  obtain ⟨C⟩ := exists_fixed_projected_cover d hs x z hx hn hcap hm P Q hP hQ hPQ
  obtain ⟨Y, hY, hr, hb, hconn, _⟩ := exists_preliminary_Q d hs x hx hn hcap owner ho
  let delta : d.StarIndex → ℝ := fun i => coveredPIncrease d x P Q C.cover i.1
  let A := generalPoint d owner rootStar x delta
  have hA : A ∈ projectedFrameworkTwo G d.centers owner := by
    have hh := enlargedRepairPoint_feasible d hs hc owner ho rootStar hroot x hx hcap delta
      (coveredPIncrease_admissible d hs x z hx hn hcap hm P Q hP hQ C)
    rwa [Manuscript20261105.nonloopReconnectionLP_eq_projection] at hh
  refine ⟨C, A, Y, hA, hY, ?_⟩
  intro i hi
  apply max_le
  · have hh := coveredPQ_connector d hs x z hx hn hcap hm P Q hP hQ C owner ho rootStar hroot Y hconn i hi
    change pqConnectorArm d x P Q A Y i - P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 at hh
    linarith
  · have hh := coveredPQ_deficit d hs x z hx hn hcap hm P Q hP hQ C owner rootStar Y hr hb i hi
    change pqDeficitArm d x P Q A Y i - P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 at hh
    linarith

end TSP.Improvements20261105
