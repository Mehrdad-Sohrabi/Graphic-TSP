import TSP.Improvements20261105.GatedDependencyBudget

/-! Every bypass donor owns its tail, its designated gate and its own
outside backs. The ownership maps are injective on the actual tree. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem gate_owner_sum (P : GatePlan d) (hP : P.RespectsTree d) (q : d.tree.Child → ℝ) :
    (∑ s : d.tree.Child, if P.UsesGate d s then q (P.receiver s) else 0) =
      ∑ r : d.tree.Child, if P.IsReceiver d r then q r else 0 := by
  let S := Finset.univ.filter (P.UsesGate d)
  have himage : S.image P.receiver = Finset.univ.filter (P.IsReceiver d) := by
    ext r
    simp [S, GatePlan.IsReceiver]
  have hinj : Set.InjOn P.receiver S := by
    intro s hs t ht he
    exact gate_receiver_unique d P hP s t (Finset.mem_filter.mp hs).2 (Finset.mem_filter.mp ht).2 he
  have he := Finset.sum_image (f := q) hinj
  rw [himage] at he
  simpa only [S, Finset.sum_filter] using he.symm

noncomputable def GatedDrops.donorUse (P : GatePlan d) (a : GatedDrops d)
    (s : d.tree.Child) (b : BackEdge d) : ℝ :=
  (if d.lower b.1 = (s : V) then (a.tail s : ℝ) else 0) +
  (if P.UsesGate d s ∧ backConnectorPath d b (P.receiver s) then (a.pref (P.receiver s) : ℝ) else 0) +
  (if d.anchor b.1 = s ∧ P.OutsideBack d b then (a.outside s : ℝ) else 0)

noncomputable def GatedDrops.donorResource (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) (s : d.tree.Child) : ℝ := ∑ b : BackEdge d, x b * a.donorUse d P s b

theorem GatedDrops.donorUse_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (s : d.tree.Child) (b : BackEdge d) : 0 ≤ a.donorUse d P s b := by
  have ht : (0 : ℝ) ≤ a.tail s := by exact_mod_cast ha.tail_nonneg _
  have hp : (0 : ℝ) ≤ a.pref (P.receiver s) := by exact_mod_cast ha.pref_nonneg _
  have ho : (0 : ℝ) ≤ a.outside s := by exact_mod_cast ha.outside_nonneg _
  unfold donorUse
  split_ifs <;> linarith

theorem GatedDrops.gatePathTerm_sum (P : GatePlan d) (a : GatedDrops d) (b : BackEdge d) :
    (∑ w : (expandedTree d).Child, a.gatePathTerm d P b w) =
      ∑ v : d.tree.Child, if P.IsReceiver d v ∧ backConnectorPath d b v then (a.pref v : ℝ) else 0 := by
  rw [← (expandedTreeRoles d).sum_comp, Fintype.sum_sum_type]
  have hz : (∑ v : d.tree.Child, a.gatePathTerm d P b ((expandedTreeRoles d) (.inr v))) = 0 := by
    apply Finset.sum_eq_zero
    intro v _
    simp only [gatePathTerm, Equiv.symm_apply_apply]
    split_ifs <;> rfl
  rw [hz, add_zero]
  apply Finset.sum_congr rfl
  intro v _
  simp only [gatePathTerm, Equiv.symm_apply_apply]
  change (if onExpandedBackPath d b (expandedConnectorChild d v) then
    (if P.IsReceiver d v then (a.pref v : ℝ) else 0) else 0) = _
  rw [show onExpandedBackPath d b (expandedConnectorChild d v) ↔ backConnectorPath d b v
    from expanded_connector_back_path d b v]
  split_ifs <;> simp_all

theorem GatedDrops.donorUse_sum_le {P : GatePlan d} {a : GatedDrops d}
    (hP : P.RespectsTree d) (ha : a.Admissible d P) (b : BackEdge d) :
    (∑ s : d.tree.Child, a.donorUse d P s b) ≤ a.dependencyUse d P b := by
  have ht : (∑ s : d.tree.Child, if d.lower b.1 = (s : V) then (a.tail s : ℝ) else 0) ≤
      (a.tail (d.lower b.1) : ℝ) := by
    by_cases hr : d.lower b.1 = d.tree.root
    · have hh : ∀ s : d.tree.Child, d.lower b.1 ≠ (s : V) := fun s he => s.2 (he.symm.trans hr)
      simp only [if_neg (hh _), Finset.sum_const_zero]
      exact_mod_cast ha.tail_nonneg _
    · let s₀ : d.tree.Child := ⟨d.lower b.1, hr⟩
      rw [Finset.sum_eq_single s₀]
      · simp [s₀]
      · intro s _ hne
        have hn : d.lower b.1 ≠ (s : V) := fun he => hne (Subtype.ext he.symm)
        simp [hn]
      · simp
  have hp : (∑ s : d.tree.Child, if P.UsesGate d s ∧ backConnectorPath d b (P.receiver s)
        then (a.pref (P.receiver s) : ℝ) else 0) =
      ∑ w : (expandedTree d).Child, a.gatePathTerm d P b w := by
    rw [a.gatePathTerm_sum d P b]
    have h := gate_owner_sum d P hP (fun v => if backConnectorPath d b v then (a.pref v : ℝ) else 0)
    simpa only [ite_and] using h
  have ho : (∑ s : d.tree.Child, if d.anchor b.1 = s ∧ P.OutsideBack d b then (a.outside s : ℝ) else 0) =
      if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0 := by
    rw [Finset.sum_eq_single (d.anchor b.1)]
    · simp
    · intro s _ hne
      simp [Ne.symm hne]
    · simp
  simp only [donorUse, Finset.sum_add_distrib, dependencyUse]
  rw [hp, ho]
  linarith

theorem GatedDrops.total_donorResource_bound {P : GatePlan d} {a : GatedDrops d}
    (hP : P.RespectsTree d) (ha : a.Admissible d P)
    (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) :
    (∑ s : d.tree.Child, a.donorResource d P x s) ≤ a.internalSelectedBackMass d P x := by
  unfold donorResource
  rw [Finset.sum_comm]
  have h : (∑ b : BackEdge d, ∑ s : d.tree.Child, x b * a.donorUse d P s b) ≤
      ∑ b : BackEdge d, x b * a.dependencyUse d P b := by
    apply Finset.sum_le_sum
    intro b _
    rw [← Finset.mul_sum]
    exact mul_le_mul_of_nonneg_left (a.donorUse_sum_le d hP ha b) (hx b)
  exact h.trans (a.total_dependency_mass_bound d ha x hx)

end TSP.Improvements20261105
