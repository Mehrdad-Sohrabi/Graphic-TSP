import TSP.Improvements20261105.CriticalIncidenceFloor

/-! Exact critical-parent charge on the actual canonical components.
The singleton/no-child case has its separate clipped payment theorem. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 ScoredParameters Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_critical_parent_bound (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (C : Finset d.tree.Child)
    (hCH : C ⊆ a.componentHeads d P r) (hC : C.Nonempty)
    (hnonex : 0 < (a.componentEmptyChildren d hs hc P r).card ∨ 2 ≤ (a.componentHeads d P r).card)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e) (hscore : ScoreComparisons d x C)
    (q : d.tree.Child → ℝ) (hq : ∀ s ∈ a.componentHeads d P r, 0 ≤ q s)
    (hpack : ∀ s ∈ a.componentHeads d P r, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s ∈ a.componentHeads d P r, (d.backGroup s).card ≤ 3 →
      ∀ e ∈ d.backGroup s, z e ≤ q s) :
    24 * (1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card) ≤
      (∑ s ∈ C, rawCriticalIncidence d x z s) +
      (∑ s ∈ a.componentHeads d P r \ C, mixedNoncriticalIncidence d z s) -
      (162 / 19) * (G.internalEdges (headCenters d
        (a.componentHeads d P r \ countExcluded d (9 / 20) z (a.componentHeads d P r) C))).card +
      48 * (∑ v ∈ a.chosenLeaves d hs hc P r, leafProjectionLoss d x z v) := by
  have hi := canonical_signed_parent_incidence d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
    r C hCH hC hnonex x z hx hcap hz hzx q hq hpack hsmall
  have hm (v : V) (hv : v ∈ a.chosenLeaves d hs hc P r) :
      1 ≤ edgeSum x (d.backEdges.filter (fun e => d.lower e = v)) := by
    have hh := dfs_leaf_back_mass d hs hx hcap ⟨v, a.chosenLeaf_nonroot d hs hc P r v hv⟩
      (a.chosenLeaves_are_leaves d hs hc P r v hv)
    simpa only [edgeSum, Finset.sum_filter] using hh
  have hp := score_parent_incidence d hs x z hx.1 hz hzx C hscore
    (a.chosenLeaves d hs hc P r) (a.componentHeads d P r) hCH
    (a.chosenLeaves_heads_in d hs hc ha r) hm
  rw [a.chosenLeaves_card d hs hc P r] at hp
  exact combine_signed_score_incidence d x z (a.componentHeads d P r) C hCH _ _ _
    (Finset.sum_nonneg (fun v _ => leafProjectionLoss_nonneg d x z hzx v)) hi hp

end TSP.Improvements20261105
