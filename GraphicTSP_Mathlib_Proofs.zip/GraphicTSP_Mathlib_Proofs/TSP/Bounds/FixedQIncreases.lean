import TSP.Improvements20261105.FullFreeQ

/-! The fixed preliminary increase min(E,o), and full terminal endpoints.
The terminal set is fixed before the selector and can be any collection
of surviving heads with headless receiving vertices. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def survivingExcess {G : Graph V E} (d : DFSData G)
    (x : E → ℝ) (v : d.tree.Child) : ℝ :=
  max (edgeSum x (d.backGroup v) - 1 - degreeExcess G x (d.tree.parent v)) 0

theorem survivingExcess_bounds {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (v : d.tree.Child) :
    0 ≤ survivingExcess d x v ∧ survivingExcess d x v ≤ 1 - x (d.treeEdge v) := by
  have hm : edgeSum x (d.group v) ≤ edgeSum x (G.cut {d.tree.parent v}) :=
    Finset.sum_le_sum_of_subset_of_nonneg (group_subset_center_cut d hsimple v)
      (fun e _ _ => hx.1 e)
  rw [group_mass_eq_tree_add_backs d x v] at hm
  refine ⟨le_max_right _ _, max_le ?_ ?_⟩
  · unfold degreeExcess
    linarith
  · linarith [hcap (d.treeEdge v)]

theorem survivingExcess_positive {G : Graph V E} (d : DFSData G)
    (x : E → ℝ) (v : d.tree.Child) (he : 0 < survivingExcess d x v) :
    SurvivingPositive d x v := by
  unfold survivingExcess at he
  have hh := (lt_max_iff.mp he).resolve_right (lt_irrefl _)
  unfold SurvivingPositive
  linarith

noncomputable def preliminaryQIncrease {G : Graph V E} (d : DFSData G)
    (x : E → ℝ) (v : d.tree.Child) : ℝ :=
  if d.tree.parent v = d.tree.root then 0 else
    min (survivingExcess d x v) (outgoingBackMass d x v)

theorem preliminaryQIncrease_bounds {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (v : d.tree.Child) :
    0 ≤ preliminaryQIncrease d x v ∧ preliminaryQIncrease d x v ≤ 1 - x (d.treeEdge v) ∧
      preliminaryQIncrease d x v ≤ outgoingBackMass d x v ∧
      preliminaryQIncrease d x v ≤ survivingExcess d x v := by
  have he := survivingExcess_bounds d hsimple hx hcap v
  have ho : 0 ≤ outgoingBackMass d x v := Finset.sum_nonneg (fun e _ => hx.1 e)
  unfold preliminaryQIncrease
  split_ifs
  · exact ⟨le_rfl, by linarith [hcap (d.treeEdge v)], ho, he.1⟩
  · exact ⟨le_min he.1 ho, (min_le_left _ _).trans he.2, min_le_right _ _, min_le_left _ _⟩

noncomputable def fixedQIncrease {G : Graph V E} (d : DFSData G)
    (x : E → ℝ) (terminal : Finset d.tree.Child) (v : d.tree.Child) : ℝ :=
  if v ∈ terminal then 1 - x (d.treeEdge v) else preliminaryQIncrease d x v

theorem fixedQIncrease_admissible {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (terminal : Finset d.tree.Child)
    (hterminal : ∀ v ∈ terminal, SurvivingPositive d x v ∧
      ∀ i : d.StarIndex, d.centers i ≠ (v : V)) :
    (∀ v, 0 ≤ fixedQIncrease d x terminal v) ∧
    (∀ v, fixedQIncrease d x terminal v ≤ 1 - x (d.treeEdge v)) ∧
    (∀ v, fixedQIncrease d x terminal v ≠ 0 → SurvivingPositive d x v) ∧
    (∀ v : d.tree.Child, ClassifiedCenter d x v → fixedQIncrease d x terminal v ≤
      edgeSum x (minorBoundary d x v) - x (d.treeEdge v)) := by
  have hb : ∀ v, 0 ≤ fixedQIncrease d x terminal v ∧
      fixedQIncrease d x terminal v ≤ 1 - x (d.treeEdge v) := by
    intro v
    unfold fixedQIncrease
    split_ifs
    · exact ⟨sub_nonneg.mpr (hcap _), le_rfl⟩
    · have hp := preliminaryQIncrease_bounds d hsimple hx hcap v
      exact ⟨hp.1, hp.2.1⟩
  refine ⟨fun v => (hb v).1, fun v => (hb v).2, ?_, ?_⟩
  · intro v hv
    by_cases ht : v ∈ terminal
    · exact (hterminal v ht).1
    · rw [fixedQIncrease, if_neg ht] at hv
      have hp := preliminaryQIncrease_bounds d hsimple hx hcap v
      apply survivingExcess_positive d x v
      exact (lt_of_le_of_ne hp.1 (Ne.symm hv)).trans_le hp.2.2.2
  · intro v hv
    have ht : v ∉ terminal := by
      intro hvt
      exact headless_unclassified d hx hn hcap v (hterminal v hvt).2 hv
    rw [fixedQIncrease, if_neg ht]
    exact (preliminaryQIncrease_bounds d hsimple hx hcap v).2.2.1.trans
      (outgoing_le_other_boundary_mass d hsimple hx.1 v hv)

theorem fixed_free_Q_exists {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (owner : E → Option d.StarIndex) (howner : ValidOwner d.stars owner)
    (terminal : Finset d.tree.Child)
    (hterminal : ∀ v ∈ terminal, SurvivingPositive d x v ∧
      ∀ i : d.StarIndex, d.centers i ≠ (v : V)) :
    ∃ Q : (E ⊕ d.StarIndex) → ℝ,
      Q ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ v, Q (Sum.inl (d.treeEdge v)) = x (d.treeEdge v) / 2 + fixedQIncrease d x terminal v) ∧
      (∀ e ∈ d.backEdges, Q (Sum.inl e) = 1 - x e / 2) ∧
      (∀ i : ClassifiedStarIndex d x, Q (Sum.inr i.1) =
        if partialMain d hx hn hcap (partialCenter d x i) ≠ some i ∨
          Even (G.intDegree d.treeEdges (partialCenter d x i))
        then classifiedCapacity d hx hn hcap (Sum.inr i) / 2
        else 1 - classifiedCapacity d hx hn hcap (Sum.inr i) / 2) ∧
      (∀ i : d.StarIndex, ¬ClassifiedCenter d x (d.centers i) →
        Q (Sum.inr i) ≤ edgeSum x (d.stars i) / 2) := by
  obtain ⟨ht, htop, hsource, hfree⟩ := fixedQIncrease_admissible d hsimple hx hn hcap terminal hterminal
  obtain ⟨Q, hQ, hrep, hc, hu⟩ := exists_full_free_Q d hsimple hx hn hcap owner howner
    (fixedQIncrease d x terminal) ht htop hsource hfree
  refine ⟨Q, hQ, ?_, ?_, hc, hu⟩
  · intro v
    have htree : d.treeEdge v ∈ d.treeEdges := Finset.mem_image.mpr ⟨v, Finset.mem_univ _, rfl⟩
    rw [hrep, halfComplementPoint, if_pos htree, treeIntervalValue_tree]
    ring
  · intro e he
    have hnot := (Finset.mem_sdiff.mp he).2
    rw [hrep, halfComplementPoint, if_neg hnot, treeIntervalValue_off_tree d x _ e hnot]
    ring

end TSP.Improvements20261105
