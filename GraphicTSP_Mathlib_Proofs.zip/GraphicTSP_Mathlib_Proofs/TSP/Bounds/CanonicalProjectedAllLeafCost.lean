import TSP.Improvements20261105.NoPairLeafFamilyCost
import TSP.Improvements20261105.NoPairGuardAccounting
import TSP.Improvements20261105.SharedNoPairLeafReserves
import TSP.Improvements20261105.CanonicalClippedLeafCouponCost
import TSP.Improvements20261105.ProjectedPaidLeafCost
import TSP.Improvements20261105.ProjectedKLeafFamilyCost
import TSP.Improvements20261105.ProjectedMultiplePairLeafCost
import TSP.Improvements20261105.ProjectedLargeRemainingLeafFamilyCost
import TSP.Improvements20261105.ProjectedSolePairLeafFamilyCost
import TSP.Improvements20261105.EnlargedOneExtraBackLeafFamilyCost
import TSP.Improvements20261105.EnlargedTwoBackSingleLeafFamilyCost
import TSP.Improvements20261105.TwoOneBackLeafFamilyCost
import TSP.Improvements20261105.TwoOneBackLeafDisjoint
import TSP.Improvements20261105.SharedTwoHeadLeafError
import TSP.Improvements20261105.CanonicalOneExtraBackLeafCost
import TSP.Improvements20261105.TwoBackSingleLeafFamilyCost
import TSP.Improvements20261105.TwoBackSingleLeafDisjoint
import TSP.Improvements20261105.SharedTwoBackLeafError
import TSP.Improvements20261105.LeafProjectionConversion
import TSP.Improvements20261105.OneExtraBackLeafFamilyCost
import TSP.Improvements20261105.OneExtraBackLeafDisjoint
import TSP.Improvements20261105.SharedLeafError
import TSP.Improvements20261105.SolePairLeafFamilyCost
import TSP.Improvements20261105.SolePairLeafDisjoint

/-! The single-extra-head/two-back family is removed from the actual
global ledger. Every entry cut and original back budget is allocated
once. Geometric and erased-mass charges retain their explicit owners. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem canonical_projected_all_leaf_elimination (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (S : Finset (d).tree.Child) (hscore : ScoreComparisons d x S)
    (T : Finset (d).tree.Child) (hTS : T ⊆ S)
    (hT : ∀ s ∈ T, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (b : (d).tree.Child → ℝ) (hbcap : ∀ s, b s ≤ 1)
    (hbout : ∀ s, P.kind s = .outsideGate → b s ≤ outsideBackMass d P (fun e => x e.1) s)
    (q : (d).tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z ((d).backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, ((d).backGroup s).card ≤ 3 → ∀ e ∈ (d).backGroup s, z e ≤ q s)
    (hn : 2 ≤ Fintype.card V)
    (hprojection : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hrootStar : (d).centers rootStar = (d).tree.root)
    (R : E ⊕ (d).StarIndex → ℝ)
    (Q : E ⊕ (d).StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G (d).centers owner)
    (hrep : ∀ c, Q (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Q (.inl e) = 1-x e/2)
    (m : (d).StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x ((d).treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hmprojected : ∀ i ∈ projectedZeroTerminalHeads d z,
      (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
        max (x ((d).treeEdge i.1)-projectedZeroGuardCapacity d x z Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Q i)
    (hconn : FixedQConnectorValues d x hx hn hcap R)
    (hloss : ∀ i, edgeSum Q (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Q i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
      m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1)
    (hconnectors : ∀ i : (d).StarIndex, R (.inr i) = Q (.inr i))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1) :
    let L := a.paidLeafRoots d P x
    let J := a.paidLeafHeads d P x
    let KJ := pairStarHeads d (a.KLeafPairs d P x z C)
    let ML := a.multiplePairLeafRoots d P x z C
    let MJ := pairStarHeads d (a.matchingPairsForRoots d P x z C ML)
    let LL := a.largeRemainingLeafRoots d P x z C
    let LJ := a.componentStarUnion d P LL
    let SL := a.solePairLeafRoots d P x z C
    let SJ := a.componentStarUnion d P SL
    let EL := a.oneExtraBackLeafRoots d P x z C
    let EJ := a.componentStarUnion d P EL
    let BL := a.twoBackSingleLeafRoots d P x z C
    let BJ := a.componentStarUnion d P BL
    let DL := a.twoBackTwoHeadLeafRoots d P x z C
    let DJ := a.componentStarUnion d P DL
    let NL := a.noPairLeafRoots d P x z C
    let NJ := a.componentStarUnion d P NL
    let U := projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x
    let J0 := a.componentStarUnion d P (a.zeroLeafRoots d P x)
    let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
    48*a.value d P (fun _ => 0)+(∑ i : (d).StarIndex, cost i)-
      (704/5 : ℝ)*(∑ i ∈ U, m i) ≤
      (∑ s ∈ a.selectedHeads d,
        (24*(edgeSum z ((d).backGroup s)-gatedFreeBase d s)+refinedIncidenceCharge d x z S T s-
          24*accountedCoupon d P b s+24*couponResidual d P (fun e => x e.1) b s))+
      24*((a.headfulLeafComponents d P).card-L.card-(a.KLeafRoots d P x z C).card-ML.card-LL.card-SL.card-EL.card-BL.card-DL.card-NL.card-1-(a.selectedRootHeads d).card)-
      (162/19)*(∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z S r : ℝ))+
      72*(∑ s ∈ a.selectedHeads d, ownProjectionLoss d x z s)+
      (244/5)*(edgeSum x Finset.univ-Fintype.card V)-12*Chapter11.totalOverage d x+
      (4*∑ i ∈ KJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ MJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ LJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ SJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ EJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ BJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ DJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ NJ, (((d).backGroup i.1).card : ℝ))+
      (48*∑ i ∈ NJ, fixedRemoval d x (allFullOverrideTargets d x) i.1)+
      (24*∑ i ∈ BJ, fixedRemoval d x (allFullOverrideTargets d x) i.1)+
      (∑ i ∈ Finset.univ \ ((((((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) ∪ EJ) ∪ BJ) ∪ DJ) ∪ NJ), cost i)-
      (704/5 : ℝ)*(∑ i ∈ U \ (a.paidLeafGuardHeads d P x ∪ NJ.filter (fun i => i ∈ U)), m i)+
      (∑ r ∈ (((a.zeroLeafRoots d P x ∪ EL) ∪ BL) ∪ DL) ∪ NL, a.componentOwnedError d P x r) := by
  let J := a.paidLeafHeads d P x
  let KJ := pairStarHeads d (a.KLeafPairs d P x z C)
  let ML := a.multiplePairLeafRoots d P x z C
  let MJ := pairStarHeads d (a.matchingPairsForRoots d P x z C ML)
  let LL := a.largeRemainingLeafRoots d P x z C
  let LJ := a.componentStarUnion d P LL
  let SL := a.solePairLeafRoots d P x z C
  let SJ := a.componentStarUnion d P SL
  let EL := a.oneExtraBackLeafRoots d P x z C
  let EJ := a.componentStarUnion d P EL
  let BL := a.twoBackSingleLeafRoots d P x z C
  let BJ := a.componentStarUnion d P BL
  let DL := a.twoBackTwoHeadLeafRoots d P x z C
  let DJ := a.componentStarUnion d P DL
  let NL := a.noPairLeafRoots d P x z C
  let NJ := a.componentStarUnion d P NL
  let U := projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x
  let J0 := a.componentStarUnion d P (a.zeroLeafRoots d P x)
  let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
  let SW := a.componentEntryCuts d P SL
  let EW := a.componentEntryCuts d P EL
  let BW := a.componentEntryCuts d P BL
  let DW := a.componentEntryCuts d P DL
  let NW := a.componentEntryCuts d P NL
  let W := ((((a.paidLeafCuts d P x ∪ SW) ∪ EW) ∪ BW) ∪ DW) ∪ NW
  have hW : W ⊆ a.trueCuts d P := Finset.union_subset
    (Finset.union_subset
    (Finset.union_subset
      (Finset.union_subset
        (Finset.union_subset (a.paidLeafCuts_subset d P x) (a.componentEntryCuts_subset d P SL))
        (a.componentEntryCuts_subset d P EL))
      (a.componentEntryCuts_subset d P BL))
    (a.componentEntryCuts_subset d P DL)) (a.componentEntryCuts_subset d P NL)
  have hentry := a.solePairLeafRoots_entry d P x z C
  have hcutdis := a.solePairLeafCuts_disjoint_paid d P x z C
  have hentryE := a.oneExtraBackLeafRoots_entry d P x z C
  have hcutdisE : Disjoint EW (a.paidLeafCuts d P x ∪ SW) := Finset.disjoint_union_right.mpr
    ⟨a.oneExtraBackLeafCuts_disjoint_paid d P x z C,a.oneExtraBackLeafCuts_disjoint_sole d P x z C⟩
  have hentryB := a.twoBackSingleLeafRoots_entry d P x z C
  have hcutdisB : Disjoint BW ((a.paidLeafCuts d P x ∪ SW) ∪ EW) := Finset.disjoint_union_right.mpr
    ⟨Finset.disjoint_union_right.mpr ⟨a.twoBackSingleLeafCuts_disjoint_paid d P x z C,
      a.twoBackSingleLeafCuts_disjoint_sole d P x z C⟩,a.twoBackSingleLeafCuts_disjoint_one_extra d P x z C⟩
  have hentryD := a.twoBackTwoHeadLeafRoots_entry d P x z C
  have hcutdisD : Disjoint DW (((a.paidLeafCuts d P x ∪ SW) ∪ EW) ∪ BW) :=
    Finset.disjoint_union_right.mpr ⟨Finset.disjoint_union_right.mpr
      ⟨Finset.disjoint_union_right.mpr ⟨a.twoBackTwoHeadLeafCuts_disjoint_paid d P x z C,
        a.twoBackTwoHeadLeafCuts_disjoint_sole d P x z C⟩,
        a.twoBackTwoHeadLeafCuts_disjoint_one_extra d P x z C⟩,
        a.twoBackTwoHeadLeafCuts_disjoint_single d P x z C⟩
  have hentryN := a.noPairLeafRoots_entry d P x z C
  have hcutdisN : Disjoint NW ((((a.paidLeafCuts d P x ∪ SW) ∪ EW) ∪ BW) ∪ DW) :=
    a.noPairLeafCuts_disjoint_prior d P x z C
  have hledger := canonical_clipped_leaf_coupon_cost_ledger d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
    x z hx hcap hz hzx S hscore T hTS hT b hbcap hbout W hW q hq hpack hsmall
  dsimp only [W,SW,EW,BW,DW,NW,SL,EL,BL,DL,NL] at hledger
  rw [Finset.sum_union hcutdisN.symm,Finset.card_union_of_disjoint hcutdisN.symm,
    Finset.sum_union hcutdisD.symm,Finset.card_union_of_disjoint hcutdisD.symm,
    Finset.sum_union hcutdisB.symm,Finset.card_union_of_disjoint hcutdisB.symm,
    Finset.sum_union hcutdisE.symm,Finset.card_union_of_disjoint hcutdisE.symm,
    Finset.sum_union hcutdis.symm,Finset.card_union_of_disjoint hcutdis.symm,
    a.paidLeafCuts_sum d P x (fun r => 24*(2-max (componentEntryCoverage d x r) 1)),
    a.componentEntryCuts_sum d P _ hentry (fun r => 24*(2-max (componentEntryCoverage d x r) 1)),
    a.componentEntryCuts_sum d P _ hentryE (fun r => 24*(2-max (componentEntryCoverage d x r) 1)),
    a.componentEntryCuts_sum d P _ hentryB (fun r => 24*(2-max (componentEntryCoverage d x r) 1)),
    a.componentEntryCuts_sum d P _ hentryD (fun r => 24*(2-max (componentEntryCoverage d x r) 1)),
    a.componentEntryCuts_sum d P _ hentryN (fun r => 24*(2-max (componentEntryCoverage d x r) 1)),
    a.paidLeafCuts_card d P x,a.componentEntryCuts_card d P _ hentry,
    a.componentEntryCuts_card d P _ hentryE,a.componentEntryCuts_card d P _ hentryB,a.componentEntryCuts_card d P _ hentryD,a.componentEntryCuts_card d P _ hentryN] at hledger
  simp only [Nat.cast_add] at hledger
  have hbase : FixedQConnectorValues d x hx hn hcap Q := by
    constructor
    · intro i
      exact (hconnectors i.1).symm.trans (hconn.1 i)
    · intro i hi
      rw [← hconnectors i]
      exact hconn.2 i hi
  have hpaid := a.projected_current_paid_leaf_cost d hs P hP t ht f hf hb ha hcan x z hx hn hcap
    hprojection C owner ho rootStar hrootStar R Q hQ hrep hbacks m hm0 hm hguarded hconn hloss hmpositive
  have hK := scoredDFS_projected_K_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar R hconn Q hrep hbacks hloss hterminal P a ha
  have hM := scoredDFS_projected_multiple_pair_leaf_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hconn hrep hbacks hloss hterminal hguarded P a ha
  have hL := scoredDFS_projected_large_remaining_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hconn hrep hbacks hloss hterminal hguarded P hP t ht f hf hb a ha hcan
  have hS := scoredDFS_projected_sole_pair_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hconn hrep hbacks hloss hterminal hguarded P hP t ht f hf hb a ha hcan
  have hE := enlarged_scoredDFS_one_extra_back_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hQ hconn hrep hbacks hloss hterminal hguarded P hP t ht f hf hb a ha hcan
  have hB := enlarged_scoredDFS_two_back_single_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hQ hconn hrep hbacks hloss hterminal hguarded P hP t ht f hf hb a ha hcan
  have hD := scoredDFS_two_one_back_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hQ hconn hrep hbacks hloss hterminal hguarded P hP t ht f hf hb a ha hcan
  have hN := scoredDFS_no_pair_leaf_family_cost G x z hs hconnected root hx hn hcap hprojection C
    owner ho rootStar hrootStar Q R hbase hconn hrep hbacks hloss hterminal hguarded P hP t ht f hf hb a ha hcan
    m hmprojected hmpositive
  have hdK : Disjoint KJ J := a.KLeafHeads_disjoint_paid d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hdM : Disjoint MJ (J ∪ KJ) := a.multiplePairHeads_disjoint_prior d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hdL : Disjoint LJ ((J ∪ KJ) ∪ MJ) := a.largeRemainingLeafHeads_disjoint d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hdS : Disjoint SJ (((J ∪ KJ) ∪ MJ) ∪ LJ) := a.solePairLeafHeads_disjoint d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hdE : Disjoint EJ ((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) := a.oneExtraBackLeafHeads_disjoint d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hdB : Disjoint BJ (((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) ∪ EJ) := a.twoBackSingleLeafHeads_disjoint d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hdD : Disjoint DJ ((((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) ∪ EJ) ∪ BJ) :=
    Finset.disjoint_union_right.mpr
      ⟨a.twoBackTwoHeadLeafHeads_disjoint_prior d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan,
        a.componentStarUnion_disjoint d P _ _ (a.twoBackTwoHeadLeafRoots_disjoint_single d P x z C)⟩
  have hdN : Disjoint NJ (((((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) ∪ EJ) ∪ BJ) ∪ DJ) :=
    a.noPairLeafHeads_disjoint_prior d hs x z hx hn hcap hprojection C P hP t ht f hf hb ha hcan
  have hsum := Finset.sum_sdiff (Finset.subset_univ ((((((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) ∪ EJ) ∪ BJ) ∪ DJ) ∪ NJ)) (f := cost)
  rw [Finset.sum_union hdN.symm,Finset.sum_union hdD.symm,Finset.sum_union hdB.symm,Finset.sum_union hdE.symm,Finset.sum_union hdS.symm,Finset.sum_union hdL.symm,Finset.sum_union hdM.symm,Finset.sum_union hdK.symm] at hsum
  have hmass := a.projected_guard_mass_no_pair_partition d P x z hx hn hzx C m
  dsimp only at hmass
  have herrors := a.all_leaf_error_identity d P x z C
  dsimp only [J,KJ,ML,MJ,LL,LJ,SL,SJ,EL,EJ,BL,BJ,DL,DJ,NL,NJ,U,J0,cost] at hsum
  dsimp only at hM hL hS hE hB hD hN ⊢
  have hclip (F : Finset (FlowVertex d)) :
      (∑ r ∈ F, 24*(2-max (componentEntryCoverage d x r) 1)) ≤
        ∑ r ∈ F, 24*(2-componentEntryCoverage d x r) := by
    apply Finset.sum_le_sum
    intro r hr
    have hh := le_max_left (componentEntryCoverage d x r) (1 : ℝ)
    linarith only [hh]
  have hclipPaid := hclip (a.paidLeafRoots d P x)
  have hclipS := hclip (a.solePairLeafRoots d P x z C)
  have hclipE := hclip (a.oneExtraBackLeafRoots d P x z C)
  have hclipB := hclip (a.twoBackSingleLeafRoots d P x z C)
  linarith only [hledger,hpaid,hK,hM,hL,hS,hE,hB,hD,hN,hsum,hmass,herrors,
    hclipPaid,hclipS,hclipE,hclipB]

end TSP.Improvements20261105
