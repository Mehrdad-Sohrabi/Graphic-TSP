import TSP.Improvements20261105.CanonicalDropCoordinates

/-! A canonical optimum forbids a feasible coordinate deletion that does
not lower the objective and removes a selected head. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem gatedCutCount_mono (P : GatePlan d) (p q : GatedVertex d → ℤ)
    (hpre : ∀ v, gatedPrefixDrop d q v ≤ gatedPrefixDrop d p v)
    (hsuf : ∀ v, gatedSuffixDrop d q v ≤ gatedSuffixDrop d p v)
    (hrep : ∀ v, gatedRepresentativeDrop d q v ≤ gatedRepresentativeDrop d p v) :
    gatedCutCount d P q ≤ gatedCutCount d P p := by
  apply Finset.card_le_card
  intro a ha
  simp only [Finset.mem_filter, Finset.mem_univ, true_and] at ha ⊢
  refine ⟨ha.1, ?_⟩
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · have hh := hsuf v
    unfold gatedSuffixDrop at hh
    simpa only [gatedNetwork, Sum.elim_inl] using
      (show p (gatedAux d v) < p (gatedGate d v) by
        have h := ha.2
        change q (gatedAux d v) < q (gatedGate d v) at h
        omega)
  · have hh := hrep v
    unfold gatedRepresentativeDrop at hh
    have h := ha.2
    change q (gatedCenter d v) < q (gatedAux d v) at h
    change p (gatedCenter d v) < p (gatedAux d v)
    omega
  · simpa [gatedLower] using ha.1
  · simpa [gatedLower] using ha.1
  · have hk : k = 0 := by
      by_contra hn
      simpa [gatedLower, hn] using ha.1
    subst k
    have hh := hpre v
    unfold gatedPrefixDrop at hh
    have h := ha.2
    change q (gatedGate d v) < q (gatedCenter d (d.tree.parent v)) at h
    change p (gatedGate d v) < p (gatedCenter d (d.tree.parent v))
    omega

theorem canonical_drops_no_head_deletion (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a b : GatedDrops d) (ha : a.Admissible d P) (hb' : b.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (hp : ∀ v, b.pref v ≤ a.pref v) (hs : ∀ v, b.suffix v ≤ a.suffix v)
    (hr : ∀ v, b.representative v ≤ a.representative v)
    (hh : ∀ v, b.head v ≤ a.head v)
    (hval : a.value d P t ≤ b.value d P t)
    (s : d.tree.Child) (hsa : a.head s = 1) (hsb : b.head s = 0) : False := by
  have hbetter : realCapacityDualValue (gatedNetwork d P) (fun e => (gatedCost d e : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (a.potential d P v : ℝ)) ≤
      realCapacityDualValue (gatedNetwork d P) (fun e => (gatedCost d e : ℤ))
        (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (b.potential d P v : ℝ)) := by
    simpa only [a.potential_value d P hP t ha, b.potential_value d P hP t hb'] using hval
  have hopt := gated_optimal_of_improvement d P t f hf hb (a.potential d P) (b.potential d P)
    hcan.1 (b.potential_feasible d P hb') hbetter
  have hprele : gatedPrefixCount d P (b.potential d P) ≤ gatedPrefixCount d P (a.potential d P) := by
    apply Finset.card_le_card
    intro v hv
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, GatedDrops.potential_prefix] at hv ⊢
    exact ⟨hv.1, hv.2.trans_le (hp v)⟩
  have hpre := le_antisymm hprele (hcan.2.1 _ hopt)
  have hcutle : gatedCutCount d P (b.potential d P) ≤ gatedCutCount d P (a.potential d P) := by
    apply gatedCutCount_mono
    · simpa using hp
    · simpa using hs
    · simpa using hr
  have hcuts := le_antisymm hcutle (hcan.2.2.1 _ hopt hpre)
  have hheadlt : gatedSelectedHeadCount d (b.potential d P) < gatedSelectedHeadCount d (a.potential d P) := by
    apply Finset.card_lt_card
    apply Finset.ssubset_iff_subset_ne.mpr
    constructor
    · intro v hv
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, GatedDrops.potential_headSelector] at hv ⊢
      have hv' := hh v
      have hbin := a.head_binary d ha v
      omega
    · intro heq
      have hsm : s ∈ Finset.univ.filter (fun v : d.tree.Child => gatedHeadSelector d (a.potential d P) v = 1) := by
        simp [hsa]
      rw [← heq] at hsm
      simpa [hsb] using hsm
  have hmin := hcan.2.2.2 _ hopt hpre hcuts
  omega

end TSP.Improvements20261105
