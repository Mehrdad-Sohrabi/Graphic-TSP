import TSP.Improvements20261105.ScoreParentIncidence

/-! Combine signed and scored incidence at the exact general-bound
parameters. The free parent margin pays 96/19 per critical selected head
while retaining the 162/19 head-center edge credit. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 ScoredParameters Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def headScoreSum (x z : E → ℝ) (s : d.tree.Child) : ℝ :=
  ∑ e ∈ d.backGroup s, perBackPayment (d.backGroup s).card (winningBenchmark d x s) (z e)

noncomputable def rawCriticalIncidence (x z : E → ℝ) (s : d.tree.Child) : ℝ :=
  (360 / 19) * signedStarIncidence d (9 / 20) z s + (96 / 19) * headScoreSum d x z s - 96 / 19

noncomputable def mixedNoncriticalIncidence (z : E → ℝ) (s : d.tree.Child) : ℝ :=
  (360 / 19) * min (((d.backGroup s).card : ℝ) - 1) (signedStarIncidence d (9 / 20) z s) +
  (96 / 19) * min (((d.backGroup s).card : ℝ) - 1) (massSlope * edgeSum z (d.backGroup s) - 1)

theorem fixedHeadPayment_critical (x z : E → ℝ) (C : Finset d.tree.Child)
    (s : d.tree.Child) (hs : s ∈ C) : fixedHeadPayment d x z C s = headScoreSum d x z s := by
  apply Finset.sum_congr rfl
  intro e he
  have ha := (d.mem_group s e).mp (Finset.mem_sdiff.mp he).1
  simp only [fixedBackPayment, ha, if_pos hs, scoreArm, perBackPayment]

theorem signedHeadCharge_split (mu : ℝ) (z : E → ℝ) (H C : Finset d.tree.Child)
    (hCH : C ⊆ H) :
    (∑ s ∈ H, signedHeadCharge d mu z C s) = (∑ s ∈ C, signedStarIncidence d mu z s) +
      ∑ s ∈ H \ C, min (((d.backGroup s).card : ℝ) - 1) (signedStarIncidence d mu z s) := by
  rw [← Finset.sum_sdiff (f := signedHeadCharge d mu z C) hCH, add_comm]
  congr 1
  · exact Finset.sum_congr rfl (fun s hs => by simp [signedHeadCharge, hs])
  · exact Finset.sum_congr rfl (fun s hs => by simp [signedHeadCharge, (Finset.mem_sdiff.mp hs).2])

theorem combine_signed_score_incidence (x z : E → ℝ) (H C : Finset d.tree.Child)
    (hCH : C ⊆ H) (A delta e : ℝ) (hd : 0 ≤ delta)
    (hinc : A ≤ (∑ s ∈ H, signedHeadCharge d (9 / 20) z C s) - 4 / 15 - (9 / 20) * e + 2 * delta)
    (hscore : A ≤ (∑ s ∈ C, fixedHeadPayment d x z C s) +
      (∑ s ∈ H \ C, min (((d.backGroup s).card : ℝ) - 1) (massSlope * edgeSum z (d.backGroup s) - 1)) -
      ((C.card : ℝ) - 1) + massSlope * delta) :
    24 * A ≤ (∑ s ∈ C, rawCriticalIncidence d x z s) +
      (∑ s ∈ H \ C, mixedNoncriticalIncidence d z s) - (162 / 19) * e + 48 * delta := by
  rw [signedHeadCharge_split d (9 / 20) z H C hCH] at hinc
  have hp : (∑ s ∈ C, fixedHeadPayment d x z C s) = ∑ s ∈ C, headScoreSum d x z s :=
    Finset.sum_congr rfl (fun s hs => fixedHeadPayment_critical d x z C s hs)
  rw [hp] at hscore
  have hcrit : (∑ s ∈ C, rawCriticalIncidence d x z s) =
      (360 / 19) * (∑ s ∈ C, signedStarIncidence d (9 / 20) z s) +
      (96 / 19) * (∑ s ∈ C, headScoreSum d x z s) - (96 / 19) * C.card := by
    simp only [rawCriticalIncidence, Finset.sum_sub_distrib, Finset.sum_add_distrib,
      ← Finset.mul_sum, Finset.sum_const, nsmul_eq_mul]
    ring
  have hnon : (∑ s ∈ H \ C, mixedNoncriticalIncidence d z s) =
      (360 / 19) * (∑ s ∈ H \ C, min (((d.backGroup s).card : ℝ) - 1) (signedStarIncidence d (9 / 20) z s)) +
      (96 / 19) * (∑ s ∈ H \ C, min (((d.backGroup s).card : ℝ) - 1) (massSlope * edgeSum z (d.backGroup s) - 1)) := by
    simp only [mixedNoncriticalIncidence, Finset.sum_add_distrib, ← Finset.mul_sum]
  rw [hcrit, hnon]
  norm_num only [massSlope] at hscore ⊢
  linarith

end TSP.Improvements20261105
