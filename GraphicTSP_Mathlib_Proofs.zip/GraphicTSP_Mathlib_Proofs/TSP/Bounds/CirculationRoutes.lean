import TSP.Improvements20261105.CirculationDual

/-! Route one directed graph's arcs through another graph. The endpoint
balance and cost identities transport nonnegative-circulation certificates. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E W A : Type} [Fintype V] [Fintype E] [Fintype W] [Fintype A]
  [DecidableEq V] [DecidableEq E] [DecidableEq W] [DecidableEq A]

def flowDivergence (N : Graph V E) (f : E → ℝ) (v : V) : ℝ :=
  arcSum N.src f v - arcSum N.dst f v

noncomputable def routeFlow (route : A → E → ℝ) (g : A → ℝ) (e : E) : ℝ :=
  ∑ a, g a * route a e

theorem arcSum_routeFlow (endpoint : E → V) (route : A → E → ℝ) (g : A → ℝ) (v : V) :
    arcSum endpoint (routeFlow route g) v = ∑ a, g a * arcSum endpoint (route a) v := by
  unfold arcSum routeFlow
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  by_cases h : endpoint e = v
  · simp [h]
  · simp [h]

theorem flowDivergence_routeFlow (N : Graph V E) (route : A → E → ℝ) (g : A → ℝ) (v : V) :
    flowDivergence N (routeFlow route g) v = ∑ a, g a * flowDivergence N (route a) v := by
  simp only [flowDivergence, arcSum_routeFlow, mul_sub, Finset.sum_sub_distrib]

theorem routeFlow_nonneg (route : A → E → ℝ) (g : A → ℝ)
    (hr : ∀ a e, 0 ≤ route a e) (hg : ∀ a, 0 ≤ g a) (e : E) : 0 ≤ routeFlow route g e :=
  Finset.sum_nonneg (fun a _ => mul_nonneg (hg a) (hr a e))

theorem routeFlow_cost (route : A → E → ℝ) (c : E → ℝ) (h : A → ℝ) :
    (∑ e, c e * routeFlow route h e) = ∑ a, h a * (∑ e, c e * route a e) := by
  unfold routeFlow
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro e _
  ring

theorem routeFlow_balanced (N : Graph V E) (H : Graph W A) (φ : W → V)
    (route : A → E → ℝ)
    (hr : ∀ a v, flowDivergence N (route a) v =
      (if φ (H.src a) = v then 1 else 0) - (if φ (H.dst a) = v then 1 else 0))
    (g : A → ℝ) (hg : Balanced H g) : Balanced N (routeFlow route g) := by
  intro v
  apply sub_eq_zero.mp
  change flowDivergence N (routeFlow route g) v = 0
  rw [flowDivergence_routeFlow]
  simp_rw [hr]
  have hh := balanced_potential_sum H g hg (fun w => if φ w = v then (1 : ℝ) else 0)
  simp only [mul_sub, Finset.sum_sub_distrib] at hh ⊢
  linarith

theorem route_transport_nonnegative_cost (N : Graph V E) (H : Graph W A) (φ : W → V)
    (route : A → E → ℝ) (c : E → ℝ) (d : A → ℝ)
    (hn : ∀ a e, 0 ≤ route a e)
    (hr : ∀ a v, flowDivergence N (route a) v =
      (if φ (H.src a) = v then 1 else 0) - (if φ (H.dst a) = v then 1 else 0))
    (hcost : ∀ a, ∑ e, c e * route a e = d a)
    (hN : ∀ f : E → ℝ, (∀ e, 0 ≤ f e) → Balanced N f → 0 ≤ ∑ e, c e * f e) :
    ∀ g : A → ℝ, (∀ a, 0 ≤ g a) → Balanced H g → 0 ≤ ∑ a, d a * g a := by
  intro g hg hb
  have hh := hN (routeFlow route g) (routeFlow_nonneg route g hn hg)
    (routeFlow_balanced N H φ route hr g hb)
  rw [routeFlow_cost route c g] at hh
  simp_rw [hcost, mul_comm] at hh
  exact hh

end TSP.Improvements20261105
