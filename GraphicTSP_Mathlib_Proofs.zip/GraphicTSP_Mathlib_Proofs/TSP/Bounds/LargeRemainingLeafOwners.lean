import TSP.Improvements20261105.RemainingLeafOwners

/-! Large remaining leaf families are selected by original back counts.
They exclude every previously paid component, so their whole-component
budgets cannot overlap any earlier pair or head charge. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.largeRemainingLeafRoots (P : GatePlan d) (a : GatedDrops d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5)) : Finset (FlowVertex d) :=
  ((a.headfulLeafComponents d P).image (fun r : a.Component d P => (r : FlowVertex d))).filter
    (fun r => r ≠ .inl d.tree.root ∧ r ∉ a.paidLeafRoots d P x ∧
      r ∉ a.KLeafRoots d P x z C ∧ r ∉ a.multiplePairLeafRoots d P x z C ∧
      ((a.matchingPairsAt d P x z C r = ∅ ∧
        (6 : ℝ) ≤ ∑ i ∈ a.actualComponentStars d P r, ((d.backGroup i.1).card : ℝ)) ∨
       ((a.matchingPairsAt d P x z C r).card = 1 ∧
        (3 : ℝ) ≤ ∑ i ∈ a.actualComponentStars d P r \ pairStarHeads d (a.matchingPairsAt d P x z C r),
          ((d.backGroup i.1).card : ℝ))))

theorem GatedDrops.largeRemainingLeafRoots_disjoint (P : GatePlan d) (a : GatedDrops d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    Disjoint (a.largeRemainingLeafRoots d P x z C)
      ((a.paidLeafRoots d P x ∪ a.KLeafRoots d P x z C) ∪ a.multiplePairLeafRoots d P x z C) := by
  apply Finset.disjoint_left.mpr
  intro r hr hp
  have hh := (Finset.mem_filter.mp hr).2
  rcases Finset.mem_union.mp hp with hp | hp
  · rcases Finset.mem_union.mp hp with hp | hp
    · exact hh.2.1 hp
    · exact hh.2.2.1 hp
  · exact hh.2.2.2.1 hp

theorem GatedDrops.largeRemainingLeafHeads_disjoint (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P)) :
    Disjoint (a.componentStarUnion d P (a.largeRemainingLeafRoots d P x z C))
      ((a.paidLeafHeads d P x ∪ pairStarHeads d (a.KLeafPairs d P x z C)) ∪
        pairStarHeads d (a.matchingPairsForRoots d P x z C (a.multiplePairLeafRoots d P x z C))) := by
  have hdis := a.componentStarUnion_disjoint d P _ _ (a.largeRemainingLeafRoots_disjoint d P x z C)
  have hkheads := a.KLeafHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
  have hmheads := a.matchingPairHeads_subset_starUnion d hs x z hx hn hcap hm C P hP t ht f hf hb ha hcan
    (a.multiplePairLeafRoots d P x z C)
  apply Finset.disjoint_left.mpr
  intro i hi hj
  apply Finset.disjoint_left.mp hdis hi
  rcases Finset.mem_union.mp hj with hj | hmj
  · rcases Finset.mem_union.mp hj with hp | hk
    · rw [a.paidLeafHeads_eq_starUnion d P x] at hp
      obtain ⟨r,hr,hir⟩ := Finset.mem_biUnion.mp hp
      exact Finset.mem_biUnion.mpr ⟨r,Finset.mem_union_left _ (Finset.mem_union_left _ hr),hir⟩
    · obtain ⟨r,hr,hir⟩ := Finset.mem_biUnion.mp (hkheads hk)
      exact Finset.mem_biUnion.mpr ⟨r,Finset.mem_union_left _ (Finset.mem_union_right _ hr),hir⟩
  · obtain ⟨r,hr,hir⟩ := Finset.mem_biUnion.mp (hmheads hmj)
    exact Finset.mem_biUnion.mpr ⟨r,Finset.mem_union_right _ hr,hir⟩

end TSP.Improvements20261105
