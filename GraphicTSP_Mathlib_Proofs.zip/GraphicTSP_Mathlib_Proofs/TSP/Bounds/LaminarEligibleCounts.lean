import TSP.Improvements20261105.EligibleBinary
import TSP.Improvements20261105.LaminarMarkedCounting

/-! Local half-rank charges for eligible, nonpartitionable singleton leaves. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter10
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def markedSingletons (B : Finset V) : Finset (Finset V) :=
  B.image (fun v => ({v} : Finset V))

noncomputable def nontightShores (G : Graph V E) (x : E → ℝ) (L : LaminarSystem V) :
    Finset (Finset V) := L.family.filter (fun A => edgeSum x (G.cut A) ≠ 2)

theorem marked_children_card_lt {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (L : LaminarSystem V)
    (hroot : L.root = d.tree.root)
    (htight : ∀ A ∈ L.family, 2 ≤ A.card → A ≠ L.top → edgeSum x (G.cut A) = 2)
    (B : Finset V) (hB : ∀ v ∈ B, EligibleVertex d x v)
    (A : Finset V) (hA : A ∈ L.family) (hcard : 2 ≤ A.card) :
    (L.children A ∩ markedSingletons B).card < (L.children A).card := by
  have hex : ∃ v ∈ A, 1 ≤ ancestorMass d x v := by
    by_cases htop : A = L.top
    · have hh := top_shore_has_ineligible d hx hn
      simpa only [htop, LaminarSystem.top, hroot] using hh
    · exact tight_shore_has_ineligible d hx A hcard
        ⟨L.root, Finset.mem_compl.mpr (L.avoids A hA)⟩ (htight A hA hcard htop)
  obtain ⟨v, hv, hmass⟩ := hex
  obtain ⟨C, hC, hvC⟩ := L.exists_child_containing hA hcard hv
  have hnot : C ∉ markedSingletons B := by
    intro hc
    obtain ⟨w, hw, hcw⟩ := Finset.mem_image.mp hc
    have hvw : v = w := Finset.mem_singleton.mp (hcw.symm ▸ hvC)
    subst v
    exact (not_lt_of_ge hmass) (hB w hw).2
  apply Finset.card_lt_card
  refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.inter_subset_left, ?_⟩
  intro heq
  have hc : C ∈ L.children A ∩ markedSingletons B := by rw [heq]; exact hC
  exact hnot (Finset.mem_inter.mp hc).2

theorem binary_marked_has_nontight_child {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (L : LaminarSystem V)
    (hroot : L.root = d.tree.root)
    (htight : ∀ A ∈ L.family, 2 ≤ A.card → A ≠ L.top → edgeSum x (G.cut A) = 2)
    (B : Finset V) (hB : ∀ v ∈ B, EligibleVertex d x v ∧ ¬PartitionableVertex G x v)
    (A : Finset V) (hA : A ∈ L.family) (hcard : 2 ≤ A.card)
    (hd : (L.children A).card = 2)
    (hm : (L.children A ∩ markedSingletons B).Nonempty) :
    (L.children A ∩ nontightShores G x L).Nonempty := by
  obtain ⟨C, hC⟩ := hm
  obtain ⟨hchild, hcmark⟩ := Finset.mem_inter.mp hC
  obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hcmark
  have hsibling := L.binary_singleton_sibling hA hcard hd v hchild
  by_cases hvT : edgeSum x (G.cut {v}) = 2
  · by_cases hsT : edgeSum x (G.cut (A.erase v)) = 2
    · exfalso
      by_cases htop : A = L.top
      · have hsT' : edgeSum x (G.cut (({d.tree.root}ᶜ : Finset V).erase v)) = 2 := by
          simpa only [htop, LaminarSystem.top, hroot] using hsT
        have hh := top_erase_tight_ineligible d hx hn v (hB v hv).1.1 hsT'
        exact (not_lt_of_ge hh) (hB v hv).1.2
      · have hvA : v ∈ A := (Finset.ssubset_iff_subset_ne.mp (L.child_spec hchild).2.1).1
          (Finset.mem_singleton_self v)
        exact (hB v hv).2 (tight_binary_partition G x A v hvA (htight A hA hcard htop) hsT hvT)
    · exact ⟨A.erase v, Finset.mem_inter.mpr ⟨hsibling,
        Finset.mem_filter.mpr ⟨(L.child_spec hsibling).1, hsT⟩⟩⟩
  · exact ⟨{v}, Finset.mem_inter.mpr ⟨hchild,
      Finset.mem_filter.mpr ⟨(L.child_spec hchild).1, hvT⟩⟩⟩

theorem eligible_local_half_rank {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (L : LaminarSystem V)
    (hroot : L.root = d.tree.root)
    (htight : ∀ A ∈ L.family, 2 ≤ A.card → A ≠ L.top → edgeSum x (G.cut A) = 2)
    (B : Finset V) (hB : ∀ v ∈ B, EligibleVertex d x v ∧ ¬PartitionableVertex G x v)
    (A : Finset V) (hA : A ∈ L.internalNodes) :
    (L.children A ∩ markedSingletons B).card ≤
      2 * ((L.children A).card - 2) + (L.children A ∩ nontightShores G x L).card := by
  have ha := Finset.mem_filter.mp hA
  have hd := L.internal_two_children ha.1 ha.2
  have hk := marked_children_card_lt d hx hn L hroot htight B (fun v hv => (hB v hv).1)
    A ha.1 ha.2
  by_cases htwo : (L.children A).card = 2
  · by_cases hz : (L.children A ∩ markedSingletons B).card = 0
    · omega
    · have hm : (L.children A ∩ markedSingletons B).Nonempty := Finset.card_pos.mp (by omega)
      have hs := Finset.card_pos.mpr
        (binary_marked_has_nontight_child d hx hn L hroot htight B hB A ha.1 ha.2 htwo hm)
      omega
  · omega

theorem eligible_marked_count {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 3 ≤ Fintype.card V) (L : LaminarSystem V)
    (hroot : L.root = d.tree.root)
    (htight : ∀ A ∈ L.family, 2 ≤ A.card → A ≠ L.top → edgeSum x (G.cut A) = 2)
    (B : Finset V) (hB : ∀ v ∈ B, EligibleVertex d x v ∧ ¬PartitionableVertex G x v) :
    B.card ≤ 2 * L.deficiency + (nontightShores G x L).card := by
  have hM : markedSingletons B ⊆ L.family := by
    intro C hC
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hC
    exact L.singleton_mem v (by simpa only [hroot] using (hB v hv).1.1)
  have htop : L.top ∉ markedSingletons B := by
    intro hm
    obtain ⟨v, hv, he⟩ := Finset.mem_image.mp hm
    have hc : L.top.card + 1 = Fintype.card V := by
      dsimp [LaminarSystem.top]
      have hh := Finset.card_compl ({L.root} : Finset V)
      simp only [Finset.card_singleton] at hh
      omega
    rw [← he, Finset.card_singleton] at hc
    omega
  have hs := L.marked_bound_of_local (markedSingletons B) (nontightShores G x L) hM
    (Finset.filter_subset _ _) htop
    (eligible_local_half_rank d hx (by omega) L hroot htight B hB)
  simpa only [markedSingletons, Finset.card_image_of_injective _ Finset.singleton_injective] using hs

end TSP.Improvements20261105
