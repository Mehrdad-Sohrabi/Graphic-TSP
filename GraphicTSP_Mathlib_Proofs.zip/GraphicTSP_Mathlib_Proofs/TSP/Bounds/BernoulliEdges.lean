import TSP.Improvements20261105.SimultaneousLabelCoupling
import TSP.Graph

/-! An explicit finite independent-edge distribution for coordinates in
the unit cube. Used only on edges with no minor endpoint. -/
namespace TSP.Improvements20261105
open Graph Classical
open scoped BigOperators
variable {E : Type} [Fintype E] [DecidableEq E]

noncomputable def bernoulliEdgeWeight (m : E → ℝ) (b : E → Bool) : ℝ :=
  ∏ e, if b e = true then m e else 1 - m e

def bernoulliEdgeSet (b : E → Bool) : Finset E := Finset.univ.filter (fun e => b e = true)

theorem bernoulliEdgeWeight_nonneg (m : E → ℝ) (hm : ∀ e, 0 ≤ m e ∧ m e ≤ 1) (b : E → Bool) :
    0 ≤ bernoulliEdgeWeight m b := by
  apply Finset.prod_nonneg
  intro e _
  split_ifs
  · exact (hm e).1
  · exact sub_nonneg.mpr (hm e).2

theorem bernoulliEdgeWeight_sum (m : E → ℝ) : ∑ b, bernoulliEdgeWeight m b = 1 := by
  unfold bernoulliEdgeWeight
  rw [← Fintype.prod_sum (fun (e : E) (b : Bool) => if b = true then m e else 1 - m e)]
  have hs : ∀ e, (∑ b : Bool, if b = true then m e else 1 - m e) = 1 := by
    intro e
    simp
  simp_rw [hs]
  simp

theorem bernoulliEdge_marginal (m : E → ℝ) (e : E) :
    ∑ b, bernoulliEdgeWeight m b * incidence (bernoulliEdgeSet b) e = m e := by
  have hs : ∀ e', (∑ b : Bool, if b = true then m e' else 1 - m e') = 1 := by
    intro e'
    simp
  have hh := product_probability_coordinate (fun e' b => if b = true then m e' else 1 - m e') hs e true
  simpa [bernoulliEdgeWeight, bernoulliEdgeSet, incidence] using hh

end TSP.Improvements20261105
