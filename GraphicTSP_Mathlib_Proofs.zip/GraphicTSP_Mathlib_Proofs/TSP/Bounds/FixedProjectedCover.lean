import TSP.Improvements20261105.ProjectedMatchingWeights
import TSP.Improvements20261105.FullFloorTreeLinks
import TSP.Improvements20261105.FullFloorTightness
import TSP.Improvements20261105.CappedCoverFeasibility

/-! Construct the entire fixed, source-capped cover from the actual
projected graph. Its matching and cost identities are conclusions. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

structure ProjectedCoverWitness (x z : E → ℝ) (P Q : ℝ) where
  matching : Finset d.tree.Child
  cover : d.tree.Child → ℝ
  link_subset : matching ⊆ projectionLinks d x
  matching_endpoints : ∀ s ∈ matching, ∀ t ∈ matching, ∀ a,
    (a = s ∨ a = unaryNext d s) → (a = t ∨ a = unaryNext d t) → s = t
  floor_bound : ∀ s, fixedCoverFloor d x z Q s ≤ cover s
  edge_bound : ∀ s ∈ projectionLinks d x, fixedCoverEdge d x P Q s ≤ cover s + cover (unaryNext d s)
  source_cap : ∀ s ∈ matching, cover s ≤ (P - Q) * (x (d.treeEdge s) + survivingExcess d x s)
  source_excess : ∀ s ∈ matching, outgoingBackMass d x s < survivingExcess d x s
  pair_cost : ∀ s ∈ matching, cover s + cover (unaryNext d s) =
    P * survivingExcess d x s - Q - P * outgoingBackMass d x s
  unmatched_floor : ∀ s ∉ matchingEndpoints id (unaryNext d) matching, cover s = fixedCoverFloor d x z Q s
  total_cost : (∑ s, cover s) =
    (∑ s ∈ Finset.univ \ matchingEndpoints id (unaryNext d) matching, fixedCoverFloor d x z Q s) +
    ∑ s ∈ matching, (P * survivingExcess d x s - Q - P * outgoingBackMass d x s)

theorem exists_fixed_projected_cover (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (hPQ : Q ≤ P) :
    Nonempty (ProjectedCoverWitness d x z P Q) := by
  let floor := fixedCoverFloor d x z Q
  let ell := fixedCoverEdge d x P Q
  let cap : d.tree.Child → ℝ := fun s => (P - Q) * (x (d.treeEdge s) + survivingExcess d x s)
  obtain ⟨M, c, hsub, hmatch, hpos, hf, hc, hsum⟩ :=
    full_floor_tree_links d (projectionLinks d x) (unaryNext d) (projectionLinks_parent d x) floor ell
  have hloop (s : d.tree.Child) (hsM : s ∈ M) : id s ≠ unaryNext d s := by
    intro he
    have hpar := projectionLinks_parent d x s (hsub hsM)
    have hd := d.tree.parent_depth (unaryNext d s) (unaryNext d s).2
    change s = unaryNext d s at he
    rw [hpar, ← he] at hd
    omega
  obtain ⟨_, hnext, hdis⟩ := matching_endpoint_disjointness id (unaryNext d) M hloop hmatch
  have hd : Disjoint M (M.image (unaryNext d)) := by simpa using hdis
  have hcapfloor (s : d.tree.Child) (hsM : s ∈ M) : floor s ≤ cap s := by
    apply (fixedCoverFloor_nonpositive d hs x z hx hcap Q hQ s).trans
    exact mul_nonneg (sub_nonneg.mpr hPQ)
      (add_nonneg (hx.1 _) (survivingExcess_bounds d hs hx hcap s).1)
  have hin (s : d.tree.Child) (hlink : s ∈ projectionLinks d x) (ht : unaryNext d s ∈ M) :
      ell s ≤ floor s + cap (unaryNext d s) := by
    have htpos := projectionLink_source_positive d hs x z hx hn hm (unaryNext d s) (hsub ht)
    have hh := projected_predecessor_cap d hs x z hx hn hcap hm P Q hP.le hQ s hlink htpos
    change ell s - floor s ≤ cap (unaryNext d s) at hh
    linarith
  let c' := cappedMatchingCover M (unaryNext d) c cap
  obtain ⟨hf', hc', hcap'⟩ := cappedMatchingCover_feasible (projectionLinks d x) M (unaryNext d)
    floor ell c cap hd hnext hf hc hcapfloor hin
  have hsum' : (∑ s, c' s) = (∑ s, floor s) + ∑ s ∈ M, (ell s - floor s - floor (unaryNext d s)) :=
    (cappedMatchingCover_sum M (unaryNext d) c cap).trans hsum
  obtain ⟨htight, hunmatched⟩ := full_floor_tightness_on id (unaryNext d) M hloop hmatch floor c' ell
    hf' (fun s hsM => hc' s (hsub hsM)) hsum'
  have hraw (s : d.tree.Child) (hsM : s ∈ M) : outgoingBackMass d x s < survivingExcess d x s ∧
      ell s = P * survivingExcess d x s - Q - P * outgoingBackMass d x s := by
    have hh := positive_projected_matching_edge d hs x z hx hn hcap hm P Q hP hQ s (hsub hsM) (hpos s hsM)
    exact ⟨hh.1, hh.2.2⟩
  refine ⟨⟨M, c', hsub, hmatch, hf', hc', hcap', fun s hsM => (hraw s hsM).1,
    fun s hsM => (htight s hsM).trans (hraw s hsM).2, hunmatched, ?_⟩⟩
  have hp := full_floor_cost_partition id (unaryNext d) M hloop hmatch floor c' ell hsum'
  rw [hp]
  congr 1
  exact Finset.sum_congr rfl (fun s hsM => (hraw s hsM).2)

end TSP.Improvements20261105
