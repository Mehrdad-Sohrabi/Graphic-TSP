import TSP.Improvements20261105.CriticalIncidenceCombination
import TSP.Improvements20261105.GatedDeficitBudget
import TSP.Improvements20261105.OldParentIncidence

/-! The whole-incidence floor pays only the actual singleton exception.
Its membership test agrees with the raw test whenever the floor is
nonpositive and the noncritical envelope is nonnegative. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 ScoredParameters Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def noncriticalIncidence (z : E → ℝ) (s : d.tree.Child) : ℝ :=
  max (24 * oldIncidence d z s) (mixedNoncriticalIncidence d z s)

noncomputable def clippedCriticalIncidence (x z : E → ℝ) (s : d.tree.Child) : ℝ :=
  max (rawCriticalIncidence d x z s) (-(124 / 5) * (2 - edgeSum z (d.backGroup s)))

noncomputable def fixedCriticalHeads (x z : E → ℝ) (eligible : Finset d.tree.Child) : Finset d.tree.Child :=
  eligible.filter (fun s => clippedCriticalIncidence d x z s ≤ noncriticalIncidence d z s)

theorem noncriticalIncidence_nonneg (z : E → ℝ) (s : d.tree.Child) (hs : 1 ≤ (d.backGroup s).card) :
    0 ≤ noncriticalIncidence d z s :=
  (mul_nonneg (by norm_num) (oldIncidence_nonneg d z s hs)).trans (le_max_left _ _)

theorem critical_floor_membership_eq_raw (x z : E → ℝ) (s : d.tree.Child)
    (hs : 1 ≤ (d.backGroup s).card) (ha : edgeSum z (d.backGroup s) ≤ 2) :
    clippedCriticalIncidence d x z s ≤ noncriticalIncidence d z s ↔
      rawCriticalIncidence d x z s ≤ noncriticalIncidence d z s := by
  have hn := noncriticalIncidence_nonneg d z s hs
  have hf : -(124 / 5 : ℝ) * (2 - edgeSum z (d.backGroup s)) ≤ 0 := by linarith
  exact ⟨fun h => (le_max_left _ _).trans h, fun h => max_le h (hf.trans hn)⟩

theorem fixedCriticalHeads_mem (x z : E → ℝ) (eligible : Finset d.tree.Child)
    (s : d.tree.Child) (hs : s ∈ eligible) :
    (if s ∈ fixedCriticalHeads d x z eligible then clippedCriticalIncidence d x z s else noncriticalIncidence d z s) =
      min (clippedCriticalIncidence d x z s) (noncriticalIncidence d z s) := by
  by_cases hh : clippedCriticalIncidence d x z s ≤ noncriticalIncidence d z s
  · simp [fixedCriticalHeads, hs, hh, min_eq_left hh]
  · simp [fixedCriticalHeads, hs, hh, min_eq_right (le_of_not_ge hh)]

theorem ownBackMass_original (x : E → ℝ) (s : d.tree.Child) :
    ownBackMass d (fun b => x b.1) s = edgeSum x (d.backGroup s) := by
  unfold ownBackMass
  simp_rw [back_anchor_iff_group]
  exact original_back_subset_sum d x _ (fun e he => ((d.mem_backGroup_iff s e).mp he).1)

theorem canonical_singleton_clipped_payment (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : FlowVertex d) (s : d.tree.Child) (hheads : a.componentHeads d P r = {s})
    (x z : E → ℝ) (hx : ∀ e, 0 ≤ x e) (hzx : ∀ e, z e ≤ x e) :
    0 ≤ clippedCriticalIncidence d x z s + 48 * (edgeSum x (d.backGroup s) - edgeSum z (d.backGroup s)) +
      (124 / 5) * a.outgoingDeficit d P (fun b => x b.1) r := by
  have hshort := canonical_singleton_parent_mass_shortfall d hs hc P hP t ht f hf hb a ha hcan
    r s hheads (fun b => x b.1) (fun b => z b.1) (fun b => hx b.1)
  simp only [ownBackMass_original] at hshort
  have hfloor : -(124 / 5 : ℝ) * (2 - edgeSum z (d.backGroup s)) ≤ clippedCriticalIncidence d x z s :=
    le_max_right _ _
  have hrem : edgeSum z (d.backGroup s) ≤ edgeSum x (d.backGroup s) :=
    Finset.sum_le_sum (fun e _ => hzx e)
  linarith

end TSP.Improvements20261105
