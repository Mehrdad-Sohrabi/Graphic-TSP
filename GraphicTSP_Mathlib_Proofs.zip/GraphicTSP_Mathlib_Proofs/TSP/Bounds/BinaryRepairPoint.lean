import TSP.Improvements20261105.BinaryBypassCuts
import TSP.Chapter10.OneThirdCriterion
import TSP.Improvements20261105.ParityGauge

/-! The binary one-third point of every simultaneously bypassed cycle union. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter05 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def binaryRepairPoint (D : Finset E) (e : E) : ℝ :=
  if e ∈ D then 1 / 3 else 1

theorem binaryRepairPoint_box (D : Finset E) (e : E) :
    (1 / 3 : ℝ) ≤ binaryRepairPoint D e ∧ binaryRepairPoint D e ≤ 1 := by
  unfold binaryRepairPoint
  split_ifs <;> norm_num

theorem binaryRepairPoint_cutBlossom (G : Graph V E) (D : Finset E)
    (hcut : ∀ U : Finset V, (D ∩ G.cut U).card ≠ 1) :
    CutBlossomConstraints G (binaryRepairPoint D) := by
  apply cutBlossom_of_oneThird_deficits G _ (binaryRepairPoint_box D)
  intro U e he
  by_cases hed : e ∈ D
  · have hin : e ∈ D ∩ G.cut U := Finset.mem_inter.mpr ⟨hed, he⟩
    have hpos : 0 < (D ∩ G.cut U).card := Finset.card_pos.mpr ⟨e, hin⟩
    have htwo : 1 < (D ∩ G.cut U).card := by have hh := hcut U; omega
    obtain ⟨f, hf, hne⟩ := Finset.exists_mem_ne htwo e
    have hpair := pair_deficit_le_cut (binaryRepairPoint D) (G.cut U) e f he
      (Finset.mem_inter.mp hf).2 (Ne.symm hne) (fun a _ => (binaryRepairPoint_box D a).2)
    have heq : binaryRepairPoint D e = 1 / 3 := if_pos hed
    have hfq : binaryRepairPoint D f = 1 / 3 := if_pos (Finset.mem_inter.mp hf).1
    rw [heq, hfq] at hpair
    rw [heq]
    linarith
  · have heq : binaryRepairPoint D e = 1 := if_neg hed
    rw [heq, sub_self, mul_zero]
    exact Finset.sum_nonneg (s := G.cut U)
      (fun a _ => sub_nonneg.mpr (binaryRepairPoint_box D a).2)

theorem binaryRepairPoint_join (G : Graph V E) (D : Finset E)
    (hcut : ∀ U : Finset V, (D ∩ G.cut U).card ≠ 1) :
    binaryRepairPoint D ∈ joinPolytope G (G.oddVertices Finset.univ) (G.intDegree Finset.univ) := by
  apply bounded_join_of_box_blossom
  · intro e
    have hb := binaryRepairPoint_box D e
    exact ⟨by linarith, hb.2⟩
  · exact (oddGraph_blossom_iff G _).mpr (binaryRepairPoint_cutBlossom G D hcut)

theorem bypassed_binary_point_feasible {G : Graph V E} (d : DFSData G)
    (B : Finset E) (hB : B ⊆ d.backEdges) (R : Finset d.tree.Child)
    (hown : ∀ v ∈ R, ∃ b₁ ∈ B, ∃ b₂ ∈ B,
      b₁ ≠ b₂ ∧ OwnReturn d v b₁ ∧ OwnReturn d v b₂)
    (hwitness : ∀ v ∈ R, BypassWitness d B v) :
    binaryRepairPoint (binaryRetained d B R) ∈
      joinPolytope G (G.oddVertices Finset.univ) (G.intDegree Finset.univ) :=
  binaryRepairPoint_join G _ (binaryRetained_cut_not_singleton d B hB R hown hwitness)

end TSP.Improvements20261105
