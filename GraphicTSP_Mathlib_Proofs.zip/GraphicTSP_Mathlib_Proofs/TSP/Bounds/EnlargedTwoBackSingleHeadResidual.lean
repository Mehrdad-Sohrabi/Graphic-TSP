import TSP.Improvements20261105.EnlargedUnaryProjectedPrefixFloor
import TSP.Improvements20261105.EnlargedUnaryPositivePrefixFloor
import TSP.Improvements20261105.OneExtraBackGeometry
import TSP.Improvements20261105.BranchingPrefixCoverage
import TSP.Improvements20261105.UncrossedSourceCoverage
import TSP.Improvements20261105.ComponentOwnedError
import TSP.Improvements20261105.TwoBackScalar

/-! A leaf with one additional two-back head. Actual
cut coverage and the genuine unary floor pay the residual, retaining
24 times the removed mass explicitly for later disjoint conversion;
the projected-positive case is covered separately by its actual floor. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (P : GatePlan d) (hP : P.RespectsTree d)
variable (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
variable (hf : Chapter06.Balanced (gatedNetwork d P) f)
variable (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
variable (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

include hs hP ht hf hb ha hcan in
theorem GatedDrops.enlarged_two_back_single_head_residual (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : Y ∈ projectedFrameworkTwo G d.centers owner)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hguard : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (r : FlowVertex d) (hr : r ≠ .inl d.tree.root)
    (hmarker : r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P))
    (hout : a.componentOutgoingCuts d P r = ∅)
    (s : d.tree.Child) (hl : s ∈ projectionLinks d x)
    (hscomp : a.component d P (.inr s) = r)
    (w : d.StarIndex) (hI : a.sourceOtherLeafStars d P r s = {w})
    (hcount : (d.backGroup w.1).card = 2)
    (hunmatched : w.1 ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hgreedy : ∀ e ∈ d.backGroup w.1, x e ≤ x (d.treeEdge w.1))
    (hcost : guardedNormalizedHeadCost d x z C owner rootStar R a w ≤ 0) :
    24*(2-componentEntryCoverage d x r)+guardedNormalizedHeadCost d x z C owner rootStar R a w ≤
      24*(1-x (d.treeEdge s)-survivingExcess d x s)+(96/5 : ℝ)+a.componentOwnedError d P x r+
        24*fixedRemoval d x (allFullOverrideTargets d x) w.1 := by
  have hwI : w ∈ a.sourceOtherLeafStars d P r s := by rw [hI]; exact Finset.mem_singleton_self _
  have hwmem := (Finset.mem_filter.mp hwI).1
  have hwcomp := (Finset.mem_filter.mp hwmem).2
  have hnr := a.nonroot_component_head_center d P r hr w hwcomp
  have hgamma : 0 ≤ 1-x (d.treeEdge s)-survivingExcess d x s := by
    linarith [(survivingExcess_bounds d hs hx hcap s).2]
  have hsource := a.source_prefix_coverage d hs x hx P r hr hmarker hout s hl hscomp
  rw [hI,Finset.sum_singleton] at hsource
  have hsource' : 2-(1-x (d.treeEdge s)-survivingExcess d x s) ≤
      componentEntryCoverage d x r+edgeSum x (d.backGroup w.1) := by linarith only [hsource]
  have hgreedy' : edgeSum x (d.backGroup w.1) ≤ 2*x (d.treeEdge w.1) := by
    have hsum := Finset.sum_le_sum (fun e (he : e ∈ d.backGroup w.1) => hgreedy e he)
    simpa only [Finset.sum_const,hcount,nsmul_eq_mul,Nat.cast_ofNat] using hsum
  have hremoved := (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) w.1).1
  have hmass := hm w.1
  have herr0 := a.componentOwnedError_nonnegative d P x hx hn r
  by_cases hcross : ∃ e ∈ d.backGroup w.1,
      e ∈ G.cut (subtreeVertices d ⟨d.tree.parent s,(Finset.mem_filter.mp hl).2.1⟩)
  · obtain ⟨e,he,hecross⟩ := hcross
    have hheads : ∀ i ∈ a.actualComponentStars d P r, i.1 = s ∨ i.1 = unaryNext d s ∨ i = w := by
      intro i hi
      by_cases his : i.1 = s
      · exact Or.inl his
      · by_cases hir : i.1 = unaryNext d s
        · exact Or.inr (Or.inl hir)
        · have himem : i ∈ a.sourceOtherLeafStars d P r s := Finset.mem_filter.mpr ⟨hi,his,hir⟩
          rw [hI,Finset.mem_singleton] at himem
          exact Or.inr (Or.inr himem)
    have hfirst := a.one_extra_crossing_first d x P r s hl w hheads e he hecross
    by_cases hcenter : a.component d P (.inl (d.centers w)) = r
    · have howned := a.internal_center_error_owned d P x hx hn r (d.centers w) hcenter
      have hxi := degreeExcess_nonnegative G hx hn (d.centers w)
      by_cases hbranch : 2 ≤ childCount d (d.centers w)
      · have hprefix := a.branching_prefix_coverage d hs x hx P r hr hmarker hout w.1 hcenter hbranch hfirst
        change x (d.treeEdge w.1)+edgeSum x (d.backGroup w.1)-degreeExcess G x (d.centers w) ≤ _ at hprefix
        have hpay := two_back_branch_residual _ _ _ _ _ _ hgamma hsource' hgreedy' hprefix hcost
        linarith only [hpay,howned,hxi,hremoved]
      · have hcpos : 1 ≤ childCount d (d.centers w) := by
          apply Finset.card_pos.mpr
          exact ⟨w.1,Finset.mem_filter.mpr ⟨Finset.mem_univ _,rfl⟩⟩
        let v : d.tree.Child := ⟨d.centers w,hnr⟩
        have hunary : childCount d v = 1 := by change childCount d (d.centers w) = 1; omega
        by_cases hz0 : edgeSum z (d.backGroup w.1) ≤ 1
        · have hfloor := a.enlarged_unary_projected_zero_prefix_floor d hs P hP t ht f hf hb ha hcan x z hx hn hcap hm C
            owner ho rootStar hroot Y R hR hY hrep hbacks hloss hterminal hguard
            r w hwcomp hfirst v rfl hunary hz0
          have hsourceProj : 2-(1-x (d.treeEdge s)-survivingExcess d x s) ≤
              componentEntryCoverage d x r+edgeSum z (d.backGroup w.1)+
                fixedRemoval d x (allFullOverrideTargets d x) w.1 := by linarith only [hsource',hmass]
          have hgreedyProj : edgeSum z (d.backGroup w.1) ≤ 2*x (d.treeEdge w.1) := by
            linarith only [hgreedy',hmass,hremoved]
          have hpay := two_back_unary_projected_residual _ _ _ _ _ _ _ hsourceProj hgreedyProj hfloor
          linarith only [hpay,howned,hxi]
        · have hfloor := a.enlarged_unary_positive_prefix_floor d hs P hP t ht f hf hb ha hcan x z hx hn hcap hm C
            owner ho rootStar hroot Y R hR hrep hbacks hloss hterminal
            r w hwcomp hfirst v rfl hunary (lt_of_not_ge hz0) hunmatched
          have hq0 := hx.1 (d.treeEdge w.1)
          linarith only [hsource',hgreedy',hfloor,hq0,herr0,hremoved]
    · have hrw := a.outside_head_center_entry d P r w.1 hwcomp hcenter
      have hentry : componentEntryCoverage d x r = edgeSum x (deletedSubtreeCut d w.1) := by rw [hrw]; rfl
      have hprefix : x (d.treeEdge w.1)+edgeSum x (d.backGroup w.1)-enteringStarDeficit d x w.1 ≤
          componentEntryCoverage d x r := by
        have hh := le_max_left (edgeSum x (d.group w.1)-edgeSum x (deletedSubtreeCut d w.1)) (0 : ℝ)
        change edgeSum x (d.group w.1)-edgeSum x (deletedSubtreeCut d w.1) ≤ enteringStarDeficit d x w.1 at hh
        rw [group_mass_eq_tree_add_backs] at hh
        rw [hentry]
        linarith only [hh]
      have hpay := two_back_branch_residual _ _ _ _ _ _ hgamma hsource' hgreedy' hprefix hcost
      have howned := a.entering_star_error_owned d P x hx hn w.1
      rw [← hrw] at howned
      have he0 : 0 ≤ enteringStarDeficit d x w.1 := le_max_right _ _
      linarith only [hpay,howned,he0,hremoved]
  · have huncrossed : ∀ i ∈ a.sourceOtherLeafStars d P r s, ∀ b ∈ d.backGroup i.1,
        b ∉ G.cut (subtreeVertices d ⟨d.tree.parent s,(Finset.mem_filter.mp hl).2.1⟩) := by
      intro i hi b hb
      rw [hI,Finset.mem_singleton] at hi
      subst i
      intro hbcut
      exact hcross ⟨b,hb,hbcut⟩
    have hc := a.uncrossed_source_coverage d hs x hx P r hr hmarker hout s hl hscomp huncrossed
    linarith only [hc,hcost,herr0,hremoved]

end TSP.Improvements20261105
