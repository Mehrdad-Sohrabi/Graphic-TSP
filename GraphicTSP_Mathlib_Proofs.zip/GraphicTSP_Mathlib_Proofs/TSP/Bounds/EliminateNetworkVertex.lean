import TSP.Improvements20261105.CirculationRoutes

/-! Eliminate one vertex by composing each incoming and outgoing arc.
Nonnegative-circulation cost is preserved by explicit two-arc routes. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def singleArcFlow (e₀ : E) (e : E) : ℝ := if e = e₀ then 1 else 0

theorem singleArcFlow_divergence (N : Graph V E) (e : E) (v : V) :
    flowDivergence N (singleArcFlow e) v =
      (if N.src e = v then 1 else 0) - (if N.dst e = v then 1 else 0) := by
  have hh (endpoint : E → V) : arcSum endpoint (singleArcFlow e) v =
      if endpoint e = v then 1 else 0 := by
    unfold arcSum
    rw [Finset.sum_eq_single e]
    · simp [singleArcFlow]
    · intro a _ hne
      simp [singleArcFlow, hne]
    · simp
  simp only [flowDivergence, hh]

theorem singleArcFlow_cost (c : E → ℝ) (e : E) :
    (∑ f, c f * singleArcFlow e f) = c e := by simp [singleArcFlow]

theorem flowDivergence_add (N : Graph V E) (f g : E → ℝ) (v : V) :
    flowDivergence N (fun e => f e + g e) v =
      flowDivergence N f v + flowDivergence N g v := by
  simp only [flowDivergence, arcSum_add]
  ring

theorem loop_cost_nonnegative (N : Graph V E) (c : E → ℝ)
    (hN : ∀ f : E → ℝ, (∀ e, 0 ≤ f e) → Balanced N f → 0 ≤ ∑ e, c e * f e)
    (e : E) (he : N.src e = N.dst e) : 0 ≤ c e := by
  have hb : Balanced N (singleArcFlow e) := by
    intro v
    apply sub_eq_zero.mp
    change flowDivergence N (singleArcFlow e) v = 0
    rw [singleArcFlow_divergence, he, sub_self]
  have hh := hN (singleArcFlow e) (fun f => by unfold singleArcFlow; split_ifs <;> norm_num) hb
  rwa [singleArcFlow_cost] at hh

abbrev AwayVertex (v₀ : V) := {v : V // v ≠ v₀}
abbrev AwayArc (N : Graph V E) (v₀ : V) := {e : E // N.src e ≠ v₀ ∧ N.dst e ≠ v₀}
abbrev IntoArc (N : Graph V E) (v₀ : V) := {e : E // N.src e ≠ v₀ ∧ N.dst e = v₀}
abbrev FromArc (N : Graph V E) (v₀ : V) := {e : E // N.src e = v₀ ∧ N.dst e ≠ v₀}
abbrev EliminationArc (N : Graph V E) (v₀ : V) := AwayArc N v₀ ⊕ (IntoArc N v₀ × FromArc N v₀)

def eliminatedNetwork (N : Graph V E) (v₀ : V) : Graph (AwayVertex v₀) (EliminationArc N v₀) where
  src := Sum.elim (fun e => ⟨N.src e.1, e.2.1⟩) (fun e => ⟨N.src e.1.1, e.1.2.1⟩)
  dst := Sum.elim (fun e => ⟨N.dst e.1, e.2.2⟩) (fun e => ⟨N.dst e.2.1, e.2.2.2⟩)

def eliminatedCost (N : Graph V E) (v₀ : V) (c : E → ℤ) : EliminationArc N v₀ → ℤ :=
  Sum.elim (fun e => c e.1) (fun e => c e.1.1 + c e.2.1)

noncomputable def eliminationRoute (N : Graph V E) (v₀ : V) : EliminationArc N v₀ → E → ℝ :=
  Sum.elim (fun e => singleArcFlow e.1)
    (fun e f => singleArcFlow e.1.1 f + singleArcFlow e.2.1 f)

theorem eliminationRoute_nonnegative (N : Graph V E) (v₀ : V) :
    ∀ a e, 0 ≤ eliminationRoute N v₀ a e := by
  intro a e
  cases a <;> simp only [eliminationRoute, Sum.elim_inl, Sum.elim_inr, singleArcFlow] <;>
    split_ifs <;> norm_num

theorem eliminationRoute_divergence (N : Graph V E) (v₀ : V) :
    ∀ a v, flowDivergence N (eliminationRoute N v₀ a) v =
      (if ((eliminatedNetwork N v₀).src a : V) = v then 1 else 0) -
      (if ((eliminatedNetwork N v₀).dst a : V) = v then 1 else 0) := by
  intro a v
  cases a with
  | inl e => exact singleArcFlow_divergence N e.1 v
  | inr e =>
    change flowDivergence N (fun f => singleArcFlow e.1.1 f + singleArcFlow e.2.1 f) v = _
    rw [flowDivergence_add, singleArcFlow_divergence, singleArcFlow_divergence, e.1.2.2, e.2.2.1]
    change _ = (if N.src e.1.1 = v then 1 else 0) - (if N.dst e.2.1 = v then 1 else 0)
    ring

theorem eliminationRoute_cost (N : Graph V E) (v₀ : V) (c : E → ℤ) :
    ∀ a, (∑ e, (c e : ℝ) * eliminationRoute N v₀ a e) = eliminatedCost N v₀ c a := by
  intro a
  cases a with
  | inl e => exact singleArcFlow_cost (fun e => (c e : ℝ)) e.1
  | inr e =>
    simp only [eliminationRoute, eliminatedCost, Sum.elim_inr, mul_add, Finset.sum_add_distrib,
      singleArcFlow_cost, Int.cast_add]

theorem eliminated_nonnegative_circulations (N : Graph V E) (v₀ : V) (c : E → ℤ)
    (hN : ∀ f : E → ℝ, (∀ e, 0 ≤ f e) → Balanced N f → 0 ≤ ∑ e, (c e : ℝ) * f e) :
    ∀ g : EliminationArc N v₀ → ℝ, (∀ a, 0 ≤ g a) → Balanced (eliminatedNetwork N v₀) g →
      0 ≤ ∑ a, (eliminatedCost N v₀ c a : ℝ) * g a :=
  route_transport_nonnegative_cost N (eliminatedNetwork N v₀) Subtype.val
    (eliminationRoute N v₀) (fun e => (c e : ℝ)) (fun a => (eliminatedCost N v₀ c a : ℝ))
    (eliminationRoute_nonnegative N v₀) (eliminationRoute_divergence N v₀)
    (eliminationRoute_cost N v₀ c) hN

theorem finite_integer_interval {ι κ : Type} [Fintype ι] [Fintype κ]
    (L : ι → ℤ) (U : κ → ℤ) (hLU : ∀ i j, L i ≤ U j) :
    ∃ z : ℤ, (∀ i, L i ≤ z) ∧ ∀ j, z ≤ U j := by
  classical
  by_cases hU : (Finset.univ : Finset κ).Nonempty
  · obtain ⟨j, _, hj⟩ := Finset.exists_min_image Finset.univ U hU
    exact ⟨U j, fun i => hLU i j, fun k => hj k (Finset.mem_univ _)⟩
  · by_cases hL : (Finset.univ : Finset ι).Nonempty
    · obtain ⟨i, _, hi⟩ := Finset.exists_max_image Finset.univ L hL
      exact ⟨L i, fun k => hi k (Finset.mem_univ _), fun j => (hU ⟨j, Finset.mem_univ _⟩).elim⟩
    · exact ⟨0, fun i => (hL ⟨i, Finset.mem_univ _⟩).elim,
        fun j => (hU ⟨j, Finset.mem_univ _⟩).elim⟩

theorem extend_eliminated_potential (N : Graph V E) (v₀ : V) (c : E → ℤ)
    (hloop : ∀ e, N.src e = N.dst e → 0 ≤ c e)
    (q : AwayVertex v₀ → ℤ)
    (hq : ∀ a, q ((eliminatedNetwork N v₀).dst a) - q ((eliminatedNetwork N v₀).src a) ≤
      eliminatedCost N v₀ c a) :
    ∃ p : V → ℤ, ∀ e, p (N.dst e) - p (N.src e) ≤ c e := by
  let L := fun e : FromArc N v₀ => q ⟨N.dst e.1, e.2.2⟩ - c e.1
  let U := fun e : IntoArc N v₀ => q ⟨N.src e.1, e.2.1⟩ + c e.1
  have hLU : ∀ e f, L e ≤ U f := by
    intro e f
    have hh := hq (Sum.inr (f, e))
    change q ⟨N.dst e.1, e.2.2⟩ - q ⟨N.src f.1, f.2.1⟩ ≤ c f.1 + c e.1 at hh
    dsimp [L, U]
    omega
  obtain ⟨z, hzL, hzU⟩ := finite_integer_interval L U hLU
  let p : V → ℤ := fun v => if h : v = v₀ then z else q ⟨v, h⟩
  refine ⟨p, ?_⟩
  intro e
  by_cases hs : N.src e = v₀ <;> by_cases hd : N.dst e = v₀
  · have hh := hloop e (hs.trans hd.symm)
    simp [p, hs, hd, hh]
  · have hh := hzL ⟨e, hs, hd⟩
    dsimp [L] at hh
    simp only [p, dif_neg hd, dif_pos hs]
    omega
  · have hh := hzU ⟨e, hs, hd⟩
    dsimp [U] at hh
    simp only [p, dif_pos hd, dif_neg hs]
    omega
  · have hh := hq (Sum.inl ⟨e, hs, hd⟩)
    simpa only [eliminatedNetwork, eliminatedCost, Sum.elim_inl, p, dif_neg hs, dif_neg hd] using hh

end TSP.Improvements20261105
