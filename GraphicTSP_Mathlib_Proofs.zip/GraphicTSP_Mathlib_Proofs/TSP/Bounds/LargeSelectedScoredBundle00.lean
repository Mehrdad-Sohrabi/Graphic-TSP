import TSP.Improvements20261105.LargeSelectedGreedyScoredSourceEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t5_r3_cap_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 32 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4014686941841/14172220610:ℝ)*hzu + (32349875712/1417222061:ℝ)*hR0 + (75130547712/1417222061:ℝ)*hRo + (117454334976/7086110305:ℝ)*hgap + (945957831096/7086110305:ℝ)*htarget + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (-127967573184/1417222061:ℝ)*hmass
  · linear_combination (1529131270256609/5116171640210:ℝ)*hzu + (32349875712/1417222061:ℝ)*hR0 + (75130547712/1417222061:ℝ)*hRo + (117454334976/7086110305:ℝ)*hgap + (354795657734324/2558085820105:ℝ)*htarget + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (-127967573184/1417222061:ℝ)*hmass
  · linear_combination (4014686941841/14172220610:ℝ)*hzu + (32349875712/1417222061:ℝ)*hR0 + (75130547712/1417222061:ℝ)*hRo + (117454334976/7086110305:ℝ)*hgap + (945957831096/7086110305:ℝ)*htarget + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (-127967573184/1417222061:ℝ)*hmass
  · linear_combination (1529131270256609/5116171640210:ℝ)*hzu + (32349875712/1417222061:ℝ)*hR0 + (75130547712/1417222061:ℝ)*hRo + (117454334976/7086110305:ℝ)*hgap + (354795657734324/2558085820105:ℝ)*htarget + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (-127967573184/1417222061:ℝ)*hmass

theorem large_selected_scored_t5_r3_cap_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 32 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (108880766001/1358181728:ℝ)*hR0 + (24573357297/169772716:ℝ)*hRo + (20112140520625/294385889544:ℝ)*hchoice + (4022428104125/294385889544:ℝ)*hem + (3942433614/212215895:ℝ)*hgap + (511/8:ℝ)*htarget + (657072269/848863580:ℝ)*hC + (1/1:ℝ)*hI + (191791311/848863580:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (40334315836761/490303603808:ℝ)*hR0 + (9080136326169/61287950476:ℝ)*hRo + (7543542498824665/106273306125384:ℝ)*hchoice + (1508708499764933/106273306125384:ℝ)*hem + (75164568906/4032102005:ℝ)*hgap + (187223/2888:ℝ)*htarget + (12527428151/16128408020:ℝ)*hC + (1/1:ℝ)*hI + (3600979869/16128408020:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (108880766001/1358181728:ℝ)*hR0 + (24573357297/169772716:ℝ)*hRo + (20112140520625/294385889544:ℝ)*hchoice + (4022428104125/294385889544:ℝ)*hem + (3942433614/212215895:ℝ)*hgap + (511/8:ℝ)*htarget + (657072269/848863580:ℝ)*hC + (1/1:ℝ)*hI + (191791311/848863580:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (40334315836761/490303603808:ℝ)*hR0 + (9080136326169/61287950476:ℝ)*hRo + (7543542498824665/106273306125384:ℝ)*hchoice + (1508708499764933/106273306125384:ℝ)*hem + (75164568906/4032102005:ℝ)*hgap + (187223/2888:ℝ)*htarget + (12527428151/16128408020:ℝ)*hC + (1/1:ℝ)*hI + (3600979869/16128408020:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t5_r3_cap_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 32 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (195994232112/1417222061:ℝ)*hMl + (511/2:ℝ)*hzl + (700733516868/7086110305:ℝ)*hR0 + (271124779824/1417222061:ℝ)*hRo + (195994232112/1417222061:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (72704015348368/511617164021:ℝ)*hMl + (187223/722:ℝ)*hzl + (258327567868172/2558085820105:ℝ)*hR0 + (99826143072400/511617164021:ℝ)*hRo + (72704015348368/511617164021:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (195994232112/1417222061:ℝ)*hMl + (511/2:ℝ)*hzl + (700733516868/7086110305:ℝ)*hR0 + (271124779824/1417222061:ℝ)*hRo + (195994232112/1417222061:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (72704015348368/511617164021:ℝ)*hMl + (187223/722:ℝ)*hzl + (258327567868172/2558085820105:ℝ)*hR0 + (99826143072400/511617164021:ℝ)*hRo + (72704015348368/511617164021:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t5_r3_cap_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 32 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1145711256/8759483:ℝ)*hR0 + (10029503424/43797415:ℝ)*hRo + (349332606496/2531490587:ℝ)*hchoice + (349332606496/12657452935:ℝ)*hem + (868253184/43797415:ℝ)*hgap + (36177216/43797415:ℝ)*hC + (1/1:ℝ)*hI + (7620199/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (415985765826/3162173363:ℝ)*hR0 + (3640079614416/15810866815:ℝ)*hRo + (380968914756872/2741604305721:ℝ)*hchoice + (380968914756872/13708021528605:ℝ)*hem + (16515689088/832150885:ℝ)*hgap + (688153712/832150885:ℝ)*hC + (1/1:ℝ)*hI + (143997173/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1145711256/8759483:ℝ)*hR0 + (10029503424/43797415:ℝ)*hRo + (349332606496/2531490587:ℝ)*hchoice + (349332606496/12657452935:ℝ)*hem + (868253184/43797415:ℝ)*hgap + (36177216/43797415:ℝ)*hC + (1/1:ℝ)*hI + (7620199/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (415985765826/3162173363:ℝ)*hR0 + (3640079614416/15810866815:ℝ)*hRo + (380968914756872/2741604305721:ℝ)*hchoice + (380968914756872/13708021528605:ℝ)*hem + (16515689088/832150885:ℝ)*hgap + (688153712/832150885:ℝ)*hC + (1/1:ℝ)*hI + (143997173/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t5_r3_cap_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 32 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t5_r4_cap_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (1/4 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (1512/13:ℝ)*hzu + (1/1:ℝ)*hH0 + (456/13:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource
  · linear_combination (687608/4693:ℝ)*hzu + (1/1:ℝ)*hH0 + (200060/4693:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource

theorem large_selected_scored_t5_r4_cap_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (621/2000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (621/2000 : ℝ) (242/621 : ℝ) (311/690 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (621/2000 : ℝ) (311/690 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (265419001/257830:ℝ)*hMu + (225300352/4859535:ℝ)*hqM + (617349547/3239690:ℝ)*hR0 + (138217/590:ℝ)*hRo + (148986073/757758:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (5018332251/4898770:ℝ)*hMu + (3816507952/92331165:ℝ)*hqM + (12039107217/61554110:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (148986073/757758:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass
  · linear_combination (265419001/257830:ℝ)*hMu + (225300352/4859535:ℝ)*hqM + (617349547/3239690:ℝ)*hR0 + (138217/590:ℝ)*hRo + (148986073/757758:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (3744/295:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (7896/295:ℝ)*hmass
  · linear_combination (5018332251/4898770:ℝ)*hMu + (3816507952/92331165:ℝ)*hqM + (12039107217/61554110:ℝ)*hR0 + (50967153/212990:ℝ)*hRo + (148986073/757758:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1485436/106495:ℝ)*htarget + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (3385864/106495:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (621/2000 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (28947517410/1570397623:ℝ)*hR0 + (235501303632/7851988115:ℝ)*hRo + (31871652496264/1361534739141:ℝ)*hchoice + (31871652496264/6807673695705:ℝ)*hem + (4421251968/7851988115:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (184218832/7851988115:ℝ)*hC + (1/1:ℝ)*hI + (7667769283/7851988115:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (12738850781190/566913541903:ℝ)*hR0 + (103636381775088/2834567709515:ℝ)*hRo + (14025666503601176/491514040829901:ℝ)*hchoice + (14025666503601176/2457570204149505:ℝ)*hem + (102402507648/149187774185:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (4266771152/149187774185:ℝ)*hC + (1/1:ℝ)*hI + (144921003033/149187774185:ℝ)*hsource + (2045432/66785:ℝ)*hmass
  · linear_combination (28947517410/1570397623:ℝ)*hR0 + (235501303632/7851988115:ℝ)*hRo + (31871652496264/1361534739141:ℝ)*hchoice + (31871652496264/6807673695705:ℝ)*hem + (4421251968/7851988115:ℝ)*hgap + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (184218832/7851988115:ℝ)*hC + (1/1:ℝ)*hI + (7667769283/7851988115:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (12738850781190/566913541903:ℝ)*hR0 + (103636381775088/2834567709515:ℝ)*hRo + (14025666503601176/491514040829901:ℝ)*hchoice + (14025666503601176/2457570204149505:ℝ)*hem + (102402507648/149187774185:ℝ)*hgap + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (4266771152/149187774185:ℝ)*hC + (1/1:ℝ)*hI + (144921003033/149187774185:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (621/2000 : ℝ) ≤ M) (hMu : M ≤ (3949/12000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (3949/12000 : ℝ) (1898/3949 : ℝ) (21031/39490 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (3949/12000 : ℝ) (21031/39490 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (9070536487/8853658:ℝ)*hMu + (3744/59:ℝ)*hzl + (32725088/971907:ℝ)*hqM + (131693231/647938:ℝ)*hR0 + (29141/118:ℝ)*hRo + (25782008099/130103754:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (171283030157/168219502:ℝ)*hMu + (1485436/21299:ℝ)*hzl + (505726988/18466233:ℝ)*hqM + (2579537845/12310822:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (25782008099/130103754:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass
  · linear_combination (9070536487/8853658:ℝ)*hMu + (3744/59:ℝ)*hzl + (32725088/971907:ℝ)*hqM + (131693231/647938:ℝ)*hR0 + (29141/118:ℝ)*hRo + (25782008099/130103754:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (2328/59:ℝ)*hmass
  · linear_combination (171283030157/168219502:ℝ)*hMu + (1485436/21299:ℝ)*hzl + (505726988/18466233:ℝ)*hqM + (2579537845/12310822:ℝ)*hR0 + (10787605/42598:ℝ)*hRo + (25782008099/130103754:ℝ)*hem + (24/1:ℝ)*hgap + (1/1:ℝ)*hH0 + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (3949/12000 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (229/640 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (229/640 : ℝ) (138/229 : ℝ) (1471/2290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (14304/229:ℝ)*hzl + (274278973050/9719487991:ℝ)*hR0 + (446276997072/9719487991:ℝ)*hRo + (100661759605240/2808932029399:ℝ)*hchoice + (20132351921048/2808932029399:ℝ)*hem + (8378310528/9719487991:ℝ)*hgap + (1/1:ℝ)*hH0 + (349096272/9719487991:ℝ)*hC + (1/1:ℝ)*hI + (9370391719/9719487991:ℝ)*hsource + (8808/229:ℝ)*hmass
  · linear_combination (5707076/82669:ℝ)*hzl + (115933935313875/3508735164751:ℝ)*hR0 + (188635125526680/3508735164751:ℝ)*hRo + (127645008258004300/3042073387839117:ℝ)*hchoice + (25529001651600860/3042073387839117:ℝ)*hem + (186389273280/184670271829:ℝ)*hgap + (1/1:ℝ)*hH0 + (7766219720/184670271829:ℝ)*hC + (1/1:ℝ)*hI + (176904052109/184670271829:ℝ)*hsource + (3723020/82669:ℝ)*hmass
  · linear_combination (14304/229:ℝ)*hzl + (274278973050/9719487991:ℝ)*hR0 + (446276997072/9719487991:ℝ)*hRo + (100661759605240/2808932029399:ℝ)*hchoice + (20132351921048/2808932029399:ℝ)*hem + (8378310528/9719487991:ℝ)*hgap + (1/1:ℝ)*hH0 + (349096272/9719487991:ℝ)*hC + (1/1:ℝ)*hI + (9370391719/9719487991:ℝ)*hsource + (8808/229:ℝ)*hmass
  · linear_combination (5707076/82669:ℝ)*hzl + (115933935313875/3508735164751:ℝ)*hR0 + (188635125526680/3508735164751:ℝ)*hRo + (127645008258004300/3042073387839117:ℝ)*hchoice + (25529001651600860/3042073387839117:ℝ)*hem + (186389273280/184670271829:ℝ)*hgap + (1/1:ℝ)*hH0 + (7766219720/184670271829:ℝ)*hC + (1/1:ℝ)*hI + (176904052109/184670271829:ℝ)*hsource + (3723020/82669:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (3949/12000 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (229/640 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (29141/118:ℝ)*hzl + (302408539062/2504147561:ℝ)*hR0 + (527866538928/2504147561:ℝ)*hRo + (86751938651720/723698645129:ℝ)*hchoice + (17350387730344/723698645129:ℝ)*hem + (248130400896/12520737805:ℝ)*hgap + (10338766704/12520737805:ℝ)*hC + (1/1:ℝ)*hI + (2181971101/12520737805:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10787605/42598:ℝ)*hzl + (113337601254957/903997269521:ℝ)*hR0 + (197341731158376/903997269521:ℝ)*hRo + (98541510951733940/783765632674707:ℝ)*hchoice + (19708302190346788/783765632674707:ℝ)*hem + (4747983449664/237894018295:ℝ)*hgap + (197832643736/237894018295:ℝ)*hC + (1/1:ℝ)*hI + (40061374559/237894018295:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass
  · linear_combination (29141/118:ℝ)*hzl + (302408539062/2504147561:ℝ)*hR0 + (527866538928/2504147561:ℝ)*hRo + (86751938651720/723698645129:ℝ)*hchoice + (17350387730344/723698645129:ℝ)*hem + (248130400896/12520737805:ℝ)*hgap + (10338766704/12520737805:ℝ)*hC + (1/1:ℝ)*hI + (2181971101/12520737805:ℝ)*hsource + (1/1:ℝ)*hR + (2328/59:ℝ)*hmass
  · linear_combination (10787605/42598:ℝ)*hzl + (113337601254957/903997269521:ℝ)*hR0 + (197341731158376/903997269521:ℝ)*hRo + (98541510951733940/783765632674707:ℝ)*hchoice + (19708302190346788/783765632674707:ℝ)*hem + (4747983449664/237894018295:ℝ)*hgap + (197832643736/237894018295:ℝ)*hC + (1/1:ℝ)*hI + (40061374559/237894018295:ℝ)*hsource + (1/1:ℝ)*hR + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (57563508198/466874969:ℝ)*hR0 + (100339432752/466874969:ℝ)*hRo + (2930820676120/23810623419:ℝ)*hchoice + (586164135224/23810623419:ℝ)*hem + (46442169984/2334374845:ℝ)*hgap + (1935090416/2334374845:ℝ)*hC + (1/1:ℝ)*hI + (399284429/2334374845:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (21433987663653/168541863809:ℝ)*hR0 + (37285939130664/168541863809:ℝ)*hRo + (18706027215027860/146125795922403:ℝ)*hchoice + (3741205443005572/146125795922403:ℝ)*hem + (887654945856/44353122055:ℝ)*hgap + (36985622744/44353122055:ℝ)*hC + (1/1:ℝ)*hI + (7367499311/44353122055:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (5509/22:ℝ)*hzl + (57563508198/466874969:ℝ)*hR0 + (100339432752/466874969:ℝ)*hRo + (2930820676120/23810623419:ℝ)*hchoice + (586164135224/23810623419:ℝ)*hem + (46442169984/2334374845:ℝ)*hgap + (1935090416/2334374845:ℝ)*hC + (1/1:ℝ)*hI + (399284429/2334374845:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (21433987663653/168541863809:ℝ)*hR0 + (37285939130664/168541863809:ℝ)*hRo + (18706027215027860/146125795922403:ℝ)*hchoice + (3741205443005572/146125795922403:ℝ)*hem + (887654945856/44353122055:ℝ)*hgap + (36985622744/44353122055:ℝ)*hC + (1/1:ℝ)*hI + (7367499311/44353122055:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (2309/6000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (111/320 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (2309/6000 : ℝ) (1618/2309 : ℝ) (16871/23090 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (2309/6000 : ℝ) (16871/23090 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (111/320 : ℝ) (62/111 : ℝ) (223/370 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (4648/185:ℝ)*hMl + (12782/925:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (5624938/333925:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass
  · linear_combination (4648/185:ℝ)*hMl + (12782/925:ℝ)*hR0 + (4648/185:ℝ)*hRo + (4648/185:ℝ)*hchoice + (1/1:ℝ)*hH0 + (2272/185:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (4648/185:ℝ)*hmass
  · linear_combination (2045432/66785:ℝ)*hMl + (5624938/333925:ℝ)*hR0 + (2045432/66785:ℝ)*hRo + (2045432/66785:ℝ)*hchoice + (1/1:ℝ)*hH0 + (912068/66785:ℝ)*htarget + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2045432/66785:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_8
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (2309/6000 : ℝ))
    (hzl : (111/320 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (2309/6000 : ℝ) (1618/2309 : ℝ) (16871/23090 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (2309/6000 : ℝ) (16871/23090 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (6402/295:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (535843/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (6402/295:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (535843/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_9
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (2309/6000 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (6402/295:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (535843/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (6402/295:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (535843/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t5_r4_cap_cell_10
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (2309/6000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (2309/6000 : ℝ) (1618/2309 : ℝ) (16871/23090 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (2309/6000 : ℝ) (16871/23090 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (22424223005704/168964405049:ℝ)*hMl + (5509/22:ℝ)*hzl + (7480603000066/76802002295:ℝ)*hR0 + (31697925000712/168964405049:ℝ)*hRo + (22424223005704/168964405049:ℝ)*hchoice + (1285317817344/76802002295:ℝ)*hgap + (53554909056/76802002295:ℝ)*hC + (1/1:ℝ)*hI + (23247093239/76802002295:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (8417528589892636/60996150222689:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (2781093704232199/27725522828495:ℝ)*hR0 + (11765335010090524/60996150222689:ℝ)*hRo + (8417528589892636/60996150222689:ℝ)*hchoice + (1285317817344/76802002295:ℝ)*hgap + (53554909056/76802002295:ℝ)*hC + (1/1:ℝ)*hI + (23247093239/76802002295:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (22424223005704/168964405049:ℝ)*hMl + (5509/22:ℝ)*hzl + (7480603000066/76802002295:ℝ)*hR0 + (31697925000712/168964405049:ℝ)*hRo + (22424223005704/168964405049:ℝ)*hchoice + (1285317817344/76802002295:ℝ)*hgap + (53554909056/76802002295:ℝ)*hC + (1/1:ℝ)*hI + (23247093239/76802002295:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (8417528589892636/60996150222689:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (2781093704232199/27725522828495:ℝ)*hR0 + (11765335010090524/60996150222689:ℝ)*hRo + (8417528589892636/60996150222689:ℝ)*hchoice + (1285317817344/76802002295:ℝ)*hgap + (53554909056/76802002295:ℝ)*hC + (1/1:ℝ)*hI + (23247093239/76802002295:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_11
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (2309/6000 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2076572117816/15589442671:ℝ)*hMl + (5509/22:ℝ)*hzl + (680892408014/7086110305:ℝ)*hR0 + (2903008142648/15589442671:ℝ)*hRo + (2076572117816/15589442671:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (779387191147844/5627788804231:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (253238323447121/2558085820105:ℝ)*hR0 + (1077730596112196/5627788804231:ℝ)*hRo + (779387191147844/5627788804231:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (2076572117816/15589442671:ℝ)*hMl + (5509/22:ℝ)*hzl + (680892408014/7086110305:ℝ)*hR0 + (2903008142648/15589442671:ℝ)*hRo + (2076572117816/15589442671:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (779387191147844/5627788804231:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (253238323447121/2558085820105:ℝ)*hR0 + (1077730596112196/5627788804231:ℝ)*hRo + (779387191147844/5627788804231:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_12
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (5391575868/42443179:ℝ)*hR0 + (9379708896/42443179:ℝ)*hRo + (1567997895760/12266078731:ℝ)*hchoice + (313599579152/12266078731:ℝ)*hem + (4246228224/212215895:ℝ)*hgap + (176926176/212215895:ℝ)*hC + (1/1:ℝ)*hI + (35289719/212215895:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (1989207192948/15321987619:ℝ)*hR0 + (3455793025440/15321987619:ℝ)*hRo + (1745318349587920/13284163265673:ℝ)*hchoice + (349063669917584/13284163265673:ℝ)*hem + (81022776576/4032102005:ℝ)*hgap + (3375949024/4032102005:ℝ)*hC + (1/1:ℝ)*hI + (656152981/4032102005:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (5391575868/42443179:ℝ)*hR0 + (9379708896/42443179:ℝ)*hRo + (1567997895760/12266078731:ℝ)*hchoice + (313599579152/12266078731:ℝ)*hem + (4246228224/212215895:ℝ)*hgap + (176926176/212215895:ℝ)*hC + (1/1:ℝ)*hI + (35289719/212215895:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (1989207192948/15321987619:ℝ)*hR0 + (3455793025440/15321987619:ℝ)*hRo + (1745318349587920/13284163265673:ℝ)*hchoice + (349063669917584/13284163265673:ℝ)*hem + (81022776576/4032102005:ℝ)*hgap + (3375949024/4032102005:ℝ)*hC + (1/1:ℝ)*hI + (656152981/4032102005:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_13
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (195994232112/1417222061:ℝ)*hMl + (511/2:ℝ)*hzl + (700733516868/7086110305:ℝ)*hR0 + (271124779824/1417222061:ℝ)*hRo + (195994232112/1417222061:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (72704015348368/511617164021:ℝ)*hMl + (187223/722:ℝ)*hzl + (258327567868172/2558085820105:ℝ)*hR0 + (99826143072400/511617164021:ℝ)*hRo + (72704015348368/511617164021:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (195994232112/1417222061:ℝ)*hMl + (511/2:ℝ)*hzl + (700733516868/7086110305:ℝ)*hR0 + (271124779824/1417222061:ℝ)*hRo + (195994232112/1417222061:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (72704015348368/511617164021:ℝ)*hMl + (187223/722:ℝ)*hzl + (258327567868172/2558085820105:ℝ)*hR0 + (99826143072400/511617164021:ℝ)*hRo + (72704015348368/511617164021:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_14
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1145711256/8759483:ℝ)*hR0 + (10029503424/43797415:ℝ)*hRo + (349332606496/2531490587:ℝ)*hchoice + (349332606496/12657452935:ℝ)*hem + (868253184/43797415:ℝ)*hgap + (36177216/43797415:ℝ)*hC + (1/1:ℝ)*hI + (7620199/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (415985765826/3162173363:ℝ)*hR0 + (3640079614416/15810866815:ℝ)*hRo + (380968914756872/2741604305721:ℝ)*hchoice + (380968914756872/13708021528605:ℝ)*hem + (16515689088/832150885:ℝ)*hgap + (688153712/832150885:ℝ)*hC + (1/1:ℝ)*hI + (143997173/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1145711256/8759483:ℝ)*hR0 + (10029503424/43797415:ℝ)*hRo + (349332606496/2531490587:ℝ)*hchoice + (349332606496/12657452935:ℝ)*hem + (868253184/43797415:ℝ)*hgap + (36177216/43797415:ℝ)*hC + (1/1:ℝ)*hI + (7620199/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (415985765826/3162173363:ℝ)*hR0 + (3640079614416/15810866815:ℝ)*hRo + (380968914756872/2741604305721:ℝ)*hchoice + (380968914756872/13708021528605:ℝ)*hem + (16515689088/832150885:ℝ)*hgap + (688153712/832150885:ℝ)*hC + (1/1:ℝ)*hI + (143997173/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t5_r4_cap_cell_15
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t5_r5_all_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (0/1 : ℝ) ≤ z) (hzu : z ≤ (13/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/80 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (153476550/8759483:ℝ)*hR0 + (250157232/8759483:ℝ)*hRo + (56688882440/2531490587:ℝ)*hchoice + (11337776488/2531490587:ℝ)*hem + (4618368/8759483:ℝ)*hgap + (1/1:ℝ)*hH0 + (192432/8759483:ℝ)*hC + (1/1:ℝ)*hI + (8567051/8759483:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (75868574550/3162173363:ℝ)*hR0 + (123661058352/3162173363:ℝ)*hRo + (84069612658520/2741604305721:ℝ)*hchoice + (16813922531704/2741604305721:ℝ)*hem + (120158592/166430177:ℝ)*hgap + (1/1:ℝ)*hH0 + (5006608/166430177:ℝ)*hC + (1/1:ℝ)*hI + (161423569/166430177:ℝ)*hsource + (11864/361:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (153476550/8759483:ℝ)*hR0 + (250157232/8759483:ℝ)*hRo + (56688882440/2531490587:ℝ)*hchoice + (11337776488/2531490587:ℝ)*hem + (4618368/8759483:ℝ)*hgap + (1/1:ℝ)*hH0 + (192432/8759483:ℝ)*hC + (1/1:ℝ)*hI + (8567051/8759483:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (20528/361:ℝ)*hzl + (75868574550/3162173363:ℝ)*hR0 + (123661058352/3162173363:ℝ)*hRo + (84069612658520/2741604305721:ℝ)*hchoice + (16813922531704/2741604305721:ℝ)*hem + (120158592/166430177:ℝ)*hgap + (1/1:ℝ)*hH0 + (5006608/166430177:ℝ)*hC + (1/1:ℝ)*hI + (161423569/166430177:ℝ)*hsource + (11864/361:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (13/80 : ℝ) ≤ z) (hzu : z ≤ (39/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (39/160 : ℝ) (0/1 : ℝ) (7/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (48/1:ℝ)*hzl + (153476550/8759483:ℝ)*hR0 + (250157232/8759483:ℝ)*hRo + (56688882440/2531490587:ℝ)*hchoice + (11337776488/2531490587:ℝ)*hem + (4618368/8759483:ℝ)*hgap + (1/1:ℝ)*hH0 + (192432/8759483:ℝ)*hC + (1/1:ℝ)*hI + (8567051/8759483:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (1016910040875/41108253719:ℝ)*hR0 + (127500009720/3162173363:ℝ)*hRo + (1126833260701100/35640855974373:ℝ)*hchoice + (225366652140220/35640855974373:ℝ)*hem + (1610554560/2163592301:ℝ)*hgap + (1/1:ℝ)*hH0 + (67106440/2163592301:ℝ)*hC + (1/1:ℝ)*hI + (2096485861/2163592301:ℝ)*hsource + (159020/4693:ℝ)*hmass
  · linear_combination (48/1:ℝ)*hzl + (153476550/8759483:ℝ)*hR0 + (250157232/8759483:ℝ)*hRo + (56688882440/2531490587:ℝ)*hchoice + (11337776488/2531490587:ℝ)*hem + (4618368/8759483:ℝ)*hgap + (1/1:ℝ)*hH0 + (192432/8759483:ℝ)*hC + (1/1:ℝ)*hI + (8567051/8759483:ℝ)*hsource + (24/1:ℝ)*hmass
  · linear_combination (271652/4693:ℝ)*hzl + (1016910040875/41108253719:ℝ)*hR0 + (127500009720/3162173363:ℝ)*hRo + (1126833260701100/35640855974373:ℝ)*hchoice + (225366652140220/35640855974373:ℝ)*hem + (1610554560/2163592301:ℝ)*hgap + (1/1:ℝ)*hH0 + (67106440/2163592301:ℝ)*hC + (1/1:ℝ)*hI + (2096485861/2163592301:ℝ)*hsource + (159020/4693:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (39/160 : ℝ) ≤ z) (hzu : z ≤ (13/40 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)]
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (768/13:ℝ)*hzl + (2916054450/113873279:ℝ)*hR0 + (365614416/8759483:ℝ)*hRo + (1077088766360/32909377631:ℝ)*hchoice + (215417753272/32909377631:ℝ)*hem + (87748992/113873279:ℝ)*hgap + (1/1:ℝ)*hH0 + (3656208/113873279:ℝ)*hC + (1/1:ℝ)*hI + (110217071/113873279:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (1279354941375/41108253719:ℝ)*hR0 + (160405307160/3162173363:ℝ)*hRo + (1417647227618300/35640855974373:ℝ)*hchoice + (283529445523660/35640855974373:ℝ)*hem + (2026207680/2163592301:ℝ)*hgap + (1/1:ℝ)*hH0 + (84425320/2163592301:ℝ)*hC + (1/1:ℝ)*hI + (2079166981/2163592301:ℝ)*hsource + (200060/4693:ℝ)*hmass
  · linear_combination (768/13:ℝ)*hzl + (2916054450/113873279:ℝ)*hR0 + (365614416/8759483:ℝ)*hRo + (1077088766360/32909377631:ℝ)*hchoice + (215417753272/32909377631:ℝ)*hem + (87748992/113873279:ℝ)*hgap + (1/1:ℝ)*hH0 + (3656208/113873279:ℝ)*hC + (1/1:ℝ)*hI + (110217071/113873279:ℝ)*hsource + (456/13:ℝ)*hmass
  · linear_combination (312692/4693:ℝ)*hzl + (1279354941375/41108253719:ℝ)*hR0 + (160405307160/3162173363:ℝ)*hRo + (1417647227618300/35640855974373:ℝ)*hchoice + (283529445523660/35640855974373:ℝ)*hem + (2026207680/2163592301:ℝ)*hgap + (1/1:ℝ)*hH0 + (84425320/2163592301:ℝ)*hC + (1/1:ℝ)*hI + (2079166981/2163592301:ℝ)*hsource + (200060/4693:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (3744/59:ℝ)*hzl + (72493352550/2504147561:ℝ)*hR0 + (117953320752/2504147561:ℝ)*hRo + (26605424200840/723698645129:ℝ)*hchoice + (5321084840168/723698645129:ℝ)*hem + (2214430848/2504147561:ℝ)*hgap + (1/1:ℝ)*hH0 + (92267952/2504147561:ℝ)*hC + (1/1:ℝ)*hI + (2411879609/2504147561:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (30338218924125/903997269521:ℝ)*hR0 + (49363059396840/903997269521:ℝ)*hRo + (33402835801430900/783765632674707:ℝ)*hchoice + (6680567160286180/783765632674707:ℝ)*hem + (48775352640/47578803659:ℝ)*hgap + (1/1:ℝ)*hH0 + (2032306360/47578803659:ℝ)*hC + (1/1:ℝ)*hI + (45546497299/47578803659:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (3744/59:ℝ)*hzl + (72493352550/2504147561:ℝ)*hR0 + (117953320752/2504147561:ℝ)*hRo + (26605424200840/723698645129:ℝ)*hchoice + (5321084840168/723698645129:ℝ)*hem + (2214430848/2504147561:ℝ)*hgap + (1/1:ℝ)*hH0 + (92267952/2504147561:ℝ)*hC + (1/1:ℝ)*hI + (2411879609/2504147561:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (1485436/21299:ℝ)*hzl + (30338218924125/903997269521:ℝ)*hR0 + (49363059396840/903997269521:ℝ)*hRo + (33402835801430900/783765632674707:ℝ)*hchoice + (6680567160286180/783765632674707:ℝ)*hem + (48775352640/47578803659:ℝ)*hgap + (1/1:ℝ)*hH0 + (2032306360/47578803659:ℝ)*hC + (1/1:ℝ)*hI + (45546497299/47578803659:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (1043/3000 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (1043/3000 : ℝ) (586/1043 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (1043/3000 : ℝ) (6317/10430 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5509/22:ℝ)*hzl + (57563508198/466874969:ℝ)*hR0 + (100339432752/466874969:ℝ)*hRo + (2930820676120/23810623419:ℝ)*hchoice + (586164135224/23810623419:ℝ)*hem + (46442169984/2334374845:ℝ)*hgap + (1935090416/2334374845:ℝ)*hC + (1/1:ℝ)*hI + (399284429/2334374845:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (21433987663653/168541863809:ℝ)*hR0 + (37285939130664/168541863809:ℝ)*hRo + (18706027215027860/146125795922403:ℝ)*hchoice + (3741205443005572/146125795922403:ℝ)*hem + (887654945856/44353122055:ℝ)*hgap + (36985622744/44353122055:ℝ)*hC + (1/1:ℝ)*hI + (7367499311/44353122055:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (5509/22:ℝ)*hzl + (57563508198/466874969:ℝ)*hR0 + (100339432752/466874969:ℝ)*hRo + (2930820676120/23810623419:ℝ)*hchoice + (586164135224/23810623419:ℝ)*hem + (46442169984/2334374845:ℝ)*hgap + (1935090416/2334374845:ℝ)*hC + (1/1:ℝ)*hI + (399284429/2334374845:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (2030725/7942:ℝ)*hzl + (21433987663653/168541863809:ℝ)*hR0 + (37285939130664/168541863809:ℝ)*hRo + (18706027215027860/146125795922403:ℝ)*hchoice + (3741205443005572/146125795922403:ℝ)*hem + (887654945856/44353122055:ℝ)*hgap + (36985622744/44353122055:ℝ)*hC + (1/1:ℝ)*hI + (7367499311/44353122055:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (13/40 : ℝ) ≤ z) (hzu : z ≤ (59/160 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (59/160 : ℝ) (38/59 : ℝ) (401/590 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (6402/295:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (535843/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass
  · linear_combination (2328/59:ℝ)*hMl + (3744/59:ℝ)*hzl + (6402/295:ℝ)*hR0 + (2328/59:ℝ)*hRo + (2328/59:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (2328/59:ℝ)*hmass
  · linear_combination (974260/21299:ℝ)*hMl + (1485436/21299:ℝ)*hzl + (535843/21299:ℝ)*hR0 + (974260/21299:ℝ)*hRo + (974260/21299:ℝ)*hchoice + (1/1:ℝ)*hH0 + (1/1:ℝ)*hI + (1/1:ℝ)*hsource + (974260/21299:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (1043/3000 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (59/160 : ℝ) ≤ z) (hzu : z ≤ (33/80 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (33/80 : ℝ) (26/33 : ℝ) (89/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2076572117816/15589442671:ℝ)*hMl + (5509/22:ℝ)*hzl + (680892408014/7086110305:ℝ)*hR0 + (2903008142648/15589442671:ℝ)*hRo + (2076572117816/15589442671:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (779387191147844/5627788804231:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (253238323447121/2558085820105:ℝ)*hR0 + (1077730596112196/5627788804231:ℝ)*hRo + (779387191147844/5627788804231:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass
  · linear_combination (2076572117816/15589442671:ℝ)*hMl + (5509/22:ℝ)*hzl + (680892408014/7086110305:ℝ)*hR0 + (2903008142648/15589442671:ℝ)*hRo + (2076572117816/15589442671:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (472/11:ℝ)*hmass
  · linear_combination (779387191147844/5627788804231:ℝ)*hMl + (2030725/7942:ℝ)*hzl + (253238323447121/2558085820105:ℝ)*hR0 + (1077730596112196/5627788804231:ℝ)*hRo + (779387191147844/5627788804231:ℝ)*hchoice + (117454334976/7086110305:ℝ)*hgap + (4893930624/7086110305:ℝ)*hC + (1/1:ℝ)*hI + (2192179681/7086110305:ℝ)*hsource + (1/1:ℝ)*hR + (191380/3971:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (33/80 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (511/2:ℝ)*hzl + (1084320636/8759483:ℝ)*hR0 + (1905837792/8759483:ℝ)*hRo + (326657053520/2531490587:ℝ)*hchoice + (65331410704/2531490587:ℝ)*hem + (859016448/43797415:ℝ)*hgap + (35792352/43797415:ℝ)*hC + (1/1:ℝ)*hI + (8005063/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (400239071796/3162173363:ℝ)*hR0 + (702349790880/3162173363:ℝ)*hRo + (363520076741840/2741604305721:ℝ)*hchoice + (72704015348368/2741604305721:ℝ)*hem + (16390993152/832150885:ℝ)*hgap + (682958048/832150885:ℝ)*hC + (1/1:ℝ)*hI + (149192837/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (511/2:ℝ)*hzl + (1084320636/8759483:ℝ)*hR0 + (1905837792/8759483:ℝ)*hRo + (326657053520/2531490587:ℝ)*hchoice + (65331410704/2531490587:ℝ)*hem + (859016448/43797415:ℝ)*hgap + (35792352/43797415:ℝ)*hC + (1/1:ℝ)*hI + (8005063/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (187223/722:ℝ)*hzl + (400239071796/3162173363:ℝ)*hR0 + (702349790880/3162173363:ℝ)*hRo + (363520076741840/2741604305721:ℝ)*hchoice + (72704015348368/2741604305721:ℝ)*hem + (16390993152/832150885:ℝ)*hgap + (682958048/832150885:ℝ)*hC + (1/1:ℝ)*hI + (149192837/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_8
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1145711256/8759483:ℝ)*hR0 + (10029503424/43797415:ℝ)*hRo + (349332606496/2531490587:ℝ)*hchoice + (349332606496/12657452935:ℝ)*hem + (868253184/43797415:ℝ)*hgap + (36177216/43797415:ℝ)*hC + (1/1:ℝ)*hI + (7620199/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (415985765826/3162173363:ℝ)*hR0 + (3640079614416/15810866815:ℝ)*hRo + (380968914756872/2741604305721:ℝ)*hchoice + (380968914756872/13708021528605:ℝ)*hem + (16515689088/832150885:ℝ)*hgap + (688153712/832150885:ℝ)*hC + (1/1:ℝ)*hI + (143997173/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1145711256/8759483:ℝ)*hR0 + (10029503424/43797415:ℝ)*hRo + (349332606496/2531490587:ℝ)*hchoice + (349332606496/12657452935:ℝ)*hem + (868253184/43797415:ℝ)*hgap + (36177216/43797415:ℝ)*hC + (1/1:ℝ)*hI + (7620199/43797415:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (415985765826/3162173363:ℝ)*hR0 + (3640079614416/15810866815:ℝ)*hRo + (380968914756872/2741604305721:ℝ)*hchoice + (380968914756872/13708021528605:ℝ)*hem + (16515689088/832150885:ℝ)*hgap + (688153712/832150885:ℝ)*hC + (1/1:ℝ)*hI + (143997173/832150885:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t5_r5_all_cell_9
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(9/20 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 5*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(10000/2601 : ℝ)*(5*(q+(9/20 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hMl : (41/150 : ℝ) ≤ M) (hMu : M ≤ (211/500 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hS := hSall (211/500 : ℝ) (172/211 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (211/500 : ℝ) (1759/2110 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]
  · linarith only [hzl,hRo,hchoice,hem,ho0,hoe,ha,hmass]

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r3_cap_cell_0
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (141192545637/1996061720:ℝ)*hMu + (70108660779/798424688:ℝ)*hR0 + (1533/8:ℝ)*hRo + (42071806059/399212344:ℝ)*hchoice + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (2574240698943/37925172680:ℝ)*hMu + (1353748088433/15170069072:ℝ)*hR0 + (561669/2888:ℝ)*hRo + (821047848753/7585034536:ℝ)*hchoice + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (141192545637/1996061720:ℝ)*hMu + (70108660779/798424688:ℝ)*hR0 + (1533/8:ℝ)*hRo + (42071806059/399212344:ℝ)*hchoice + (24/1:ℝ)*hgap + (511/8:ℝ)*htarget + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (2574240698943/37925172680:ℝ)*hMu + (1353748088433/15170069072:ℝ)*hR0 + (561669/2888:ℝ)*hRo + (821047848753/7585034536:ℝ)*hchoice + (24/1:ℝ)*hgap + (187223/2888:ℝ)*htarget + (29295964661/499015430:ℝ)*hgood + (1/1:ℝ)*hC + (1/1:ℝ)*hI + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_1
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5105325615743/18848008030:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (1228815153608/9424004015:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass
  · linear_combination (1949189606914607/6804130898830:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (461296780391052/3402065449415:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass
  · linear_combination (5105325615743/18848008030:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (1228815153608/9424004015:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass
  · linear_combination (1949189606914607/6804130898830:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (461296780391052/3402065449415:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_2
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (125583650154273/1767249947744:ℝ)*hR0 + (139970228683449/883624973872:ℝ)*hRo + (78474499475025/883624973872:ℝ)*hchoice + (5566184643747/276132804335:ℝ)*hgap + (511/8:ℝ)*htarget + (26158166491675/883624973872:ℝ)*hgood + (1855394881249/2209062434680:ℝ)*hC + (1/1:ℝ)*hI + (353667553431/2209062434680:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (46602014163400137/637977231135584:ℝ)*hR0 + (51832090626213153/318988615567792:ℝ)*hRo + (29476019984104569/318988615567792:ℝ)*hchoice + (5605326628707/276132804335:ℝ)*hgap + (187223/2888:ℝ)*htarget + (9825339994701523/318988615567792:ℝ)*hgood + (1868442209569/2209062434680:ℝ)*hC + (1/1:ℝ)*hI + (340620225111/2209062434680:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (125583650154273/1767249947744:ℝ)*hR0 + (139970228683449/883624973872:ℝ)*hRo + (78474499475025/883624973872:ℝ)*hchoice + (5566184643747/276132804335:ℝ)*hgap + (511/8:ℝ)*htarget + (26158166491675/883624973872:ℝ)*hgood + (1855394881249/2209062434680:ℝ)*hC + (1/1:ℝ)*hI + (353667553431/2209062434680:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (46602014163400137/637977231135584:ℝ)*hR0 + (51832090626213153/318988615567792:ℝ)*hRo + (29476019984104569/318988615567792:ℝ)*hchoice + (5605326628707/276132804335:ℝ)*hgap + (187223/2888:ℝ)*htarget + (9825339994701523/318988615567792:ℝ)*hgood + (1868442209569/2209062434680:ℝ)*hC + (1/1:ℝ)*hI + (340620225111/2209062434680:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_3
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_4
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (1343795072568/11218043735:ℝ)*hR0 + (2929822481136/11218043735:ℝ)*hRo + (2046781217136/11218043735:ℝ)*hchoice + (52826906880/2243608747:ℝ)*hgap + (682260405712/11218043735:ℝ)*hgood + (2201121120/2243608747:ℝ)*hC + (1/1:ℝ)*hI + (42487627/2243608747:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (487993820186682/4049713788335:ℝ)*hR0 + (1063621647450324/4049713788335:ℝ)*hRo + (744157922431284/4049713788335:ℝ)*hchoice + (5029353231936/213142830965:ℝ)*hgap + (248052640810428/4049713788335:ℝ)*hgood + (209556384664/213142830965:ℝ)*hC + (1/1:ℝ)*hI + (3586446301/213142830965:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (1343795072568/11218043735:ℝ)*hR0 + (2929822481136/11218043735:ℝ)*hRo + (2046781217136/11218043735:ℝ)*hchoice + (52826906880/2243608747:ℝ)*hgap + (682260405712/11218043735:ℝ)*hgood + (2201121120/2243608747:ℝ)*hC + (1/1:ℝ)*hI + (42487627/2243608747:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (487993820186682/4049713788335:ℝ)*hR0 + (1063621647450324/4049713788335:ℝ)*hRo + (744157922431284/4049713788335:ℝ)*hchoice + (5029353231936/213142830965:ℝ)*hgap + (248052640810428/4049713788335:ℝ)*hgood + (209556384664/213142830965:ℝ)*hC + (1/1:ℝ)*hI + (3586446301/213142830965:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_5
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+q-(3/1 : ℝ)*M ≤ 0)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

theorem large_selected_scored_t6_r3_cap_cell_6
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (4429/14000 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (4429/14000 : ℝ) (1858/4429 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (4429/14000 : ℝ) (21151/44290 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (30186024991/429267948:ℝ)*hR0 + (243664535839/1717071792:ℝ)*hRo + (11103303083825/169703928776:ℝ)*hchoice + (11103303083825/1018223572656:ℝ)*hem + (3264133139/178861645:ℝ)*hgap + (511/8:ℝ)*htarget + (3264133139/4292679480:ℝ)*hC + (1/1:ℝ)*hI + (1028546341/4292679480:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (11186569159543/154965729228:ℝ)*hR0 + (90023237049463/619862916912:ℝ)*hRo + (4172681488453721/61263118288136:ℝ)*hchoice + (4172681488453721/367578709728816:ℝ)*hem + (62201358761/3398371255:ℝ)*hgap + (187223/2888:ℝ)*htarget + (62201358761/81560910120:ℝ)*hC + (1/1:ℝ)*hI + (19359551359/81560910120:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (30186024991/429267948:ℝ)*hR0 + (243664535839/1717071792:ℝ)*hRo + (11103303083825/169703928776:ℝ)*hchoice + (11103303083825/1018223572656:ℝ)*hem + (3264133139/178861645:ℝ)*hgap + (511/8:ℝ)*htarget + (3264133139/4292679480:ℝ)*hC + (1/1:ℝ)*hI + (1028546341/4292679480:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (11186569159543/154965729228:ℝ)*hR0 + (90023237049463/619862916912:ℝ)*hRo + (4172681488453721/61263118288136:ℝ)*hchoice + (4172681488453721/367578709728816:ℝ)*hem + (62201358761/3398371255:ℝ)*hgap + (187223/2888:ℝ)*htarget + (62201358761/81560910120:ℝ)*hC + (1/1:ℝ)*hI + (19359551359/81560910120:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_7
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/3 : ℝ) ≤ z) (hzu : z ≤ (5/12 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/12 : ℝ) (4/5 : ℝ) (41/50 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (5105325615743/18848008030:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (1228815153608/9424004015:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass
  · linear_combination (1949189606914607/6804130898830:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (461296780391052/3402065449415:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass
  · linear_combination (5105325615743/18848008030:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (1228815153608/9424004015:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass
  · linear_combination (1949189606914607/6804130898830:ℝ)*hzu + (37594123776/1884800803:ℝ)*hR0 + (103610174976/1884800803:ℝ)*hRo + (154958926848/9424004015:ℝ)*hgap + (461296780391052/3402065449415:ℝ)*htarget + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (-164339636032/1884800803:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_8
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (4429/14000 : ℝ) ≤ M) (hMu : M ≤ (10127/28000 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (10127/28000 : ℝ) (6254/10127 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (10127/28000 : ℝ) (66413/101270 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (26158166491675/370389429464:ℝ)*hMl + (42474428506651/740778858928:ℝ)*hR0 + (47457222324763/370389429464:ℝ)*hRo + (26158166491675/370389429464:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (511/8:ℝ)*htarget + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (9825339994701523/133710584036504:ℝ)*hMl + (15715510582107859/267421168073008:ℝ)*hR0 + (17514299150446291/133710584036504:ℝ)*hRo + (9825339994701523/133710584036504:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (187223/2888:ℝ)*htarget + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass
  · linear_combination (26158166491675/370389429464:ℝ)*hMl + (42474428506651/740778858928:ℝ)*hR0 + (47457222324763/370389429464:ℝ)*hRo + (26158166491675/370389429464:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (511/8:ℝ)*htarget + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (-127/8:ℝ)*hmass
  · linear_combination (9825339994701523/133710584036504:ℝ)*hMl + (15715510582107859/267421168073008:ℝ)*hR0 + (17514299150446291/133710584036504:ℝ)*hRo + (9825339994701523/133710584036504:ℝ)*hchoice + (3855697916928/231493393415:ℝ)*hgap + (187223/2888:ℝ)*htarget + (160654079872/231493393415:ℝ)*hC + (1/1:ℝ)*hI + (70839313543/231493393415:ℝ)*hsource + (1/1:ℝ)*hR + (-37591/2888:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_9
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (10127/28000 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/12 : ℝ) ≤ z) (hzu : z ≤ (1/2 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_left (by linarith only [hzu] : z ≤ 1-z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzl] : (0 : ℝ) ≤ 24*z-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass
  · linear_combination (254810074576/1884800803:ℝ)*hMl + (511/2:ℝ)*hzl + (7173876568/81947861:ℝ)*hR0 + (358420249552/1884800803:ℝ)*hRo + (254810074576/1884800803:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (48/1:ℝ)*hmass
  · linear_combination (94579922826864/680413089883:ℝ)*hMl + (187223/722:ℝ)*hzl + (2646149569416/29583177821:ℝ)*hR0 + (131983195993200/680413089883:ℝ)*hRo + (94579922826864/680413089883:ℝ)*hchoice + (154958926848/9424004015:ℝ)*hgap + (6456621952/9424004015:ℝ)*hC + (1/1:ℝ)*hI + (2967382063/9424004015:ℝ)*hsource + (1/1:ℝ)*hR + (18704/361:ℝ)*hmass

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_scored_t6_r3_cap_cell_10
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (1/2 : ℝ) ≤ z) (hzu : z ≤ (5/6 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_left (by linarith only [hzu] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linear_combination (2651/10:ℝ)*hzl + (5776369856/50701605:ℝ)*hR0 + (11289993008/50701605:ℝ)*hRo + (1364520811424/10022017255:ℝ)*hchoice + (682260405712/30066051765:ℝ)*hem + (322682624/16900535:ℝ)*hgap + (40335328/50701605:ℝ)*hC + (1/1:ℝ)*hI + (10366277/50701605:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (699179431728/6101093135:ℝ)*hR0 + (1365860001324/6101093135:ℝ)*hRo + (496105281620856/3617948229055:ℝ)*hchoice + (82684213603476/3617948229055:ℝ)*hem + (1227407808/64222033:ℝ)*hgap + (51141992/64222033:ℝ)*hC + (1/1:ℝ)*hI + (13080041/64222033:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass
  · linear_combination (2651/10:ℝ)*hzl + (5776369856/50701605:ℝ)*hR0 + (11289993008/50701605:ℝ)*hRo + (1364520811424/10022017255:ℝ)*hchoice + (682260405712/30066051765:ℝ)*hem + (322682624/16900535:ℝ)*hgap + (40335328/50701605:ℝ)*hC + (1/1:ℝ)*hI + (10366277/50701605:ℝ)*hsource + (1/1:ℝ)*hR + (288/5:ℝ)*hmass
  · linear_combination (960739/3610:ℝ)*hzl + (699179431728/6101093135:ℝ)*hR0 + (1365860001324/6101093135:ℝ)*hRo + (496105281620856/3617948229055:ℝ)*hchoice + (82684213603476/3617948229055:ℝ)*hem + (1227407808/64222033:ℝ)*hgap + (51141992/64222033:ℝ)*hC + (1/1:ℝ)*hI + (13080041/64222033:ℝ)*hsource + (1/1:ℝ)*hR + (105832/1805:ℝ)*hmass

theorem large_selected_scored_t6_r3_cap_cell_11
    (M q e z a o R S I H g : ℝ)
    (hq0 : 0 ≤ q) (hqM : q ≤ M) (hR0 : 0 ≤ R) (hRM : R+M ≤ 1) (hRo : R ≤ o)
    (hchoice : M ≤ q+(1/2 : ℝ)*R)
    (he0 : 0 ≤ e) (hem : e ≤ 6*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hCscore : ∀ U B : ℝ, 0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → M ≤ U →
      S ≤ (360/19)*(B*(1+e)-1/10)+(96/19)*(2000/593 : ℝ)*(6*(q+(1/2 : ℝ)*R)-(1+e))-96/19)
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hMl : (79/350 : ℝ) ≤ M) (hMu : M ≤ (407/1000 : ℝ))
    (hzl : (5/6 : ℝ) ≤ z) (hzu : z ≤ (1/1 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hS := hSall (407/1000 : ℝ) (314/407 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hMu
  have hC := hCscore (407/1000 : ℝ) (3233/4070 : ℝ) (by norm_num) (by norm_num) (by norm_num) hMu
  have hI := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hzu
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hzl]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hzl] : 1-z ≤ z)] at hL hR ⊢
  rw [max_eq_right (by linarith only [hzl] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp hI with hI | hI
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]
  · linarith only [hMl,hzl,hRo,hchoice,ho0,ha,hmass]

end TSP.Improvements20261105
