import TSP.Improvements20261105.GatedResourceFormula
import TSP.Improvements20261105.BypassPaymentArithmetic
import TSP.Improvements20261105.GatedComponentLedger

/-! Pay the four bypass claims from one disjoint internal-mass account
and the actual owned penalties. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def bypassMassClaim (P : GatePlan d) (x : BackEdge d → ℝ) (s : d.tree.Child) : ℝ :=
  match P.kind s with
  | .disabled => 0
  | .outgoing => min (tailBackMass d x s) 2
  | .twoDirections => 2
  | .sharedGate => min (tailBackMass d x s + gateBackMass d x (P.receiver s)) 2
  | .outsideGate => min (min (outsideBackMass d P x s) (gateBackMass d x (P.receiver s))) 2

theorem GatedDrops.donorResource_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) (s : d.tree.Child) :
    0 ≤ a.donorResource d P x s :=
  Finset.sum_nonneg (fun b _ => mul_nonneg (hx b) (a.donorUse_nonneg d ha s b))

theorem selected_bypass_payment {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P)
    (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) (s : d.tree.Child)
    (hsel : a.head s = 1) (hrep : a.representative s = 0) :
    bypassMassClaim d P x s ≤ a.donorResource d P x s + 2 * (a.penalty d P s : ℝ) := by
  have ho := tailBackMass_nonneg d x hx (s : V)
  have hF := gateBackMass_nonneg d x hx (P.receiver s)
  have hA := outsideBackMass_nonneg d P x hx s
  have ht : (0 : ℝ) ≤ a.tail s := by exact_mod_cast ha.tail_nonneg _
  have hp : (0 : ℝ) ≤ a.pref (P.receiver s) := by exact_mod_cast ha.pref_nonneg _
  have hb : (0 : ℝ) ≤ a.outside s := by exact_mod_cast ha.outside_nonneg _
  cases hk : P.kind s with
  | disabled =>
    simpa [bypassMassClaim, GatedDrops.penalty, hk] using a.donorResource_nonneg d ha x hx s
  | outgoing =>
    have h := outgoing_switch_payment (a.tail s) (ha.tail_nonneg _) _ ho
    rw [a.donorResource_formula]
    simp only [bypassMassClaim, GatedDrops.penalty, hk, hsel, hrep, sub_zero, GatePlan.UsesGate,
      reduceCtorEq, or_self, if_false, add_zero]
    nlinarith
  | twoDirections =>
    have h := a.donorResource_nonneg d ha x hx s
    simp only [bypassMassClaim, GatedDrops.penalty, hk, hsel, hrep, sub_zero]
    norm_num
    linarith
  | sharedGate =>
    have h := shared_switch_payment (a.tail s) (a.pref (P.receiver s))
      (ha.tail_nonneg _) (ha.pref_nonneg _) _ _ ho hF
    rw [a.donorResource_formula]
    simp only [bypassMassClaim, GatedDrops.penalty, hk, hsel, hrep, sub_zero, GatePlan.UsesGate,
      true_or, if_true]
    nlinarith
  | outsideGate =>
    have h := outside_switch_payment (a.outside s) (a.pref (P.receiver s))
      (ha.outside_nonneg _) (ha.pref_nonneg _) _ _ hA hF
    rw [a.donorResource_formula]
    simp only [bypassMassClaim, GatedDrops.penalty, hk, hsel, hrep, sub_zero, GatePlan.UsesGate,
      or_true, if_true]
    nlinarith

theorem canonical_total_bypass_payment
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x : BackEdge d → ℝ) (hx : ∀ b, 0 ≤ x b) :
    (∑ s ∈ a.selectedHeads d, bypassMassClaim d P x s) ≤
      a.internalSelectedBackMass d P x + 2 * (∑ s : d.tree.Child, (a.penalty d P s : ℝ)) := by
  have hlocal (s : d.tree.Child) (hs : s ∈ a.selectedHeads d) :
      bypassMassClaim d P x s ≤ a.donorResource d P x s + 2 * (a.penalty d P s : ℝ) := by
    have hsel := (Finset.mem_filter.mp hs).2
    exact selected_bypass_payment d ha x hx s hsel
      (canonical_selected_rep_zero d P hP t ht f hf hb a hcan s hsel)
  have h := Finset.sum_le_sum hlocal
  have hsub := Finset.sum_le_sum_of_subset_of_nonneg
    (f := fun s => a.donorResource d P x s + 2 * (a.penalty d P s : ℝ))
    (Finset.subset_univ (a.selectedHeads d))
    (fun s _ _ => add_nonneg (a.donorResource_nonneg d ha x hx s)
      (mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) (by exact_mod_cast a.penalty_nonneg d P s)))
  have hres := a.total_donorResource_bound d hP ha x hx
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum] at h hsub
  linarith

end TSP.Improvements20261105
