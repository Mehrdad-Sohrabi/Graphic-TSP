import TSP.Improvements20261105.ScoredUniformNetLoad

/-! An unconditional count tail for selected matching-source loads. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_large_any_source_load
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hcount : 33 ≤ ((d).backGroup s).card)
    (δ : ℝ) (hδ : δ ≤ 1/2) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1) := by
  have hh := scoredDFS_uniform_canonical_load G x z hs hc root hx hn hcap hz hzx hm eligible T s
  have he := (survivingExcess_bounds d hs hx hcap s).2
  have hq0 := hx.1 ((d).treeEdge s)
  have ho0 : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hcR : (33 : ℝ) ≤ (((d).backGroup s).card : ℝ) := by exact_mod_cast hcount
  linarith only [hh,he,hq0,ho0,hcR,hδ]

end TSP.Improvements20261105
