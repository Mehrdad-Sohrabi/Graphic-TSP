import TSP.Improvements20261105.ExtendedResidualBoundary
import TSP.Improvements20261105.ExtendedResidualMassBalance
import TSP.Improvements20261105.RemainingMatchingPartition

/-! The added residual donors are exactly the targets of the remaining
matching pairs. Every exiting residual still enters a remaining source. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.internalMatchingTargets (a : GatedDrops d) (P : GatePlan d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5)) : Finset d.StarIndex :=
  (a.internalMatchingPairs d P x z C).image Prod.snd

theorem GatedDrops.internalMatchingTargets_target (a : GatedDrops d) (P : GatePlan d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (i : d.StarIndex) (hi : i ∈ a.internalMatchingTargets d P x z C) :
    i.1 ∈ C.matching.image (unaryNext d) := by
  obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hi
  have hh := (Finset.mem_filter.mp (Finset.mem_filter.mp hp).1).2
  exact Finset.mem_image.mpr ⟨p.1.1,hh⟩

theorem GatedDrops.internalMatchingTargets_not_source (a : GatedDrops d) (P : GatePlan d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (i : d.StarIndex) (hi : i ∈ a.internalMatchingTargets d P x z C) : i.1 ∉ C.matching := by
  intro hh
  exact Finset.disjoint_left.mp (fixed_matching_source_target_disjoint d x z (415/2) (704/5) C)
    hh (a.internalMatchingTargets_target d P x z C i hi)

theorem GatedDrops.internalMatchingTargets_not_high_q (a : GatedDrops d) (P : GatePlan d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (i : d.StarIndex) (hi : i ∈ a.internalMatchingTargets d P x z C) :
    i ∉ a.selectedHighQHeads d x z C := by
  obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hi
  intro hh
  exact (Finset.mem_filter.mp hp).2.2
    ((a.selectedHighQHeads_matching_closed d x z C p (Finset.mem_filter.mp hp).1).mpr hh)

theorem GatedDrops.internalUnmatched_disjoint_matchingTargets (a : GatedDrops d) (P : GatePlan d)
    (x z : E → ℝ) (C : ProjectedCoverWitness d x z (415/2) (704/5)) :
    Disjoint (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C) := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  apply (Finset.mem_filter.mp hi).2.2
  exact Finset.mem_union_right _ (a.internalMatchingTargets_target d P x z C i hj)

theorem extended_actual_residual_outside_receiver
    (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (p : d.StarIndex × d.StarIndex)
    (hp : p ∈ extendedResidualOutside d x z a.head
      (a.internalUnmatchedHeads d P x z C) (a.internalMatchingTargets d P x z C)) :
    p.2 ∈ (a.internalMatchingPairs d P x z C).image Prod.fst := by
  have hpair := (Finset.mem_filter.mp hp).1
  have hdonor := Finset.mem_filter.mp (Finset.mem_filter.mp hpair).2.1
  have hsource : p.1.1 ∉ C.matching := by
    rcases Finset.mem_union.mp hdonor.1 with hh | hh
    · intro hsrc
      apply (Finset.mem_filter.mp hh).2.2
      simpa only [matchingEndpoints,Finset.image_id] using
        (Finset.mem_union_left (C.matching.image (unaryNext d)) hsrc)
    · exact a.internalMatchingTargets_not_source d P x z C p.1 hh
  have hnH : p.1 ∉ a.selectedHighQHeads d x z C := by
    rcases Finset.mem_union.mp hdonor.1 with hh | hh
    · intro hhq
      exact (Finset.mem_sdiff.mp (Finset.mem_filter.mp hh).1).2 (Finset.mem_union_right _ hhq)
    · exact a.internalMatchingTargets_not_high_q d P x z C p.1 hh
  have hclass := residual_nonsource_receiver_classification d hs hc x z hx hn hcap hm C P hP t ht f hf hb a ha hcan _ p hpair hsource hnH hdonor.2.1
  rcases hclass with hin | hout
  · exact ((Finset.mem_filter.mp hp).2 hin).elim
  · obtain ⟨q,hq,he⟩ := fixedMatchingStarPair_exists d hs x z hx hn hcap hm C p.2.1 hout.1
    have hei : q.1=p.2 := Subtype.ext he
    exact Finset.mem_image.mpr ⟨q,Finset.mem_filter.mpr ⟨hq,hei ▸ hout.2.1,hei ▸ hout.2.2⟩,hei⟩

end TSP.Improvements20261105
