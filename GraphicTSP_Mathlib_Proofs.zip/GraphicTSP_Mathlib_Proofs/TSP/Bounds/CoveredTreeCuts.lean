import TSP.Chapter05.DFSData
import TSP.Chapter05.TreeCutGeometry

/-! Cut geometry for the forest covered by a fixed set of back edges.
Only covered tree edges are used in the extremal-crossing arguments. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def BackCovers (b : E) (v : d.tree.Child) : Prop :=
  d.tree.Ancestor v (d.lower b) ∧ d.tree.depth (d.upper b) < d.tree.depth v

def BackCovered (B : Finset E) (v : d.tree.Child) : Prop :=
  ∃ b ∈ B, BackCovers d b v

def CoveredCrosses (B : Finset E) (U : Finset V) (v : d.tree.Child) : Prop :=
  BackCovered d B v ∧ d.tree.Crosses U v

def CoveredTerminal (B : Finset E) (U : Finset V) (v : d.tree.Child) : Prop :=
  CoveredCrosses d B U v ∧
    ∀ w : d.tree.Child, CoveredCrosses d B U w → d.tree.Ancestor v w → w = v

theorem covered_terminal_exists (B : Finset E) (U : Finset V)
    (v : d.tree.Child) (hv : CoveredCrosses d B U v) :
    ∃ w : d.tree.Child, CoveredTerminal d B U w ∧ d.tree.Ancestor v w := by
  let C := Finset.univ.filter (fun w : d.tree.Child =>
    CoveredCrosses d B U w ∧ d.tree.Ancestor v w)
  have hC : C.Nonempty := ⟨v, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hv, .refl⟩⟩
  obtain ⟨w, hw, hmax⟩ := Finset.exists_max_image C (fun w => d.tree.depth w) hC
  have hws := (Finset.mem_filter.mp hw).2
  refine ⟨w, ⟨hws.1, ?_⟩, hws.2⟩
  intro a ha hwa
  have has : a ∈ C := Finset.mem_filter.mpr ⟨Finset.mem_univ _, ha, hwa.trans hws.2⟩
  have hle := hmax a has
  have hge := d.tree.ancestor_depth_le hwa
  exact Subtype.ext (d.tree.ancestors_eq_of_depth_eq (.refl) hwa (by omega))

theorem covered_crossing_ancestor (B : Finset E) (U : Finset V) (z : d.tree.Child)
    (hz : ∀ a, CoveredTerminal d B U a → a = z)
    (v : d.tree.Child) (hv : CoveredCrosses d B U v) : d.tree.Ancestor v z := by
  obtain ⟨w, hw, hvw⟩ := covered_terminal_exists d B U v hv
  simpa only [hz w hw] using hvw

theorem backCovers_parent_path (b : E) (v : d.tree.Child) (hb : BackCovers d b v) :
    d.tree.Ancestor (d.upper b) (d.tree.parent v) := by
  have ha := d.tree.common_ancestor_of_depth_le (d.edge_ancestor b) hb.1 (le_of_lt hb.2)
  apply d.tree.ancestor_parent_of_ne ha
  intro h
  have hlt := hb.2
  rw [h] at hlt
  exact Nat.lt_irrefl _ hlt

theorem backCovers_below (b : E) (v w : d.tree.Child) (hb : BackCovers d b v)
    (hw : d.tree.OnPath v (d.lower b) w) : BackCovers d b w := by
  exact ⟨hw.2, hb.2.trans_le (d.tree.ancestor_depth_le hw.1)⟩

theorem backCovers_above (b : E) (v w : d.tree.Child) (hb : BackCovers d b v)
    (hw : d.tree.OnPath (d.upper b) (d.tree.parent v) w)
    (hne : (w : V) ≠ d.upper b) : BackCovers d b w := by
  have hstrict : d.tree.depth (d.upper b) < d.tree.depth w := by
    have hle := d.tree.ancestor_depth_le hw.1
    by_contra hn
    exact hne (d.tree.ancestors_eq_of_depth_eq (.refl) hw.1 (by omega))
  exact ⟨hb.1.trans ((Relation.ReflTransGen.single ⟨v.2, rfl⟩).trans hw.2), hstrict⟩

theorem covered_terminal_lower_side (B : Finset E) (U : Finset V)
    (v : d.tree.Child) (hv : CoveredTerminal d B U v)
    (b : E) (hb : b ∈ B) (hc : BackCovers d b v) :
    d.lower b ∈ U ↔ (v : V) ∈ U := by
  apply d.tree.membership_along_of_no_cross U hc.1
  intro w hw hne hcross
  have hcov : BackCovered d B w := ⟨b, hb, backCovers_below d b v w hc hw⟩
  exact hne (congrArg Subtype.val (hv.2 w ⟨hcov, hcross⟩ hw.1))

theorem covered_shallowest_upper_side (B : Finset E) (U : Finset V)
    (v : d.tree.Child)
    (hmin : ∀ w, CoveredCrosses d B U w → d.tree.depth v ≤ d.tree.depth w)
    (b : E) (hb : b ∈ B) (hc : BackCovers d b v) :
    d.tree.parent v ∈ U ↔ d.upper b ∈ U := by
  apply d.tree.membership_along_of_no_cross U (backCovers_parent_path d b v hc)
  intro w hw hne hcross
  have hcov : BackCovered d B w := ⟨b, hb, backCovers_above d b v w hc hw hne⟩
  have hh := hmin w ⟨hcov, hcross⟩
  have hle := d.tree.ancestor_depth_le hw.2
  have hd := d.tree.parent_depth v v.2
  omega

theorem covered_spare_lower_side (B : Finset E) (U : Finset V)
    (v z : d.tree.Child)
    (hz : ∀ a, CoveredTerminal d B U a → a = z)
    (b : E) (hb : b ∈ B) (hc : BackCovers d b v)
    (hspare : ∀ w : d.tree.Child, d.tree.OnPath v (d.lower b) w →
      (w : V) ≠ v → ¬d.tree.Ancestor w z) :
    d.lower b ∈ U ↔ (v : V) ∈ U := by
  apply d.tree.membership_along_of_no_cross U hc.1
  intro w hw hne hcross
  have hcov : BackCovered d B w := ⟨b, hb, backCovers_below d b v w hc hw⟩
  exact hspare w hw hne (covered_crossing_ancestor d B U z hz w ⟨hcov, hcross⟩)

theorem dfs_cut_iff (U : Finset V) (e : E) :
    e ∈ G.cut U ↔ ¬(d.lower e ∈ U ↔ d.upper e ∈ U) := by
  rcases d.oriented e with h | h <;>
    simp only [Graph.cut, Finset.mem_filter, Finset.mem_univ, true_and, h.1, h.2] <;> tauto

theorem dfs_tree_cut_iff (U : Finset V) (v : d.tree.Child) :
    d.treeEdge v ∈ G.cut U ↔ d.tree.Crosses U v := by
  rw [dfs_cut_iff, d.treeEdge_lower, d.treeEdge_upper]
  rfl

theorem backCovers_iff_fundamental_cut (b : E) (v : d.tree.Child) :
    BackCovers d b v ↔ b ∈ G.cut (d.tree.descendantShore v) := by
  rw [dfs_cut_iff d]
  simp only [RootedTree.descendantShore, Finset.mem_filter, Finset.mem_univ, true_and]
  have ha : d.tree.Ancestor v (d.upper b) → d.tree.Ancestor v (d.lower b) :=
    fun h => (d.edge_ancestor b).trans h
  constructor
  · intro h
    have hl := h.1
    have hn : ¬d.tree.Ancestor v (d.upper b) := by
      intro hh
      have hd := d.tree.ancestor_depth_le hh
      have ht := h.2
      omega
    tauto
  · intro h
    have hl : d.tree.Ancestor v (d.lower b) := by tauto
    have hn : ¬d.tree.Ancestor v (d.upper b) := by tauto
    refine ⟨hl, ?_⟩
    exact lt_of_not_ge (fun hh => hn (d.tree.common_ancestor_of_depth_le hl (d.edge_ancestor b) hh))

theorem selected_back_crossing_has_covered_crossing (B : Finset E) (U : Finset V)
    (b : E) (hb : b ∈ B) (hc : b ∈ G.cut U) :
    ∃ v : d.tree.Child, CoveredCrosses d B U v := by
  by_contra hn
  push_neg at hn
  have hs : d.lower b ∈ U ↔ d.upper b ∈ U := by
    apply d.tree.membership_along_of_no_cross U (d.edge_ancestor b)
    intro v hv hne hcross
    have hd : d.tree.depth (d.upper b) < d.tree.depth v := by
      have hle := d.tree.ancestor_depth_le hv.1
      by_contra hh
      exact hne (d.tree.ancestors_eq_of_depth_eq (.refl) hv.1 (by omega))
    exact hn v ⟨⟨b, hb, hv.2, hd⟩, hcross⟩
  exact (dfs_cut_iff d U b).mp hc hs

end TSP.Improvements20261105
