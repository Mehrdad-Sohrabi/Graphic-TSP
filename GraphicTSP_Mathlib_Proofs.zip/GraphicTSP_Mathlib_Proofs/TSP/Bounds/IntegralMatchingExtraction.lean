import TSP.Improvements20261105.BipartiteMatchingNetwork

/-! Integral unit-capacity flow yields actual disjoint endpoint pairs. -/
namespace TSP.Improvements20261105
open Graph Chapter06 Classical
open scoped BigOperators
variable {L R E : Type} [Fintype L] [Fintype R] [Fintype E]
  [DecidableEq L] [DecidableEq R] [DecidableEq E]

theorem unit_fiber_injective (endpoint : E → L) (k : E → ℝ) (M : Finset E)
    (hk : ∀ e, 0 ≤ k e) (hM : ∀ e ∈ M, k e = 1)
    (hs : ∀ l, (∑ e, if endpoint e = l then k e else 0) ≤ 1) :
    Set.InjOn endpoint (M : Set E) := by
  intro a ha b hb heq
  by_contra hne
  have hle : (2 : ℝ) ≤ ∑ e, if endpoint e = endpoint a then k e else 0 := by
    calc
      2 = ∑ e ∈ ({a, b} : Finset E), if endpoint e = endpoint a then k e else 0 := by
        norm_num [hne, heq, hM a ha, hM b hb]
      _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
        (fun e _ _ => by split_ifs; exact hk e; exact le_rfl)
  have hu := hs (endpoint a)
  linarith

theorem integral_matching_extraction (left : E → L) (right : E → R)
    (g : MatchingArc L R E → ℕ)
    (hg : Balanced (matchingNetwork left right) (fun a => (g a : ℝ)))
    (hb : ∀ a, g a ≤ matchingCapacity a) :
    ∃ M : Finset E, Set.InjOn left (M : Set E) ∧ Set.InjOn right (M : Set E) ∧
      ∀ w : E → ℝ, (∑ e, w e * (g (.inl e) : ℝ)) = ∑ e ∈ M, w e := by
  let f : MatchingArc L R E → ℝ := fun a => g a
  have hfb : ∀ a, 0 ≤ f a ∧ f a ≤ matchingCapacity a := fun a =>
    ⟨Nat.cast_nonneg _, by dsimp [f]; exact_mod_cast hb a⟩
  have he1 (e : E) : g (.inl e) ≤ 1 := by
    have hh := matching_edge_le_one left right f hg hfb e
    change (g (.inl e) : ℝ) ≤ 1 at hh
    exact_mod_cast hh
  let M : Finset E := Finset.univ.filter (fun e => g (.inl e) = 1)
  have hM (e : E) (he : e ∈ M) : f (.inl e) = 1 := by
    have hh := (Finset.mem_filter.mp he).2
    simp [f, hh]
  refine ⟨M, ?_, ?_, ?_⟩
  · apply unit_fiber_injective left (fun e => f (.inl e)) M (fun e => (hfb _).1) hM
    intro l
    rw [matching_left_balance left right f hg l]
    simpa [matchingCapacity] using (hfb (.inr (.inl (.inl l)))).2
  · apply unit_fiber_injective right (fun e => f (.inl e)) M (fun e => (hfb _).1) hM
    intro r
    rw [matching_right_balance left right f hg r]
    simpa [matchingCapacity] using (hfb (.inr (.inl (.inr r)))).2
  · intro w
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro e _
    by_cases h : g (.inl e) = 1
    · simp [h]
    · have hz : g (.inl e) = 0 := by have hh := he1 e; omega
      simp [hz]

end TSP.Improvements20261105
