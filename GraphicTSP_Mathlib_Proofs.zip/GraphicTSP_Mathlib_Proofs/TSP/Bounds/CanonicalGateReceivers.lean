import TSP.Improvements20261105.GatePrefixPromotion
import TSP.Improvements20261105.GatedDualFormula
import TSP.Improvements20261105.CanonicalGatedChoice

/-! A canonical optimal dual selects every receiver of a positive gated
prefix. The exchange preserves actual dual feasibility and cannot lower
the objective; its strict improvement is in the first canonical priority. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem gate_receiver_nonroot (P : GatePlan d) (hP : P.RespectsTree d)
    (r : d.tree.Child) (hr : P.IsReceiver d r) : d.tree.parent r ≠ d.tree.root := by
  obtain ⟨s, hs, he⟩ := hr
  rw [← he, hP s hs]
  exact s.2

theorem promoteGatePrefix_reward (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (hr : P.IsReceiver d r) (hn : d.tree.parent r ≠ d.tree.root)
    (v : d.tree.Child) :
    gatedTrueReward d P (promoteGatePrefix d P p r) v =
      gatedTrueReward d P p v + (if v = r then 1 else 0) := by
  unfold gatedTrueReward
  rw [promoteGatePrefix_suffix, promoteGatePrefix_representative, promoteGatePrefix_prefix]
  by_cases he : v = r
  · subst v
    simp [hr, hn]
    omega
  · simp [he]

theorem promoteGatePrefix_penalty_le (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r v : d.tree.Child) :
    gatedBypassPenalty d P (promoteGatePrefix d P p r) v ≤ gatedBypassPenalty d P p v +
      (if P.UsesGate d v ∧ P.receiver v = r then 1 else 0) := by
  have hd := gatePromotionSide_bypass d P r v
  have hdiff : ((promoteGatePrefix d P p r (gatedBypassTarget d P v) : ℤ) : ℝ) -
      promoteGatePrefix d P p r (gatedBypassSource d P v) =
      (p (gatedBypassTarget d P v) : ℝ) - p (gatedBypassSource d P v) +
        (if P.UsesGate d v ∧ P.receiver v = r then (1 : ℝ) else 0) := by
    have hdR : (gatePromotionSide d P r (gatedBypassTarget d P v) : ℝ) -
        gatePromotionSide d P r (gatedBypassSource d P v) =
        (if P.UsesGate d v ∧ P.receiver v = r then (1 : ℝ) else 0) := by
      exact_mod_cast hd
    simp only [promoteGatePrefix, Int.cast_add]
    linarith
  by_cases hdis : P.kind v = .disabled
  · simp [gatedBypassPenalty, hdis, GatePlan.UsesGate]
  · simp only [gatedBypassPenalty, if_neg hdis, hdiff]
    split_ifs <;> apply max_le <;> linarith [le_max_left
      ((p (gatedBypassTarget d P v) : ℝ) - p (gatedBypassSource d P v)) 0,
      le_max_right ((p (gatedBypassTarget d P v) : ℝ) - p (gatedBypassSource d P v)) 0]

theorem gate_receiver_owner_sum (P : GatePlan d) (hP : P.RespectsTree d)
    (r : d.tree.Child) (hr : P.IsReceiver d r) :
    (∑ v : d.tree.Child, if P.UsesGate d v ∧ P.receiver v = r then (1 : ℝ) else 0) = 1 := by
  obtain ⟨s, hs, he⟩ := hr
  rw [Finset.sum_eq_single s]
  · simp [hs, he]
  · intro v _ hv
    have hn : ¬(P.UsesGate d v ∧ P.receiver v = r) := by
      rintro ⟨huse, hrec⟩
      exact hv (gate_receiver_unique d P hP v s huse hs (hrec.trans he.symm))
    simp [hn]
  · simp

theorem promoteGatePrefix_dual_nondecreasing (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (hr : P.IsReceiver d r) :
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (p v : ℝ)) ≤
    realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t)
      (fun v => (promoteGatePrefix d P p r v : ℝ)) := by
  rw [gated_augmented_dual_formula, gated_augmented_dual_formula]
  have hlocal : ∀ v : d.tree.Child,
      ((gatedTrueReward d P p v : ℝ) - ((gatedFreeBase d v : ℝ) + t v) *
        max (gatedHeadSelector d p v : ℝ) 0 - gatedBypassPenalty d P p v) +
        (if v = r then 1 else 0) - (if P.UsesGate d v ∧ P.receiver v = r then 1 else 0) ≤
      (gatedTrueReward d P (promoteGatePrefix d P p r) v : ℝ) -
        ((gatedFreeBase d v : ℝ) + t v) * max (gatedHeadSelector d (promoteGatePrefix d P p r) v : ℝ) 0 -
        gatedBypassPenalty d P (promoteGatePrefix d P p r) v := by
    intro v
    rw [promoteGatePrefix_reward d P p r hr (gate_receiver_nonroot d P hP r hr),
      promoteGatePrefix_head]
    push_cast
    linarith [promoteGatePrefix_penalty_le d P p r v]
  have hh := Finset.sum_le_sum (s := Finset.univ) (fun v _ => hlocal v)
  simp only [Finset.sum_sub_distrib, Finset.sum_add_distrib,
    gate_receiver_owner_sum d P hP r hr] at hh
  simpa using hh

theorem promoteGatePrefix_count (P : GatePlan d) (p : GatedVertex d → ℤ)
    (r : d.tree.Child) (hr : P.IsReceiver d r) (hpre : gatedPrefixDrop d p r = 1) :
    gatedPrefixCount d P (promoteGatePrefix d P p r) + 1 = gatedPrefixCount d P p := by
  let S := Finset.univ.filter (fun v : d.tree.Child => P.IsReceiver d v ∧ 0 < gatedPrefixDrop d p v)
  have hm : r ∈ S := by simp [S, hr, hpre]
  have he : Finset.univ.filter (fun v : d.tree.Child =>
      P.IsReceiver d v ∧ 0 < gatedPrefixDrop d (promoteGatePrefix d P p r) v) = S.erase r := by
    ext v
    by_cases hv : v = r
    · subst v
      simp [S, promoteGatePrefix_prefix, hpre]
    · simp [S, promoteGatePrefix_prefix, hv]
  unfold gatedPrefixCount
  rw [he]
  exact Finset.card_erase_add_one hm

theorem canonical_gate_receiver_selected (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (p : GatedVertex d → ℤ) (hp : CanonicalGatedFor d P t f p)
    (r : d.tree.Child) (hr : P.IsReceiver d r) (hpre : 0 < gatedPrefixDrop d p r) :
    gatedHeadSelector d p r = 1 := by
  have hfeas := hp.1.1
  have hroot := gate_receiver_nonroot d P hP r hr
  have hbox := gated_nonroot_split_drop_bounds d hs hc hfeas r hroot
  have hpre' : gatedPrefixDrop d p r = 1 := by omega
  have hsuf : gatedSuffixDrop d p r = 0 := by omega
  by_contra hn
  have hhead : gatedHeadSelector d p r = 0 := by
    have hh := gated_head_selector_binary d P p hfeas r
    omega
  let q := promoteGatePrefix d P p r
  have hq : GatedDualFeasible d P q := promoteGatePrefix_feasible d P p hfeas r hr hpre' hsuf hhead
  have hge := promoteGatePrefix_dual_nondecreasing d P hP t p r hr
  have hle := real_capacity_circulation_weak_duality (gatedNetwork d P)
    (fun a => (gatedCost d a : ℤ)) (gatedLower d P) (gatedAugmentedUpper d P t) f hf hb
    (fun v => (q v : ℝ)) (by
      intro a ha
      dsimp only
      exact_mod_cast hq a ((gatedAugmentedUpper_none d P t a).mp ha))
  have heq : realCapacityDualValue (gatedNetwork d P) (fun a => (gatedCost d a : ℤ))
      (gatedLower d P) (gatedAugmentedUpper d P t) (fun v => (q v : ℝ)) =
      ∑ v : d.tree.Child, f (gatedPaidArc d v) := by
    simp only [Int.cast_natCast] at hle
    rw [gated_cost_sum d f] at hle
    rw [hp.1.2] at hge
    exact le_antisymm hle hge
  have hmin := hp.2.1 q ⟨hq, heq⟩
  have hcount := promoteGatePrefix_count d P p r hr hpre'
  dsimp only [q] at hmin
  omega

end TSP.Improvements20261105
