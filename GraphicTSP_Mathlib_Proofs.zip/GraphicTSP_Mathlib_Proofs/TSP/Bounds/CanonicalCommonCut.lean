import TSP.Improvements20261105.CanonicalHeadDeletion
import TSP.Improvements20261105.CommonPathBudget
import TSP.Improvements20261105.SelectedLinkComponents
import TSP.Chapter10.StarSuccessors

/-! No true cut is common to every back of a selected head. In particular
a selected unary donor and its successor share one actual component,
whether or not the successor is selected. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_no_common_true_cut
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) (w : (expandedTree d).Child) :
    ¬∀ b ∈ ownBackEdges d s, w ∈ a.backPathCuts d P b := by
  intro hw
  have hsize := canonical_selected_head_size d P hP t ht f hf hb a ha hcan s hsel
  have hB : (ownBackEdges d s).Nonempty := by
    apply Finset.card_pos.mp
    rw [ownBackEdges_card]
    omega
  have hcost := a.common_cut_deletion_cost d ha (ownBackEdges d s) {s} hB w hw
  have hstrict := canonical_selected_head_deletion_cost d P hP t ht f hf hb a ha hcan s hsel
  rw [hcost] at hstrict
  have hb : (1 : ℝ) ≤ gatedFreeBase d s := by unfold gatedFreeBase; split_ifs <;> norm_num
  linarith

theorem unary_own_back_crosses_connector (hs : G.IsSimple) (s u : d.tree.Child)
    (hunary : childCount d s = 1) (hpar : d.tree.parent u = (s : V))
    (b : BackEdge d) (hb : b ∈ ownBackEdges d s) : backConnectorPath d b u := by
  have hanchor := (Finset.mem_filter.mp hb).2
  have hgroup := (back_anchor_iff_group d b s).mp hanchor
  have hdesc := ((d.mem_backGroup_iff s b.1).mp hgroup).2.2
  obtain ⟨v, hvpar, hvdesc⟩ := d.tree.exists_child_below hdesc (Ne.symm (backGroup_lower_ne_child d hs s hgroup))
  have hveq := one_child_unique d s hunary v u hvpar hpar
  rw [hveq] at hvdesc
  have hsu : d.tree.Ancestor (s : V) (u : V) := Relation.ReflTransGen.single ⟨u.2, hpar⟩
  have hne : u ≠ s := by
    intro he
    have hd := d.tree.parent_depth u u.2
    rw [hpar, he] at hd
    omega
  exact ⟨⟨by simpa only [hanchor] using hsu, hvdesc⟩, by simpa only [hanchor] using hne⟩

theorem canonical_selected_unary_connector_uncut (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s u : d.tree.Child) (hunary : childCount d s = 1) (hpar : d.tree.parent u = (s : V))
    (hsel : a.head s = 1) : expandedConnectorChild d u ∉ a.trueCuts d P := by
  intro hw
  apply canonical_no_common_true_cut d P hP t ht f hf hb a ha hcan s hsel (expandedConnectorChild d u)
  intro b hb'
  exact Finset.mem_filter.mpr ⟨hw, (expanded_connector_back_path d b u).mpr
    (unary_own_back_crosses_connector d hs s u hunary hpar b hb')⟩

theorem canonical_selected_unary_same_component (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s u : d.tree.Child) (hunary : childCount d s = 1) (hpar : d.tree.parent u = (s : V))
    (hsel : a.head s = 1) : a.headComponent d P s = a.headComponent d P u := by
  have huncut := canonical_selected_unary_connector_uncut d hs P hP t ht f hf hb a ha hcan s u hunary hpar hsel
  have hsame := (expandedTree d).cutComponentRoot_uncut (a.trueCuts d P) (expandedConnectorChild d u) huncut
  change a.component d P (.inr u) = a.component d P (.inl (d.tree.parent u)) at hsame
  rw [hpar] at hsame
  have hsrep := canonical_selected_center_same_head d P hP t ht f hf hb a hcan s hsel
  exact Subtype.ext (hsrep.symm.trans hsame.symm)

end TSP.Improvements20261105
