import Mathlib.Tactic

namespace TSP.Improvements20261105
set_option autoImplicit false

theorem high_q_triple_financing (t q : ℝ) (ht : 0 ≤ t) (hq : 0 ≤ q)
    (hpack : 1 ≤ t*q) : (13123/200 : ℝ) ≤ 8+4*t+(415/2)*q := by
  have htpos : 0 < t := by nlinarith
  by_contra h
  have hh : 4*t+(415/2)*q < (11523/200 : ℝ) := by linarith
  have hm := mul_lt_mul_of_pos_right hh htpos
  nlinarith [sq_nonneg (2*t-(11523/800 : ℝ))]

theorem high_q_triple_group_scalar (ts tw tr q h e : ℝ) (ns nw nr : ℤ)
    (hs : ns=0 ∨ ns=1) (hw : nw=0 ∨ nw=1) (hr : nr=0 ∨ nr=1)
    (hh0 : 0 ≤ h) (hh1 : h ≤ 1/2) (heq : e+q ≤ h)
    (hts : 2 ≤ ts) (htw : 0 ≤ tw) (htr : 0 ≤ tr) (hq : 0 ≤ q) (hpack : 1 ≤ tw*q) :
    (415/2)*e-(704/5)+60*h*(1-(ns:ℝ)-(nw:ℝ))+(ns:ℝ)*(48+240/361)+
      (nw:ℝ)*(48*h+2064/361)+(nr:ℝ)*(54+4*tr) ≤ 4*(ts+tw+tr) := by
  have ha := high_q_triple_financing tw q htw hq hpack
  have hb : (nr:ℝ)*(54+4*tr) ≤ 54+4*tr := by
    rcases hr with rfl | rfl <;> norm_num <;> linarith
  rcases hs with rfl | rfl <;> rcases hw with rfl | rfl <;> norm_num at * <;> linarith

end TSP.Improvements20261105
