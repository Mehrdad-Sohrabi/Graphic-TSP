import TSP.Chapter10.GeneralSparsity
import TSP.GraphCutCounting
import TSP.SupportExtreme

/-! Restrict a full-rank cut family to the edges induced by an actual
vertex set. This is a rank argument on the original support. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def inducedGraph (G : Graph V E) (W : Finset V) : Graph W (G.internalEdges W) where
  src := fun e => ⟨G.src e.1, (Finset.mem_filter.mp e.2).2.1⟩
  dst := fun e => ⟨G.dst e.1, (Finset.mem_filter.mp e.2).2.2⟩

noncomputable def restrictShore (W U : Finset V) : Finset W :=
  Finset.univ.filter (fun v => v.1 ∈ U)

@[simp] theorem mem_restrictShore (W U : Finset V) (v : W) :
    v ∈ restrictShore W U ↔ v.1 ∈ U := by simp [restrictShore]

theorem induced_restricted_cut (G : Graph V E) (W U : Finset V) :
    (G.restrictTo (G.internalEdges W)).cut U = (inducedGraph G W).cut (restrictShore W U) := by
  ext e
  simp [Graph.cut, Graph.restrictTo, inducedGraph]

theorem induced_cut_sum (G : Graph V E) (W U : Finset V) (y : G.internalEdges W → ℝ) :
    edgeSum (extendEdgeVector (G.internalEdges W) y) (G.cut U) =
      edgeSum y ((inducedGraph G W).cut (restrictShore W U)) := by
  rw [extendEdgeVector_cut, induced_restricted_cut]

noncomputable def restrictedCutFamily (W : Finset V) (F : Finset (Finset V)) : Finset (Finset W) :=
  (F.image (restrictShore W)).erase ∅

theorem restrictedCutFamily_laminar (W : Finset V) (F : Finset (Finset V))
    (hF : LaminarFamily F) : LaminarFamily (restrictedCutFamily W F) := by
  intro A hA B hB
  obtain ⟨U, hU, rfl⟩ := Finset.mem_image.mp (Finset.mem_of_mem_erase hA)
  obtain ⟨Z, hZ, rfl⟩ := Finset.mem_image.mp (Finset.mem_of_mem_erase hB)
  rcases hF U hU Z hZ with hd | hs | hs
  · left
    apply Finset.disjoint_left.mpr
    intro v hv hz
    exact (Finset.disjoint_left.mp hd) ((mem_restrictShore W U v).mp hv)
      ((mem_restrictShore W Z v).mp hz)
  · right; left
    intro v hv
    exact (mem_restrictShore W Z v).mpr (hs ((mem_restrictShore W U v).mp hv))
  · right; right
    intro v hv
    exact (mem_restrictShore W U v).mpr (hs ((mem_restrictShore W Z v).mp hv))

theorem restricted_cut_rows_injective (G : Graph V E) (W : Finset V)
    (F : Finset (Finset V)) (hi : Function.Injective (cutRowMap G F)) :
    Function.Injective (cutRowMap (inducedGraph G W) (restrictedCutFamily W F)) := by
  have hz : ∀ y : G.internalEdges W → ℝ,
      cutRowMap (inducedGraph G W) (restrictedCutFamily W F) y = 0 → y = 0 := by
    intro y hy
    have hf : cutRowMap G F (extendEdgeVector (G.internalEdges W) y) = 0 := by
      funext U
      change edgeSum (extendEdgeVector (G.internalEdges W) y) (G.cut U.1) = 0
      rw [induced_cut_sum]
      by_cases he : restrictShore W U.1 = ∅
      · rw [he, Graph.cut_empty]
        exact Finset.sum_empty
      · have hm : restrictShore W U.1 ∈ restrictedCutFamily W F :=
          Finset.mem_erase.mpr ⟨he, Finset.mem_image.mpr ⟨U.1, U.2, rfl⟩⟩
        exact congrFun hy ⟨restrictShore W U.1, hm⟩
    have he : extendEdgeVector (G.internalEdges W) y = 0 :=
      hi (hf.trans (map_zero (cutRowMap G F)).symm)
    funext e
    have hh := congrFun he e.1
    simpa [extendEdgeVector, e.2] using hh
  intro y z he
  apply sub_eq_zero.mp
  apply hz
  rw [map_sub, he, sub_self]

theorem induced_edge_card_le_family (G : Graph V E) (W : Finset V)
    (F : Finset (Finset V)) (hi : Function.Injective (cutRowMap G F)) :
    (G.internalEdges W).card ≤ (restrictedCutFamily W F).card := by
  have hh := LinearMap.finrank_le_finrank_of_injective (restricted_cut_rows_injective G W F hi)
  simpa only [Module.finrank_fintype_fun_eq_card, Fintype.card_coe] using hh

end TSP.Improvements20261105
