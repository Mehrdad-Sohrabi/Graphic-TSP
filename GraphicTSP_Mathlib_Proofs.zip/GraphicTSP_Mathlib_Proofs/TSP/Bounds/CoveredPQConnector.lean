import TSP.Improvements20261105.CoveredPConnectorBounds
import TSP.Improvements20261105.FixedQLinkConnector

/-! The actual P/Q connector arm is bounded by the constructed cover
after subtracting one common projection charge. -/
namespace TSP.Improvements20261105
open Graph Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem coveredPQ_connector (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (P Q : ℝ) (hP : 0 < P) (hQ : 0 ≤ Q) (C : ProjectedCoverWitness d x z P Q)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (i : d.StarIndex) (hi : d.centers i ≠ d.tree.root) :
    (3 * P / 2) * (generalPoint d owner rootStar x (fun j => coveredPIncrease d x P Q C.cover j.1) (.inr i) - 1 / 3) +
      Q * (Y (.inr i) - edgeSum x (d.stars i) / 2) -
      P * fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 := by
  have hir : i ≠ rootStar := fun h => hi (h ▸ hroot)
  have hqfloor := (fixedQ_connector_floor_bound d hs x z hx hn hcap hm Y hY Q hQ i).trans (C.floor_bound i.1)
  have hcount : 0 < childCount d (d.centers i) := by
    apply Finset.card_pos.mpr
    exact ⟨i.1, Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩⟩
  by_cases hunary : childCount d (d.centers i) = 1
  · let v : d.tree.Child := ⟨d.centers i, hi⟩
    have hv : d.centers i = (v : V) := rfl
    have hpc := coveredP_connector_unary d hs x z hx hn hcap hm P Q hP hQ C owner ho rootStar i hir v hv hunary
    have hmul := mul_le_mul_of_nonneg_left hpc hP.le
    by_cases hexport : outgoingBackMass d x v < coveredPIncrease d x P Q C.cover v
    · have hl := coveredPIncrease_export_link d hs x z hx hn hcap hm P Q hP hQ C v hunary hexport
      have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v hunary).2 i.1 hv).symm
      have hqn := fixedQ_link_connector d hs x z hx hn hcap hm Y hY i v hv hl
      have hxi := degreeExcess_nonnegative G hx hn (d.centers i)
      have hqle : Y (.inr i) - edgeSum x (d.stars i) / 2 ≤
          -(1 - x (d.treeEdge v) - outgoingBackMass d x v) := by linarith
      have hqmul := mul_le_mul_of_nonneg_left hqle hQ
      have hlink := (coveredPIncrease_link d hs x z hx hn hcap hm P Q hP hQ C v hl).2.2.2
      rw [hnext] at hlink
      rw [max_eq_left (by linarith : 0 ≤ coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v)] at hmul
      nlinarith
    · rw [max_eq_right (by linarith : coveredPIncrease d x P Q C.cover v - outgoingBackMass d x v ≤ 0), add_zero] at hmul
      nlinarith
  · have hc : 2 ≤ childCount d (d.centers i) := by omega
    have hpc := coveredP_connector_many d hs x z hx hn hcap hm P Q hP hQ C owner ho rootStar i hir hc
    have hmul := mul_le_mul_of_nonneg_left hpc hP.le
    nlinarith

end TSP.Improvements20261105
