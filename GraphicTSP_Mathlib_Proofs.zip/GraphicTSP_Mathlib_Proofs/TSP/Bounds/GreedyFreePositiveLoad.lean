import TSP.Improvements20261105.GreedyHeadPacking
import TSP.Improvements20261105.GreedyHeadLoads

/-! Every greedy positive star with a full Q representative credit is
paid by its own back count. This uses the actual finite sums and covers
all counts, without a finite certificate cutoff. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem four_count_affine_bound (t q A Z : ℝ) (ht : 0 ≤ t) (hq : 0 ≤ q)
    (hA : 0 ≤ A) (hZ : 0 ≤ Z) (hprod : 1 ≤ t*q) (hdisc : A^2 ≤ 16*Z) :
    A-Z*q ≤ 4*t := by
  by_contra hh
  have hsum : 0 ≤ 4*t+Z*q := by positivity
  have hlt : 4*t+Z*q < A := by linarith
  have hsq : (4*t+Z*q)^2 < A^2 := (sq_lt_sq₀ hsum hA).mpr hlt
  have hp := mul_le_mul_of_nonneg_left hprod hZ
  nlinarith [sq_nonneg (4*t-Z*q)]

theorem greedy_free_positive_load_bound (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : 0 ≤ q) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hzq : ∀ e ∈ d.backGroup s, z e ≤ q)
    (hpositive : 1 ≤ edgeSum z (d.backGroup s))
    (hpack : edgeSum z (d.backGroup s)+q ≤ 2) :
    24*(edgeSum z (d.backGroup s)-1)+noncriticalIncidence d z s-(704/5)*q ≤
      4*(d.backGroup s).card := by
  let a := edgeSum z (d.backGroup s)
  let n : ℝ := (d.backGroup s).card
  have ha0 : 0 ≤ a := Finset.sum_nonneg hz
  have hn : 0 ≤ n := Nat.cast_nonneg _
  have hmass : a ≤ n*q := by
    have hh := Finset.sum_le_sum hzq
    simpa [a,n] using hh
  have hprod : 1 ≤ n*q := hpositive.trans hmass
  have hramp := Finset.sum_le_sum (s := d.backGroup s)
    (fun e he => greedy_ramp_quadratic (z e) q (hz e he) (hzq e he))
  simp only [← Finset.mul_sum] at hramp
  have hr : starIncidenceRamp d (1/2) z s ≤ 2*q*a := hramp
  have hconv := Finset.sum_le_sum (s := d.backGroup s)
    (fun e he => signed_ramp_convex (z e) (hz e he))
  simp only [Finset.sum_add_distrib,← Finset.mul_sum] at hconv
  have hmu : signedStarIncidence d (9/20) z s ≤
      (9/10)*starIncidenceRamp d (1/2) z s+(1/10)*(a-1) := by
    unfold signedStarIncidence starIncidenceRamp edgeSum
    dsimp only [a,edgeSum] at *
    linarith only [hconv]
  have hquadratic := mul_le_mul_of_nonneg_left hpack (show 0 ≤ q by exact hq)
  have hold := min_le_right ((d.backGroup s).card-1 : ℝ) (starIncidenceRamp d (1/2) z s)
  have hnew := min_le_right ((d.backGroup s).card-1 : ℝ) (signedStarIncidence d (9/20) z s)
  have hmassarm := min_le_right ((d.backGroup s).card-1 : ℝ) (ScoredParameters.massSlope*a-1)
  have holdbound : 24*(a-1)+24*oldIncidence d z s-(704/5)*q ≤ 24-(344/5)*q := by
    unfold oldIncidence
    change a+q ≤ 2 at hpack
    change q*(a+q) ≤ q*2 at hquadratic
    nlinarith only [hold,hr,hpack,hquadratic,sq_nonneg q]
  have hnewbound : 24*(a-1)+mixedNoncriticalIncidence d z s-(704/5)*q ≤
      (13924/361 : ℝ)-(193764/1805)*q := by
    unfold mixedNoncriticalIncidence
    change a+q ≤ 2 at hpack
    change q*(a+q) ≤ q*2 at hquadratic
    change min _ ((100/57 : ℝ)*a-1) ≤ (100/57 : ℝ)*a-1 at hmassarm
    change 24*(a-1)+((360/19)*min _ (signedStarIncidence d (9/20) z s)+
      (96/19)*min _ ((100/57 : ℝ)*a-1))-(704/5)*q ≤ _
    nlinarith only [hnew,hmassarm,hmu,hr,hpack,hquadratic,sq_nonneg q]
  have hb0 := four_count_affine_bound n q 24 (344/5) hn hq (by norm_num) (by norm_num) hprod (by norm_num)
  have hb1 := four_count_affine_bound n q (13924/361) (193764/1805) hn hq
    (by norm_num) (by norm_num) hprod (by norm_num)
  unfold noncriticalIncidence
  rw [add_max]
  apply (sub_le_iff_le_add).mpr
  exact max_le ((sub_le_iff_le_add).mp (holdbound.trans hb0))
    ((sub_le_iff_le_add).mp (hnewbound.trans hb1))

end TSP.Improvements20261105
