import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (x z : E → ℝ) (hx : G.SubtourFeasible x)
variable (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
variable (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
  fixedRemoval d x (allFullOverrideTargets d x) s)
variable (C : ProjectedCoverWitness d x z (415/2) (704/5))
variable (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
variable (R : E ⊕ d.StarIndex → ℝ) (i : d.StarIndex)
variable (hR : (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
  -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)

include hs hx hn hcap hm hR in
theorem current_positive_deficit_bound (hp : 1 < edgeSum z (d.backGroup i.1)) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
      (415/2)*(survivingExcess d x i.1-
        forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C
          (fixedHForceTargets d x z (415/2) (704/5) C) i.1)-
        (704/5)*(x (d.treeEdge i.1)+preliminaryQIncrease d x i.1) := by
  have hb := terminal_forcedPQ_deficit_bound d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C)
    (fixedHForceTargets_subset d x z (415/2) (704/5) C)
    (fixedPositiveTerminalChildren d x) owner rootStar R i hR
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  rw [max_eq_left (by linarith)] at he
  have hmass := hm i.1
  have hrem : fixedRemoval d x (allFullOverrideTargets d x) i.1 ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := le_max_right _ _
  change pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i ≤ _ at hb
  linarith

include hs hx hn hcap hm hR in
theorem current_projected_protected_deficit
    (hp : ProtectedHead d x z (415/2) (704/5) C i.1) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -60*min (x (d.treeEdge i.1)) (1-x (d.treeEdge i.1)) := by
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  have hpos : 1 < edgeSum z (d.backGroup i.1) := by
    have hh := hp.2.1
    rw [← he] at hh
    have hh' := (lt_max_iff.mp hh).resolve_right (lt_irrefl _)
    linarith
  have hb := current_positive_deficit_bound d hs x z hx hn hcap hm C owner rootStar R i hR hpos
  have hK := protectedCoverIncrease_deficit d hs x z hx hn hcap hm (415/2) (704/5) 60
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C i.1 hp
  have hg : protectedCoverIncrease d x z (415/2) (704/5) 60 C i.1 ≤
      forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C
        (fixedHForceTargets d x z (415/2) (704/5) C) i.1 := by
    unfold forcedCoverIncrease
    split_ifs
    · exact le_max_left _ _
    · exact le_rfl
  linarith

include hs hx hn hcap hm hR in
theorem current_projected_intrinsic_deficit (hnr : d.centers i ≠ d.tree.root)
    (hp : 1 < edgeSum z (d.backGroup i.1)) (ho : outgoingBackMass d x i.1 ≤ survivingExcess d x i.1) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        (415/2)*survivingExcess d x i.1-(704/5)*x (d.treeEdge i.1)-
          (3483/10)*outgoingBackMass d x i.1 := by
  change d.tree.parent (i.1 : V) ≠ d.tree.root at hnr
  have hb := current_positive_deficit_bound d hs x z hx hn hcap hm C owner rootStar R i hR hp
  have hfree := coveredPIncrease_free_lower d hs x z hx hn hcap hm (415/2) (704/5)
    (by norm_num) (by norm_num) C i.1 hnr
  rw [min_eq_right ho] at hfree
  have hg := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C) i.1
  have heta : preliminaryQIncrease d x i.1=outgoingBackMass d x i.1 := by
    rw [preliminaryQIncrease, if_neg hnr, min_eq_right ho]
  rw [heta] at hb
  linarith

include hs hx hn hcap hm hR in
theorem current_projected_free_positive_deficit (hnr : d.centers i ≠ d.tree.root)
    (hp : 1 < edgeSum z (d.backGroup i.1))
    (hfree : survivingExcess d x i.1 ≤ outgoingBackMass d x i.1 ∨ childCount d i.1≠1) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5)*x (d.treeEdge i.1) := by
  change d.tree.parent (i.1 : V) ≠ d.tree.root at hnr
  have hb := current_positive_deficit_bound d hs x z hx hn hcap hm C owner rootStar R i hR hp
  have hbase : survivingExcess d x i.1 ≤ coveredPIncrease d x (415/2) (704/5) C.cover i.1 := by
    rcases hfree with hE | hu
    · have hh := coveredPIncrease_free_lower d hs x z hx hn hcap hm (415/2) (704/5)
        (by norm_num) (by norm_num) C i.1 hnr
      rwa [min_eq_left hE] at hh
    · have hnlink : i.1 ∉ projectionLinks d x := fun h => hu (Finset.mem_filter.mp h).2.2.2.1
      rw [coveredPIncrease, if_neg hnr, if_neg hnlink]
  have hg := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C) i.1
  have heta := (preliminaryQIncrease_bounds d hs hx hcap i.1).1
  linarith

end TSP.Improvements20261105
