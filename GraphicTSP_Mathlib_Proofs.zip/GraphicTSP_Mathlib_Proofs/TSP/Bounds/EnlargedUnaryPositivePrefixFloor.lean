import TSP.Improvements20261105.CurrentProjectedGuardedDeficits
import TSP.Improvements20261105.UnaryPrefixQCredit
import TSP.Improvements20261105.ProjectedLeafQFloor
import TSP.Improvements20261105.TerminalForcedDeficits
import TSP.Improvements20261105.GuardedPositiveDeficits
import TSP.Improvements20261105.ActualZeroLeafCost

/-! A projected-positive unmatched unary first head retains its
ordinary negative Q floor. The preceding head is excluded by actual
component geometry, so neither K nor H can export through it. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (P : GatePlan d) (hP : P.RespectsTree d)
variable (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
variable (hf : Chapter06.Balanced (gatedNetwork d P) f)
variable (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
variable (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))

include hs hP ht hf hb ha hcan in
theorem GatedDrops.enlarged_unary_positive_prefix_floor (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (r : FlowVertex d) (i : d.StarIndex) (hicomp : a.component d P (.inr i.1) = r)
    (hfirst : ∀ j ∈ a.actualComponentStars d P r, d.tree.Ancestor i.1 j.1)
    (v : d.tree.Child) (hv : d.centers i = (v : V)) (hunary : childCount d v = 1)
    (hpositive : 1 < edgeSum z (d.backGroup i.1))
    (hunmatched : i.1 ∉ matchingEndpoints id (unaryNext d) C.matching) :
    guardedNormalizedHeadCost d x z C owner rootStar R a i ≤
      -(704/5 : ℝ)*x (d.treeEdge i.1) := by
  have hnr : d.centers i ≠ d.tree.root := by rw [hv]; exact v.2
  have hir : i ≠ rootStar := fun h => hnr (h ▸ hroot)
  let delta := terminalPIncrease d x (fixedPositiveTerminalChildren d x)
    (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C
      (fixedHForceTargets d x z (415/2) (704/5) C) j.1)
  have hdelta : AdmissibleAdjustment d x delta := terminalPIncrease_admissible d hs x hx hn hcap _ _
    (forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C (fixedHForceTargets d x z (415/2) (704/5) C)
      (fixedHForceTargets_subset d x z (415/2) (704/5) C))
  have hp := a.unary_prefix_P_connector d hs P hP t ht f hf hb ha hcan x hx hcap delta hdelta
    owner ho rootStar r i hir hicomp hfirst v hv hunary
  have hev : Even (G.intDegree d.treeEdges (d.centers i)) := by
    rw [hv,tree_degree_eq,if_neg v.2,hunary]
    norm_num
  have hqconn := fixedQ_connector_floor_bound d hs x z hx hn hcap hm R hR (704/5) (by norm_num) i
  have hfloor : fixedCoverFloor d x z (704/5) i.1 =
      -(704/5 : ℝ)*(x (d.treeEdge i.1)+preliminaryQIncrease d x i.1) := by
    have hnr' : d.tree.parent i.1 ≠ d.tree.root := hnr
    have hev' : Even (G.intDegree d.treeEdges (d.tree.parent i.1)) := hev
    rw [fixedCoverFloor,if_neg hnr',if_pos hev',if_pos hpositive]
  rw [hfloor] at hqconn
  have hrem0 := (fixedRemoval_bounds d hs hx hcap hn _ (allFullOverrideTargets_valid d x) i.1).1
  have hmass := hm i.1
  have hactual : 1 < edgeSum x (d.backGroup i.1) := by linarith only [hpositive,hrem0,hmass]
  have hqd := guarded_projected_positive_Q_deficit d x z Y R hrep hbacks hloss hterminal i hpositive
  have hdef := terminal_forcedPQ_deficit_le_cover d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C) (fixedHForceTargets_subset d x z (415/2) (704/5) C)
    (fixedPositiveTerminalChildren d x) owner rootStar R i hnr hqd
  change pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
    (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ C.cover i.1 at hdef
  rw [C.unmatched_floor i.1 hunmatched,hfloor] at hdef
  have heta := (preliminaryQIncrease_bounds d hs hx hcap i.1).1
  have htau := starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  have hj := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
    (a.head i.1) (by exact_mod_cast ha.head_nonneg i.1)
  have hconn : pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*x (d.treeEdge i.1) := by
    change currentGuardedP d x z C owner rootStar (.inr i) ≤ _ at hp
    unfold pqConnectorArm
    linarith only [hp,hqconn,htau,heta]
  have hdef' : pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*x (d.treeEdge i.1) := by linarith only [hdef,heta]
  have hmaxcost := max_le (sub_le_iff_le_add.mp hconn) (sub_le_iff_le_add.mp hdef')
  unfold guardedNormalizedHeadCost
  linarith only [hj,hmaxcost]

end TSP.Improvements20261105
