import TSP.Improvements20261105.CanonicalComponentPruning

/-! Every internal true-cut component contains a selected head, because
an actual original back edge covers each outgoing true cut. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem exists_back_on_nonroot_connector (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (v : d.tree.Child) (hv : d.tree.parent v ≠ d.tree.root) :
    ∃ b : BackEdge d, backConnectorPath d b v := by
  have hcard := deletedSubtreeCut_card d hs (two_connected_as_k hc) v hv
  obtain ⟨e, he⟩ := Finset.card_pos.mp (show 0 < (deletedSubtreeCut d v).card by omega)
  let b : BackEdge d := ⟨e, deletedSubtreeCut_back d v he⟩
  refine ⟨b, ?_⟩
  exact (cycle_parent_arc_iff d b v).mpr ((deletedSubtreeCut_iff d v e).mp he)

theorem GatedDrops.true_cut_covered (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (w : (expandedTree d).Child)
    (hw : w ∈ a.trueCuts d P) : ∃ b : BackEdge d, w ∈ a.backPathCuts d P b := by
  obtain ⟨u, rfl⟩ := (expandedTreeRoles d).surjective w
  cases u with
  | inl v =>
    have hp : 0 < a.trueRoleWeight d P (.inl v) := (Finset.mem_filter.mp hw).2
    have hn : d.tree.parent v ≠ d.tree.root := by
      intro hr
      simp [GatedDrops.trueRoleWeight, hr] at hp
    obtain ⟨b, hb⟩ := exists_back_on_nonroot_connector d hs hc v hn
    exact ⟨b, Finset.mem_filter.mpr ⟨hw, (expanded_connector_back_path d b v).mpr hb⟩⟩
  | inr v =>
    have hp : 0 < a.trueRoleWeight d P (.inr v) := (Finset.mem_filter.mp hw).2
    have hi : ¬(d.backGroup v).Nonempty := by
      intro hactive
      simp [GatedDrops.trueRoleWeight, hactive] at hp
    have hn : d.tree.parent v ≠ d.tree.root := fun hr => hi (root_group_nonempty d hs hc v hr)
    obtain ⟨b, hb⟩ := exists_back_on_nonroot_connector d hs hc v hn
    exact ⟨b, Finset.mem_filter.mpr ⟨hw, (expanded_representative_back_path d b v).mpr hb.1⟩⟩

theorem GatedDrops.internal_component_occupied (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P) (r : FlowVertex d)
    (hout : (a.componentOutgoingCuts d P r).Nonempty) : (a.componentHeads d P r).Nonempty := by
  obtain ⟨w, hw⟩ := hout
  have hwm := Finset.mem_filter.mp hw
  obtain ⟨b, hb⟩ := a.true_cut_covered d hs hc P w hwm.1
  have hsel := a.crossing_back_selected d ha b ⟨w, hb⟩
  have hparent := a.parent_component_of_back_cut d ha b w hb
  refine ⟨d.anchor b.1, (a.mem_componentHeads d P r _).mpr ⟨hsel, ?_⟩⟩
  exact hparent.symm.trans hwm.2

theorem canonical_occupied_iff_internal (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P)) (r : FlowVertex d) :
    (a.componentHeads d P r).Nonempty ↔ (a.componentOutgoingCuts d P r).Nonempty := by
  constructor
  · intro hh
    by_contra hn
    have hz := Finset.not_nonempty_iff_eq_empty.mp hn
    have hhead := canonical_leaf_component_headless d hs hc P hP t ht f hf hb a ha hcan r hz
    rw [hhead] at hh
    exact Finset.not_nonempty_empty hh
  · exact a.internal_component_occupied d hs hc ha r

end TSP.Improvements20261105
