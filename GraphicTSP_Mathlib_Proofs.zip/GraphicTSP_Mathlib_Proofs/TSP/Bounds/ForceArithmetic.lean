import Mathlib.Tactic

/-! Exact thresholds for the fixed unmatched-source and matched-target
forces. All inequalities retain their explicit parameter requirements. -/
namespace TSP.Improvements20261105

noncomputable def protectedIncrease (P Q K E q eta h d : ℝ) : ℝ :=
  max d (max 0 ((P * E - Q * (q + eta) + K * h) / P))

theorem protectedIncrease_bounds (P Q K E q eta h d : ℝ)
    (hP : 0 < P) (hQ : 0 ≤ Q) (hK : 0 ≤ K) (hKQ : K ≤ Q)
    (hE : 0 ≤ E) (hq : 0 ≤ q) (heta : 0 ≤ eta) (hh : 0 ≤ h ∧ h ≤ q)
    (hd : 0 ≤ d ∧ d ≤ E) :
    d ≤ protectedIncrease P Q K E q eta h d ∧
      0 ≤ protectedIncrease P Q K E q eta h d ∧
      protectedIncrease P Q K E q eta h d ≤ E ∧
      P * (E - protectedIncrease P Q K E q eta h d) - Q * (q + eta) ≤ -K * h := by
  have hKh : K * h ≤ Q * (q + eta) := by
    calc
      _ ≤ Q * h := mul_le_mul_of_nonneg_right hKQ hh.1
      _ ≤ _ := mul_le_mul_of_nonneg_left (by linarith) hQ
  have htop : (P * E - Q * (q + eta) + K * h) / P ≤ E := by
    apply (div_le_iff₀ hP).mpr
    nlinarith
  have hraw : (P * E - Q * (q + eta) + K * h) / P ≤ protectedIncrease P Q K E q eta h d :=
    (le_max_right _ _).trans (le_max_right _ _)
  have hraw' := (div_le_iff₀ hP).mp hraw
  exact ⟨le_max_left _ _, hd.1.trans (le_max_left _ _),
    max_le hd.2 (max_le hE htop), by nlinarith⟩

theorem protectedIncrease_change (P Q K E q eta h d : ℝ)
    (hP : 0 < P) (hKh : 0 ≤ K * h) (hd : 0 ≤ d)
    (hold : P * (E - d) - Q * (q + eta) ≤ 0) :
    P * (protectedIncrease P Q K E q eta h d - d) ≤ K * h := by
  have hbase : d ≤ d + K * h / P := le_add_of_nonneg_right (div_nonneg hKh hP.le)
  have hzero : 0 ≤ d + K * h / P := hd.trans hbase
  have hth : (P * E - Q * (q + eta) + K * h) / P ≤ d + K * h / P := by
    apply (div_le_iff₀ hP).mpr
    have hmul : (d + K * h / P) * P = d * P + K * h := by field_simp
    rw [hmul]
    nlinarith
  have hle : protectedIncrease P Q K E q eta h d ≤ d + K * h / P :=
    max_le hbase (max_le hzero hth)
  have hmul := mul_le_mul_of_nonneg_left hle hP.le
  have hdiv : P * (K * h / P) = K * h := by field_simp
  nlinarith

theorem target_force_bounds (P Q D B q h a : ℝ)
    (hP : 0 < P) (hDQ : D ≤ Q) (hQP : Q ≤ P) (hD : 0 ≤ D) (hQ : 0 ≤ Q)
    (hB : 0 ≤ B) (hq : q ≤ 1) (hh : h ≤ 1 - q) (ha : 1 - q ≤ a) :
    0 ≤ (Q * (1 - q) - max (D * h - B) 0) / P ∧
      (Q * (1 - q) - max (D * h - B) 0) / P ≤ min a (1 - q) := by
  have hmax : max (D * h - B) 0 ≤ Q * (1 - q) := by
    apply max_le
    · have h1 := mul_le_mul_of_nonneg_left hh hD
      have h2 := mul_le_mul_of_nonneg_right hDQ (sub_nonneg.mpr hq)
      linarith
    · exact mul_nonneg hQ (sub_nonneg.mpr hq)
  have htop : (Q * (1 - q) - max (D * h - B) 0) / P ≤ 1 - q := by
    apply (div_le_iff₀ hP).mpr
    have h1 := mul_le_mul_of_nonneg_right hQP (sub_nonneg.mpr hq)
    have h2 := le_max_right (D * h - B) 0
    nlinarith
  exact ⟨div_nonneg (sub_nonneg.mpr hmax) hP.le, le_min (htop.trans ha) htop⟩

end TSP.Improvements20261105
