import TSP.Improvements20261105.SignedCappedParent
import TSP.Improvements20261105.GatedComponentChildren

/-! Apply signed incidence to the actual canonical true-cut components
and a fixed projected back vector. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem leafProjectionLoss_nonneg (x z : E → ℝ) (hz : ∀ e, z e ≤ x e) (v : V) :
    0 ≤ leafProjectionLoss d x z v := by
  apply Finset.sum_nonneg
  intro e _
  change 0 ≤ if d.lower e = v then x e - z e else 0
  split_ifs
  · exact sub_nonneg.mpr (hz e)
  · exact le_rfl

theorem GatedDrops.chosenLeaf_nonroot (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P) (v : V)
    (hv : v ∈ a.chosenLeaves d hs hc P r) : v ≠ d.tree.root := by
  have hleaf := a.chosenLeaves_are_leaves d hs hc P r v hv
  obtain ⟨c, hc'⟩ := root_child_exists d hc
  intro hr
  exact hleaf c (hc'.trans hr.symm)

theorem GatedDrops.chosenLeaf_projected_mass (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (z : E → ℝ)
    (v : V) (hv : v ∈ a.chosenLeaves d hs hc P r) :
    1 - leafProjectionLoss d x z v ≤ ∑ e ∈ d.backEdges, if d.lower e = v then z e else 0 :=
  dfs_leaf_projected_mass d hs hx hcap z ⟨v, a.chosenLeaf_nonroot d hs hc P r v hv⟩
    (a.chosenLeaves_are_leaves d hs hc P r v hv)

theorem canonical_component_head_size (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (s : d.tree.Child) (hs : s ∈ a.componentHeads d P r) :
    2 ≤ (d.backGroup s).card := by
  have hh := canonical_selected_head_size d P hP t ht f hf hb a ha hcan s
    ((a.mem_componentHeads d P r s).mp hs).1
  have hb : 1 ≤ gatedFreeBase d s := by unfold gatedFreeBase; split_ifs <;> omega
  omega

theorem canonical_signed_parent_incidence (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (C : Finset d.tree.Child)
    (hCH : C ⊆ a.componentHeads d P r) (hC : C.Nonempty)
    (hnonex : 0 < (a.componentEmptyChildren d hs hc P r).card ∨ 2 ≤ (a.componentHeads d P r).card)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (q : d.tree.Child → ℝ) (hq : ∀ s ∈ a.componentHeads d P r, 0 ≤ q s)
    (hpack : ∀ s ∈ a.componentHeads d P r, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s ∈ a.componentHeads d P r, (d.backGroup s).card ≤ 3 →
      ∀ e ∈ d.backGroup s, z e ≤ q s) :
    1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card ≤
      (∑ s ∈ a.componentHeads d P r, signedHeadCharge d (9 / 20) z C s) - 4 / 15 -
      (9 / 20) * (G.internalEdges (headCenters d
        (a.componentHeads d P r \ countExcluded d (9 / 20) z (a.componentHeads d P r) C))).card +
      2 * (∑ v ∈ a.chosenLeaves d hs hc P r, leafProjectionLoss d x z v) := by
  have hh := capped_signed_parent_incidence d hs x₀ hx₀ hpositive
    (a.chosenLeaves d hs hc P r) (a.chosenLeaves_are_leaves d hs hc P r)
    (a.componentHeads d P r) C hCH hC (a.chosenLeaves_heads_in d hs hc ha r)
    (by simpa only [a.chosenLeaves_card d hs hc P r] using hnonex)
    (9 / 20) (4 / 15) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    z hz (fun e => (hzx e).trans (hcap e)) q hq hpack hsmall
    (canonical_component_head_size d P hP t ht f hf hb a ha hcan r)
    (leafProjectionLoss d x z) (fun v _ => leafProjectionLoss_nonneg d x z hzx v)
    (a.chosenLeaf_projected_mass d hs hc P r hx hcap z)
  simpa only [a.chosenLeaves_card d hs hc P r] using hh

end TSP.Improvements20261105
