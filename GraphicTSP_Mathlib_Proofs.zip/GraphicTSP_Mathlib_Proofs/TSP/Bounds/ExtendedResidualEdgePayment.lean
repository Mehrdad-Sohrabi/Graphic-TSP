import TSP.Improvements20261105.UnselectedHResidualEdgePayment
import TSP.Improvements20261105.UnselectedPositiveNonHResidualPayment
import TSP.Improvements20261105.UnselectedZeroLowTargetResidualPayment
import TSP.Improvements20261105.RetainedSelectedResidual
import TSP.Improvements20261105.UnselectedPositiveResidualEdgePayment
import TSP.Improvements20261105.UnselectedZeroResidualEdgePayment
import TSP.Improvements20261105.ResidualReceiverForceBudget
import TSP.Improvements20261105.GreedyFreePositiveLoad
import TSP.Improvements20261105.CurrentProjectedUnmatchedHeadCost
import TSP.Improvements20261105.SelectedZeroHeadPayment
import TSP.Improvements20261105.CurrentProjectedKZeroReceiver
import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost
import TSP.Improvements20261105.KOriginOwnership

/-! Actual positive unmatched residual sources may transfer to any
unmatched receiver. Only a selected positive recipient retains new debt. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_extended_residual_edge_payment
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (ν : (d).tree.Child → ℤ)
    (i : (d).StarIndex)
    (hu : i.1 ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hbinary : ν i.1=0 ∨ ν i.1=1)
    (H : Finset (d).StarIndex) (j : (d).StarIndex)
    (hpair : (j,i) ∈ couponResidualStarPairs d x z H)
    (hsource : j.1 ∉ C.matching)
    (hsourcepos : 1 < edgeSum z ((d).backGroup j.1)) :
    currentSelectedHeadCost d x z C owner rootStar R eligible T ν i+
      24*actualCouponResidual d x z j ≤
      (4 : ℝ)*((d).backGroup i.1).card+
      24*retainedSelectedResidual d x z ν i := by
  rcases hbinary with hzeroSel | honeSel
  · have hret : retainedSelectedResidual d x z ν i=0 := by simp [retainedSelectedResidual,hzeroSel]
    rw [hret,mul_zero,add_zero]
    by_cases hH : j.1 ∈ fixedHForceTargets d x z (415/2) (704/5) C
    · exact scoredDFS_unselected_H_residual_edge_payment G x z hs hc root hx hn hcap hz hzx hm C owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T ν i hu hzeroSel H j hpair hH hsourcepos
    · by_cases hp : 1 < edgeSum z ((d).backGroup i.1)
      · exact scoredDFS_unselected_positive_nonH_residual_edge_payment G x z hs hc root hx hn hcap hz hzx hm C owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T ν i hu hzeroSel hp H j hpair hH
      · have hn0 : (0 : ℝ) ≤ ((d).backGroup i.1).card := Nat.cast_nonneg _
        by_cases hdonor : j.1 ∉ matchingEndpoints id (unaryNext d) C.matching
        · have hh := scoredDFS_unselected_zero_residual_edge_payment G x z hs hc root hx hn hcap hz hzx hm C owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T ν i hzeroSel (le_of_not_gt hp) H j hpair hdonor hsourcepos
          linarith only [hh,hn0]
        · have hend : j.1 ∈ matchingEndpoints id (unaryNext d) C.matching := not_not.mp hdonor
          have htarget : j.1 ∈ C.matching.image (unaryNext d) := by
            rcases Finset.mem_union.mp hend with hh | hh
            · have hh' : j.1 ∈ C.matching := by simpa using hh
              exact (hsource hh').elim
            · exact hh
          have hlow : x ((d).treeEdge j.1) < 13/40 := by
            by_contra hh
            exact hH (Finset.mem_filter.mpr ⟨htarget,le_of_not_gt hh⟩)
          have hh := scoredDFS_unselected_zero_low_target_residual_edge_payment G x z hs hc root hx hn hcap hz hzx hm C owner ho rootStar hroot Y R hY hR hrep hbacks hloss hterminal hzero eligible T ν i hu hzeroSel (le_of_not_gt hp) H j hpair hH hlow hsourcepos
          linarith only [hh,hn0]
  · exact scoredDFS_selected_unmatched_retained_residual_payment G x z hs hc root hx hn hcap hz hzx hm C owner rootStar Y R hY hrep hbacks hloss hterminal eligible T ν i honeSel hu H j hpair

end TSP.Improvements20261105
