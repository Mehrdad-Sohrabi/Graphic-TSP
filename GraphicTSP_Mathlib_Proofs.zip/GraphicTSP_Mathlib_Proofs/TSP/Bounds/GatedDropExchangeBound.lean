import TSP.Improvements20261105.GatedDropMonotonicity

/-! A deletion exchange has an explicit loss bound. Gate ownership is
injective, so a deleted prefix is paid for at most once. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.deletionCost (a b : GatedDrops d) : ℝ :=
  (∑ v : d.tree.Child, (((a.pref v - b.pref v) + (a.suffix v - b.suffix v) +
    (a.representative v - b.representative v) : ℤ) : ℝ)) +
  ∑ v : V, ((a.tail v - b.tail v : ℤ) : ℝ)

theorem GatedDrops.reward_change_bound (P : GatePlan d) (a b : GatedDrops d)
    (hp : ∀ v, b.pref v ≤ a.pref v) (hs : ∀ v, b.suffix v ≤ a.suffix v)
    (hr : ∀ v, b.representative v ≤ a.representative v) (v : d.tree.Child) :
    a.reward d P v - b.reward d P v +
      (if P.IsReceiver d v then a.pref v - b.pref v else 0) ≤
    (a.pref v - b.pref v) + (a.suffix v - b.suffix v) +
      (a.representative v - b.representative v) := by
  have hpv := hp v
  have hsv := hs v
  have hrv := hr v
  by_cases hroot : d.tree.parent v = d.tree.root <;>
    by_cases hactive : (d.backGroup v).Nonempty <;> by_cases hrecv : P.IsReceiver d v <;>
    simp [GatedDrops.reward, hroot, hactive, hrecv] <;> omega

theorem GatedDrops.exchange_value_bound {P : GatePlan d} (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) {a b : GatedDrops d}
    (ha : a.Admissible d P) (hb : b.Admissible d P)
    (hp : ∀ v, b.pref v ≤ a.pref v) (hs : ∀ v, b.suffix v ≤ a.suffix v)
    (hr : ∀ v, b.representative v ≤ a.representative v)
    (ht : ∀ v, b.tail v ≤ a.tail v) (hh : ∀ v, b.head v ≤ a.head v)
    (hrpos : ∀ v, b.head v ≠ 0 → a.representative v ≤ b.representative v)
    (hopos : ∀ v, b.head v ≠ 0 → a.outside v ≤ b.outside v) :
    a.value d P t +
      (∑ v : d.tree.Child, ((gatedFreeBase d v : ℝ) + t v) * ((a.head v - b.head v : ℤ) : ℝ)) -
        a.deletionCost d b ≤ b.value d P t := by
  have hpen : (∑ v : d.tree.Child, (b.penalty d P v : ℝ)) ≤
      (∑ v : d.tree.Child, (a.penalty d P v : ℝ)) +
      (∑ v : d.tree.Child, if P.IsReceiver d v then ((a.pref v - b.pref v : ℤ) : ℝ) else 0) +
      ∑ v : V, ((a.tail v - b.tail v : ℤ) : ℝ) := by
    have hsum : (∑ v : d.tree.Child, (b.penalty d P v : ℝ)) ≤
        (∑ v : d.tree.Child, (a.penalty d P v : ℝ)) +
        ∑ v : d.tree.Child, (a.penaltyBudget d P b v : ℝ) := by
      rw [← Finset.sum_add_distrib]
      apply Finset.sum_le_sum
      intro v _
      exact_mod_cast GatedDrops.penalty_change_bound d ha hb hp ht hh hrpos hopos v
    have hh' := GatedDrops.penaltyBudget_sum_le d P hP a b ht
    linarith
  have hrew : (∑ v : d.tree.Child, (a.reward d P v : ℝ)) -
      (∑ v : d.tree.Child, (b.reward d P v : ℝ)) +
      (∑ v : d.tree.Child, if P.IsReceiver d v then ((a.pref v - b.pref v : ℤ) : ℝ) else 0) ≤
      ∑ v : d.tree.Child, (((a.pref v - b.pref v) + (a.suffix v - b.suffix v) +
        (a.representative v - b.representative v) : ℤ) : ℝ) := by
    rw [← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro v _
    have hh' := a.reward_change_bound d P b hp hs hr v
    push_cast at hh' ⊢
    exact_mod_cast hh'
  have hheads :
      (∑ v : d.tree.Child, ((gatedFreeBase d v : ℝ) + t v) * (a.head v : ℝ)) -
      (∑ v : d.tree.Child, ((gatedFreeBase d v : ℝ) + t v) * (b.head v : ℝ)) =
      ∑ v : d.tree.Child, ((gatedFreeBase d v : ℝ) + t v) * ((a.head v - b.head v : ℤ) : ℝ) := by
    simp [Int.cast_sub, mul_sub, Finset.sum_sub_distrib]
  simp only [GatedDrops.value, Finset.sum_sub_distrib, GatedDrops.deletionCost]
  linarith

end TSP.Improvements20261105
