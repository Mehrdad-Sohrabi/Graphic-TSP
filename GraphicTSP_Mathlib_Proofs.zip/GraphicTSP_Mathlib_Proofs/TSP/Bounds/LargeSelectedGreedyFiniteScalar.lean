import TSP.Improvements20261105.LargeSelectedGreedyT5R3Cap
import TSP.Improvements20261105.LargeSelectedGreedyT5R4Cap
import TSP.Improvements20261105.LargeSelectedGreedyT5R5All
import TSP.Improvements20261105.LargeSelectedGreedyScopeAggregates
import TSP.Improvements20261105.ScoredParameters
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 6000000
set_option linter.unusedVariables false

theorem large_selected_greedy_source_scalar (t r bad : ℕ) (ht0 : 5 ≤ t) (ht1 : t ≤ 31)
    (hr : 3 ≤ r) (hb : bad ≤ 1) (q e z a o S I H g : ℝ)
    (hq0 : 0 ≤ q) (hz0 : 0 ≤ z)
    (he0 : 0 ≤ e) (hem : e ≤ (t : ℝ)*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*((t : ℝ)+1)+2*(bad : ℝ))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ (r : ℝ)*z)
    (hgood : t%2=0 → bad=0 → e+(1-(t : ℝ)/2)*q ≤ 0)
    (hgate : t ≤ 25 → q ≤ ScoredParameters.lower t ∨ ScoredParameters.upper t ≤ q ∨
      q+e ≤ 1-ScoredParameters.incomingThreshold t) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤
      4*((t : ℝ)+(r : ℝ))+2*(bad : ℝ) := by
  by_cases htail : 25 ≤ t
  · have hkmin : (25:ℝ) ≤ (t:ℝ) := by exact_mod_cast htail
    have hkmax : (t:ℝ) ≤ (31:ℝ) := by exact_mod_cast ht1
    have hem31 : e ≤ 31*q-1 := by
      have hh := mul_le_mul_of_nonneg_right hkmax hq0
      linarith only [hem,hh]
    have hq31 : (1/31:ℝ) ≤ q := by linarith only [hem31,he0]
    have hs : (415/2)*(e-o)-(704/5)+24*e+(S-2*(bad:ℝ))+24*g ≤ 4*((t:ℝ)+1) := by linarith only [hsource]
    have hSb : S-2*(bad:ℝ) ≤ S := by have hn : (0:ℝ) ≤ (bad:ℝ) := Nat.cast_nonneg bad; linarith only [hn]
    have hSs (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
        (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
      hSb.trans (hSall U A B hA hAd hAU hB hBd hBU hU)
    have hh := large_selected_greedy_group_25_31 (t:ℝ) q e z a o (S-2*(bad:ℝ)) I H g hkmin hkmax
      he0 hem31 heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hs hSs hIall hHL hHR hq31 hz0
    have hrR : (3:ℝ) ≤ (r:ℝ) := by exact_mod_cast hr
    linarith only [hh,hrR]
  have hsmall : t ≤ 24 := by omega
  interval_cases t
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/5 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (41/150 : ℝ) ∨ (211/500 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t5_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t5_r4_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t5_r5_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 24 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t5_r3_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t5_r4_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t5_r5_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/6 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(3/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t6_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hg hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t6_r4_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hg hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t6_r5_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t6_r3_cap_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t6_r4_cap_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t6_r5_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/7 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (19/100 : ℝ) ∨ (46/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t7_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t7_r4_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t7_r5_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 32 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t7_r3_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t7_r4_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t7_r5_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/8 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(4/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t8_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hg hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t8_r4_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hg hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t8_r5_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t8_r3_cap_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      by_cases hr4 : r=4
      · have ht : a ≤ 4*z := by simpa only [hr4,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=4 := by exact_mod_cast hr4
        have hh := large_selected_greedy_t8_r4_cap_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (5 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 5≤r by omega)
      have hh := large_selected_greedy_t8_r5_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/9 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (37/250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t9_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t9_r4_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 40 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t9_r3_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t9_r4_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/10 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (377/2750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(5/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t10_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hg hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t10_r4_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t10_r3_cap_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t10_r4_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/11 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (16/125 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t11_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t11_r4_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 48 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t11_r3_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t11_r4_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/12 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (391/3250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(6/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t12_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hg hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t12_r4_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t12_r3_cap_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t12_r4_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/13 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (199/1750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t13_r3_cap_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t13_r4_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 56 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      by_cases hr3 : r=3
      · have ht : a ≤ 3*z := by simpa only [hr3,Nat.cast_ofNat] using htarget
        have hrR : (r : ℝ)=3 := by exact_mod_cast hr3
        have hh := large_selected_greedy_t13_r3_cap_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR ht hq hz0 hgate'
        linarith only [hh,hrR]
      have hrR : (4 : ℝ) ≤ (r : ℝ) := by exact_mod_cast (show 4≤r by omega)
      have hh := large_selected_greedy_t13_r4_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/14 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (27/250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(7/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t14_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t14_r3_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/15 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (103/1000 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t15_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 64 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t15_r3_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/16 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (419/4250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(8/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t16_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t16_r3_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/17 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (71/750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t17_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 72 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t17_r3_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/18 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (433/4750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(9/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t18_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t18_r3_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/19 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (11/125 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t19_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 80 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t19_r3_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/20 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (149/1750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(10/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t20_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t20_r3_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/21 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (227/2750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t21_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 88 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t21_r3_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/22 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (461/5750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(11/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t22_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t22_r3_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/23 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (39/500 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t23_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hsource' : (415/2)*(e-o)-(704/5)+24*e+(S-2)+24*g ≤ 96 := by linarith only [hsource]
      have hSall' (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
          (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20) (hU : q ≤ U) :=
        (show S-2 ≤ S by linarith only).trans (hSall U A B hA hAd hAU hB hBd hBU hU)
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t23_r3_all_bad0 q e z a o (S-2) I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource' hSall' hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]
  · norm_num only [Nat.cast_ofNat] at hem hsource ⊢
    have hq : (1/24 : ℝ) ≤ q := by linarith only [hem,he0]
    have hgate' : q ≤ (19/250 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ) := by
      have hh := hgate (by decide)
      norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hh ⊢
      exact hh
    interval_cases bad
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hg : e+(1-(12/1 : ℝ))*q ≤ 0 := by
        have hh := hgood (by decide) rfl
        norm_num at hh ⊢
        exact hh
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t24_r3_all_bad0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hg hq hz0 hgate'
      linarith only [hh,hrR]
    · norm_num only [Nat.cast_zero,Nat.cast_one] at hsource ⊢
      have hrR : (3 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
      have hh := large_selected_greedy_t24_r3_all_bad1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hq hz0 hgate'
      linarith only [hh,hrR]

end TSP.Improvements20261105
