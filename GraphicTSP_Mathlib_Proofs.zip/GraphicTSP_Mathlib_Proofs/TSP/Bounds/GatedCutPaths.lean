import TSP.Improvements20261105.GatedTrueCuts
import TSP.Improvements20261105.RootedCutPaths

/-! Every actual back edge crosses at most one component boundary of the
true-cut forest. A back crossing a boundary has a selected head. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def onExpandedBackPath (b : BackEdge d) (w : (expandedTree d).Child) : Prop :=
  (expandedTree d).OnPath (.inr (d.anchor b.1)) (.inl (d.lower b.1)) w ∧
    (w : FlowVertex d) ≠ .inr (d.anchor b.1)

noncomputable def GatedDrops.physicalPathTerm (a : GatedDrops d) (b : BackEdge d)
    (w : (expandedTree d).Child) : ℝ :=
  if onExpandedBackPath d b w then (a.physicalRoleWeight d ((expandedTreeRoles d).symm w) : ℝ) else 0

noncomputable def GatedDrops.backPathCuts (P : GatePlan d) (a : GatedDrops d)
    (b : BackEdge d) : Finset (expandedTree d).Child :=
  (expandedTree d).cutsOnPath (a.trueCuts d P) (.inr (d.anchor b.1)) (.inl (d.lower b.1))

theorem GatedDrops.physicalPathTerm_sum (a : GatedDrops d) (b : BackEdge d) :
    (∑ w : (expandedTree d).Child, a.physicalPathTerm d b w) = a.pathCost d b := by
  rw [← (expandedTreeRoles d).sum_comp, Fintype.sum_sum_type, ← Finset.sum_add_distrib]
  rw [a.pathCost_indicator]
  apply Finset.sum_congr rfl
  intro v _
  simp only [GatedDrops.physicalPathTerm, Equiv.symm_apply_apply]
  simp only [expandedTreeRoles, Equiv.coe_fn_mk,
    Sum.elim_inl, Sum.elim_inr, onExpandedBackPath, expanded_connector_back_path,
    expanded_representative_back_path, GatedDrops.physicalRoleWeight]

theorem GatedDrops.physicalPathTerm_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child) :
    0 ≤ a.physicalPathTerm d b w := by
  have hh := a.trueRoleWeight_bounds d ha ((expandedTreeRoles d).symm w)
  unfold physicalPathTerm
  split_ifs
  · exact_mod_cast hh.1.trans hh.2
  · exact le_rfl

theorem GatedDrops.backPathCut_indicator_le {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child) :
    (if w ∈ a.backPathCuts d P b then (1 : ℝ) else 0) ≤ a.physicalPathTerm d b w := by
  by_cases hm : w ∈ a.backPathCuts d P b
  · rw [if_pos hm]
    have hmc := Finset.mem_filter.mp hm
    have hw : 0 < a.trueCutWeight d P w := (Finset.mem_filter.mp hmc.1).2
    have hp : onExpandedBackPath d b w := hmc.2
    have hb := (a.trueRoleWeight_bounds d ha ((expandedTreeRoles d).symm w)).2
    have hone : (1 : ℤ) ≤ a.physicalRoleWeight d ((expandedTreeRoles d).symm w) := by
      change 0 < a.trueRoleWeight d P ((expandedTreeRoles d).symm w) at hw
      omega
    rw [physicalPathTerm, if_pos hp]
    exact_mod_cast hone
  · rw [if_neg hm]
    exact a.physicalPathTerm_nonneg d ha b w

theorem GatedDrops.backPathCuts_card_le_pathCost {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    ((a.backPathCuts d P b).card : ℝ) ≤ a.pathCost d b := by
  rw [← a.physicalPathTerm_sum d b]
  have hh := Finset.sum_le_sum (s := Finset.univ)
    (fun w _ => a.backPathCut_indicator_le d ha b w)
  simpa using hh

theorem GatedDrops.backPathCuts_card_le_head {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    ((a.backPathCuts d P b).card : ℝ) + (a.tail (d.lower b.1) : ℝ) +
      (if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0) ≤
      (a.head (d.anchor b.1) : ℝ) := by
  exact (add_le_add_right (add_le_add_right (a.backPathCuts_card_le_pathCost d ha b) _) _).trans (ha.back b)

theorem GatedDrops.backPathCuts_card_le_one {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) : (a.backPathCuts d P b).card ≤ 1 := by
  have hh := a.backPathCuts_card_le_head d ha b
  have ht : (0 : ℝ) ≤ a.tail (d.lower b.1) := by exact_mod_cast ha.tail_nonneg _
  have ho : (0 : ℝ) ≤ if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0 := by
    split_ifs
    · exact_mod_cast ha.outside_nonneg _
    · exact le_rfl
  have hb : (a.head (d.anchor b.1) : ℝ) ≤ 1 := by
    have hbin := a.head_binary d ha (d.anchor b.1)
    exact_mod_cast (show a.head (d.anchor b.1) ≤ 1 by omega)
  exact_mod_cast (show ((a.backPathCuts d P b).card : ℝ) ≤ 1 by linarith)

theorem GatedDrops.crossing_back_selected {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (hcross : (a.backPathCuts d P b).Nonempty) :
    a.head (d.anchor b.1) = 1 := by
  have hh := a.backPathCuts_card_le_head d ha b
  have hc : (0 : ℝ) < (a.backPathCuts d P b).card := by exact_mod_cast Finset.card_pos.mpr hcross
  have ht : (0 : ℝ) ≤ a.tail (d.lower b.1) := by exact_mod_cast ha.tail_nonneg _
  have ho : (0 : ℝ) ≤ if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0 := by
    split_ifs
    · exact_mod_cast ha.outside_nonneg _
    · exact le_rfl
  rcases a.head_binary d ha (d.anchor b.1) with hz | hz
  · rw [hz] at hh
    norm_num at hh
    linarith
  · exact hz

theorem GatedDrops.back_components {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) :
    (expandedTree d).cutComponentRoot (a.trueCuts d P) (.inr (d.anchor b.1)) =
      (expandedTree d).cutComponentRoot (a.trueCuts d P) (.inl (d.lower b.1)) ∨
    ∃ c ∈ a.trueCuts d P,
      (expandedTree d).cutComponentRoot (a.trueCuts d P) ((expandedTree d).parent c) =
        (expandedTree d).cutComponentRoot (a.trueCuts d P) (.inr (d.anchor b.1)) ∧
      (expandedTree d).cutComponentRoot (a.trueCuts d P) (.inl (d.lower b.1)) = (c : FlowVertex d) := by
  exact (expandedTree d).cutsOnPath_card_le_one (a.trueCuts d P)
    (expanded_auxiliary_ancestor d _ (d.anchor_spec b.1).2) (a.backPathCuts_card_le_one d ha b)

end TSP.Improvements20261105
