import TSP.Improvements20261105.GatedPathConstraints
import TSP.Improvements20261105.GatedRepresentativeShift

/-! Independent coordinates for the dual drops. The potential below is built
from sums on the actual rooted DFS tree; its arc differences are proved, not
postulated. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

structure GatedDrops where
  pref : d.tree.Child → ℤ
  suffix : d.tree.Child → ℤ
  representative : d.tree.Child → ℤ
  head : d.tree.Child → ℤ
  tail : V → ℤ
  outside : d.tree.Child → ℤ

noncomputable def GatedDrops.center (a : GatedDrops d) (v : V) : ℤ :=
  -∑ s : d.tree.Child, descendantBit d s v * (a.pref s + a.suffix s + a.representative s)

theorem GatedDrops.center_parent (a : GatedDrops d) (v : d.tree.Child) :
    a.center d (d.tree.parent v) - a.center d v =
      a.pref v + a.suffix v + a.representative v := by
  unfold GatedDrops.center
  rw [neg_sub_neg, ← Finset.sum_sub_distrib]
  calc
    _ = ∑ s : d.tree.Child, (if v = s then 1 else 0) *
        (a.pref s + a.suffix s + a.representative s) := by
      apply Finset.sum_congr rfl
      intro s _
      rw [← sub_mul, descendantBit_child_difference]
    _ = _ := by simp

noncomputable def GatedDrops.potential (P : GatePlan d) (a : GatedDrops d) : GatedVertex d → ℤ
  | .inl (.inl v) => a.center d v
  | .inl (.inr v) => a.center d v + a.representative v
  | .inr (.inl v) => a.center d v - a.tail v
  | .inr (.inr (v, k)) =>
      if k = 0 then a.center d v + a.representative v - a.head v
      else if k = 1 then a.center d v + a.representative v + a.suffix v
      else if k = 2 then a.center d v + a.representative v - a.head v + a.outside v
      else max (a.center d v - a.tail v)
        (a.center d (P.receiver v) + a.representative (P.receiver v) + a.suffix (P.receiver v))

@[simp] theorem GatedDrops.potential_center (P : GatePlan d) (a : GatedDrops d) (v : V) :
    a.potential d P (gatedCenter d v) = a.center d v := rfl
@[simp] theorem GatedDrops.potential_aux (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.potential d P (gatedAux d v) = a.center d v + a.representative v := rfl
@[simp] theorem GatedDrops.potential_tail (P : GatePlan d) (a : GatedDrops d) (v : V) :
    a.potential d P (gatedTail d v) = a.center d v - a.tail v := rfl
@[simp] theorem GatedDrops.potential_head (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.potential d P (gatedHead d v) = a.center d v + a.representative v - a.head v := by
  simp [GatedDrops.potential]
@[simp] theorem GatedDrops.potential_gate (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.potential d P (gatedGate d v) = a.center d v + a.representative v + a.suffix v := by
  simp [GatedDrops.potential]
@[simp] theorem GatedDrops.potential_outside (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.potential d P (gatedOutside d v) =
      a.center d v + a.representative v - a.head v + a.outside v := by
  simp [GatedDrops.potential]
@[simp] theorem GatedDrops.potential_collector (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    a.potential d P (gatedCollector d v) =
      max (a.center d v - a.tail v)
        (a.center d (P.receiver v) + a.representative (P.receiver v) + a.suffix (P.receiver v)) := by
  simp [GatedDrops.potential]

@[simp] theorem GatedDrops.potential_prefix (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedPrefixDrop d (a.potential d P) v = a.pref v := by
  have hh := a.center_parent d v
  simp only [gatedPrefixDrop, potential_center, potential_gate]
  omega
@[simp] theorem GatedDrops.potential_suffix (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedSuffixDrop d (a.potential d P) v = a.suffix v := by
  simp [gatedSuffixDrop]
@[simp] theorem GatedDrops.potential_representative (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedRepresentativeDrop d (a.potential d P) v = a.representative v := by
  simp [gatedRepresentativeDrop]
@[simp] theorem GatedDrops.potential_connector (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedConnectorDrop d (a.potential d P) v = a.pref v + a.suffix v := by
  rw [← gated_split_drop_identity, potential_prefix, potential_suffix]
@[simp] theorem GatedDrops.potential_headSelector (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedHeadSelector d (a.potential d P) v = a.head v := by simp [gatedHeadSelector]
@[simp] theorem GatedDrops.potential_tailDrop (P : GatePlan d) (a : GatedDrops d) (v : V) :
    gatedTailDrop d (a.potential d P) v = a.tail v := by simp [gatedTailDrop]
@[simp] theorem GatedDrops.potential_outsideDrop (P : GatePlan d) (a : GatedDrops d) (v : d.tree.Child) :
    gatedOutsideDrop d (a.potential d P) v = a.outside v := by simp [gatedOutsideDrop]

noncomputable def GatedDrops.pathCost (a : GatedDrops d) (b : BackEdge d) : ℝ :=
  ∑ v : d.tree.Child, (backCycle d b (.inl (.inl v)) * ((a.pref v + a.suffix v : ℤ) : ℝ) +
    backCycle d b (.inl (.inr v)) * (a.representative v : ℝ))

@[simp] theorem GatedDrops.potential_pathCost (P : GatePlan d) (a : GatedDrops d) (b : BackEdge d) :
    gatedTreePathCost d (a.potential d P) b = a.pathCost d b := by
  simp [gatedTreePathCost, GatedDrops.pathCost]

noncomputable def gatedDropsOf (p : GatedVertex d → ℤ) : GatedDrops d where
  pref := gatedPrefixDrop d p
  suffix := gatedSuffixDrop d p
  representative := gatedRepresentativeDrop d p
  head := gatedHeadSelector d p
  tail := gatedTailDrop d p
  outside := gatedOutsideDrop d p

theorem gatedDropsOf_pathCost (p : GatedVertex d → ℤ) (b : BackEdge d) :
    (gatedDropsOf d p).pathCost d b = gatedTreePathCost d p b := by
  simp [GatedDrops.pathCost, gatedDropsOf, gatedTreePathCost, gated_split_drop_identity]

end TSP.Improvements20261105
