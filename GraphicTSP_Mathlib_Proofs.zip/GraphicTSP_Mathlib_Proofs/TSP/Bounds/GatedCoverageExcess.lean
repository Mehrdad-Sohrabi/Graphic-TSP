import TSP.Improvements20261105.GatedComponentMass
import TSP.Chapter11.CoverageDeficits

/-! Bound the negative coverage of the actual true cuts by original
subtour degree excess. This uses the union-of-subtrees cut inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem original_back_subset_sum (x : E → ℝ) (S : Finset E) (hS : S ⊆ d.backEdges) :
    (∑ b : BackEdge d, if b.1 ∈ S then x b.1 else 0) = edgeSum x S := by
  rw [(Finset.sum_subtype d.backEdges (fun _ => Iff.rfl)
    (fun b => if b ∈ S then x b else 0)).symm, ← Finset.sum_filter]
  simp [Finset.filter_mem_eq_inter, Finset.inter_eq_right.mpr hS, edgeSum]

theorem GatedDrops.connector_cutCoverage (a : GatedDrops d) (x : E → ℝ) (v : d.tree.Child) :
    a.cutCoverage d (fun b => x b.1) (expandedConnectorChild d v) =
      edgeSum x (deletedSubtreeCut d v) := by
  unfold cutCoverage
  have hi (b : BackEdge d) : onExpandedBackPath d b (expandedConnectorChild d v) ↔
      b.1 ∈ deletedSubtreeCut d v :=
    (expanded_connector_back_path d b v).trans
      ((cycle_parent_arc_iff d b v).trans (deletedSubtreeCut_iff d v b.1).symm)
  simp_rw [hi]
  exact original_back_subset_sum d x _ (deletedSubtreeCut_back d v)

theorem GatedDrops.representative_cutCoverage_ge (a : GatedDrops d) (x : E → ℝ)
    (hx : ∀ e, 0 ≤ x e) (v : d.tree.Child) :
    edgeSum x (deletedSubtreeCut d v) ≤
      a.cutCoverage d (fun b => x b.1) (expandedRepresentativeChild d v) := by
  rw [← a.connector_cutCoverage d x v]
  unfold cutCoverage
  apply Finset.sum_le_sum
  intro b _
  by_cases hp : onExpandedBackPath d b (expandedConnectorChild d v)
  · have hr : onExpandedBackPath d b (expandedRepresentativeChild d v) := (expanded_representative_back_path d b v).mpr
      ((expanded_connector_back_path d b v).mp hp).1
    simp [hp, hr]
  · simp only [if_neg hp]
    split_ifs
    · exact hx b.1
    · exact le_rfl

theorem GatedDrops.true_representative_coverage_ge_one (a : GatedDrops d) (P : GatePlan d)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (v : d.tree.Child) (hv : expandedRepresentativeChild d v ∈ a.trueCuts d P) :
    1 ≤ a.cutCoverage d (fun b => x b.1) (expandedRepresentativeChild d v) := by
  have hp : 0 < a.trueRoleWeight d P (.inr v) := (Finset.mem_filter.mp hv).2
  have hi : ¬(d.backGroup v).Nonempty := by
    intro hg
    simp [trueRoleWeight, hg] at hp
  have hc := subtree_group_coverage d hx v
  rw [d.group_singleton_of_inactive v hi] at hc
  simp only [edgeSum, Finset.sum_singleton] at hc
  have hq := hcap (d.treeEdge v)
  have hl := a.representative_cutCoverage_ge d x hx.1 v
  change (∑ e ∈ deletedSubtreeCut d v, x e) ≤ _ at hl
  linarith

theorem nonroot_connector_deficit_sum (x : E → ℝ) :
    (∑ v : d.tree.Child, if d.tree.parent v = d.tree.root then (0 : ℝ) else
      max (1 - edgeSum x (deletedSubtreeCut d v)) 0) =
      ∑ u ∈ Finset.univ.erase d.tree.root, vertexDeficit d x u := by
  simp_rw [vertex_deficit_as_positive_parts]
  simp only [childSet, Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro v _
  by_cases hr : d.tree.parent v = d.tree.root
  · simp [hr]
  · simp [hr]

theorem GatedDrops.coverageExcess_ge_neg_deficits (P : GatePlan d) (a : GatedDrops d)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) :
    -(∑ u ∈ Finset.univ.erase d.tree.root, vertexDeficit d x u) ≤
      a.coverageExcess d P (fun b => x b.1) := by
  let C (w : (expandedTree d).Child) : ℝ :=
    if w ∈ a.trueCuts d P then a.cutCoverage d (fun b => x b.1) w - 1 else 0
  have hc (v : d.tree.Child) :
      -(if d.tree.parent v = d.tree.root then (0 : ℝ) else
        max (1 - edgeSum x (deletedSubtreeCut d v)) 0) ≤ C (expandedConnectorChild d v) := by
    by_cases hr : d.tree.parent v = d.tree.root
    · have hn : expandedConnectorChild d v ∉ a.trueCuts d P := by
        simp [trueCuts, trueRoleWeight, hr]
      simp [C, hn, hr]
    · rw [if_neg hr]
      by_cases hm : expandedConnectorChild d v ∈ a.trueCuts d P
      · simp only [C, if_pos hm, a.connector_cutCoverage d x v]
        have hh := le_max_left (1 - edgeSum x (deletedSubtreeCut d v)) 0
        linarith
      · simp only [C, if_neg hm]
        exact neg_nonpos.mpr (le_max_right _ _)
  have hr (v : d.tree.Child) : 0 ≤ C (expandedRepresentativeChild d v) := by
    by_cases hm : expandedRepresentativeChild d v ∈ a.trueCuts d P
    · simp only [C, if_pos hm]
      linarith [a.true_representative_coverage_ge_one d P hx hcap v hm]
    · simp [C, hm]
  have he : a.coverageExcess d P (fun b => x b.1) =
      ∑ v : d.tree.Child, (C (expandedConnectorChild d v) + C (expandedRepresentativeChild d v)) := by
    have hs : a.coverageExcess d P (fun b => x b.1) = ∑ w : (expandedTree d).Child, C w := by
      simp [coverageExcess, C]
    rw [hs, ← (expandedTreeRoles d).sum_comp, Fintype.sum_sum_type, ← Finset.sum_add_distrib]
    rfl
  rw [he, ← nonroot_connector_deficit_sum, ← Finset.sum_neg_distrib]
  exact Finset.sum_le_sum (fun v _ => le_trans (hc v) (le_add_of_nonneg_right (hr v)))

theorem GatedDrops.coverageExcess_lower_bound (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) :
    -(edgeSum x Finset.univ - Fintype.card V) + totalOverage d x / 2 ≤
      a.coverageExcess d P (fun b => x b.1) := by
  have h1 := a.coverageExcess_ge_neg_deficits d P hx hcap
  have h2 := total_deficit_bound d hs hc hx hcap
  linarith

end TSP.Improvements20261105
