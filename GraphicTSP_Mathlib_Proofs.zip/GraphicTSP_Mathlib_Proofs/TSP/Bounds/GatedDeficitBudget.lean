import TSP.Improvements20261105.GatedOutgoingCoverage
import TSP.Improvements20261105.GatedCoverageExcess

/-! Positive deficits of outgoing true cuts have disjoint component
owners, and their total is bounded by the original LP excess. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.trueDeficit (P : GatePlan d) (a : GatedDrops d)
    (x : BackEdge d → ℝ) : ℝ := ∑ w ∈ a.trueCuts d P, max (1 - a.cutCoverage d x w) 0

theorem GatedDrops.outgoingDeficit_sum (P : GatePlan d) (a : GatedDrops d) (x : BackEdge d → ℝ) :
    (∑ r : a.Component d P, a.outgoingDeficit d P x r) = a.trueDeficit d P x := by
  simp only [outgoingDeficit, componentOutgoingCuts, Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro w _
  let r₀ : a.Component d P := (expandedTree d).cutComponentMap (a.trueCuts d P) ((expandedTree d).parent w)
  have hr₀ : (r₀ : FlowVertex d) = a.component d P ((expandedTree d).parent w) := rfl
  rw [Finset.sum_eq_single r₀]
  · simp [hr₀]
  · intro r _ hne
    have hn : a.component d P ((expandedTree d).parent w) ≠ (r : FlowVertex d) := by
      intro he
      exact hne (Subtype.ext (he.symm.trans hr₀.symm))
    simp [hn]
  · simp

theorem GatedDrops.trueDeficit_le_vertexDeficits (P : GatePlan d) (a : GatedDrops d)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) :
    a.trueDeficit d P (fun b => x b.1) ≤ ∑ u ∈ Finset.univ.erase d.tree.root, vertexDeficit d x u := by
  let C (w : (expandedTree d).Child) : ℝ :=
    if w ∈ a.trueCuts d P then max (1 - a.cutCoverage d (fun b => x b.1) w) 0 else 0
  have hc (v : d.tree.Child) : C (expandedConnectorChild d v) ≤
      if d.tree.parent v = d.tree.root then (0 : ℝ) else max (1 - edgeSum x (deletedSubtreeCut d v)) 0 := by
    by_cases hr : d.tree.parent v = d.tree.root
    · have hn : expandedConnectorChild d v ∉ a.trueCuts d P := by
        simp [trueCuts, trueRoleWeight, hr]
      simp [C, hn, hr]
    · rw [if_neg hr]
      by_cases hm : expandedConnectorChild d v ∈ a.trueCuts d P
      · simp only [C, if_pos hm, a.connector_cutCoverage d x v]
        exact le_rfl
      · simp only [C, if_neg hm]
        exact le_max_right _ _
  have hr (v : d.tree.Child) : C (expandedRepresentativeChild d v) = 0 := by
    by_cases hm : expandedRepresentativeChild d v ∈ a.trueCuts d P
    · simp only [C, if_pos hm]
      apply max_eq_right
      linarith [a.true_representative_coverage_ge_one d P hx hcap v hm]
    · simp [C, hm]
  have he : a.trueDeficit d P (fun b => x b.1) =
      ∑ v : d.tree.Child, (C (expandedConnectorChild d v) + C (expandedRepresentativeChild d v)) := by
    have hh : a.trueDeficit d P (fun b => x b.1) = ∑ w : (expandedTree d).Child, C w := by
      simp [trueDeficit, C]
    rw [hh, ← (expandedTreeRoles d).sum_comp, Fintype.sum_sum_type, ← Finset.sum_add_distrib]
    rfl
  rw [he, ← nonroot_connector_deficit_sum]
  simp_rw [hr, add_zero]
  exact Finset.sum_le_sum (fun v _ => hc v)

theorem GatedDrops.trueDeficit_bound (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) :
    a.trueDeficit d P (fun b => x b.1) ≤
      edgeSum x Finset.univ - Fintype.card V - totalOverage d x / 2 :=
  (a.trueDeficit_le_vertexDeficits d P hx hcap).trans (total_deficit_bound d hs hc hx hcap)

theorem GatedDrops.outgoingDeficit_subset_bound (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1) (R : Finset (a.Component d P)) :
    (∑ r ∈ R, a.outgoingDeficit d P (fun b => x b.1) r) ≤ edgeSum x Finset.univ - Fintype.card V := by
  have hh := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ R)
    (fun r _ _ => a.outgoingDeficit_nonneg d P (fun b => x b.1) r)
  rw [a.outgoingDeficit_sum d P] at hh
  have hb := a.trueDeficit_bound d hs hc P hx hcap
  have hn := totalOverage_nonneg d x
  linarith

end TSP.Improvements20261105
