import TSP.Improvements20261105.BinaryPathEvent
import TSP.Improvements20261105.ParityGauge
import TSP.Chapter08.StarResiduals
import TSP.GraphCutWeights

/-! The adjacent path-edge correlation bound follows from the actual
odd-tree join parity, with every off-path tree edge charged explicitly. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter08 Classical
open scoped BigOperators
variable {V E I : Type} [Fintype V] [Fintype E] [Fintype I]
  [DecidableEq V] [DecidableEq E]

noncomputable def otherTreeEdges (G : Graph V E) (T : Finset E) (v : V) (e f : E) : Finset E :=
  (G.cut {v} ∩ T) \ {e, f}

noncomputable def incidentBackEdges (G : Graph V E) (T : Finset E) (v : V) : Finset E :=
  G.cut {v} \ T

theorem incident_path_partition (G : Graph V E) (T : Finset E) (v : V) (e f : E)
    (he : e ∈ G.cut {v} ∩ T) (hf : f ∈ G.cut {v} ∩ T) (hef : e ≠ f)
    (z : E → ℝ) :
    edgeSum z (G.cut {v}) = z e + z f + edgeSum z (otherTreeEdges G T v e f) +
      edgeSum z (incidentBackEdges G T v) := by
  have hp : ({e,f} : Finset E) ⊆ G.cut {v} ∩ T := by
    intro a ha
    rcases Finset.mem_insert.mp ha with h | h
    · simpa [h] using he
    · simpa [Finset.mem_singleton.mp h] using hf
  have h1 := Finset.sum_sdiff hp (f := z)
  have h2 := Finset.sum_sdiff (Finset.inter_subset_left : G.cut {v} ∩ T ⊆ G.cut {v}) (f := z)
  have hd : G.cut {v} \ (G.cut {v} ∩ T) = incidentBackEdges G T v := by
    ext a; simp [incidentBackEdges]
  rw [hd] at h2
  simp [hef] at h1
  change edgeSum z (otherTreeEdges G T v e f) + (z e + z f) = _ at h1
  dsimp only [edgeSum] at *
  linarith

theorem path_join_mismatch (G : Graph V E) (T J : Finset E) (v : V) (e f : E)
    (hs : ∀ a, G.src a ≠ G.dst a)
    (he : e ∈ G.cut {v} ∩ T) (hf : f ∈ G.cut {v} ∩ T) (hef : e ≠ f)
    (hJ : G.IsJoin (G.oddVertices T) J) :
    (if (e ∈ J) ↔ (f ∈ J) then (0 : ℝ) else 1) ≤
      edgeSum (fun a => 1 - incidence J a) (otherTreeEdges G T v e f) +
      edgeSum (incidence J) (incidentBackEdges G T v) := by
  let R := otherTreeEdges G T v e f
  let B := incidentBackEdges G T v
  have hdeg := incident_path_partition G T v e f he hf hef (incidence J)
  rw [← loopless_degree_eq_cut G hs, degree_incidence] at hdeg
  have hpart : G.intDegree J v = (if e ∈ J then 1 else 0) + (if f ∈ J then 1 else 0) +
      (R ∩ J).card + (B ∩ J).card := by
    have hi (A : Finset E) : edgeSum (incidence J) A = ((A ∩ J).card : ℝ) := by
      simp [edgeSum, incidence, Finset.filter_mem_eq_inter]
    rw [hi, hi] at hdeg
    simp only [incidence] at hdeg
    exact_mod_cast hdeg
  have htpart : G.intDegree T v = 2 + R.card := by
    have hh := incident_path_partition G T v e f he hf hef (incidence T)
    rw [← loopless_degree_eq_cut G hs, degree_incidence] at hh
    have hR : edgeSum (incidence T) R = (R.card : ℝ) := by
      have hh : ∀ a ∈ R, incidence T a = (1 : ℝ) := by
        intro a ha
        exact if_pos ((Finset.mem_inter.mp (Finset.mem_sdiff.mp ha).1).2)
      calc
        edgeSum (incidence T) R = ∑ a ∈ R, (1 : ℝ) := Finset.sum_congr rfl hh
        _ = (R.card : ℝ) := by simp
    have hB : edgeSum (incidence T) B = 0 := by
      exact Finset.sum_eq_zero (fun a ha => if_neg (Finset.mem_sdiff.mp ha).2)
    rw [show edgeSum (incidence T) (otherTreeEdges G T v e f) = (R.card : ℝ) from hR,
      show edgeSum (incidence T) (incidentBackEdges G T v) = 0 from hB] at hh
    simp only [incidence, if_pos (Finset.mem_inter.mp he).2, if_pos (Finset.mem_inter.mp hf).2] at hh
    exact_mod_cast hh
  have hp := (isJoin_iff_parity G _ J).mp hJ v
  have ht := (isJoin_iff_parity G _ T).mp rfl v
  rw [hpart] at hp
  rw [htpart] at ht
  have hchosen : (R ∩ J).card ≤ R.card := Finset.card_le_card Finset.inter_subset_left
  have hnonneg : 0 ≤ edgeSum (fun a => 1 - incidence J a) R + edgeSum (incidence J) B := by
    apply add_nonneg <;> apply Finset.sum_nonneg <;> intro a ha <;> simp [incidence] <;> split_ifs <;> norm_num
  by_cases hsame : (e ∈ J) ↔ (f ∈ J)
  · simpa [hsame] using hnonneg
  · have hne : (if e ∈ J then 1 else 0 : ℕ) ≠ (if f ∈ J then 1 else 0 : ℕ) := by
      by_cases heJ : e ∈ J <;> by_cases hfJ : f ∈ J <;> simp_all
    have hm := parity_path_mismatch (if e ∈ J then 1 else 0) (if f ∈ J then 1 else 0)
      (R ∩ J).card R.card (B ∩ J).card (by split_ifs <;> omega) (by split_ifs <;> omega)
      hchosen (by omega) hne
    have hsum : edgeSum (fun a => 1 - incidence J a) R + edgeSum (incidence J) B =
        (R.card : ℝ) - ((R ∩ J).card : ℝ) + ((B ∩ J).card : ℝ) := by
      simp [edgeSum, incidence, Finset.sum_sub_distrib, Finset.filter_mem_eq_inter]
    rw [if_neg hsame, show edgeSum (fun a => 1-incidence J a) (otherTreeEdges G T v e f) +
      edgeSum (incidence J) (incidentBackEdges G T v) = _ from hsum]
    exact_mod_cast hm

end TSP.Improvements20261105
