import TSP.Improvements20261105.ControlledJoinGuard

/-! Controlled guards on disjoint cycles share one Q mixture. Both the
future events and the representative marginals are preserved. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Classical
open scoped BigOperators
variable {V E A : Type} [Fintype V] [Fintype E]
  [DecidableEq V] [DecidableEq E] [DecidableEq A]

 theorem JoinMixture.disjoint_controlled_guards {G : Graph V E} {T : Finset V}
    (F : Finset A) (C N : A → Finset E) (rep : A → E) (q k : A → ℝ)
    (f : ℝ) (hf : 0 ≤ f) (hf1 : f ≤ 1) (M : JoinMixture G T)
    (hC : ∀ a ∈ F, ∀ v, Even (G.intDegree (C a) v))
    (hNC : ∀ a ∈ F, N a ⊆ C a) (hrep : ∀ a ∈ F, rep a ∈ C a)
    (hdis : ∀ a ∈ F, ∀ b ∈ F, a ≠ b → Disjoint (C a) (C b))
    (hk : ∀ a ∈ F, 0 ≤ k a) (hq : ∀ a ∈ F, M.point (rep a) ≤ q a/2) :
    ∃ (R : JoinMixture G T) (m : A → ℝ),
      (∀ a ∈ F, 0 ≤ m a ∧ f * max (M.eventMass (N a) - max (q a-k a) 0/2) 0 ≤ m a) ∧
      (∀ e, (∀ a ∈ F, e ∉ C a) → R.point e = M.point e) ∧
      (∀ a ∈ F, ∀ e ∈ N a, R.point e = M.point e - m a) ∧
      (∀ S : Finset E,
        (∀ a ∈ F, S ∩ C a = ∅ ∨ ∃ e, rep a ≠ e ∧ S ∩ C a = {rep a,e}) →
        edgeSum M.point S - edgeSum R.point S ≤
          ∑ a ∈ F, (if S ∩ C a = ∅ then 0 else f*k a)) ∧
      (∀ S : Finset E, (∀ a ∈ F, Disjoint S (C a)) → R.eventMass S = M.eventMass S) := by
  induction F using Finset.induction_on with
  | empty =>
    refine ⟨M, fun _ => 0, ?_, ?_, ?_, ?_, ?_⟩
    · simp
    · simp
    · simp
    · intro S _; simp
    · simp
  | @insert a F ha ih =>
    obtain ⟨R, m, hm, hout, hpath, hloss, hpres⟩ := ih
      (fun b hb => hC b (Finset.mem_insert_of_mem hb))
      (fun b hb => hNC b (Finset.mem_insert_of_mem hb))
      (fun b hb => hrep b (Finset.mem_insert_of_mem hb))
      (fun b hb c hc hbc => hdis b (Finset.mem_insert_of_mem hb) c (Finset.mem_insert_of_mem hc) hbc)
      (fun b hb => hk b (Finset.mem_insert_of_mem hb))
      (fun b hb => hq b (Finset.mem_insert_of_mem hb))
    have had : ∀ b ∈ F, Disjoint (C a) (C b) := by
      intro b hb
      exact hdis a (Finset.mem_insert_self _ _) b (Finset.mem_insert_of_mem hb) (fun h => ha (h ▸ hb))
    have hre : R.point (rep a) ≤ q a/2 := by
      rw [hout (rep a) (fun b hb he => Finset.disjoint_left.mp (had b hb)
        (hrep a (Finset.mem_insert_self _ _)) he)]
      exact hq a (Finset.mem_insert_self _ _)
    have hevent : R.eventMass (N a) = M.eventMass (N a) :=
      hpres (N a) (fun b hb => (had b hb).mono_left (hNC a (Finset.mem_insert_self _ _)))
    obtain ⟨Z, ma, hma, hmaLower, hzout, hzpath, hzpair, hzloss, hzpres⟩ :=
      R.controlled_guard (C a) (N a) (rep a)
        (hC a (Finset.mem_insert_self _ _)) (hNC a (Finset.mem_insert_self _ _))
        (q a) (k a) f (hk a (Finset.mem_insert_self _ _)) hf hf1 hre
    let m' := Function.update m a ma
    refine ⟨Z, m', ?_, ?_, ?_, ?_, ?_⟩
    · intro b hb
      rcases Finset.mem_insert.mp hb with hba | hb
      · subst b
        simpa only [m', Function.update_same, hevent] using And.intro hma hmaLower
      · have hba : b ≠ a := fun h => ha (h ▸ hb)
        simpa only [m', Function.update_of_ne hba] using hm b hb
    · intro e he
      rw [hzout e (he a (Finset.mem_insert_self _ _))]
      exact hout e (fun b hb => he b (Finset.mem_insert_of_mem hb))
    · intro b hb e he
      rcases Finset.mem_insert.mp hb with hba | hb
      · subst b
        rw [hzpath e he]
        have heout : ∀ b ∈ F, e ∉ C b := by
          intro b hb hc
          exact Finset.disjoint_left.mp (had b hb) (hNC a (Finset.mem_insert_self _ _) he) hc
        rw [hout e heout]
        simp only [m', Function.update_same]
      · have heout : e ∉ C a := by
          intro hca
          exact Finset.disjoint_left.mp (had b hb) hca (hNC b (Finset.mem_insert_of_mem hb) he)
        have hba : b ≠ a := fun h => ha (h ▸ hb)
        rw [hzout e heout, hpath b hb e he]
        simp only [m', Function.update_of_ne hba]
    · intro S hS
      have hprior := hloss S (fun b hb => hS b (Finset.mem_insert_of_mem hb))
      have hnew : edgeSum R.point S - edgeSum Z.point S ≤
          if S ∩ C a = ∅ then 0 else f*k a := by
        rcases hS a (Finset.mem_insert_self _ _) with hz | ⟨e, hne, heq⟩
        · rw [if_pos hz]
          have hzero := hzloss S
          simpa only [hz, Finset.card_empty, Nat.cast_zero, zero_mul] using hzero
        · have hneSet : S ∩ C a ≠ ∅ := by
            rw [heq]
            exact Finset.insert_nonempty _ _ |>.ne_empty
          rw [if_neg hneSet]
          exact hzpair S e hne heq
      rw [Finset.sum_insert ha]
      linarith
    · intro S hS
      rw [hzpres S (hS a (Finset.mem_insert_self _ _))]
      exact hpres S (fun b hb => hS b (Finset.mem_insert_of_mem hb))

end TSP.Improvements20261105
