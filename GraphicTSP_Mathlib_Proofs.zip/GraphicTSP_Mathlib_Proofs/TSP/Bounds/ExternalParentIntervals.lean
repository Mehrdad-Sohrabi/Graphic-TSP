import TSP.Improvements20261105.MassRemoval

/-! Exact local pair weights for the classified Q interval. The incoming
item p is external. Every new pair is (p,e), so no pair contains two
internal resource items. This file proves weights and marginals; the
simultaneous graph feasibility is a separate obligation. -/
namespace TSP.Improvements20261105
open Graph Classical
open scoped BigOperators
variable {E : Type} [DecidableEq E]

theorem external_interval_arithmetic (q k t : ℝ)
    (hq : 0 ≤ q) (hk : 0 ≤ k) (hc : q + k ≤ 1) (ht : 0 ≤ t) (htop : t ≤ 1 - q) :
    0 ≤ min t k ∧ min t k ≤ k ∧ min t k ≤ t ∧
    0 ≤ q / 2 + t - min t k / 2 ∧
    (q + k) / 2 + t - min t k / 2 ≤ 1 ∧
    (q + k) / 2 ≤ (q + k) / 2 + max (t - k) 0 ∧
    (q + k) / 2 + max (t - k) 0 ≤ 1 - (q + k) / 2 ∧
    t - min t k = max (t - k) 0 := by
  by_cases htk : t ≤ k
  · rw [min_eq_left htk, max_eq_right (by linarith : t - k ≤ 0)]
    constructor; exact ht
    constructor; exact htk
    constructor; exact le_rfl
    constructor; linarith
    constructor; linarith
    constructor; linarith
    constructor; linarith
    ring
  · have hkt : k ≤ t := le_of_not_ge htk
    rw [min_eq_right hkt, max_eq_left (by linarith : 0 ≤ t - k)]
    constructor; exact hk
    constructor; exact le_rfl
    constructor; exact hkt
    constructor; linarith
    constructor; linarith
    constructor; linarith
    constructor; linarith
    ring

/-- Distribute the transferable mass over the other boundary incidences.
alpha(e) is the remaining (e,A) pair weight, beta(e) the new (p,e)
weight, and incoming the (p,A) weight. -/
theorem external_parent_pair_weights (A : Finset E) (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (q t : ℝ) (hq : 0 ≤ q) (hc : q + edgeSum x A ≤ 1)
    (ht : 0 ≤ t) (htop : t ≤ 1 - q) :
    ∃ (alpha beta : E → ℝ) (incoming : ℝ),
      (∀ e, 0 ≤ alpha e ∧ 0 ≤ beta e) ∧ 0 ≤ incoming ∧
      (∀ e ∉ A, alpha e = x e / 2 ∧ beta e = 0) ∧
      (∀ e, alpha e + beta e = x e / 2) ∧
      (incoming + edgeSum beta A = q / 2 + t) ∧
      (incoming + edgeSum alpha A =
        (q + edgeSum x A) / 2 + max (t - edgeSum x A) 0) ∧
      (incoming + edgeSum alpha A + edgeSum beta A ≤ 1) ∧
      ((q + edgeSum x A) / 2 ≤ incoming + edgeSum alpha A) ∧
      (incoming + edgeSum alpha A ≤ 1 - (q + edgeSum x A) / 2) ∧
      (edgeSum beta A = min t (edgeSum x A) / 2) := by
  have hk : 0 ≤ edgeSum x A := Finset.sum_nonneg (fun e _ => hx e)
  obtain ⟨hb0, hbk, hbt, hinc, htotal, hlow, hupp, hid⟩ :=
    external_interval_arithmetic q (edgeSum x A) t hq hk hc ht htop
  obtain ⟨y, hy, hout, hsum⟩ := exists_remove_mass x A hx (min t (edgeSum x A)) hb0 hbk
  let alpha := fun e => y e / 2
  let beta := fun e => (x e - y e) / 2
  let incoming := q / 2 + t - min t (edgeSum x A) / 2
  have ha : edgeSum alpha A = (edgeSum x A - min t (edgeSum x A)) / 2 := by
    change (∑ e ∈ A, y e / 2) = _
    rw [← Finset.sum_div]
    change edgeSum y A / 2 = _
    rw [hsum]
  have hb : edgeSum beta A = min t (edgeSum x A) / 2 := by
    change (∑ e ∈ A, (x e - y e) / 2) = _
    rw [← Finset.sum_div, Finset.sum_sub_distrib]
    change (edgeSum x A - edgeSum y A) / 2 = _
    rw [hsum]
    ring
  refine ⟨alpha, beta, incoming, ?_, hinc, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hb⟩
  · intro e
    exact ⟨div_nonneg (hy e).1 (by norm_num), div_nonneg (sub_nonneg.mpr (hy e).2) (by norm_num)⟩
  · intro e he
    simp [alpha, beta, hout e he]
  · intro e
    dsimp [alpha, beta]
    ring
  · rw [hb]
    dsimp [incoming]
    ring
  · rw [ha]
    dsimp [incoming]
    linarith
  · rw [ha, hb]
    dsimp [incoming]
    linarith
  · rw [ha]
    dsimp [incoming]
    linarith
  · rw [ha]
    dsimp [incoming]
    linarith

/-- Every light-anchor path uses either the old (e,A) pair or the new
(p,e) pair. Its total marginal is unchanged on any light incidence set. -/
theorem light_anchor_pair_marginal (A : Finset E) (x alpha beta : E → ℝ)
    (hm : ∀ e, alpha e + beta e = x e / 2) :
    edgeSum alpha A + edgeSum beta A = edgeSum x A / 2 := by
  simp only [edgeSum, ← Finset.sum_add_distrib, Finset.sum_div]
  exact Finset.sum_congr rfl (fun e _ => hm e)

theorem incoming_interval_box (q t : ℝ) (hq : 0 ≤ q) (ht : 0 ≤ t) (htop : t ≤ 1 - q) :
    q / 2 ≤ q / 2 + t ∧ q / 2 + t ≤ 1 - q / 2 := by
  constructor <;> linarith

theorem free_interval_anchor_unchanged (q k t : ℝ) (hfree : t ≤ k) :
    (q + k) / 2 + max (t - k) 0 = (q + k) / 2 := by
  rw [max_eq_right (by linarith : t - k ≤ 0), add_zero]

end TSP.Improvements20261105
