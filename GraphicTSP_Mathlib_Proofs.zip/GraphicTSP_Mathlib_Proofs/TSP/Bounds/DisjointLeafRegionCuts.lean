import TSP.Improvements20261105.SourcePrefixCoverage

/-! Back boundaries of disjoint original-vertex regions are counted
once when every crossing back has its tail in its region. Foreign backs
are paid by the actual leaf entry; internal owners are explicit stars. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem region_back_boundaries_disjoint (A B : Finset V) (hdis : Disjoint A B)
    (hA : ∀ e ∈ G.cut A ∩ d.backEdges, d.lower e ∈ A)
    (hB : ∀ e ∈ G.cut B ∩ d.backEdges, d.lower e ∈ B) :
    Disjoint (G.cut A ∩ d.backEdges) (G.cut B ∩ d.backEdges) := by
  apply Finset.disjoint_left.mpr
  intro e heA heB
  exact Finset.disjoint_left.mp hdis (hA e heA) (hB e heB)

theorem GatedDrops.disjoint_leaf_regions_back_budget (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (P : GatePlan d) (a : GatedDrops d) (r : FlowVertex d) (hr : r ≠ .inl d.tree.root)
    (hmarker : r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P))
    (hout : a.componentOutgoingCuts d P r = ∅)
    (regions : Finset (Finset V))
    (hdis : ∀ A ∈ regions, ∀ B ∈ regions, A ≠ B → Disjoint A B)
    (hinside : ∀ A ∈ regions, A ⊆ a.originalComponentVertices d P r)
    (htail : ∀ A ∈ regions, ∀ e ∈ G.cut A ∩ d.backEdges, d.lower e ∈ A)
    (I : Finset d.StarIndex)
    (howners : ∀ A ∈ regions, ∀ e ∈ G.cut A ∩ d.backEdges,
      a.component d P (.inr (d.anchor e)) = r → ∃ i ∈ I, e ∈ d.backGroup i.1) :
    (∑ A ∈ regions, edgeSum x (G.cut A ∩ d.backEdges)) ≤
      componentEntryCoverage d x r+∑ i ∈ I, edgeSum x (d.backGroup i.1) := by
  let boundary := regions.biUnion (fun A => G.cut A ∩ d.backEdges)
  let owned := I.biUnion (fun i => d.backGroup i.1)
  have hsum : edgeSum x boundary = ∑ A ∈ regions, edgeSum x (G.cut A ∩ d.backEdges) :=
    Finset.sum_biUnion (fun A hA B hB hne => region_back_boundaries_disjoint d A B
      (hdis A hA B hB hne) (htail A hA) (htail B hB))
  have howned : edgeSum x owned = ∑ i ∈ I, edgeSum x (d.backGroup i.1) :=
    Finset.sum_biUnion (fun i _ j _ h => back_groups_disjoint d i.1 j.1 (fun he => h (Subtype.ext he)))
  have hsub : boundary ⊆ deletedSubtreeCut d (nonrootComponentEntry d r hr) ∪ owned := by
    intro e he
    obtain ⟨A,hA,heA⟩ := Finset.mem_biUnion.mp he
    have htailcomp := (Finset.mem_filter.mp (hinside A hA (htail A hA e heA))).2
    by_cases hhead : a.component d P (.inr (d.anchor e)) = r
    · obtain ⟨i,hi,hei⟩ := howners A hA e heA hhead
      exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨i,hi,hei⟩)
    · let b : BackEdge d := ⟨e,(Finset.mem_inter.mp heA).2⟩
      exact Finset.mem_union_left _ (a.foreign_leaf_back_enters d P r hr hmarker hout b htailcomp hhead)
  have hmass := Finset.sum_le_sum_of_subset_of_nonneg hsub (fun e _ _ => hx e)
  have hunion := nonnegative_edgeSum_union_le x hx (deletedSubtreeCut d (nonrootComponentEntry d r hr)) owned
  change edgeSum x boundary ≤ edgeSum x (deletedSubtreeCut d (nonrootComponentEntry d r hr) ∪ owned) at hmass
  rw [hsum] at hmass
  rw [howned] at hunion
  rw [componentEntryCoverage_eq_deleted d x r hr]
  linarith only [hmass,hunion]

end TSP.Improvements20261105
