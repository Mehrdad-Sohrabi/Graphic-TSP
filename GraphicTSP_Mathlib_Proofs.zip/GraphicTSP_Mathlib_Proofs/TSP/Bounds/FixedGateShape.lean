import TSP.Improvements20261105.FixedGateGeometry

/-! The fixed outgoing bypass occurs only at a nonbranching child;
every genuine branching child receives one of the three branch gadgets. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem children_partition_card (s : d.tree.Child) :
    (headedChildren d s).card + (headlessChildren d s).card = (Chapter11.childSet d s).card :=
  Finset.filter_card_add_filter_neg_card_eq_card (fun r => (d.backGroup r).Nonempty)

theorem fixedGatePlan_outgoing_shape (x : E → ℝ) (s : d.tree.Child)
    (hs : (fixedGatePlan d x).kind s = .outgoing) :
    d.tree.parent s ≠ d.tree.root ∧ (Chapter11.childSet d s).card ≤ 1 := by
  have hpart := children_partition_card d s
  have hn : d.tree.parent s ≠ d.tree.root := by
    intro he
    simp [fixedGatePlan, fixedBypassKind, he] at hs
  refine ⟨hn, ?_⟩
  by_contra hc
  by_cases hi : 2 ≤ (headlessChildren d s).card
  · simp [fixedGatePlan, fixedBypassKind, hn, hc, hi] at hs
  · have hh : (headedChildren d s).Nonempty := Finset.card_pos.mp (by omega)
    simp only [fixedGatePlan, fixedBypassKind, if_neg hn, if_neg hc, if_neg hi, if_pos hh] at hs
    split_ifs at hs <;> simp_all

theorem fixedGatePlan_active_outgoing_unary (hsimple : G.IsSimple) (x : E → ℝ) (s : d.tree.Child)
    (hs : (fixedGatePlan d x).kind s = .outgoing) (hactive : (d.backGroup s).Nonempty) :
    childCount d s = 1 := by
  have h1 := (fixedGatePlan_outgoing_shape d x s hs).2
  have h2 := star_child_has_child d hsimple ⟨s, hactive⟩
  change childCount d s ≤ 1 at h1
  change 1 ≤ childCount d s at h2
  omega

end TSP.Improvements20261105
