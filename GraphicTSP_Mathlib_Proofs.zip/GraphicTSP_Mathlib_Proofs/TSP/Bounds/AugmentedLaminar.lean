import TSP.Improvements20261105.LaminarEligibleCounts

/-! Add singleton and top shores to the original tight spanning family.
Nontight additions correspond exactly to degree-slack vertices for n >= 3. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Chapter10
open Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def augmentedLaminar (G : Graph V E) (x : E → ℝ) (root : V)
    (hn : 2 ≤ Fintype.card V) (F : Finset (Finset V)) (hlam : LaminarFamily F)
    (htight : ∀ A ∈ F, TightShore G x root A) : LaminarSystem V where
  root := root
  family := F ∪ baseShores root
  laminar := by
    intro A hA B hB
    rcases Finset.mem_union.mp hA with hA | hA
    · rcases Finset.mem_union.mp hB with hB | hB
      · exact hlam A hA B hB
      · exact compatible_with_base root A (htight A hA).2.1 B hB
    · rcases Finset.mem_union.mp hB with hB | hB
      · exact compatible_symm (compatible_with_base root B (htight B hB).2.1 A hA)
      · exact baseShores_laminar root A hA B hB
  nonempty := by
    intro A hA
    rcases Finset.mem_union.mp hA with hA | hA
    · exact (htight A hA).1
    · exact base_shore_nonempty root hn A hA
  avoids := by
    intro A hA
    rcases Finset.mem_union.mp hA with hA | hA
    · exact (htight A hA).2.1
    · intro hr
      have htop := baseShores_subset_top root A hA hr
      simpa using htop
  singleton_mem := by
    intro v hv
    apply Finset.mem_union_right
    apply Finset.mem_insert_of_mem
    exact Finset.mem_image.mpr ⟨v, Finset.mem_erase.mpr ⟨hv, Finset.mem_univ _⟩, rfl⟩
  top_mem := Finset.mem_union_right _ (Finset.mem_insert_self _ _)

noncomputable def degreeSlackVertices (G : Graph V E) (x : E → ℝ) : Finset V :=
  Finset.univ.filter (fun v => 2 < edgeSum x (G.cut {v}))

def baseShoreFor (root v : V) : Finset V := if v = root then {root}ᶜ else {v}

theorem baseShoreFor_mem (root v : V) : baseShoreFor root v ∈ baseShores root := by
  by_cases hv : v = root
  · simp [baseShoreFor, hv, baseShores]
  · rw [baseShoreFor, if_neg hv]
    exact Finset.mem_insert_of_mem (Finset.mem_image.mpr
      ⟨v, Finset.mem_erase.mpr ⟨hv, Finset.mem_univ _⟩, rfl⟩)

theorem baseShoreFor_cut (G : Graph V E) (root v : V) : G.cut (baseShoreFor root v) = G.cut {v} := by
  by_cases hv : v = root
  · simp [baseShoreFor, hv, cut_complement]
  · simp [baseShoreFor, hv]

theorem top_card_ge_two (root : V) (hn : 3 ≤ Fintype.card V) :
    2 ≤ ({root}ᶜ : Finset V).card := by
  have hc := Finset.card_compl ({root} : Finset V)
  simp only [Finset.card_singleton] at hc
  omega

theorem baseShoreFor_injective (root : V) (hn : 3 ≤ Fintype.card V) :
    Function.Injective (baseShoreFor root) := by
  intro v w he
  have htop := top_card_ge_two root hn
  by_cases hv : v = root <;> by_cases hw : w = root
  · exact hv.trans hw.symm
  · simp only [baseShoreFor, hv, if_true, hw, if_false] at he
    rw [he, Finset.card_singleton] at htop
    omega
  · simp only [baseShoreFor, hv, if_false, hw, if_true] at he
    rw [← he, Finset.card_singleton] at htop
    omega
  · simp only [baseShoreFor, hv, hw, if_false] at he
    exact Finset.singleton_injective he

theorem augmented_internal_tight (G : Graph V E) (x : E → ℝ) (root : V)
    (hn : 2 ≤ Fintype.card V) (F : Finset (Finset V)) (hlam : LaminarFamily F)
    (htight : ∀ A ∈ F, TightShore G x root A)
    (A : Finset V) (hA : A ∈ (augmentedLaminar G x root hn F hlam htight).family)
    (hcard : 2 ≤ A.card) (htop : A ≠ (augmentedLaminar G x root hn F hlam htight).top) :
    edgeSum x (G.cut A) = 2 := by
  rcases Finset.mem_union.mp hA with hA | hA
  · exact (htight A hA).2.2
  · rcases Finset.mem_insert.mp hA with he | hA
    · exact (htop he).elim
    · obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp hA
      simp only [Finset.card_singleton] at hcard
      omega

theorem augmented_nontight_eq (G : Graph V E) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (root : V) (hn : 2 ≤ Fintype.card V) (F : Finset (Finset V)) (hlam : LaminarFamily F)
    (htight : ∀ A ∈ F, TightShore G x root A) :
    nontightShores G x (augmentedLaminar G x root hn F hlam htight) =
      (degreeSlackVertices G x).image (baseShoreFor root) := by
  ext A
  constructor
  · intro hA
    have hh := Finset.mem_filter.mp hA
    have hbase : A ∈ baseShores root := by
      rcases Finset.mem_union.mp hh.1 with hf | hb
      · exact (hh.2 (htight A hf).2.2).elim
      · exact hb
    have hpre : ∃ v, baseShoreFor root v = A := by
      rcases Finset.mem_insert.mp hbase with rfl | hb
      · exact ⟨root, by simp [baseShoreFor]⟩
      · obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hb
        exact ⟨v, by simp [baseShoreFor, (Finset.mem_erase.mp hv).1]⟩
    obtain ⟨v, rfl⟩ := hpre
    refine Finset.mem_image.mpr ⟨v, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, rfl⟩
    have hlo := hx.2 {v} (Finset.singleton_nonempty _) (singleton_compl_nonempty hn v)
    have hne : edgeSum x (G.cut {v}) ≠ 2 := by simpa only [baseShoreFor_cut] using hh.2
    exact lt_of_le_of_ne hlo (Ne.symm hne)
  · intro hA
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hA
    refine Finset.mem_filter.mpr ⟨Finset.mem_union_right _ (baseShoreFor_mem root v), ?_⟩
    rw [baseShoreFor_cut]
    exact ne_of_gt (Finset.mem_filter.mp hv).2

theorem augmented_nontight_card (G : Graph V E) {x : E → ℝ} (hx : G.SubtourFeasible x)
    (root : V) (hn : 3 ≤ Fintype.card V) (F : Finset (Finset V)) (hlam : LaminarFamily F)
    (htight : ∀ A ∈ F, TightShore G x root A) :
    (nontightShores G x (augmentedLaminar G x root (by omega) F hlam htight)).card =
      (degreeSlackVertices G x).card := by
  rw [augmented_nontight_eq G hx, Finset.card_image_of_injective _ (baseShoreFor_injective root hn)]

end TSP.Improvements20261105
