import TSP.Improvements20261105.WeightedBipartiteCover

/-! Turn two-colored edges into explicit left and right endpoint types. -/
namespace TSP.Improvements20261105
open Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def coloredLeft (A B : E → V) (P : V → Prop)
    (hP : ∀ e, P (A e) ↔ ¬P (B e)) (e : E) : {v // P v} :=
  if h : P (A e) then ⟨A e, h⟩ else
    ⟨B e, by by_contra hn; exact h ((hP e).mpr hn)⟩

noncomputable def coloredRight (A B : E → V) (P : V → Prop)
    (hP : ∀ e, P (A e) ↔ ¬P (B e)) (e : E) : {v // ¬P v} :=
  if h : P (A e) then ⟨B e, (hP e).mp h⟩ else ⟨A e, h⟩

noncomputable def combinedColorPrice (P : V → Prop)
    (u : {v // P v} → ℝ) (v : {v // ¬P v} → ℝ) (a : V) : ℝ :=
  if h : P a then u ⟨a, h⟩ else v ⟨a, h⟩

theorem combinedColorPrice_sum (P : V → Prop)
    (u : {v // P v} → ℝ) (v : {v // ¬P v} → ℝ) :
    (∑ a, combinedColorPrice P u v a) = (∑ a, u a) + (∑ a, v a) := by
  have h := Fintype.sum_subtype_add_sum_subtype P (combinedColorPrice P u v)
  have hL (a : {v // P v}) : combinedColorPrice P u v a = u a := by
    simp [combinedColorPrice, a.2]
  have hR (a : {v // ¬P v}) : combinedColorPrice P u v a = v a := by
    simp [combinedColorPrice, a.2]
  simpa only [hL, hR] using h.symm

theorem colored_endpoints_sum (A B : E → V) (P : V → Prop)
    (hP : ∀ e, P (A e) ↔ ¬P (B e)) (u : {v // P v} → ℝ) (v : {v // ¬P v} → ℝ) (e : E) :
    u (coloredLeft A B P hP e) + v (coloredRight A B P hP e) =
      combinedColorPrice P u v (A e) + combinedColorPrice P u v (B e) := by
  by_cases h : P (A e)
  · have hn := (hP e).mp h
    simp [coloredLeft, coloredRight, combinedColorPrice, h, hn]
  · have hp : P (B e) := by by_contra hn; exact h ((hP e).mpr hn)
    simp [coloredLeft, coloredRight, combinedColorPrice, h, hp, add_comm]

theorem colored_matching_endpoints (A B : E → V) (P : V → Prop)
    (hP : ∀ e, P (A e) ↔ ¬P (B e)) (M : Finset E)
    (hl : Set.InjOn (coloredLeft A B P hP) (M : Set E))
    (hr : Set.InjOn (coloredRight A B P hP) (M : Set E)) :
    ∀ e ∈ M, ∀ f ∈ M, ∀ a, (a = A e ∨ a = B e) → (a = A f ∨ a = B f) → e = f := by
  intro e he f hf a hae haf
  by_cases hp : P a
  · apply hl he hf
    apply Subtype.ext
    have hh (b : E) (ha : a = A b ∨ a = B b) : (coloredLeft A B P hP b : V) = a := by
      rcases ha with ha | ha
      · have h : P (A b) := ha ▸ hp
        simp [coloredLeft, h, ha]
      · have h : ¬P (A b) := fun h => (hP b).mp h (ha ▸ hp)
        simp [coloredLeft, h, ha]
    exact (hh e hae).trans (hh f haf).symm
  · apply hr he hf
    apply Subtype.ext
    have hh (b : E) (ha : a = A b ∨ a = B b) : (coloredRight A B P hP b : V) = a := by
      rcases ha with ha | ha
      · have h : ¬P (A b) := ha ▸ hp
        simp [coloredRight, h, ha]
      · have h : P (A b) := (hP b).mpr (ha ▸ hp)
        simp [coloredRight, h, ha]
    exact (hh e hae).trans (hh f haf).symm

end TSP.Improvements20261105
