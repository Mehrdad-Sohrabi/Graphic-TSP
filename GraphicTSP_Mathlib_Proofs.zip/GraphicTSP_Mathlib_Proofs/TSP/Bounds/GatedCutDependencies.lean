import TSP.Improvements20261105.GatedComponentLocations

/-! A positive unrewarded dependency uses the whole unit back-path budget.
Its owning selected head therefore lies in the same true-cut component. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.pathCost_le_one {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) : a.pathCost d b ≤ 1 := by
  have hh := ha.back b
  have ht : (0 : ℝ) ≤ a.tail (d.lower b.1) := by exact_mod_cast ha.tail_nonneg _
  have ho : (0 : ℝ) ≤ if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0 := by
    split_ifs
    · exact_mod_cast ha.outside_nonneg _
    · exact le_rfl
  have hb : (a.head (d.anchor b.1) : ℝ) ≤ 1 := by
    have hh' := a.head_binary d ha (d.anchor b.1)
    exact_mod_cast (show a.head (d.anchor b.1) ≤ 1 by omega)
  linarith

theorem GatedDrops.positive_tail_path_empty {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (htail : 0 < a.tail (d.lower b.1)) :
    a.backPathCuts d P b = ∅ := by
  have hh := a.backPathCuts_card_le_head d ha b
  have ht : (1 : ℝ) ≤ a.tail (d.lower b.1) := by
    exact_mod_cast (show 1 ≤ a.tail (d.lower b.1) by omega)
  have ho : (0 : ℝ) ≤ if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0 := by
    split_ifs
    · exact_mod_cast ha.outside_nonneg _
    · exact le_rfl
  have hb : (a.head (d.anchor b.1) : ℝ) ≤ 1 := by
    have hh' := a.head_binary d ha (d.anchor b.1)
    exact_mod_cast (show a.head (d.anchor b.1) ≤ 1 by omega)
  apply Finset.card_eq_zero.mp
  have hz : ((a.backPathCuts d P b).card : ℝ) = 0 :=
    le_antisymm (by linarith) (Nat.cast_nonneg _)
  exact_mod_cast hz

theorem GatedDrops.back_cuts_and_prefix_budget {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (v : d.tree.Child)
    (hv : backConnectorPath d b v) (hr : P.IsReceiver d v) (hs : a.suffix v = 0) :
    ((a.backPathCuts d P b).card : ℝ) + (a.pref v : ℝ) ≤ a.pathCost d b := by
  let k := expandedConnectorChild d v
  have hk : k ∉ a.trueCuts d P := by
    simp [k, GatedDrops.trueCuts, GatedDrops.trueRoleWeight, hr, hs]
  have hkp : onExpandedBackPath d b k := (expanded_connector_back_path d b v).mpr hv
  have hterm : a.physicalPathTerm d b k = (a.pref v : ℝ) := by
    rw [GatedDrops.physicalPathTerm, if_pos hkp]
    simp [k, expandedTreeRoles, expandedConnectorChild, GatedDrops.physicalRoleWeight, hs]
  have hcut : k ∉ a.backPathCuts d P b := fun h => hk (Finset.mem_filter.mp h).1
  have hsum : (∑ w : (expandedTree d).Child,
      ((if w ∈ a.backPathCuts d P b then (1 : ℝ) else 0) +
      (if w = k then (a.pref v : ℝ) else 0))) ≤
      ∑ w : (expandedTree d).Child, a.physicalPathTerm d b w := by
    apply Finset.sum_le_sum
    intro w _
    by_cases hw : w = k
    · subst w
      simp [hcut, hterm]
    · simpa only [if_neg hw, add_zero] using a.backPathCut_indicator_le d ha b w
  simpa [Finset.sum_add_distrib, a.physicalPathTerm_sum d b] using hsum

theorem GatedDrops.positive_prefix_path_empty {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (v : d.tree.Child)
    (hv : backConnectorPath d b v) (hr : P.IsReceiver d v)
    (hs : a.suffix v = 0) (hp : 0 < a.pref v) : a.backPathCuts d P b = ∅ := by
  have hh := a.back_cuts_and_prefix_budget d ha b v hv hr hs
  have hpR : (1 : ℝ) ≤ a.pref v := by exact_mod_cast (show 1 ≤ a.pref v by omega)
  have hb := a.pathCost_le_one d ha b
  apply Finset.card_eq_zero.mp
  have hz : ((a.backPathCuts d P b).card : ℝ) = 0 :=
    le_antisymm (by linarith) (Nat.cast_nonneg _)
  exact_mod_cast hz

theorem canonical_positive_gate_dependency_local (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (huse : P.UsesGate d s) (hpref : 0 < a.pref (P.receiver s))
    (b : BackEdge d) (hpath : backConnectorPath d b (P.receiver s)) :
    a.head s = 1 ∧ a.component d P (.inr s) = a.component d P (.inr (d.anchor b.1)) := by
  obtain ⟨howner, hrec, hsame⟩ := canonical_gate_same_component d hs hc P hP t ht f hf hb a ha hcan s huse hpref
  have hr : P.IsReceiver d (P.receiver s) := ⟨s, huse, rfl⟩
  have hsuf : a.suffix (P.receiver s) = 0 := by
    have hh := ha.paid (P.receiver s)
    rw [hrec, if_pos hr] at hh
    have hn := ha.suffix_nonneg (P.receiver s)
    omega
  have hz := a.positive_prefix_path_empty d ha b (P.receiver s) hpath hr hsuf hpref
  have hmid := a.component_back_path_middle d P b hz (.inr (P.receiver s))
    ((expanded_connector_back_path d b (P.receiver s)).mpr hpath).1
  exact ⟨howner, hsame.trans hmid.symm⟩

theorem canonical_positive_tail_dependency_local
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) (htail : 0 < a.tail s)
    (b : BackEdge d) (hbottom : d.lower b.1 = s) :
    a.component d P (.inr s) = a.component d P (.inr (d.anchor b.1)) := by
  have hz := a.positive_tail_path_empty d ha b (by simpa only [hbottom] using htail)
  have hpath := a.component_back_path_zero d P b hz
  rw [hbottom] at hpath
  have hsame := canonical_selected_center_same_head d P hP t ht f hf hb a hcan s hsel
  exact hsame.symm.trans hpath.symm

end TSP.Improvements20261105
