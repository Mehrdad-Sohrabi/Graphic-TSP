import TSP.Improvements20261105.ZeroLeafFamilyPayment
import TSP.Improvements20261105.GuardedZeroComponentCost

/-! The payment applies to actual nonroot zero-only leaf roots. Entry
geometry is derived from the graph, rather than supplied as a surrogate. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Chapter11 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.guarded_zero_leaf_family_cost (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hprojection : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (L : Finset (FlowVertex d))
    (hroot : ∀ r ∈ L, r ≠ .inl d.tree.root)
    (hmarker : ∀ r ∈ L, r ∈ (expandedTree d).cutComponentRoots (a.trueCuts d P))
    (hout : ∀ r ∈ L, a.componentOutgoingCuts d P r = ∅)
    (hheadful : ∀ r ∈ L, (a.actualComponentHeads d P r).Nonempty)
    (hzero : ∀ r ∈ L, ∀ c ∈ a.actualComponentHeads d P r, edgeSum x (d.backGroup c) ≤ 1)
    (eta : d.tree.Child → ℝ) (heta : ∀ c, eta c ≠ 0 → SurvivingPositive d x c)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hrootStar : d.centers rootStar = d.tree.root)
    (R : E ⊕ d.StarIndex → ℝ)
    (Q : E ⊕ d.StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G d.centers owner)
    (hrep : ∀ c, Q (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+eta c)
    (hbacks : ∀ e ∈ d.backEdges, Q (.inl e) = 1-x e/2)
    (m : d.StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x (d.treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : d.StarIndex, edgeSum x (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Q i) :
    let A := currentGuardedP d x z C owner rootStar
    (∑ i ∈ a.componentStarUnion d P L,
      (jointHeadTerm (pqConnectorArm d x (415/2) (704/5) A R i)
        (pqDeficitArm d x (415/2) (704/5) A R i) (a.head i.1 : ℝ)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1))+
      (∑ r ∈ L, 24*(2-componentEntryCoverage d x r))-
      (704/5 : ℝ)*(∑ r ∈ L, a.zeroGuardMassInComponent d P x m r) ≤
      24*(∑ r ∈ L, ∑ v ∈ a.originalComponentVertices d P r, degreeExcess G x v)+
      12*(∑ r ∈ L, componentEntryError d x r) := by
  have hlocal (i : d.StarIndex) (hi : i ∈ a.componentStarUnion d P L) :
      jointHeadTerm (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
        (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i) (a.head i.1 : ℝ)-
        (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5 : ℝ)*zeroQCredit d x Q i := by
    obtain ⟨r,hr,hcomp⟩ := Finset.mem_biUnion.mp hi
    have hz := hzero r hr i.1 (Finset.mem_filter.mpr
      ⟨Finset.mem_univ _, i.2, (Finset.mem_filter.mp hcomp).2⟩)
    exact a.currentGuardedP_zero_component_credit d hs P hP t ht f hf hb ha hcan x z hx hn hcap
      hprojection C owner ho rootStar hrootStar Q R r (hroot r hr) (hzero r hr) i hcomp (hguarded i hz)
  have hsum := Finset.sum_le_sum hlocal
  simp only [← Finset.mul_sum, Finset.sum_neg_distrib] at hsum
  have hpay := a.zero_leaf_family_payment_owned d hs P hP t ht f hf hb ha hcan x hx hn hcap L
    hroot hmarker hout hheadful hzero eta heta owner ho Q hQ hrep hbacks m hm0 hm
  dsimp only at hsum ⊢
  linarith

end TSP.Improvements20261105
