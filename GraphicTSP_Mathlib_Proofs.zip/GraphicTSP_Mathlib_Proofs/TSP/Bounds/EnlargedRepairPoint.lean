import TSP.Manuscript20261020.DFSConnectorBounds
import TSP.Manuscript20261105.ReconnectionLP

/-! The actual simultaneous minimum-cut point permits the full adjustment
range 0 <= d_S <= min(a_S, 1-q_S), including forced adjustments above excess. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10
open Manuscript20261020 Manuscript20261105
open Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

def AdmissibleAdjustment (x : E → ℝ) (delta : d.StarIndex → ℝ) : Prop :=
  ∀ i, d.centers i ≠ d.tree.root →
    0 ≤ delta i ∧ delta i ≤ min (starBackMass d x i) (1 - starTreeMass d x i)

theorem enlargedRepairPoint_feasible (hsimple : G.IsSimple) (hconn : IsTwoVertexConnected G)
    (owner : E → Option d.StarIndex) (howner : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (x : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (delta : d.StarIndex → ℝ) (hdelta : AdmissibleAdjustment d x delta) :
    generalPoint d owner rootStar x delta ∈ NonloopReconnectionLP G d.centers owner := by
  rw [nonloopReconnectionLP_eq_projection]
  have hp := pRepresentatives_bounds d x delta (fun e => ⟨hx.1 e, hcap e⟩)
    (fun i hi => ⟨(hdelta i hi).1, (hdelta i hi).2.trans (min_le_right _ _)⟩)
  exact completedPoint_feasible edmondsJohnson_proved G d.centers owner rootStar d.tree.root
    (pRepresentatives d x delta) x (root_copy_cut d hsimple hconn owner howner rootStar hroot)
    hx (fun e => (hp e).1) (fun e => (hp e).2)

theorem admissible_extended_le_back (x : E → ℝ) (delta : d.StarIndex → ℝ)
    (hx : ∀ e, 0 ≤ x e) (hdelta : AdmissibleAdjustment d x delta) (v : d.tree.Child) :
    extendNonrootRepairs d delta v ≤ edgeSum x (d.backGroup v) := by
  have ha : 0 ≤ edgeSum x (d.backGroup v) := Finset.sum_nonneg (fun e _ => hx e)
  by_cases hb : (d.backGroup v).Nonempty
  · by_cases hr : d.tree.parent v = d.tree.root
    · rw [extendNonrootRepairs_root d delta v hr]
      exact ha
    · have hd := (hdelta ⟨v, hb⟩ hr).2.trans (min_le_left _ _)
      simpa only [extendNonrootRepairs, dif_pos hb, if_neg hr] using hd
  · rw [extendNonrootRepairs_inactive d delta v hb]
    exact ha

theorem admissible_star_capacity (x : E → ℝ) (delta : d.StarIndex → ℝ)
    (hx : ∀ e, 0 ≤ x e) (hdelta : AdmissibleAdjustment d x delta) (i : d.StarIndex) :
    2 / 3 ≤ edgeSum (fun e => 1 - pRepresentatives d x delta e) (d.stars i) := by
  rw [p_star_capacity]
  have hd := admissible_extended_le_back d x delta hx hdelta i.1
  change extendNonrootRepairs d delta i.1 ≤ starBackMass d x i at hd
  linarith

theorem admissible_group_capacity (x : E → ℝ) (delta : d.StarIndex → ℝ)
    (hx : ∀ e, 0 ≤ x e) (hdelta : AdmissibleAdjustment d x delta) (v : d.tree.Child) :
    2 / 3 ≤ edgeSum (fun e => 1 - pRepresentatives d x delta e) (d.group v) := by
  by_cases hb : (d.backGroup v).Nonempty
  · exact admissible_star_capacity d x delta hx hdelta ⟨v, hb⟩
  · have he := Finset.not_nonempty_iff_eq_empty.mp hb
    rw [d.group_eq_insert_backGroup, he]
    have hp : pRepresentatives d x delta (d.treeEdge v) = 1 / 3 := by
      change expandedPoint d x (extendNonrootRepairs d delta) (Sum.inl (d.treeEdge v)) = _
      rw [expandedPoint_tree, extendNonrootRepairs_inactive d delta v hb]
      ring
    norm_num [edgeSum, hp]

theorem admissible_many_children_residual_capacity (hsimple : G.IsSimple)
    (x : E → ℝ) (delta : d.StarIndex → ℝ) (hx : ∀ e, 0 ≤ x e ∧ x e ≤ 1)
    (hdelta : AdmissibleAdjustment d x delta) (i : d.StarIndex)
    (hc : 2 ≤ childCount d (d.centers i)) :
    2 / 3 ≤ edgeSum (fun e => 1 - pRepresentatives d x delta e)
      (G.cut {d.centers i} \ d.stars i) := by
  have htwo : 1 < (Finset.univ.filter (fun w : d.tree.Child => d.tree.parent w = d.centers i)).card := by
    change 1 < childCount d (d.centers i)
    omega
  obtain ⟨u, hu, v, hv, huv⟩ := Finset.one_lt_card.mp htwo
  obtain ⟨w, hw, hwi⟩ : ∃ w : d.tree.Child, d.tree.parent w = d.centers i ∧ w ≠ i.1 := by
    by_cases hui : u = i.1
    · exact ⟨v, (Finset.mem_filter.mp hv).2, by intro h; exact huv (hui.trans h.symm)⟩
    · exact ⟨u, (Finset.mem_filter.mp hu).2, hui⟩
  have hsub : d.group w ⊆ G.cut {d.centers i} \ d.stars i := by
    intro e he
    refine Finset.mem_sdiff.mpr ⟨?_, ?_⟩
    · apply (mem_singleton_cut_iff_incident G hsimple.1 _ _).mpr
      rw [← hw]
      exact d.group_incident w e he
    · intro hei
      exact Finset.disjoint_left.mp (d.groups_disjoint w i.1 hwi) he hei
  have hp := pRepresentatives_bounds d x delta hx (fun j hj =>
    ⟨(hdelta j hj).1, (hdelta j hj).2.trans (min_le_right _ _)⟩)
  exact (admissible_group_capacity d x delta (fun e => (hx e).1) hdelta w).trans
    (Finset.sum_le_sum_of_subset_of_nonneg hsub (fun e _ _ => sub_nonneg.mpr (hp e).1.2))

theorem enlarged_connector_many_children (hsimple : G.IsSimple)
    (owner : E → Option d.StarIndex) (howner : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (delta : d.StarIndex → ℝ) (hdelta : AdmissibleAdjustment d x delta)
    (i : d.StarIndex) (hi : i ≠ rootStar) (hc : 2 ≤ childCount d (d.centers i)) :
    generalPoint d owner rootStar x delta (Sum.inr i) ≤ 1 / 3 + 2 / 3 * starTau d x i := by
  have hp := pRepresentatives_bounds d x delta (fun e => ⟨hx.1 e, hcap e⟩) (fun j hj =>
    ⟨(hdelta j hj).1, (hdelta j hj).2.trans (min_le_right _ _)⟩)
  have h := completed_connector_bound G d.stars d.centers owner hsimple
    (fun j e he => (d.dfs_removable_system.1 j).2.1 e he) howner i rootStar hi
    (pRepresentatives d x delta) x (eta d x (d.centers i)) 0 (by norm_num) hx
    (fun e => (hp e).1) (fun e => (hp e).2) (by simp [eta])
    (admissible_star_capacity d x delta hx.1 hdelta i)
    (by simpa using (admissible_many_children_residual_capacity d hsimple x delta
      (fun e => ⟨hx.1 e, hcap e⟩) hdelta i hc))
  simpa only [generalPoint, starTau, star_lp_sum, starTreeMass, starBackMass,
    max_eq_left (tau_nonneg _ _)] using h

theorem enlarged_connector_one_child (hsimple : G.IsSimple)
    (owner : E → Option d.StarIndex) (howner : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hcap : ∀ e, x e ≤ 1) (delta : d.StarIndex → ℝ) (hdelta : AdmissibleAdjustment d x delta)
    (i : d.StarIndex) (hi : i ≠ rootStar) (v : d.tree.Child)
    (hv : d.centers i = (v : V)) (hc : childCount d v = 1) :
    generalPoint d owner rootStar x delta (Sum.inr i) ≤
      1 / 3 + 2 / 3 * max (starTau d x i)
        (max (extendNonrootRepairs d delta v - outgoingBackMass d x v) 0) := by
  have hp := pRepresentatives_bounds d x delta (fun e => ⟨hx.1 e, hcap e⟩) (fun j hj =>
    ⟨(hdelta j hj).1, (hdelta j hj).2.trans (min_le_right _ _)⟩)
  have hres := one_child_residual_capacity d hsimple x delta v i hc hv
  have h := completed_connector_bound G d.stars d.centers owner hsimple
    (fun j e he => (d.dfs_removable_system.1 j).2.1 e he) howner i rootStar hi
    (pRepresentatives d x delta) x (eta d x (d.centers i))
    (max (extendNonrootRepairs d delta v - outgoingBackMass d x v) 0) (le_max_right _ _) hx
    (fun e => (hp e).1) (fun e => (hp e).2) (by simp [eta])
    (admissible_star_capacity d x delta hx.1 hdelta i) (by
      rw [hv, hres]
      have hmax := le_max_left (extendNonrootRepairs d delta v - outgoingBackMass d x v) 0
      linarith)
  simpa only [generalPoint, starTau, star_lp_sum, starTreeMass, starBackMass] using h

end TSP.Improvements20261105
