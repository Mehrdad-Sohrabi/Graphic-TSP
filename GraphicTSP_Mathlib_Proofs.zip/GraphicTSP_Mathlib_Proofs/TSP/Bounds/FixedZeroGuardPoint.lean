import TSP.Improvements20261105.FixedTerminalFamily
import TSP.Improvements20261105.ZeroGuardEnvelope

/-! One feasible guarded Q for the entire fixed eligible zero-head
family, with capacities derived from its actual original Q envelope. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def ownBackStar (b : BackEdge d) : d.StarIndex :=
  ⟨d.anchor b.1, own_back_anchor_active d b⟩

 theorem ownBackStar_fixed (i : d.StarIndex) : ownBackStar d (fixedOwnBack d i) = i :=
  Subtype.ext (fixedOwnBack_anchor d i)

 theorem fixed_zero_guard_cap_sum (x : E → ℝ) (k : d.StarIndex → ℝ) (i : d.StarIndex) :
    (∑ b ∈ fixedZeroTerminalBacks d x, (if d.anchor b.1 = i.1 then k (ownBackStar d b) else 0)) =
      if i ∈ fixedZeroTerminalHeads d x then k i else 0 := by
  unfold fixedZeroTerminalBacks
  rw [Finset.sum_image (fun j _ l _ h => fixedOwnBack_injective d h)]
  simp only [fixedOwnBack_anchor, ownBackStar_fixed]
  by_cases hi : i ∈ fixedZeroTerminalHeads d x
  · rw [if_pos hi, Finset.sum_eq_single i]
    · simp
    · intro j _ hji
      have hn : j.1 ≠ i.1 := fun h => hji (Subtype.ext h)
      simp [hn]
    · exact fun hn => (hn hi).elim
  · rw [if_neg hi]
    apply Finset.sum_eq_zero
    intro j hj
    have hn : j.1 ≠ i.1 := fun h => hi ((Subtype.ext h : j = i) ▸ hj)
    simp [hn]

 theorem exists_fixed_zero_guard_point (hs : G.IsSimple) (x : E → ℝ) (hx : G.SubtourFeasible x)
    (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (Q : E ⊕ d.StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G d.centers owner)
    (t : d.tree.Child → ℝ) (ht : ∀ c, t c ≠ 0 → SurvivingPositive d x c)
    (hr : ∀ c, Q (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+t c)
    (hb : ∀ e ∈ d.backEdges, Q (.inl e) = 1-x e/2) :
    ∃ (R : E ⊕ d.StarIndex → ℝ) (m : d.StarIndex → ℝ),
      R ∈ projectedFrameworkTwo G d.centers owner ∧
      (∀ i, R (.inr i) = Q (.inr i)) ∧
      (∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i ∧
        (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
          max (x (d.treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i) ∧
      edgeSum R (nonremovableRepresentatives d.stars) ≤ edgeSum Q (nonremovableRepresentatives d.stars) -
        ∑ i ∈ fixedZeroTerminalHeads d x, m i ∧
      (∀ i, edgeSum Q (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
        (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Q i else 0)) ∧
      (∀ i, edgeSum x (d.backGroup i.1) ≤ 1 →
        max (R (.inr i)-edgeSum x (d.stars i)/2)
          ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
            -zeroQCredit d x Q i) ∧
      (∀ e, (∀ b ∈ fixedZeroTerminalBacks d x,
        e ∉ (fundamentalCycleEdges d b).map Function.Embedding.inl) → R e = Q e) := by
  let k : BackEdge d → ℝ := fun b => zeroGuardCapacity d x Q (ownBackStar d b)
  have hcredit (i : d.StarIndex) (ha : edgeSum x (d.backGroup i.1) ≤ 1) :
      0 ≤ zeroQCredit d x Q i ∧ zeroQCredit d x Q i ≤ x (d.treeEdge i.1) :=
    actual_zero_Q_credit_bounds d hs x hx hn t ht owner ho Q hQ hr hb i ha
  have hk : ∀ b ∈ fixedZeroTerminalBacks d x, 0 ≤ k b := by
    intro b hbF
    have ha : edgeSum x (d.backGroup (ownBackStar d b).1) ≤ 1 :=
      fixedZeroTerminalBacks_zero d x b hbF
    exact (zeroGuardCapacity_bounds d x Q (ownBackStar d b) ha (hcredit _ ha).2).1
  obtain ⟨R, m, hR, hm, hout, hc, _, _, hsave, hloss⟩ := exists_zero_terminal_guards d hs x hx hn hcap
    owner ho Q hQ t ht hr hb (fixedZeroTerminalBacks d x)
    (fixedZeroTerminalBacks_headfree d x)
    (fun b hb c hc hne => fixedZeroTerminalBacks_distinct d x b c hb hc hne)
    (fixedZeroTerminalBacks_zero d x) k hk
  have hloss' (i : d.StarIndex) :
      edgeSum Q (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
        (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Q i else 0) := by
    have hh := hloss i
    dsimp only [k] at hh
    rwa [fixed_zero_guard_cap_sum] at hh
  refine ⟨R, fun i => m (fixedOwnBack d i), hR, hc, ?_, ?_, hloss', ?_, hout⟩
  · intro i hi
    have hbF : fixedOwnBack d i ∈ fixedZeroTerminalBacks d x := Finset.mem_image.mpr ⟨i, hi, rfl⟩
    have hh := hm _ hbF
    simpa only [fixedOwnBack_anchor, k, ownBackStar_fixed] using hh
  · have hsum : (∑ b ∈ fixedZeroTerminalBacks d x, m b) =
        ∑ i ∈ fixedZeroTerminalHeads d x, m (fixedOwnBack d i) :=
      Finset.sum_image (fun i _ j _ h => fixedOwnBack_injective d h)
    rwa [hsum] at hsave
  · intro i hi
    apply zero_guard_completed_Q_preserved d x t Q R hr hb i
      (zero_head_increase_eq_zero d x hx hn t ht i.1 hi) hi (hcredit i hi).2 (hc i)
    have hh := hloss' i
    by_cases hmem : i ∈ fixedZeroTerminalHeads d x
    · simpa only [if_pos hmem] using hh
    · rw [if_neg hmem, mul_zero] at hh
      have hk0 := (zeroGuardCapacity_bounds d x Q i hi (hcredit i hi).2).1
      linarith

end TSP.Improvements20261105
