import TSP.Improvements20261105.ExternalParentIntervals
import TSP.Chapter02.EdmondsJohnsonNecessary
import TSP.GraphCutWeights

/-! Explicit local probability space for an external-parent interval.
none is no pair; inl e is (e,A); inr e is (p,e). The virtual major item
A is implicit, so the selected original incidence set has size 0, 1 or 2. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Classical
open scoped BigOperators
variable {E : Type} [Fintype E] [DecidableEq E]

abbrev PairOutcome (E : Type) := Option (E ⊕ E)

noncomputable def externalPairSet (B : Finset E) (p : E) : PairOutcome E → Finset E
  | none => ∅
  | some (Sum.inl e) => if e ∈ B then {e} else ∅
  | some (Sum.inr e) => if e ∈ B.erase p then {p, e} else ∅

noncomputable def externalPairWeight (B : Finset E) (p : E) (alpha beta : E → ℝ)
    (incoming : ℝ) : PairOutcome E → ℝ
  | none => 1 - incoming - edgeSum alpha (B.erase p) - edgeSum beta (B.erase p)
  | some (Sum.inl e) => if e = p then incoming else if e ∈ B.erase p then alpha e else 0
  | some (Sum.inr e) => if e ∈ B.erase p then beta e else 0

theorem externalPairSet_subset (B : Finset E) (p : E) (hp : p ∈ B) (o : PairOutcome E) :
    externalPairSet B p o ⊆ B := by
  cases o with
  | none => exact Finset.empty_subset _
  | some o =>
    cases o with
    | inl e =>
      dsimp [externalPairSet]
      split_ifs with he
      · exact Finset.singleton_subset_iff.mpr he
      · exact Finset.empty_subset _
    | inr e =>
      dsimp [externalPairSet]
      split_ifs with he
      · exact Finset.insert_subset_iff.mpr ⟨hp, Finset.singleton_subset_iff.mpr (Finset.mem_erase.mp he).2⟩
      · exact Finset.empty_subset _

theorem externalPairSet_inter_card (B L : Finset E) (p : E) (hp : p ∉ L) (o : PairOutcome E) :
    (externalPairSet B p o ∩ L).card ≤ 1 := by
  cases o with
  | none => simp [externalPairSet]
  | some o =>
    cases o with
    | inl e =>
      dsimp [externalPairSet]
      split_ifs
      · exact (Finset.card_le_card Finset.inter_subset_left).trans (by simp)
      · simp
    | inr e =>
      dsimp [externalPairSet]
      split_ifs
      · have hsub : ({p, e} : Finset E) ∩ L ⊆ {e} := by
          intro f hf
          have hm := (Finset.mem_inter.mp hf)
          rcases Finset.mem_insert.mp hm.1 with rfl | he
          · exact (hp hm.2).elim
          · exact he
        exact (Finset.card_le_card hsub).trans (by simp)
      · simp

theorem externalPairWeight_single_sum (B : Finset E) (p : E) (alpha beta : E → ℝ) (a : ℝ) :
    (∑ e, externalPairWeight B p alpha beta a (some (Sum.inl e))) = a + edgeSum alpha (B.erase p) := by
  have hterm : ∀ e, externalPairWeight B p alpha beta a (some (Sum.inl e)) =
      (if e = p then a else 0) + (if e ∈ B.erase p then alpha e else 0) := by
    intro e
    by_cases he : e = p <;> simp [externalPairWeight, he]
  simp_rw [hterm]
  rw [Finset.sum_add_distrib, ← edgeSum_eq_indicator]
  simp

theorem externalPairWeight_sum (B : Finset E) (p : E) (alpha beta : E → ℝ) (a : ℝ) :
    ∑ o, externalPairWeight B p alpha beta a o = 1 := by
  rw [Fintype.sum_option, Fintype.sum_sum_type, externalPairWeight_single_sum]
  have ht : (∑ e, externalPairWeight B p alpha beta a (some (Sum.inr e))) = edgeSum beta (B.erase p) := by
    rw [edgeSum_eq_indicator]
    rfl
  rw [ht]
  dsimp [externalPairWeight]
  ring

theorem externalPairWeight_nonneg (B : Finset E) (p : E) (alpha beta : E → ℝ) (a : ℝ)
    (hab : ∀ e, 0 ≤ alpha e ∧ 0 ≤ beta e) (ha : 0 ≤ a)
    (htotal : a + edgeSum alpha (B.erase p) + edgeSum beta (B.erase p) ≤ 1) :
    ∀ o, 0 ≤ externalPairWeight B p alpha beta a o := by
  intro o
  cases o with
  | none => dsimp [externalPairWeight]; linarith
  | some o =>
    cases o with
    | inl e =>
      dsimp [externalPairWeight]
      split_ifs
      · exact ha
      · exact (hab e).1
      · exact le_rfl
    | inr e =>
      dsimp [externalPairWeight]
      split_ifs
      · exact (hab e).2
      · exact le_rfl

theorem externalPair_single_marginal (B : Finset E) (p : E) (hp : p ∈ B)
    (alpha beta : E → ℝ) (a : ℝ) (f : E) :
    (∑ e, externalPairWeight B p alpha beta a (some (Sum.inl e)) *
      incidence (externalPairSet B p (some (Sum.inl e))) f) =
      if f = p then a else if f ∈ B.erase p then alpha f else 0 := by
  rw [Finset.sum_eq_single f]
  · by_cases hf : f = p
    · subst f; simp [externalPairWeight, externalPairSet, incidence, hp]
    · by_cases hb : f ∈ B <;> simp [externalPairWeight, externalPairSet, incidence, hf, hb]
  · intro e _ hef
    by_cases he : e ∈ B <;> simp [externalPairSet, incidence, he, Ne.symm hef]
  · simp

theorem externalPair_transfer_marginal (B : Finset E) (p : E)
    (alpha beta : E → ℝ) (a : ℝ) (f : E) :
    (∑ e, externalPairWeight B p alpha beta a (some (Sum.inr e)) *
      incidence (externalPairSet B p (some (Sum.inr e))) f) =
      if f = p then edgeSum beta (B.erase p) else if f ∈ B.erase p then beta f else 0 := by
  by_cases hf : f = p
  · subst f
    rw [if_pos rfl, edgeSum_eq_indicator]
    apply Finset.sum_congr rfl
    intro e _
    by_cases he : e ∈ B.erase p <;> simp [externalPairWeight, externalPairSet, incidence, he]
  · rw [if_neg hf, Finset.sum_eq_single f]
    · by_cases hb : f ∈ B.erase p <;> simp [externalPairWeight, externalPairSet, incidence, hf, hb]
    · intro e _ hef
      by_cases he : e ∈ B.erase p <;> simp [externalPairSet, incidence, he, hf, Ne.symm hef]
    · simp

theorem externalPair_incidence_marginal (B : Finset E) (p : E) (hp : p ∈ B)
    (alpha beta : E → ℝ) (a : ℝ) (f : E) :
    (∑ o, externalPairWeight B p alpha beta a o * incidence (externalPairSet B p o) f) =
      if f = p then a + edgeSum beta (B.erase p)
      else if f ∈ B.erase p then alpha f + beta f else 0 := by
  rw [Fintype.sum_option, Fintype.sum_sum_type, externalPair_single_marginal B p hp,
    externalPair_transfer_marginal]
  simp only [externalPairSet, incidence, Finset.not_mem_empty, if_false, mul_zero, zero_add]
  split_ifs <;> ring

theorem externalPair_main_marginal (B : Finset E) (p : E) (hp : p ∈ B)
    (alpha beta : E → ℝ) (a : ℝ) :
    (∑ o, externalPairWeight B p alpha beta a o *
      (if Odd (externalPairSet B p o).card then 1 else 0)) = a + edgeSum alpha (B.erase p) := by
  rw [Fintype.sum_option, Fintype.sum_sum_type]
  have hs : ∀ e, externalPairWeight B p alpha beta a (some (Sum.inl e)) *
      (if Odd (externalPairSet B p (some (Sum.inl e))).card then 1 else 0) =
      externalPairWeight B p alpha beta a (some (Sum.inl e)) := by
    intro e
    by_cases he : e ∈ B
    · simp [externalPairSet, he]
    · have hep : e ≠ p := fun h => he (h ▸ hp)
      simp [externalPairSet, externalPairWeight, he, hep]
  have ht : ∀ e, externalPairWeight B p alpha beta a (some (Sum.inr e)) *
      (if Odd (externalPairSet B p (some (Sum.inr e))).card then 1 else 0) = 0 := by
    intro e
    by_cases he : e ∈ B.erase p
    · have hep := (Finset.mem_erase.mp he).1
      simp [externalPairSet, he, hep, Ne.symm hep]
    · simp [externalPairSet, he]
  simp_rw [hs, ht]
  simp only [externalPairSet, Finset.card_empty, Nat.not_odd_zero, if_false, mul_zero,
    Finset.sum_const_zero, zero_add, add_zero]
  exact externalPairWeight_single_sum B p alpha beta a

end TSP.Improvements20261105
