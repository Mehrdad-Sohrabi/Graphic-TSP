import TSP.Improvements20261105.ProtectedLeafPayment
import TSP.Improvements20261105.TerminalForcedConnectors
import TSP.Improvements20261105.TerminalProtectedLeafPayment
import TSP.Improvements20261105.GuardedPositiveDeficits
import TSP.Improvements20261105.EffectiveKOrigins

/-! The current protected-leaf payment uses the origin's own three-back
budget. This is the joint payment; it is not an isolated receiver claim. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_guarded_K_unmatched_group_bound (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415 / 2) (704 / 5)) (H : Finset d.tree.Child)
    (hH : H ⊆ C.matching.image (unaryNext d))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (Qbase : E ⊕ d.StarIndex → ℝ)
    (hrep : ∀ c, Qbase (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Qbase (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Qbase (starRepresentatives d.stars i)-edgeSum Y (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Qbase i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum Y (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (i j : d.StarIndex) (hv : d.centers j = (i.1 : V)) (hunary : childCount d i.1 = 1)
    (heff : coveredPIncrease d x (415 / 2) (704 / 5) C.cover i.1 <
      protectedCoverIncrease d x z (415 / 2) (704 / 5) 60 C i.1)
    (hthree : 3 ≤ (d.backGroup i.1).card)
    (hpos : 0 < survivingExcess d x j.1)
    (hu : j.1 ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hgreedy : ∀ e ∈ d.backGroup j.1, x e ≤ x (d.treeEdge j.1))
 :
    let A := generalPoint d owner rootStar x
      (terminalPIncrease d x (fixedPositiveTerminalChildren d x) (fun j => forcedCoverIncrease d x z (415 / 2) (704 / 5) 60 24 4 C H j.1))
    max (pqConnectorArm d x (415 / 2) (704 / 5) A Y i) (pqDeficitArm d x (415 / 2) (704 / 5) A Y i) +
      max (pqConnectorArm d x (415 / 2) (704 / 5) A Y j) (pqDeficitArm d x (415 / 2) (704 / 5) A Y j) + 24 ≤
      4 * ((d.backGroup i.1).card + (d.backGroup j.1).card : ℝ) +
      (415 / 2 : ℝ) * (fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 +
        fixedProjectionCharge d x (allFullOverrideTargets d x) j.1) := by
  have hT : ∀ a ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d a := by
    intro c hc
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hc
    exact (Finset.mem_filter.mp hj).2.1
  have hp : ProtectedHead d x z (415/2) (704/5) C i.1 := by
    by_contra h
    simp [protectedCoverIncrease, h] at heff
  have hai : 1 < edgeSum x (d.backGroup i.1) := by
    have hh := (lt_max_iff.mp hp.2.1).resolve_right (lt_irrefl _)
    have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent i.1)
    linarith
  have haj : 1 < edgeSum x (d.backGroup j.1) := by
    have hh := (lt_max_iff.mp hpos).resolve_right (lt_irrefl _)
    have hxi := degreeExcess_nonnegative G hx hn (d.tree.parent j.1)
    linarith
  exact current_terminal_K_unmatched_group_bound d hs x z hx hn hcap hm C H hH
    (fixedPositiveTerminalChildren d x) hT owner ho rootStar hroot Y hY i j hv hunary heff hthree hpos hu hgreedy
    (guarded_positive_Q_deficit d x Qbase Y hrep hbacks hloss hterminal i hai)
    (guarded_positive_Q_deficit d x Qbase Y hrep hbacks hloss hterminal j haj)

end TSP.Improvements20261105
