import TSP.Improvements20261105.GreedySourceUniform104
import TSP.Improvements20261105.ScoredUniformNetLoad

/-! A uniform analytic source tail. Counts at least25 need no finite
source table and no good/bad label assumption. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_greedy_source_uniform_uncouponed
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s)=edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hsc : ¬ScoredStar d x s) (hpositive : 1 < edgeSum z ((d).backGroup s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      24*survivingExcess d x s+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s+24*δ ≤ 104 := by
  have hcapz (e : E) (he : e ∈ (d).backGroup s) : z e ≤ x ((d).treeEdge s) :=
    (hzx e).trans (scoredDFS_not_scored_greedy G x hs hc root s hsc e he)
  have hI := refined_fixed_incidence_le_noncritical d x z eligible T s
  have hIall (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
      (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20)
      (hU : x ((d).treeEdge s) ≤ U) :=
    hI.trans (noncritical_uniform_linear_envelope d z s U A B hA hAd hAU hB hBd hBU
      (fun e _ => hz e) (fun e he => (hcapz e he).trans hU))
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have hp := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hgap := hδ.trans (min_le_left _ _)
  have hh := greedy_source_uniform_104 (x ((d).treeEdge s)) (edgeSum z ((d).backGroup s))
    (refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s) δ
    (hx.1 _) (hcap _) hpositive.le (by linarith only [hp]) hδ0
    (hδ.trans (min_le_right _ _)) (by linarith only [hgap,he]) hIall
  have ho0 : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  linarith only [hh,ho0,he]

theorem scoredDFS_greedy_source_mid_uncouponed
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s)=edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hsc : ¬ScoredStar d x s) (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hcount : ((d).backGroup s).card ≤ 24) (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      24*survivingExcess d x s+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s+24*δ ≤ 84 := by
  have hcapz (e : E) (he : e ∈ (d).backGroup s) : z e ≤ x ((d).treeEdge s) :=
    (hzx e).trans (scoredDFS_not_scored_greedy G x hs hc root s hsc e he)
  have hI := refined_fixed_incidence_le_noncritical d x z eligible T s
  have hIall (U A B : ℝ) (hA : 0 ≤ A) (hAd : 0 ≤ 2-A) (hAU : (2-A)*U ≤ 1/2)
      (hB : 0 ≤ B) (hBd : 0 ≤ 19/10-B) (hBU : (19/10-B)*U ≤ 9/20)
      (hU : x ((d).treeEdge s) ≤ U) :=
    hI.trans (noncritical_uniform_linear_envelope d z s U A B hA hAd hAU hB hBd hBU
      (fun e _ => hz e) (fun e he => (hcapz e he).trans hU))
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have hp := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hgap := hδ.trans (min_le_left _ _)
  have hcountMass : edgeSum z ((d).backGroup s) ≤ 24*x ((d).treeEdge s) := by
    have hh := Finset.sum_le_sum (s := (d).backGroup s) hcapz
    simp only [Finset.sum_const,nsmul_eq_mul] at hh
    have hnR : (((d).backGroup s).card : ℝ) ≤ 24 := by exact_mod_cast hcount
    have hmR := mul_le_mul_of_nonneg_right hnR (hx.1 ((d).treeEdge s))
    exact hh.trans hmR
  have hh := greedy_source_uniform_84 (x ((d).treeEdge s)) (edgeSum z ((d).backGroup s))
    (refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s) δ
    (hx.1 _) (hcap _) hpositive.le (by linarith only [hp]) hcountMass hδ0
    (hδ.trans (min_le_right _ _)) (by linarith only [hgap,he]) hIall
  have ho0 : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  linarith only [hh,ho0,he]

theorem scoredDFS_large_greedy_source_load_uncouponed
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s)=edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hsc : ¬ScoredStar d x s) (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hcount : 20 ≤ ((d).backGroup s).card)
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      24*survivingExcess d x s+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1) := by
  by_cases hn24 : ((d).backGroup s).card ≤ 24
  · have hh := scoredDFS_greedy_source_mid_uncouponed G x z hs hc root hx hn hcap hz hzx hm
      eligible T s hsc hpositive hn24 δ hδ0 hδ
    have hR : (20 : ℝ) ≤ (((d).backGroup s).card : ℝ) := by exact_mod_cast hcount
    linarith only [hh,hR]
  · have hh := scoredDFS_greedy_source_uniform_uncouponed G x z hs hc root hx hn hcap hz hzx hm
      eligible T s hsc hpositive δ hδ0 hδ
    have hR : (25 : ℝ) ≤ (((d).backGroup s).card : ℝ) := by exact_mod_cast (show 25 ≤ ((d).backGroup s).card by omega)
    linarith only [hh,hR]

end TSP.Improvements20261105
