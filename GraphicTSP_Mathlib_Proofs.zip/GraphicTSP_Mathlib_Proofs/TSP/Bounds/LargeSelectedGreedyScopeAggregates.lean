import TSP.Improvements20261105.LargeSelectedGreedyT6R3CapCells00
import TSP.Improvements20261105.LargeSelectedGreedyT6R3CapCells01
import TSP.Improvements20261105.LargeSelectedGreedyT6R3CapCells02
import TSP.Improvements20261105.LargeSelectedGreedyT6R3CapCells03
import TSP.Improvements20261105.LargeSelectedGreedyT6R3CapCells04
import TSP.Improvements20261105.UniformRampLinearEnvelope
import TSP.Improvements20261105.LargeSelectedGreedyBundle00
import TSP.Improvements20261105.LargeSelectedGreedyBundle01
import TSP.Improvements20261105.LargeSelectedGreedyBundle02
import TSP.Improvements20261105.LargeSelectedGreedyBundle03
import TSP.Improvements20261105.LargeSelectedGreedyBundle04
import TSP.Improvements20261105.LargeSelectedGreedyBundle05
import TSP.Improvements20261105.LargeSelectedGreedyBundle06
import TSP.Improvements20261105.LargeSelectedGreedyBundle07
import TSP.Improvements20261105.LargeSelectedGreedyBundle08
import TSP.Improvements20261105.LargeSelectedGreedyBundle09
import TSP.Improvements20261105.LargeSelectedGreedyBundle10
import TSP.Improvements20261105.LargeSelectedGreedyBundle11
import TSP.Improvements20261105.LargeSelectedGreedyBundle12
import TSP.Improvements20261105.LargeSelectedGreedyBundle13
import TSP.Improvements20261105.LargeSelectedGreedyBundle14
import TSP.Improvements20261105.LargeSelectedGreedyBundle15
import TSP.Improvements20261105.LargeSelectedGreedyBundle16
import TSP.Improvements20261105.LargeSelectedGreedyBundle17
import TSP.Improvements20261105.LargeSelectedGreedyBundle18
import TSP.Improvements20261105.LargeSelectedGreedyBundle19
import TSP.Improvements20261105.LargeSelectedGreedyBundle20
import TSP.Improvements20261105.LargeSelectedGreedyBundle21
import TSP.Improvements20261105.LargeSelectedGreedyBundle22
import TSP.Improvements20261105.LargeSelectedGreedyBundle23
import TSP.Improvements20261105.LargeSelectedGreedyBundle24
import TSP.Improvements20261105.LargeSelectedGreedyBundle25
import TSP.Improvements20261105.LargeSelectedGreedyBundle26
import TSP.Improvements20261105.LargeSelectedGreedyBundle27
import TSP.Improvements20261105.LargeSelectedGreedyBundle28
import TSP.Improvements20261105.LargeSelectedGreedyBundle29
import TSP.Improvements20261105.LargeSelectedGreedyBundle30
import TSP.Improvements20261105.LargeSelectedGreedyBundle31
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t6_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(3/1 : ℝ))*q ≤ 0)
    (hq0 : (1/6 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 36 := by
  have hql : (1/6 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (5/6 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/12 : ℝ)
      · have hqu : q ≤ (5/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t6_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            by_cases hsplit : q ≤ (17/48 : ℝ)
            · have hqu : q ≤ (17/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (17/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (17/48 : ℝ)
            · have hqu : q ≤ (17/48 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (59/192 : ℝ)
                    · have hqu : q ≤ (59/192 : ℝ) := hsplit
                      exact large_selected_greedy_t6_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (59/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (17/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                exact large_selected_greedy_t6_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (5/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (5/12 : ℝ)
    · have hqu : q ≤ (5/12 : ℝ) := hsplit
      by_cases hsplit : z ≤ (2/3 : ℝ)
      · have hzu : z ≤ (2/3 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t6_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (7/12 : ℝ)
          · have hzu : z ≤ (7/12 : ℝ) := hsplit
            exact large_selected_greedy_t6_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (7/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    · have hql : (5/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t6_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t6_r3_cap_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/6 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 38 := by
  have hql : (1/6 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (5/6 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r3_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r3_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/12 : ℝ)
      · have hqu : q ≤ (5/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t6_r3_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (11/48 : ℝ)
            · have hqu : q ≤ (11/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r3_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (11/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (25/96 : ℝ)
                · have hqu : q ≤ (25/96 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r3_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (25/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (53/192 : ℝ)
                    · have hqu : q ≤ (53/192 : ℝ) := hsplit
                      exact large_selected_greedy_t6_r3_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (53/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r3_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (53/192 : ℝ)
                    · have hqu : q ≤ (53/192 : ℝ) := hsplit
                      exact large_selected_greedy_t6_r3_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (53/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r3_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r3_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            by_cases hsplit : q ≤ (17/48 : ℝ)
            · have hqu : q ≤ (17/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r3_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (17/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r3_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (17/48 : ℝ)
            · have hqu : q ≤ (17/48 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (59/192 : ℝ)
                    · have hqu : q ≤ (59/192 : ℝ) := hsplit
                      exact large_selected_greedy_t6_r3_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (59/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r3_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r3_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r3_cap_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r3_cap_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r3_cap_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (17/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r3_cap_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (5/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r3_cap_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (5/12 : ℝ)
    · have hqu : q ≤ (5/12 : ℝ) := hsplit
      by_cases hsplit : z ≤ (2/3 : ℝ)
      · have hzu : z ≤ (2/3 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t6_r3_cap_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (7/12 : ℝ)
          · have hzu : z ≤ (7/12 : ℝ) := hsplit
            exact large_selected_greedy_t6_r3_cap_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (7/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r3_cap_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r3_cap_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    · have hql : (5/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t6_r3_cap_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t6_r4_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+(1-(3/1 : ℝ))*q ≤ 0)
    (hq0 : (1/6 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hql : (1/6 : ℝ) ≤ q := hq0
  have hqu : q ≤ (3/4 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/4 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (5/6 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r4_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/24 : ℝ)
      · have hqu : q ≤ (11/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          exact large_selected_greedy_t6_r4_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (37/96 : ℝ)
            · have hqu : q ≤ (37/96 : ℝ) := hsplit
              exact large_selected_greedy_t6_r4_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (37/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r4_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r4_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (11/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r4_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r4_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/24 : ℝ)
      · have hqu : q ≤ (11/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/96 : ℝ)
            · have hqu : q ≤ (23/96 : ℝ) := hsplit
              exact large_selected_greedy_t6_r4_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (23/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r4_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/96 : ℝ)
            · have hqu : q ≤ (23/96 : ℝ) := hsplit
              exact large_selected_greedy_t6_r4_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (23/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r4_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (37/96 : ℝ)
            · have hqu : q ≤ (37/96 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (67/192 : ℝ)
                · have hqu : q ≤ (67/192 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r4_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (67/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r4_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (67/192 : ℝ)
                · have hqu : q ≤ (67/192 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r4_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r4_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (67/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r4_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (37/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r4_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (37/96 : ℝ)
            · have hqu : q ≤ (37/96 : ℝ) := hsplit
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (67/192 : ℝ)
                · have hqu : q ≤ (67/192 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r4_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r4_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (67/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r4_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (37/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r4_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (11/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r4_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (11/24 : ℝ)
    · have hqu : q ≤ (11/24 : ℝ) := hsplit
      by_cases hsplit : z ≤ (2/3 : ℝ)
      · have hzu : z ≤ (2/3 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          exact large_selected_greedy_t6_r4_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t6_r4_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r4_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    · have hql : (11/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t6_r4_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t6_r4_cap_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hq0 : (1/6 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 42 := by
  have hql : (1/6 : ℝ) ≤ q := hq0
  have hqu : q ≤ (3/4 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/4 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (5/6 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r4_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/24 : ℝ)
      · have hqu : q ≤ (11/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          exact large_selected_greedy_t6_r4_cap_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (37/96 : ℝ)
            · have hqu : q ≤ (37/96 : ℝ) := hsplit
              exact large_selected_greedy_t6_r4_cap_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (37/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r4_cap_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r4_cap_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (11/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r4_cap_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r4_cap_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r4_cap_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/24 : ℝ)
      · have hqu : q ≤ (11/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/96 : ℝ)
            · have hqu : q ≤ (23/96 : ℝ) := hsplit
              exact large_selected_greedy_t6_r4_cap_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (23/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (53/192 : ℝ)
                · have hqu : q ≤ (53/192 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r4_cap_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (53/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (113/384 : ℝ)
                    · have hqu : q ≤ (113/384 : ℝ) := hsplit
                      exact large_selected_greedy_t6_r4_cap_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r4_cap_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (113/384 : ℝ)
                    · have hqu : q ≤ (113/384 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (229/640 : ℝ)
                      · have hzu : z ≤ (229/640 : ℝ) := hsplit
                        exact large_selected_greedy_t6_r4_cap_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (229/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t6_r4_cap_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r4_cap_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (53/192 : ℝ)
                · have hqu : q ≤ (53/192 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r4_cap_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (53/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (113/384 : ℝ)
                    · have hqu : q ≤ (113/384 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (243/640 : ℝ)
                      · have hzu : z ≤ (243/640 : ℝ) := hsplit
                        exact large_selected_greedy_t6_r4_cap_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (243/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t6_r4_cap_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r4_cap_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (113/384 : ℝ)
                    · have hqu : q ≤ (113/384 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (257/640 : ℝ)
                      · have hzu : z ≤ (257/640 : ℝ) := hsplit
                        exact large_selected_greedy_t6_r4_cap_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (257/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t6_r4_cap_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r4_cap_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/96 : ℝ)
            · have hqu : q ≤ (23/96 : ℝ) := hsplit
              exact large_selected_greedy_t6_r4_cap_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (23/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (53/192 : ℝ)
                · have hqu : q ≤ (53/192 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r4_cap_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r4_cap_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (53/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (113/384 : ℝ)
                    · have hqu : q ≤ (113/384 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (271/640 : ℝ)
                      · have hzu : z ≤ (271/640 : ℝ) := hsplit
                        exact large_selected_greedy_t6_r4_cap_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (271/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t6_r4_cap_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r4_cap_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r4_cap_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (37/96 : ℝ)
            · have hqu : q ≤ (37/96 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (67/192 : ℝ)
                · have hqu : q ≤ (67/192 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r4_cap_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (67/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r4_cap_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (67/192 : ℝ)
                · have hqu : q ≤ (67/192 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r4_cap_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (67/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r4_cap_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (37/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r4_cap_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (37/96 : ℝ)
            · have hqu : q ≤ (37/96 : ℝ) := hsplit
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (67/192 : ℝ)
                · have hqu : q ≤ (67/192 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r4_cap_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (67/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r4_cap_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r4_cap_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (37/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r4_cap_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (11/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r4_cap_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (11/24 : ℝ)
    · have hqu : q ≤ (11/24 : ℝ) := hsplit
      by_cases hsplit : z ≤ (2/3 : ℝ)
      · have hzu : z ≤ (2/3 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          exact large_selected_greedy_t6_r4_cap_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t6_r4_cap_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r4_cap_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    · have hql : (11/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t6_r4_cap_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t6_r5_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 28)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(3/1 : ℝ))*q ≤ 0)
    (hq0 : (1/6 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hql : (1/6 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (5/6 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r5_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r5_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r5_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          exact large_selected_greedy_t6_r5_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/48 : ℝ)
            · have hqu : q ≤ (23/48 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r5_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          exact large_selected_greedy_t6_r5_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (23/48 : ℝ)
          · have hqu : q ≤ (23/48 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r5_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r5_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (13/48 : ℝ)
            · have hqu : q ≤ (13/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (13/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r5_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r5_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/48 : ℝ)
            · have hqu : q ≤ (13/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (13/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r5_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  exact large_selected_greedy_t6_r5_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r5_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/48 : ℝ)
            · have hqu : q ≤ (23/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          by_cases hsplit : q ≤ (13/48 : ℝ)
          · have hqu : q ≤ (13/48 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (13/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (31/96 : ℝ)
              · have hqu : q ≤ (31/96 : ℝ) := hsplit
                exact large_selected_greedy_t6_r5_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (31/96 : ℝ)
              · have hqu : q ≤ (31/96 : ℝ) := hsplit
                exact large_selected_greedy_t6_r5_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (23/48 : ℝ)
          · have hqu : q ≤ (23/48 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r5_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (7/12 : ℝ)
    · have hqu : q ≤ (7/12 : ℝ) := hsplit
      by_cases hsplit : q ≤ (3/8 : ℝ)
      · have hqu : q ≤ (3/8 : ℝ) := hsplit
        exact large_selected_greedy_t6_r5_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t6_r5_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t6_r5_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 6*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 30)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/6 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (79/350 : ℝ) ∨ (407/1000 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hql : (1/6 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (5/6 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t6_r5_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t6_r5_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r5_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          exact large_selected_greedy_t6_r5_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/48 : ℝ)
            · have hqu : q ≤ (23/48 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r5_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          exact large_selected_greedy_t6_r5_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (23/48 : ℝ)
          · have hqu : q ≤ (23/48 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r5_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t6_r5_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (13/48 : ℝ)
            · have hqu : q ≤ (13/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (13/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (13/320 : ℝ)
                  · have hzu : z ≤ (13/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (19/64 : ℝ)
                    · have hqu : q ≤ (19/64 : ℝ) := hsplit
                      exact large_selected_greedy_t6_r5_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t6_r5_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (13/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r5_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r5_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/48 : ℝ)
            · have hqu : q ≤ (13/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (13/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t6_r5_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/96 : ℝ)
                · have hqu : q ≤ (31/96 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r5_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r5_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r5_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/48 : ℝ)
            · have hqu : q ≤ (23/48 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/12 : ℝ)
      · have hqu : q ≤ (7/12 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/8 : ℝ)
        · have hqu : q ≤ (3/8 : ℝ) := hsplit
          by_cases hsplit : q ≤ (13/48 : ℝ)
          · have hqu : q ≤ (13/48 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t6_r5_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t6_r5_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (13/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (31/96 : ℝ)
              · have hqu : q ≤ (31/96 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (19/64 : ℝ)
                  · have hqu : q ≤ (19/64 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r5_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r5_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (19/64 : ℝ)
                  · have hqu : q ≤ (19/64 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r5_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r5_all_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (31/96 : ℝ)
              · have hqu : q ≤ (31/96 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (19/64 : ℝ)
                  · have hqu : q ≤ (19/64 : ℝ) := hsplit
                    exact large_selected_greedy_t6_r5_all_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t6_r5_all_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t6_r5_all_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (31/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t6_r5_all_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (23/48 : ℝ)
          · have hqu : q ≤ (23/48 : ℝ) := hsplit
            exact large_selected_greedy_t6_r5_all_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (23/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t6_r5_all_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (7/12 : ℝ)
    · have hqu : q ≤ (7/12 : ℝ) := hsplit
      by_cases hsplit : q ≤ (3/8 : ℝ)
      · have hqu : q ≤ (3/8 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          exact large_selected_greedy_t6_r5_all_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t6_r5_all_cell_83 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t6_r5_all_cell_84 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    · have hql : (7/12 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t6_r5_all_cell_85 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/7 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (19/100 : ℝ) ∨ (46/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 40 := by
  have hql : (1/7 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (6/7 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t7_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t7_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/42 : ℝ)
      · have hqu : q ≤ (17/42 : ℝ) := hsplit
        exact large_selected_greedy_t7_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (17/42 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t7_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/42 : ℝ)
      · have hqu : q ≤ (17/42 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/84 : ℝ)
        · have hqu : q ≤ (23/84 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t7_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (5/24 : ℝ)
            · have hqu : q ≤ (5/24 : ℝ) := hsplit
              exact large_selected_greedy_t7_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (5/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (27/112 : ℝ)
                · have hqu : q ≤ (27/112 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (27/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (173/672 : ℝ)
                    · have hqu : q ≤ (173/672 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (173/672 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (173/672 : ℝ)
                    · have hqu : q ≤ (173/672 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (43/96 : ℝ)
                      · have hzu : z ≤ (43/96 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (335/1344 : ℝ)
                        · have hqu : q ≤ (335/1344 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (335/1344 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (43/96 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t7_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (173/672 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (43/96 : ℝ)
                      · have hzu : z ≤ (43/96 : ℝ) := hsplit
                        exact large_selected_greedy_t7_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (43/96 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t7_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (27/112 : ℝ)
                · have hqu : q ≤ (27/112 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (27/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (23/48 : ℝ)
                  · have hzu : z ≤ (23/48 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (173/672 : ℝ)
                    · have hqu : q ≤ (173/672 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (173/672 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (23/48 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (23/84 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t7_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (19/56 : ℝ)
            · have hqu : q ≤ (19/56 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (103/336 : ℝ)
                · have hqu : q ≤ (103/336 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (65/224 : ℝ)
                    · have hqu : q ≤ (65/224 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (65/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r3_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (65/224 : ℝ)
                    · have hqu : q ≤ (65/224 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r3_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (65/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r3_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (103/336 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r3_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (103/336 : ℝ)
                · have hqu : q ≤ (103/336 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r3_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (103/336 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r3_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (19/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                exact large_selected_greedy_t7_r3_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r3_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (17/42 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r3_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/42 : ℝ)
      · have hqu : q ≤ (17/42 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (23/84 : ℝ)
          · have hqu : q ≤ (23/84 : ℝ) := hsplit
            exact large_selected_greedy_t7_r3_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (23/84 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (7/12 : ℝ)
            · have hzu : z ≤ (7/12 : ℝ) := hsplit
              exact large_selected_greedy_t7_r3_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hzl : (7/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r3_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t7_r3_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (17/42 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r3_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r3_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r4_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hq0 : (1/7 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (19/100 : ℝ) ∨ (46/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hql : (1/7 : ℝ) ≤ q := hq0
  have hqu : q ≤ (3/4 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/4 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (6/7 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t7_r4_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t7_r4_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t7_r4_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r4_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t7_r4_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/56 : ℝ)
      · have hqu : q ≤ (25/56 : ℝ) := hsplit
        by_cases hsplit : q ≤ (33/112 : ℝ)
        · have hqu : q ≤ (33/112 : ℝ) := hsplit
          exact large_selected_greedy_t7_r4_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (33/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (83/224 : ℝ)
            · have hqu : q ≤ (83/224 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (149/448 : ℝ)
                · have hqu : q ≤ (149/448 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r4_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (149/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r4_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r4_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r4_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (83/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (183/448 : ℝ)
                · have hqu : q ≤ (183/448 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r4_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r4_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (183/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r4_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (183/448 : ℝ)
                · have hqu : q ≤ (183/448 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r4_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (183/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r4_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t7_r4_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (25/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r4_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t7_r4_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r4_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t7_r4_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/56 : ℝ)
      · have hqu : q ≤ (25/56 : ℝ) := hsplit
        by_cases hsplit : q ≤ (33/112 : ℝ)
        · have hqu : q ≤ (33/112 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (7/32 : ℝ)
            · have hqu : q ≤ (7/32 : ℝ) := hsplit
              exact large_selected_greedy_t7_r4_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (7/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (115/448 : ℝ)
                · have hqu : q ≤ (115/448 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r4_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (213/896 : ℝ)
                    · have hqu : q ≤ (213/896 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r4_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (213/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (229/640 : ℝ)
                      · have hzu : z ≤ (229/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (229/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (115/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r4_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (247/896 : ℝ)
                    · have hqu : q ≤ (247/896 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (229/640 : ℝ)
                      · have hzu : z ≤ (229/640 : ℝ) := hsplit
                        exact large_selected_greedy_t7_r4_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (229/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        by_cases hsplit : q ≤ (477/1792 : ℝ)
                        · have hqu : q ≤ (477/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (477/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (247/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r4_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (115/448 : ℝ)
                · have hqu : q ≤ (115/448 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (213/896 : ℝ)
                    · have hqu : q ≤ (213/896 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r4_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (213/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (243/640 : ℝ)
                      · have hzu : z ≤ (243/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (243/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (213/896 : ℝ)
                    · have hqu : q ≤ (213/896 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r4_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (213/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (257/640 : ℝ)
                      · have hzu : z ≤ (257/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (257/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (115/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (247/896 : ℝ)
                    · have hqu : q ≤ (247/896 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (243/640 : ℝ)
                      · have hzu : z ≤ (243/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (477/1792 : ℝ)
                        · have hqu : q ≤ (477/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (477/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (243/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        by_cases hsplit : q ≤ (477/1792 : ℝ)
                        · have hqu : q ≤ (477/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (477/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (247/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r4_cap_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (247/896 : ℝ)
                    · have hqu : q ≤ (247/896 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (257/640 : ℝ)
                      · have hzu : z ≤ (257/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (477/1792 : ℝ)
                        · have hqu : q ≤ (477/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (477/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (257/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        by_cases hsplit : q ≤ (477/1792 : ℝ)
                        · have hqu : q ≤ (477/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (477/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (247/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r4_cap_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (7/32 : ℝ)
            · have hqu : q ≤ (7/32 : ℝ) := hsplit
              exact large_selected_greedy_t7_r4_cap_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (7/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (115/448 : ℝ)
                · have hqu : q ≤ (115/448 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (213/896 : ℝ)
                    · have hqu : q ≤ (213/896 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r4_cap_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (213/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (271/640 : ℝ)
                      · have hzu : z ≤ (271/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (443/1792 : ℝ)
                        · have hqu : q ≤ (443/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (443/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (271/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t7_r4_cap_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r4_cap_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (115/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (247/896 : ℝ)
                    · have hqu : q ≤ (247/896 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (271/640 : ℝ)
                      · have hzu : z ≤ (271/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (477/1792 : ℝ)
                        · have hqu : q ≤ (477/1792 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r4_cap_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (477/1792 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r4_cap_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (271/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t7_r4_cap_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (247/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r4_cap_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (247/896 : ℝ)
                    · have hqu : q ≤ (247/896 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r4_cap_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (247/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r4_cap_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (115/448 : ℝ)
                · have hqu : q ≤ (115/448 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r4_cap_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (115/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r4_cap_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (33/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (83/224 : ℝ)
            · have hqu : q ≤ (83/224 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (149/448 : ℝ)
                · have hqu : q ≤ (149/448 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r4_cap_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (149/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r4_cap_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (149/448 : ℝ)
                · have hqu : q ≤ (149/448 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r4_cap_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r4_cap_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (149/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r4_cap_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (83/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r4_cap_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (83/224 : ℝ)
            · have hqu : q ≤ (83/224 : ℝ) := hsplit
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (149/448 : ℝ)
                · have hqu : q ≤ (149/448 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r4_cap_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r4_cap_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (149/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r4_cap_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r4_cap_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (83/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r4_cap_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (25/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r4_cap_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/56 : ℝ)
      · have hqu : q ≤ (25/56 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (33/112 : ℝ)
          · have hqu : q ≤ (33/112 : ℝ) := hsplit
            exact large_selected_greedy_t7_r4_cap_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (33/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t7_r4_cap_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t7_r4_cap_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (25/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r4_cap_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r4_cap_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t7_r5_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 7*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 32)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/7 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (19/100 : ℝ) ∨ (46/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hql : (1/7 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (6/7 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t7_r5_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t7_r5_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t7_r5_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r5_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (4/7 : ℝ)
      · have hqu : q ≤ (4/7 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/14 : ℝ)
        · have hqu : q ≤ (5/14 : ℝ) := hsplit
          exact large_selected_greedy_t7_r5_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/14 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t7_r5_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/28 : ℝ)
            · have hqu : q ≤ (13/28 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t7_r5_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r5_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (13/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r5_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (4/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r5_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (4/7 : ℝ)
      · have hqu : q ≤ (4/7 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/14 : ℝ)
        · have hqu : q ≤ (5/14 : ℝ) := hsplit
          exact large_selected_greedy_t7_r5_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/14 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (13/28 : ℝ)
          · have hqu : q ≤ (13/28 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t7_r5_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r5_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (13/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t7_r5_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (4/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r5_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t7_r5_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r5_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (4/7 : ℝ)
      · have hqu : q ≤ (4/7 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/14 : ℝ)
        · have hqu : q ≤ (5/14 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (1/4 : ℝ)
            · have hqu : q ≤ (1/4 : ℝ) := hsplit
              exact large_selected_greedy_t7_r5_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (1/4 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (17/56 : ℝ)
                · have hqu : q ≤ (17/56 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (13/320 : ℝ)
                  · have hzu : z ≤ (13/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (31/112 : ℝ)
                    · have hqu : q ≤ (31/112 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (13/640 : ℝ)
                      · have hzu : z ≤ (13/640 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (59/224 : ℝ)
                        · have hqu : q ≤ (59/224 : ℝ) := hsplit
                          exact large_selected_greedy_t7_r5_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                        · have hql : (59/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t7_r5_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                      · have hzl : (13/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t7_r5_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hql : (31/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r5_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (13/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r5_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r5_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r5_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (1/4 : ℝ)
            · have hqu : q ≤ (1/4 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t7_r5_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r5_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (1/4 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t7_r5_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (17/56 : ℝ)
                · have hqu : q ≤ (17/56 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t7_r5_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (31/112 : ℝ)
                    · have hqu : q ≤ (31/112 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r5_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hql : (31/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r5_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r5_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/14 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t7_r5_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/28 : ℝ)
            · have hqu : q ≤ (13/28 : ℝ) := hsplit
              exact large_selected_greedy_t7_r5_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (13/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r5_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (4/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r5_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (4/7 : ℝ)
      · have hqu : q ≤ (4/7 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/14 : ℝ)
        · have hqu : q ≤ (5/14 : ℝ) := hsplit
          by_cases hsplit : q ≤ (1/4 : ℝ)
          · have hqu : q ≤ (1/4 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (11/56 : ℝ)
              · have hqu : q ≤ (11/56 : ℝ) := hsplit
                exact large_selected_greedy_t7_r5_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (11/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r5_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r5_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (11/56 : ℝ)
              · have hqu : q ≤ (11/56 : ℝ) := hsplit
                exact large_selected_greedy_t7_r5_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (11/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t7_r5_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r5_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (1/4 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (17/56 : ℝ)
              · have hqu : q ≤ (17/56 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (31/112 : ℝ)
                  · have hqu : q ≤ (31/112 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (111/320 : ℝ)
                    · have hzu : z ≤ (111/320 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r5_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r5_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (31/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r5_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (31/112 : ℝ)
                  · have hqu : q ≤ (31/112 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (25/64 : ℝ)
                    · have hzu : z ≤ (25/64 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r5_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r5_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (31/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r5_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r5_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (17/56 : ℝ)
              · have hqu : q ≤ (17/56 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (31/112 : ℝ)
                  · have hqu : q ≤ (31/112 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (139/320 : ℝ)
                    · have hzu : z ≤ (139/320 : ℝ) := hsplit
                      exact large_selected_greedy_t7_r5_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t7_r5_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (31/112 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t7_r5_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t7_r5_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t7_r5_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/14 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (13/28 : ℝ)
          · have hqu : q ≤ (13/28 : ℝ) := hsplit
            exact large_selected_greedy_t7_r5_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (13/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t7_r5_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (4/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r5_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (4/7 : ℝ)
      · have hqu : q ≤ (4/7 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/14 : ℝ)
        · have hqu : q ≤ (5/14 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (1/4 : ℝ)
            · have hqu : q ≤ (1/4 : ℝ) := hsplit
              exact large_selected_greedy_t7_r5_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (1/4 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t7_r5_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t7_r5_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/14 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t7_r5_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (4/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t7_r5_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t7_r5_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hq0 : (1/8 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 44 := by
  have hql : (1/8 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (7/8 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t8_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/48 : ℝ)
      · have hqu : q ≤ (19/48 : ℝ) := hsplit
        exact large_selected_greedy_t8_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (19/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/48 : ℝ)
      · have hqu : q ≤ (19/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/96 : ℝ)
        · have hqu : q ≤ (25/96 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t8_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (37/192 : ℝ)
            · have hqu : q ≤ (37/192 : ℝ) := hsplit
              exact large_selected_greedy_t8_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (37/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (29/128 : ℝ)
                · have hqu : q ≤ (29/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (29/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (187/768 : ℝ)
                    · have hqu : q ≤ (187/768 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (187/768 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (25/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t8_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (21/64 : ℝ)
            · have hqu : q ≤ (21/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (113/384 : ℝ)
                · have hqu : q ≤ (113/384 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (113/384 : ℝ)
                · have hqu : q ≤ (113/384 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (21/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (19/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/48 : ℝ)
      · have hqu : q ≤ (19/48 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (25/96 : ℝ)
          · have hqu : q ≤ (25/96 : ℝ) := hsplit
            exact large_selected_greedy_t8_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hql : (25/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (7/12 : ℝ)
            · have hzu : z ≤ (7/12 : ℝ) := hsplit
              exact large_selected_greedy_t8_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hzl : (7/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r3_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t8_r3_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (19/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r3_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r3_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t8_r3_cap_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/8 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 46 := by
  have hql : (1/8 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (7/8 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t8_r3_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r3_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r3_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/48 : ℝ)
      · have hqu : q ≤ (19/48 : ℝ) := hsplit
        exact large_selected_greedy_t8_r3_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (19/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r3_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r3_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r3_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/48 : ℝ)
      · have hqu : q ≤ (19/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/96 : ℝ)
        · have hqu : q ≤ (25/96 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t8_r3_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (37/192 : ℝ)
            · have hqu : q ≤ (37/192 : ℝ) := hsplit
              exact large_selected_greedy_t8_r3_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (37/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (29/128 : ℝ)
                · have hqu : q ≤ (29/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r3_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (29/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r3_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (29/128 : ℝ)
                · have hqu : q ≤ (29/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r3_cap_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (29/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r3_cap_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (25/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t8_r3_cap_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (21/64 : ℝ)
            · have hqu : q ≤ (21/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (113/384 : ℝ)
                · have hqu : q ≤ (113/384 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r3_cap_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (113/384 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r3_cap_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r3_cap_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (21/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r3_cap_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (19/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r3_cap_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/48 : ℝ)
      · have hqu : q ≤ (19/48 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (25/96 : ℝ)
          · have hqu : q ≤ (25/96 : ℝ) := hsplit
            exact large_selected_greedy_t8_r3_cap_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (25/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (7/12 : ℝ)
            · have hzu : z ≤ (7/12 : ℝ) := hsplit
              exact large_selected_greedy_t8_r3_cap_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hzl : (7/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r3_cap_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t8_r3_cap_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (19/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r3_cap_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r3_cap_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r4_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hq0 : (1/8 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hql : (1/8 : ℝ) ≤ q := hq0
  have hqu : q ≤ (3/4 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/4 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (7/8 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r4_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/16 : ℝ)
      · have hqu : q ≤ (7/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t8_r4_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/64 : ℝ)
            · have hqu : q ≤ (23/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r4_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (87/256 : ℝ)
                    · have hqu : q ≤ (87/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (87/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (229/640 : ℝ)
                      · have hzu : z ≤ (229/640 : ℝ) := hsplit
                        exact large_selected_greedy_t8_r4_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                      · have hzl : (229/640 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t8_r4_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r4_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (23/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (51/128 : ℝ)
                · have hqu : q ≤ (51/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r4_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (51/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r4_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r4_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r4_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r4_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/16 : ℝ)
      · have hqu : q ≤ (7/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (13/64 : ℝ)
            · have hqu : q ≤ (13/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r4_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (13/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r4_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/64 : ℝ)
            · have hqu : q ≤ (13/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r4_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (13/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r4_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/64 : ℝ)
            · have hqu : q ≤ (23/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (23/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r4_cap_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/64 : ℝ)
            · have hqu : q ≤ (23/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r4_cap_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (23/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r4_cap_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r4_cap_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/16 : ℝ)
      · have hqu : q ≤ (7/16 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (9/32 : ℝ)
          · have hqu : q ≤ (9/32 : ℝ) := hsplit
            exact large_selected_greedy_t8_r4_cap_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r4_cap_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t8_r4_cap_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r4_cap_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r4_cap_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t8_r4_cap_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 4*z)
    (hq0 : (1/8 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 50 := by
  have hql : (1/8 : ℝ) ≤ q := hq0
  have hqu : q ≤ (3/4 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/4 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (7/8 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r4_cap_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/16 : ℝ)
      · have hqu : q ≤ (7/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t8_r4_cap_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/64 : ℝ)
            · have hqu : q ≤ (23/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r4_cap_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r4_cap_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (23/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (51/128 : ℝ)
                · have hqu : q ≤ (51/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r4_cap_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (51/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r4_cap_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r4_cap_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r4_cap_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r4_cap_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r4_cap_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/16 : ℝ)
      · have hqu : q ≤ (7/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (13/64 : ℝ)
            · have hqu : q ≤ (13/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r4_cap_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (13/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (57/256 : ℝ)
                    · have hqu : q ≤ (57/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (57/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (57/256 : ℝ)
                    · have hqu : q ≤ (57/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (57/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (25/64 : ℝ)
                  · have hzu : z ≤ (25/64 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_83 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/64 : ℝ)
            · have hqu : q ≤ (13/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r4_cap_cell_84 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (13/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (57/256 : ℝ)
                    · have hqu : q ≤ (57/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_85 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (57/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_86 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_87 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (139/320 : ℝ)
                  · have hzu : z ≤ (139/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r4_cap_cell_88 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r4_cap_cell_89 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r4_cap_cell_90 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/128 : ℝ)
                · have hqu : q ≤ (31/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_91 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_92 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/64 : ℝ)
            · have hqu : q ≤ (23/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r4_cap_cell_93 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_94 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_95 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (23/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r4_cap_cell_96 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/64 : ℝ)
            · have hqu : q ≤ (23/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (73/160 : ℝ)
              · have hzu : z ≤ (73/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (41/128 : ℝ)
                · have hqu : q ≤ (41/128 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r4_cap_cell_97 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (41/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r4_cap_cell_98 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r4_cap_cell_99 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (23/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r4_cap_cell_100 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r4_cap_cell_101 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/16 : ℝ)
      · have hqu : q ≤ (7/16 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (9/32 : ℝ)
          · have hqu : q ≤ (9/32 : ℝ) := hsplit
            exact large_selected_greedy_t8_r4_cap_cell_102 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r4_cap_cell_103 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t8_r4_cap_cell_104 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r4_cap_cell_105 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r4_cap_cell_106 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t8_r5_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 36)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(4/1 : ℝ))*q ≤ 0)
    (hq0 : (1/8 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 52 := by
  have hql : (1/8 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (7/8 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r5_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          exact large_selected_greedy_t8_r5_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t8_r5_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (29/64 : ℝ)
            · have hqu : q ≤ (29/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          exact large_selected_greedy_t8_r5_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (29/64 : ℝ)
          · have hqu : q ≤ (29/64 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (51/128 : ℝ)
              · have hqu : q ≤ (51/128 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r5_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (51/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r5_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r5_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (15/64 : ℝ)
            · have hqu : q ≤ (15/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (37/128 : ℝ)
                · have hqu : q ≤ (37/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (13/320 : ℝ)
                  · have hzu : z ≤ (13/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r5_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r5_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hzl : (13/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r5_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r5_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (15/64 : ℝ)
            · have hqu : q ≤ (15/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (37/128 : ℝ)
                · have hqu : q ≤ (37/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r5_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r5_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t8_r5_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (29/64 : ℝ)
            · have hqu : q ≤ (29/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          by_cases hsplit : q ≤ (15/64 : ℝ)
          · have hqu : q ≤ (15/64 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (37/128 : ℝ)
              · have hqu : q ≤ (37/128 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (67/256 : ℝ)
                  · have hqu : q ≤ (67/256 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (67/256 : ℝ)
                  · have hqu : q ≤ (67/256 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (37/128 : ℝ)
              · have hqu : q ≤ (37/128 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (67/256 : ℝ)
                  · have hqu : q ≤ (67/256 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (29/64 : ℝ)
          · have hqu : q ≤ (29/64 : ℝ) := hsplit
            exact large_selected_greedy_t8_r5_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r5_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (15/64 : ℝ)
            · have hqu : q ≤ (15/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r5_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t8_r5_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r5_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t8_r5_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 8*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 38)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/8 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (73/450 : ℝ) ∨ (43/125 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 54 := by
  have hql : (1/8 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (7/8 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r5_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          exact large_selected_greedy_t8_r5_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t8_r5_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (29/64 : ℝ)
            · have hqu : q ≤ (29/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          exact large_selected_greedy_t8_r5_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (29/64 : ℝ)
          · have hqu : q ≤ (29/64 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (51/128 : ℝ)
              · have hqu : q ≤ (51/128 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r5_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (51/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r5_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t8_r5_all_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r5_all_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (15/64 : ℝ)
            · have hqu : q ≤ (15/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (37/128 : ℝ)
                · have hqu : q ≤ (37/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (13/320 : ℝ)
                  · have hzu : z ≤ (13/320 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (67/256 : ℝ)
                    · have hqu : q ≤ (67/256 : ℝ) := hsplit
                      exact large_selected_greedy_t8_r5_all_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t8_r5_all_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (13/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (15/64 : ℝ)
            · have hqu : q ≤ (15/64 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_83 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_84 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (37/128 : ℝ)
                · have hqu : q ≤ (37/128 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_85 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_86 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_87 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t8_r5_all_cell_88 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (29/64 : ℝ)
            · have hqu : q ≤ (29/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_89 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_90 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_91 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          by_cases hsplit : q ≤ (15/64 : ℝ)
          · have hqu : q ≤ (15/64 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (23/128 : ℝ)
              · have hqu : q ≤ (23/128 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_92 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r5_all_cell_93 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_94 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (23/128 : ℝ)
              · have hqu : q ≤ (23/128 : ℝ) := hsplit
                exact large_selected_greedy_t8_r5_all_cell_95 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t8_r5_all_cell_96 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_97 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (37/128 : ℝ)
              · have hqu : q ≤ (37/128 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (67/256 : ℝ)
                  · have hqu : q ≤ (67/256 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_98 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_99 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (67/256 : ℝ)
                  · have hqu : q ≤ (67/256 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_100 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_101 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_102 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (37/128 : ℝ)
              · have hqu : q ≤ (37/128 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (67/256 : ℝ)
                  · have hqu : q ≤ (67/256 : ℝ) := hsplit
                    exact large_selected_greedy_t8_r5_all_cell_103 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (67/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t8_r5_all_cell_104 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t8_r5_all_cell_105 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (37/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t8_r5_all_cell_106 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (29/64 : ℝ)
          · have hqu : q ≤ (29/64 : ℝ) := hsplit
            exact large_selected_greedy_t8_r5_all_cell_107 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (29/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r5_all_cell_108 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_109 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/16 : ℝ)
      · have hqu : q ≤ (9/16 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/32 : ℝ)
        · have hqu : q ≤ (11/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (15/64 : ℝ)
            · have hqu : q ≤ (15/64 : ℝ) := hsplit
              exact large_selected_greedy_t8_r5_all_cell_110 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (15/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t8_r5_all_cell_111 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t8_r5_all_cell_112 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t8_r5_all_cell_113 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t8_r5_all_cell_114 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t8_r5_all_cell_115 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t9_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 9*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 40)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/9 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (37/250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 48 := by
  have hql : (1/9 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (8/9 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t9_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t9_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t9_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t9_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t9_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t9_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/18 : ℝ)
      · have hqu : q ≤ (7/18 : ℝ) := hsplit
        by_cases hsplit : q ≤ (1/4 : ℝ)
        · have hqu : q ≤ (1/4 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t9_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/72 : ℝ)
            · have hqu : q ≤ (13/72 : ℝ) := hsplit
              exact large_selected_greedy_t9_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (13/72 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (31/144 : ℝ)
                · have hqu : q ≤ (31/144 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (31/144 : ℝ)
                · have hqu : q ≤ (31/144 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (31/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (1/4 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t9_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/72 : ℝ)
            · have hqu : q ≤ (23/72 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                exact large_selected_greedy_t9_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t9_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (23/72 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t9_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (7/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/18 : ℝ)
      · have hqu : q ≤ (7/18 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (1/4 : ℝ)
          · have hqu : q ≤ (1/4 : ℝ) := hsplit
            exact large_selected_greedy_t9_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (1/4 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (7/12 : ℝ)
            · have hzu : z ≤ (7/12 : ℝ) := hsplit
              exact large_selected_greedy_t9_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hzl : (7/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t9_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t9_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (7/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t9_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t9_r4_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 9*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 40)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/9 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (37/250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 52 := by
  have hql : (1/9 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (8/9 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t9_r4_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t9_r4_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t9_r4_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t9_r4_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/9 : ℝ)
      · have hqu : q ≤ (5/9 : ℝ) := hsplit
        by_cases hsplit : q ≤ (1/3 : ℝ)
        · have hqu : q ≤ (1/3 : ℝ) := hsplit
          exact large_selected_greedy_t9_r4_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (1/3 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (4/9 : ℝ)
            · have hqu : q ≤ (4/9 : ℝ) := hsplit
              exact large_selected_greedy_t9_r4_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (4/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t9_r4_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (4/9 : ℝ)
            · have hqu : q ≤ (4/9 : ℝ) := hsplit
              exact large_selected_greedy_t9_r4_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (4/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t9_r4_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (5/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r4_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/9 : ℝ)
      · have hqu : q ≤ (5/9 : ℝ) := hsplit
        by_cases hsplit : q ≤ (1/3 : ℝ)
        · have hqu : q ≤ (1/3 : ℝ) := hsplit
          exact large_selected_greedy_t9_r4_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (1/3 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (4/9 : ℝ)
          · have hqu : q ≤ (4/9 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t9_r4_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t9_r4_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (4/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t9_r4_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (5/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r4_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t9_r4_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t9_r4_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/9 : ℝ)
      · have hqu : q ≤ (5/9 : ℝ) := hsplit
        by_cases hsplit : q ≤ (1/3 : ℝ)
        · have hqu : q ≤ (1/3 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (2/9 : ℝ)
            · have hqu : q ≤ (2/9 : ℝ) := hsplit
              exact large_selected_greedy_t9_r4_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (2/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (5/18 : ℝ)
                · have hqu : q ≤ (5/18 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (5/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (5/18 : ℝ)
                · have hqu : q ≤ (5/18 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (5/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (2/9 : ℝ)
            · have hqu : q ≤ (2/9 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t9_r4_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t9_r4_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (2/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t9_r4_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (5/18 : ℝ)
                · have hqu : q ≤ (5/18 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (5/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (1/3 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t9_r4_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t9_r4_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (5/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r4_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/9 : ℝ)
      · have hqu : q ≤ (5/9 : ℝ) := hsplit
        by_cases hsplit : q ≤ (1/3 : ℝ)
        · have hqu : q ≤ (1/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (2/9 : ℝ)
          · have hqu : q ≤ (2/9 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (1/6 : ℝ)
              · have hqu : q ≤ (1/6 : ℝ) := hsplit
                exact large_selected_greedy_t9_r4_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (1/6 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (1/6 : ℝ)
              · have hqu : q ≤ (1/6 : ℝ) := hsplit
                exact large_selected_greedy_t9_r4_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (1/6 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (2/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (5/18 : ℝ)
              · have hqu : q ≤ (5/18 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (5/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t9_r4_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (5/18 : ℝ)
              · have hqu : q ≤ (5/18 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t9_r4_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t9_r4_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (5/18 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t9_r4_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (1/3 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (4/9 : ℝ)
          · have hqu : q ≤ (4/9 : ℝ) := hsplit
            exact large_selected_greedy_t9_r4_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (4/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t9_r4_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (5/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r4_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (5/9 : ℝ)
      · have hqu : q ≤ (5/9 : ℝ) := hsplit
        by_cases hsplit : q ≤ (1/3 : ℝ)
        · have hqu : q ≤ (1/3 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (2/9 : ℝ)
            · have hqu : q ≤ (2/9 : ℝ) := hsplit
              exact large_selected_greedy_t9_r4_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (2/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t9_r4_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t9_r4_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (1/3 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t9_r4_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (5/9 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t9_r4_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t9_r4_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hq0 : (1/10 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (377/2750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 52 := by
  have hql : (1/10 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (9/10 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/60 : ℝ)
      · have hqu : q ≤ (23/60 : ℝ) := hsplit
        by_cases hsplit : q ≤ (29/120 : ℝ)
        · have hqu : q ≤ (29/120 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t10_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (41/240 : ℝ)
            · have hqu : q ≤ (41/240 : ℝ) := hsplit
              exact large_selected_greedy_t10_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (41/240 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                exact large_selected_greedy_t10_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (29/120 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t10_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (5/16 : ℝ)
            · have hqu : q ≤ (5/16 : ℝ) := hsplit
              exact large_selected_greedy_t10_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t10_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (23/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/60 : ℝ)
      · have hqu : q ≤ (23/60 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (29/120 : ℝ)
          · have hqu : q ≤ (29/120 : ℝ) := hsplit
            exact large_selected_greedy_t10_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hql : (29/120 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t10_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (23/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t10_r3_cap_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/10 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (377/2750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 54 := by
  have hql : (1/10 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (9/10 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r3_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r3_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/60 : ℝ)
      · have hqu : q ≤ (23/60 : ℝ) := hsplit
        by_cases hsplit : q ≤ (29/120 : ℝ)
        · have hqu : q ≤ (29/120 : ℝ) := hsplit
          exact large_selected_greedy_t10_r3_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (29/120 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t10_r3_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (5/16 : ℝ)
            · have hqu : q ≤ (5/16 : ℝ) := hsplit
              exact large_selected_greedy_t10_r3_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t10_r3_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (23/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r3_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/60 : ℝ)
      · have hqu : q ≤ (23/60 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (29/120 : ℝ)
          · have hqu : q ≤ (29/120 : ℝ) := hsplit
            exact large_selected_greedy_t10_r3_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (29/120 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r3_cap_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t10_r3_cap_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (23/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r3_cap_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r3_cap_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t10_r4_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 44)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(5/1 : ℝ))*q ≤ 0)
    (hq0 : (1/10 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (377/2750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hql : (1/10 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (9/10 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r4_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          exact large_selected_greedy_t10_r4_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t10_r4_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (7/16 : ℝ)
            · have hqu : q ≤ (7/16 : ℝ) := hsplit
              exact large_selected_greedy_t10_r4_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t10_r4_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          exact large_selected_greedy_t10_r4_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (7/16 : ℝ)
          · have hqu : q ≤ (7/16 : ℝ) := hsplit
            exact large_selected_greedy_t10_r4_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r4_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (17/80 : ℝ)
            · have hqu : q ≤ (17/80 : ℝ) := hsplit
              exact large_selected_greedy_t10_r4_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (43/160 : ℝ)
                · have hqu : q ≤ (43/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (17/80 : ℝ)
            · have hqu : q ≤ (17/80 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (43/160 : ℝ)
                · have hqu : q ≤ (43/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t10_r4_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          by_cases hsplit : q ≤ (17/80 : ℝ)
          · have hqu : q ≤ (17/80 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (5/32 : ℝ)
              · have hqu : q ≤ (5/32 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (5/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (5/32 : ℝ)
              · have hqu : q ≤ (5/32 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (5/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (43/160 : ℝ)
              · have hqu : q ≤ (43/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (43/160 : ℝ)
              · have hqu : q ≤ (43/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t10_r4_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (17/80 : ℝ)
            · have hqu : q ≤ (17/80 : ℝ) := hsplit
              exact large_selected_greedy_t10_r4_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t10_r4_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t10_r4_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r4_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t10_r4_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 10*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 46)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/10 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (377/2750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 58 := by
  have hql : (1/10 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (9/10 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r4_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          exact large_selected_greedy_t10_r4_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t10_r4_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          exact large_selected_greedy_t10_r4_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (7/16 : ℝ)
          · have hqu : q ≤ (7/16 : ℝ) := hsplit
            exact large_selected_greedy_t10_r4_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (7/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t10_r4_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r4_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (17/80 : ℝ)
            · have hqu : q ≤ (17/80 : ℝ) := hsplit
              exact large_selected_greedy_t10_r4_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (43/160 : ℝ)
                · have hqu : q ≤ (43/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (17/80 : ℝ)
            · have hqu : q ≤ (17/80 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (43/160 : ℝ)
                · have hqu : q ≤ (43/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t10_r4_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          by_cases hsplit : q ≤ (17/80 : ℝ)
          · have hqu : q ≤ (17/80 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (5/32 : ℝ)
              · have hqu : q ≤ (5/32 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (5/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (5/32 : ℝ)
              · have hqu : q ≤ (5/32 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (5/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t10_r4_all_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t10_r4_all_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (43/160 : ℝ)
              · have hqu : q ≤ (43/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (43/160 : ℝ)
              · have hqu : q ≤ (43/160 : ℝ) := hsplit
                exact large_selected_greedy_t10_r4_all_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (43/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t10_r4_all_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t10_r4_all_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/20 : ℝ)
      · have hqu : q ≤ (11/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/40 : ℝ)
        · have hqu : q ≤ (13/40 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (17/80 : ℝ)
            · have hqu : q ≤ (17/80 : ℝ) := hsplit
              exact large_selected_greedy_t10_r4_all_cell_83 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (17/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t10_r4_all_cell_84 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t10_r4_all_cell_85 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t10_r4_all_cell_86 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/20 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t10_r4_all_cell_87 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t10_r4_all_cell_88 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t11_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/11 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (16/125 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 56 := by
  have hql : (1/11 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (10/11 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t11_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t11_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t11_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t11_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t11_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t11_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/66 : ℝ)
      · have hqu : q ≤ (25/66 : ℝ) := hsplit
        by_cases hsplit : q ≤ (31/132 : ℝ)
        · have hqu : q ≤ (31/132 : ℝ) := hsplit
          exact large_selected_greedy_t11_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (31/132 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t11_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (27/88 : ℝ)
            · have hqu : q ≤ (27/88 : ℝ) := hsplit
              exact large_selected_greedy_t11_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (27/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t11_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (25/66 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/66 : ℝ)
      · have hqu : q ≤ (25/66 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (31/132 : ℝ)
          · have hqu : q ≤ (31/132 : ℝ) := hsplit
            exact large_selected_greedy_t11_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (31/132 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t11_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t11_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (25/66 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t11_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t11_r4_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 11*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 48)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/11 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (16/125 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 60 := by
  have hql : (1/11 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (10/11 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t11_r4_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t11_r4_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t11_r4_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t11_r4_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (6/11 : ℝ)
      · have hqu : q ≤ (6/11 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/22 : ℝ)
        · have hqu : q ≤ (7/22 : ℝ) := hsplit
          exact large_selected_greedy_t11_r4_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/22 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t11_r4_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t11_r4_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (6/11 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r4_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (6/11 : ℝ)
      · have hqu : q ≤ (6/11 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/22 : ℝ)
        · have hqu : q ≤ (7/22 : ℝ) := hsplit
          exact large_selected_greedy_t11_r4_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/22 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (19/44 : ℝ)
          · have hqu : q ≤ (19/44 : ℝ) := hsplit
            exact large_selected_greedy_t11_r4_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (19/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t11_r4_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (6/11 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r4_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t11_r4_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t11_r4_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (6/11 : ℝ)
      · have hqu : q ≤ (6/11 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/22 : ℝ)
        · have hqu : q ≤ (7/22 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (9/44 : ℝ)
            · have hqu : q ≤ (9/44 : ℝ) := hsplit
              exact large_selected_greedy_t11_r4_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (9/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (23/88 : ℝ)
                · have hqu : q ≤ (23/88 : ℝ) := hsplit
                  exact large_selected_greedy_t11_r4_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (23/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t11_r4_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t11_r4_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (9/44 : ℝ)
            · have hqu : q ≤ (9/44 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t11_r4_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (13/88 : ℝ)
                · have hqu : q ≤ (13/88 : ℝ) := hsplit
                  exact large_selected_greedy_t11_r4_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (13/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t11_r4_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t11_r4_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (9/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t11_r4_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (23/88 : ℝ)
                · have hqu : q ≤ (23/88 : ℝ) := hsplit
                  exact large_selected_greedy_t11_r4_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (23/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t11_r4_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/22 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t11_r4_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t11_r4_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (6/11 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r4_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (6/11 : ℝ)
      · have hqu : q ≤ (6/11 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/22 : ℝ)
        · have hqu : q ≤ (7/22 : ℝ) := hsplit
          by_cases hsplit : q ≤ (9/44 : ℝ)
          · have hqu : q ≤ (9/44 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (13/88 : ℝ)
              · have hqu : q ≤ (13/88 : ℝ) := hsplit
                exact large_selected_greedy_t11_r4_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (13/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (31/176 : ℝ)
                  · have hqu : q ≤ (31/176 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (111/320 : ℝ)
                    · have hzu : z ≤ (111/320 : ℝ) := hsplit
                      exact large_selected_greedy_t11_r4_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t11_r4_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (31/176 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t11_r4_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (31/176 : ℝ)
                  · have hqu : q ≤ (31/176 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (25/64 : ℝ)
                    · have hzu : z ≤ (25/64 : ℝ) := hsplit
                      exact large_selected_greedy_t11_r4_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t11_r4_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (31/176 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t11_r4_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (13/88 : ℝ)
              · have hqu : q ≤ (13/88 : ℝ) := hsplit
                exact large_selected_greedy_t11_r4_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (13/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (31/176 : ℝ)
                  · have hqu : q ≤ (31/176 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (139/320 : ℝ)
                    · have hzu : z ≤ (139/320 : ℝ) := hsplit
                      exact large_selected_greedy_t11_r4_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t11_r4_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (31/176 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t11_r4_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t11_r4_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (9/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (23/88 : ℝ)
              · have hqu : q ≤ (23/88 : ℝ) := hsplit
                exact large_selected_greedy_t11_r4_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (23/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t11_r4_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (23/88 : ℝ)
              · have hqu : q ≤ (23/88 : ℝ) := hsplit
                exact large_selected_greedy_t11_r4_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (23/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t11_r4_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/22 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t11_r4_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (6/11 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r4_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (6/11 : ℝ)
      · have hqu : q ≤ (6/11 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/22 : ℝ)
        · have hqu : q ≤ (7/22 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (9/44 : ℝ)
            · have hqu : q ≤ (9/44 : ℝ) := hsplit
              exact large_selected_greedy_t11_r4_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (9/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t11_r4_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t11_r4_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/22 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t11_r4_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (6/11 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t11_r4_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t11_r4_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t12_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 12*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 52)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hgood : e+(1-(6/1 : ℝ))*q ≤ 0)
    (hq0 : (1/12 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (391/3250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 60 := by
  have hql : (1/12 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (11/12 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (3/8 : ℝ)
      · have hqu : q ≤ (3/8 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/48 : ℝ)
        · have hqu : q ≤ (11/48 : ℝ) := hsplit
          exact large_selected_greedy_t12_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hql : (11/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t12_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (29/96 : ℝ)
            · have hqu : q ≤ (29/96 : ℝ) := hsplit
              exact large_selected_greedy_t12_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
            · have hql : (29/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t12_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (3/8 : ℝ)
      · have hqu : q ≤ (3/8 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (11/48 : ℝ)
          · have hqu : q ≤ (11/48 : ℝ) := hsplit
            exact large_selected_greedy_t12_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
          · have hql : (11/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
      · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t12_r3_cap_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 12*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 54)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/12 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (391/3250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 62 := by
  have hql : (1/12 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (11/12 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (3/8 : ℝ)
      · have hqu : q ≤ (3/8 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/48 : ℝ)
        · have hqu : q ≤ (11/48 : ℝ) := hsplit
          exact large_selected_greedy_t12_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (11/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r3_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r3_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (3/8 : ℝ)
      · have hqu : q ≤ (3/8 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (11/48 : ℝ)
          · have hqu : q ≤ (11/48 : ℝ) := hsplit
            exact large_selected_greedy_t12_r3_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (11/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r3_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r3_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r3_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r3_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t12_r4_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 12*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 52)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(6/1 : ℝ))*q ≤ 0)
    (hq0 : (1/12 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (391/3250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 64 := by
  have hql : (1/12 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (11/12 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        exact large_selected_greedy_t12_r4_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r4_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          exact large_selected_greedy_t12_r4_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t12_r4_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r4_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        exact large_selected_greedy_t12_r4_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r4_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (19/96 : ℝ)
            · have hqu : q ≤ (19/96 : ℝ) := hsplit
              exact large_selected_greedy_t12_r4_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t12_r4_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (19/96 : ℝ)
            · have hqu : q ≤ (19/96 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t12_r4_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r4_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : q ≤ (19/96 : ℝ)
          · have hqu : q ≤ (19/96 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (9/64 : ℝ)
              · have hqu : q ≤ (9/64 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (9/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t12_r4_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t12_r4_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (9/64 : ℝ)
              · have hqu : q ≤ (9/64 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (9/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t12_r4_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t12_r4_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (49/192 : ℝ)
              · have hqu : q ≤ (49/192 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (49/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (49/192 : ℝ)
              · have hqu : q ≤ (49/192 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (49/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r4_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (19/96 : ℝ)
            · have hqu : q ≤ (19/96 : ℝ) := hsplit
              exact large_selected_greedy_t12_r4_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t12_r4_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r4_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r4_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r4_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t12_r4_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 12*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 54)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/12 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (391/3250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 66 := by
  have hql : (1/12 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (11/12 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r4_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          exact large_selected_greedy_t12_r4_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t12_r4_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r4_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        exact large_selected_greedy_t12_r4_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t12_r4_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r4_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (19/96 : ℝ)
            · have hqu : q ≤ (19/96 : ℝ) := hsplit
              exact large_selected_greedy_t12_r4_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t12_r4_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (19/96 : ℝ)
            · have hqu : q ≤ (19/96 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t12_r4_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r4_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : q ≤ (19/96 : ℝ)
          · have hqu : q ≤ (19/96 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (9/64 : ℝ)
              · have hqu : q ≤ (9/64 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (9/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t12_r4_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t12_r4_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (9/64 : ℝ)
              · have hqu : q ≤ (9/64 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (9/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t12_r4_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t12_r4_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (49/192 : ℝ)
              · have hqu : q ≤ (49/192 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (49/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (49/192 : ℝ)
              · have hqu : q ≤ (49/192 : ℝ) := hsplit
                exact large_selected_greedy_t12_r4_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (49/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t12_r4_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r4_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/24 : ℝ)
      · have hqu : q ≤ (13/24 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/16 : ℝ)
        · have hqu : q ≤ (5/16 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (19/96 : ℝ)
            · have hqu : q ≤ (19/96 : ℝ) := hsplit
              exact large_selected_greedy_t12_r4_all_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (19/96 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t12_r4_all_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t12_r4_all_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t12_r4_all_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (13/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t12_r4_all_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t12_r4_all_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t13_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 13*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 56)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/13 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (199/1750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 64 := by
  have hql : (1/13 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (12/13 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t13_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t13_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t13_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t13_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t13_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t13_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (29/78 : ℝ)
      · have hqu : q ≤ (29/78 : ℝ) := hsplit
        by_cases hsplit : q ≤ (35/156 : ℝ)
        · have hqu : q ≤ (35/156 : ℝ) := hsplit
          exact large_selected_greedy_t13_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (35/156 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t13_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (29/78 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (29/78 : ℝ)
      · have hqu : q ≤ (29/78 : ℝ) := hsplit
        by_cases hsplit : z ≤ (2/3 : ℝ)
        · have hzu : z ≤ (2/3 : ℝ) := hsplit
          by_cases hsplit : q ≤ (35/156 : ℝ)
          · have hqu : q ≤ (35/156 : ℝ) := hsplit
            exact large_selected_greedy_t13_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hql : (35/156 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t13_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t13_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (29/78 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t13_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t13_r4_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 13*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 56)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/13 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (199/1750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 68 := by
  have hql : (1/13 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (12/13 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        exact large_selected_greedy_t13_r4_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t13_r4_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        exact large_selected_greedy_t13_r4_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t13_r4_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        exact large_selected_greedy_t13_r4_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        exact large_selected_greedy_t13_r4_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t13_r4_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t13_r4_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        by_cases hsplit : q ≤ (4/13 : ℝ)
        · have hqu : q ≤ (4/13 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (5/26 : ℝ)
            · have hqu : q ≤ (5/26 : ℝ) := hsplit
              exact large_selected_greedy_t13_r4_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (5/26 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t13_r4_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (5/26 : ℝ)
            · have hqu : q ≤ (5/26 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t13_r4_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t13_r4_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (5/26 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t13_r4_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t13_r4_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (4/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t13_r4_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        by_cases hsplit : q ≤ (4/13 : ℝ)
        · have hqu : q ≤ (4/13 : ℝ) := hsplit
          by_cases hsplit : q ≤ (5/26 : ℝ)
          · have hqu : q ≤ (5/26 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (7/52 : ℝ)
              · have hqu : q ≤ (7/52 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t13_r4_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t13_r4_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (7/52 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t13_r4_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t13_r4_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (7/52 : ℝ)
              · have hqu : q ≤ (7/52 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t13_r4_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t13_r4_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (7/52 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t13_r4_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t13_r4_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (5/26 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t13_r4_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t13_r4_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (4/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t13_r4_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (7/13 : ℝ)
      · have hqu : q ≤ (7/13 : ℝ) := hsplit
        by_cases hsplit : q ≤ (4/13 : ℝ)
        · have hqu : q ≤ (4/13 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (5/26 : ℝ)
            · have hqu : q ≤ (5/26 : ℝ) := hsplit
              exact large_selected_greedy_t13_r4_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (5/26 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t13_r4_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t13_r4_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (4/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t13_r4_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (7/13 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t13_r4_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t13_r4_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t14_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 60)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(7/1 : ℝ))*q ≤ 0)
    (hq0 : (1/14 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (27/250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 68 := by
  have hql : (1/14 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (13/14 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t14_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t14_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t14_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        by_cases hsplit : q ≤ (17/56 : ℝ)
        · have hqu : q ≤ (17/56 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/16 : ℝ)
            · have hqu : q ≤ (3/16 : ℝ) := hsplit
              exact large_selected_greedy_t14_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t14_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (3/16 : ℝ)
            · have hqu : q ≤ (3/16 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t14_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (29/224 : ℝ)
                · have hqu : q ≤ (29/224 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t14_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t14_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (29/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (91/320 : ℝ)
                  · have hzu : z ≤ (91/320 : ℝ) := hsplit
                    exact large_selected_greedy_t14_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t14_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t14_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t14_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t14_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t14_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        by_cases hsplit : q ≤ (17/56 : ℝ)
        · have hqu : q ≤ (17/56 : ℝ) := hsplit
          by_cases hsplit : q ≤ (3/16 : ℝ)
          · have hqu : q ≤ (3/16 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (29/224 : ℝ)
              · have hqu : q ≤ (29/224 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (45/448 : ℝ)
                  · have hqu : q ≤ (45/448 : ℝ) := hsplit
                    exact large_selected_greedy_t14_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (45/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    by_cases hsplit : z ≤ (111/320 : ℝ)
                    · have hzu : z ≤ (111/320 : ℝ) := hsplit
                      exact large_selected_greedy_t14_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t14_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (45/448 : ℝ)
                  · have hqu : q ≤ (45/448 : ℝ) := hsplit
                    exact large_selected_greedy_t14_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (45/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    by_cases hsplit : z ≤ (25/64 : ℝ)
                    · have hzu : z ≤ (25/64 : ℝ) := hsplit
                      exact large_selected_greedy_t14_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t14_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (29/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t14_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  by_cases hsplit : q ≤ (71/448 : ℝ)
                  · have hqu : q ≤ (71/448 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (25/64 : ℝ)
                    · have hzu : z ≤ (25/64 : ℝ) := hsplit
                      exact large_selected_greedy_t14_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hzl : (25/64 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t14_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (71/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t14_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (29/224 : ℝ)
              · have hqu : q ≤ (29/224 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (45/448 : ℝ)
                  · have hqu : q ≤ (45/448 : ℝ) := hsplit
                    exact large_selected_greedy_t14_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (45/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    by_cases hsplit : z ≤ (139/320 : ℝ)
                    · have hzu : z ≤ (139/320 : ℝ) := hsplit
                      exact large_selected_greedy_t14_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      by_cases hsplit : q ≤ (103/896 : ℝ)
                      · have hqu : q ≤ (103/896 : ℝ) := hsplit
                        exact large_selected_greedy_t14_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                      · have hql : (103/896 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                        by_cases hsplit : z ≤ (57/128 : ℝ)
                        · have hzu : z ≤ (57/128 : ℝ) := hsplit
                          exact large_selected_greedy_t14_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                        · have hzl : (57/128 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t14_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t14_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (29/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (71/448 : ℝ)
                  · have hqu : q ≤ (71/448 : ℝ) := hsplit
                    by_cases hsplit : z ≤ (139/320 : ℝ)
                    · have hzu : z ≤ (139/320 : ℝ) := hsplit
                      exact large_selected_greedy_t14_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                    · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t14_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                  · have hql : (71/448 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t14_r3_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t14_r3_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (55/224 : ℝ)
              · have hqu : q ≤ (55/224 : ℝ) := hsplit
                exact large_selected_greedy_t14_r3_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (55/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t14_r3_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (55/224 : ℝ)
              · have hqu : q ≤ (55/224 : ℝ) := hsplit
                exact large_selected_greedy_t14_r3_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (55/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t14_r3_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t14_r3_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        by_cases hsplit : q ≤ (17/56 : ℝ)
        · have hqu : q ≤ (17/56 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/16 : ℝ)
            · have hqu : q ≤ (3/16 : ℝ) := hsplit
              exact large_selected_greedy_t14_r3_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t14_r3_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t14_r3_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t14_r3_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t14_r3_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t14_r3_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 14*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 62)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/14 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (27/250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 70 := by
  have hql : (1/14 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (13/14 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t14_r3_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        exact large_selected_greedy_t14_r3_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t14_r3_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t14_r3_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        by_cases hsplit : q ≤ (17/56 : ℝ)
        · have hqu : q ≤ (17/56 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/16 : ℝ)
            · have hqu : q ≤ (3/16 : ℝ) := hsplit
              exact large_selected_greedy_t14_r3_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t14_r3_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (3/16 : ℝ)
            · have hqu : q ≤ (3/16 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t14_r3_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t14_r3_all_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t14_r3_all_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t14_r3_all_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t14_r3_all_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        by_cases hsplit : q ≤ (17/56 : ℝ)
        · have hqu : q ≤ (17/56 : ℝ) := hsplit
          by_cases hsplit : q ≤ (3/16 : ℝ)
          · have hqu : q ≤ (3/16 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (29/224 : ℝ)
              · have hqu : q ≤ (29/224 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t14_r3_all_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t14_r3_all_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (29/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t14_r3_all_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t14_r3_all_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (29/224 : ℝ)
              · have hqu : q ≤ (29/224 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t14_r3_all_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t14_r3_all_cell_83 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (29/224 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t14_r3_all_cell_84 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t14_r3_all_cell_85 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t14_r3_all_cell_86 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t14_r3_all_cell_87 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t14_r3_all_cell_88 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_89 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (15/28 : ℝ)
      · have hqu : q ≤ (15/28 : ℝ) := hsplit
        by_cases hsplit : q ≤ (17/56 : ℝ)
        · have hqu : q ≤ (17/56 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/16 : ℝ)
            · have hqu : q ≤ (3/16 : ℝ) := hsplit
              exact large_selected_greedy_t14_r3_all_cell_90 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (3/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t14_r3_all_cell_91 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t14_r3_all_cell_92 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (17/56 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t14_r3_all_cell_93 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (15/28 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t14_r3_all_cell_94 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t14_r3_all_cell_95 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t15_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 15*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 64)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/15 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (103/1000 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 72 := by
  have hql : (1/15 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (14/15 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/10 : ℝ)
        · have hqu : q ≤ (3/10 : ℝ) := hsplit
          exact large_selected_greedy_t15_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/10 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t15_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        exact large_selected_greedy_t15_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        exact large_selected_greedy_t15_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t15_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        exact large_selected_greedy_t15_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        exact large_selected_greedy_t15_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t15_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t15_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/10 : ℝ)
        · have hqu : q ≤ (3/10 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (11/60 : ℝ)
            · have hqu : q ≤ (11/60 : ℝ) := hsplit
              exact large_selected_greedy_t15_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (11/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t15_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (11/60 : ℝ)
            · have hqu : q ≤ (11/60 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t15_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t15_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (11/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t15_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/10 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t15_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/10 : ℝ)
        · have hqu : q ≤ (3/10 : ℝ) := hsplit
          by_cases hsplit : q ≤ (11/60 : ℝ)
          · have hqu : q ≤ (11/60 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (1/8 : ℝ)
              · have hqu : q ≤ (1/8 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t15_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t15_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (1/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t15_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t15_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (1/8 : ℝ)
              · have hqu : q ≤ (1/8 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  by_cases hsplit : q ≤ (23/240 : ℝ)
                  · have hqu : q ≤ (23/240 : ℝ) := hsplit
                    exact large_selected_greedy_t15_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                  · have hql : (23/240 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                    by_cases hsplit : z ≤ (139/320 : ℝ)
                    · have hzu : z ≤ (139/320 : ℝ) := hsplit
                      exact large_selected_greedy_t15_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                    · have hzl : (139/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t15_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t15_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (1/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t15_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t15_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (11/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t15_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t15_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/10 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t15_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (8/15 : ℝ)
      · have hqu : q ≤ (8/15 : ℝ) := hsplit
        by_cases hsplit : q ≤ (3/10 : ℝ)
        · have hqu : q ≤ (3/10 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (11/60 : ℝ)
            · have hqu : q ≤ (11/60 : ℝ) := hsplit
              exact large_selected_greedy_t15_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (11/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t15_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t15_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (3/10 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t15_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (8/15 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t15_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t15_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t16_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 16*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 68)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(8/1 : ℝ))*q ≤ 0)
    (hq0 : (1/16 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (419/4250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 76 := by
  have hql : (1/16 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (15/16 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          exact large_selected_greedy_t16_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          exact large_selected_greedy_t16_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          exact large_selected_greedy_t16_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t16_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        exact large_selected_greedy_t16_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        exact large_selected_greedy_t16_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t16_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t16_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/128 : ℝ)
            · have hqu : q ≤ (23/128 : ℝ) := hsplit
              exact large_selected_greedy_t16_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/128 : ℝ)
            · have hqu : q ≤ (23/128 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t16_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t16_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          by_cases hsplit : q ≤ (23/128 : ℝ)
          · have hqu : q ≤ (23/128 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (31/256 : ℝ)
              · have hqu : q ≤ (31/256 : ℝ) := hsplit
                by_cases hsplit : z ≤ (59/160 : ℝ)
                · have hzu : z ≤ (59/160 : ℝ) := hsplit
                  exact large_selected_greedy_t16_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t16_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (31/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t16_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (31/256 : ℝ)
              · have hqu : q ≤ (31/256 : ℝ) := hsplit
                by_cases hsplit : z ≤ (73/160 : ℝ)
                · have hzu : z ≤ (73/160 : ℝ) := hsplit
                  exact large_selected_greedy_t16_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hzl : (73/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t16_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (31/256 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t16_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t16_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/128 : ℝ)
            · have hqu : q ≤ (23/128 : ℝ) := hsplit
              exact large_selected_greedy_t16_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t16_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t16_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t16_r3_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 16*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 70)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/16 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (419/4250 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 78 := by
  have hql : (1/16 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (15/16 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          exact large_selected_greedy_t16_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        exact large_selected_greedy_t16_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        exact large_selected_greedy_t16_r3_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t16_r3_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        exact large_selected_greedy_t16_r3_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t16_r3_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t16_r3_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t16_r3_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/128 : ℝ)
            · have hqu : q ≤ (23/128 : ℝ) := hsplit
              exact large_selected_greedy_t16_r3_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (23/128 : ℝ)
            · have hqu : q ≤ (23/128 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t16_r3_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t16_r3_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          by_cases hsplit : q ≤ (23/128 : ℝ)
          · have hqu : q ≤ (23/128 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t16_r3_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t16_r3_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/32 : ℝ)
      · have hqu : q ≤ (17/32 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/64 : ℝ)
        · have hqu : q ≤ (19/64 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/128 : ℝ)
            · have hqu : q ≤ (23/128 : ℝ) := hsplit
              exact large_selected_greedy_t16_r3_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (23/128 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t16_r3_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t16_r3_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (19/64 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t16_r3_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (17/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t16_r3_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t16_r3_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t17_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 17*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 72)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/17 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (71/750 : ℝ) ∨ (2/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 80 := by
  have hql : (1/17 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (16/17 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/17 : ℝ)
        · have hqu : q ≤ (5/17 : ℝ) := hsplit
          exact large_selected_greedy_t17_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t17_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/17 : ℝ)
        · have hqu : q ≤ (5/17 : ℝ) := hsplit
          exact large_selected_greedy_t17_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t17_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/17 : ℝ)
        · have hqu : q ≤ (5/17 : ℝ) := hsplit
          exact large_selected_greedy_t17_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t17_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t17_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        exact large_selected_greedy_t17_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t17_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t17_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t17_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/17 : ℝ)
        · have hqu : q ≤ (5/17 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/17 : ℝ)
            · have hqu : q ≤ (3/17 : ℝ) := hsplit
              exact large_selected_greedy_t17_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (3/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t17_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (3/17 : ℝ)
            · have hqu : q ≤ (3/17 : ℝ) := hsplit
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t17_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t17_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (3/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t17_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t17_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/17 : ℝ)
        · have hqu : q ≤ (5/17 : ℝ) := hsplit
          by_cases hsplit : q ≤ (3/17 : ℝ)
          · have hqu : q ≤ (3/17 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t17_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t17_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (3/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t17_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t17_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (9/17 : ℝ)
      · have hqu : q ≤ (9/17 : ℝ) := hsplit
        by_cases hsplit : q ≤ (5/17 : ℝ)
        · have hqu : q ≤ (5/17 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/17 : ℝ)
            · have hqu : q ≤ (3/17 : ℝ) := hsplit
              exact large_selected_greedy_t17_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (3/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t17_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t17_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (5/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t17_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (9/17 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t17_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t17_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t18_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 18*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 76)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(9/1 : ℝ))*q ≤ 0)
    (hq0 : (1/18 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (433/4750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 84 := by
  have hql : (1/18 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (17/18 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t18_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (13/160 : ℝ)
              · have hzu : z ≤ (13/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (67/288 : ℝ)
                · have hqu : q ≤ (67/288 : ℝ) := hsplit
                  exact large_selected_greedy_t18_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (67/288 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t18_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (13/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t18_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t18_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (67/288 : ℝ)
                · have hqu : q ≤ (67/288 : ℝ) := hsplit
                  exact large_selected_greedy_t18_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
                · have hql : (67/288 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t18_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (59/144 : ℝ)
            · have hqu : q ≤ (59/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (59/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : q ≤ (25/144 : ℝ)
          · have hqu : q ≤ (25/144 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (67/288 : ℝ)
              · have hqu : q ≤ (67/288 : ℝ) := hsplit
                exact large_selected_greedy_t18_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
              · have hql : (67/288 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t18_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (59/144 : ℝ)
          · have hqu : q ≤ (59/144 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (59/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t18_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t18_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : q ≤ (25/144 : ℝ)
          · have hqu : q ≤ (25/144 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t18_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t18_r3_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t18_r3_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t18_r3_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 18*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 78)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/18 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (433/4750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 86 := by
  have hql : (1/18 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (17/18 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t18_r3_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t18_r3_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (67/288 : ℝ)
                · have hqu : q ≤ (67/288 : ℝ) := hsplit
                  exact large_selected_greedy_t18_r3_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
                · have hql : (67/288 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t18_r3_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (59/144 : ℝ)
            · have hqu : q ≤ (59/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (59/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : q ≤ (25/144 : ℝ)
          · have hqu : q ≤ (25/144 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (67/288 : ℝ)
              · have hqu : q ≤ (67/288 : ℝ) := hsplit
                exact large_selected_greedy_t18_r3_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (67/288 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t18_r3_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (59/144 : ℝ)
          · have hqu : q ≤ (59/144 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (59/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t18_r3_all_cell_73 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_74 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          exact large_selected_greedy_t18_r3_all_cell_75 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_76 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_77 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t18_r3_all_cell_78 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_79 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_80 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (25/144 : ℝ)
            · have hqu : q ≤ (25/144 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_81 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_82 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_83 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_84 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : q ≤ (25/144 : ℝ)
          · have hqu : q ≤ (25/144 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t18_r3_all_cell_85 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t18_r3_all_cell_86 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (25/144 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t18_r3_all_cell_87 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_88 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_89 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (19/36 : ℝ)
      · have hqu : q ≤ (19/36 : ℝ) := hsplit
        by_cases hsplit : q ≤ (7/24 : ℝ)
        · have hqu : q ≤ (7/24 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            exact large_selected_greedy_t18_r3_all_cell_90 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t18_r3_all_cell_91 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (7/24 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t18_r3_all_cell_92 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (19/36 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t18_r3_all_cell_93 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t18_r3_all_cell_94 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t19_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 19*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 80)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/19 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (11/125 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 88 := by
  have hql : (1/19 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (18/19 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          exact large_selected_greedy_t19_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t19_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          exact large_selected_greedy_t19_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t19_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          exact large_selected_greedy_t19_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t19_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t19_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t19_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/76 : ℝ)
            · have hqu : q ≤ (13/76 : ℝ) := hsplit
              exact large_selected_greedy_t19_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (13/76 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (39/160 : ℝ)
              · have hzu : z ≤ (39/160 : ℝ) := hsplit
                exact large_selected_greedy_t19_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t19_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t19_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (31/76 : ℝ)
            · have hqu : q ≤ (31/76 : ℝ) := hsplit
              exact large_selected_greedy_t19_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (31/76 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t19_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          by_cases hsplit : q ≤ (13/76 : ℝ)
          · have hqu : q ≤ (13/76 : ℝ) := hsplit
            exact large_selected_greedy_t19_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (13/76 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              by_cases hsplit : q ≤ (35/152 : ℝ)
              · have hqu : q ≤ (35/152 : ℝ) := hsplit
                exact large_selected_greedy_t19_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
              · have hql : (35/152 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t19_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t19_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (31/76 : ℝ)
          · have hqu : q ≤ (31/76 : ℝ) := hsplit
            exact large_selected_greedy_t19_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (31/76 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t19_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        exact large_selected_greedy_t19_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t19_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t19_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (13/76 : ℝ)
            · have hqu : q ≤ (13/76 : ℝ) := hsplit
              exact large_selected_greedy_t19_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (13/76 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t19_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t19_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          by_cases hsplit : q ≤ (13/76 : ℝ)
          · have hqu : q ≤ (13/76 : ℝ) := hsplit
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t19_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t19_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (13/76 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t19_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t19_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (10/19 : ℝ)
      · have hqu : q ≤ (10/19 : ℝ) := hsplit
        by_cases hsplit : q ≤ (11/38 : ℝ)
        · have hqu : q ≤ (11/38 : ℝ) := hsplit
          by_cases hsplit : z ≤ (2/3 : ℝ)
          · have hzu : z ≤ (2/3 : ℝ) := hsplit
            exact large_selected_greedy_t19_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (2/3 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t19_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (11/38 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t19_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (10/19 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t19_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t19_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t20_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 84)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(10/1 : ℝ))*q ≤ 0)
    (hq0 : (1/20 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (149/1750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 92 := by
  have hql : (1/20 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (19/20 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t20_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : q ≤ (27/160 : ℝ)
          · have hqu : q ≤ (27/160 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (27/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t20_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t20_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (13/32 : ℝ)
          · have hqu : q ≤ (13/32 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (13/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        exact large_selected_greedy_t20_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t20_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (27/160 : ℝ)
            · have hqu : q ≤ (27/160 : ℝ) := hsplit
              exact large_selected_greedy_t20_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
            · have hql : (27/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t20_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : q ≤ (27/160 : ℝ)
          · have hqu : q ≤ (27/160 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (27/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t20_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t20_r3_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 20*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 86)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/20 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (149/1750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 94 := by
  have hql : (1/20 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (19/20 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t20_r3_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : q ≤ (27/160 : ℝ)
          · have hqu : q ≤ (27/160 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (27/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            by_cases hsplit : z ≤ (33/80 : ℝ)
            · have hzu : z ≤ (33/80 : ℝ) := hsplit
              exact large_selected_greedy_t20_r3_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t20_r3_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        exact large_selected_greedy_t20_r3_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t20_r3_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (27/160 : ℝ)
            · have hqu : q ≤ (27/160 : ℝ) := hsplit
              exact large_selected_greedy_t20_r3_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (27/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t20_r3_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          by_cases hsplit : q ≤ (27/160 : ℝ)
          · have hqu : q ≤ (27/160 : ℝ) := hsplit
            exact large_selected_greedy_t20_r3_all_cell_65 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (27/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t20_r3_all_cell_66 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_67 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_68 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (21/40 : ℝ)
      · have hqu : q ≤ (21/40 : ℝ) := hsplit
        by_cases hsplit : q ≤ (23/80 : ℝ)
        · have hqu : q ≤ (23/80 : ℝ) := hsplit
          exact large_selected_greedy_t20_r3_all_cell_69 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t20_r3_all_cell_70 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (21/40 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t20_r3_all_cell_71 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t20_r3_all_cell_72 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t21_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 21*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 88)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/21 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (227/2750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 96 := by
  have hql : (1/21 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (20/21 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          exact large_selected_greedy_t21_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          exact large_selected_greedy_t21_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          exact large_selected_greedy_t21_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t21_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t21_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t21_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t21_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t21_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          exact large_selected_greedy_t21_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        exact large_selected_greedy_t21_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t21_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t21_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (1/6 : ℝ)
            · have hqu : q ≤ (1/6 : ℝ) := hsplit
              exact large_selected_greedy_t21_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
            · have hql : (1/6 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t21_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          by_cases hsplit : q ≤ (1/6 : ℝ)
          · have hqu : q ≤ (1/6 : ℝ) := hsplit
            exact large_selected_greedy_t21_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (1/6 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t21_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (11/21 : ℝ)
      · have hqu : q ≤ (11/21 : ℝ) := hsplit
        by_cases hsplit : q ≤ (2/7 : ℝ)
        · have hqu : q ≤ (2/7 : ℝ) := hsplit
          exact large_selected_greedy_t21_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (2/7 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t21_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (11/21 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t21_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t21_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t22_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 22*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 92)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(11/1 : ℝ))*q ≤ 0)
    (hq0 : (1/22 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (461/5750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 100 := by
  have hql : (1/22 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (21/22 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t22_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        exact large_selected_greedy_t22_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t22_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          by_cases hsplit : q ≤ (29/176 : ℝ)
          · have hqu : q ≤ (29/176 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (29/176 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t22_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t22_r3_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 22*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 94)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/22 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (461/5750 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 102 := by
  have hql : (1/22 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (21/22 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t22_r3_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        exact large_selected_greedy_t22_r3_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t22_r3_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          by_cases hsplit : q ≤ (29/176 : ℝ)
          · have hqu : q ≤ (29/176 : ℝ) := hsplit
            exact large_selected_greedy_t22_r3_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hql : (29/176 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t22_r3_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (23/44 : ℝ)
      · have hqu : q ≤ (23/44 : ℝ) := hsplit
        by_cases hsplit : q ≤ (25/88 : ℝ)
        · have hqu : q ≤ (25/88 : ℝ) := hsplit
          exact large_selected_greedy_t22_r3_all_cell_61 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (25/88 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t22_r3_all_cell_62 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (23/44 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t22_r3_all_cell_63 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t22_r3_all_cell_64 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t23_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 23*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 96)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/23 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (39/500 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 104 := by
  have hql : (1/23 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (22/23 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t23_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t23_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          exact large_selected_greedy_t23_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          exact large_selected_greedy_t23_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t23_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          exact large_selected_greedy_t23_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          exact large_selected_greedy_t23_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        exact large_selected_greedy_t23_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t23_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t23_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t23_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          exact large_selected_greedy_t23_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (12/23 : ℝ)
      · have hqu : q ≤ (12/23 : ℝ) := hsplit
        by_cases hsplit : q ≤ (13/46 : ℝ)
        · have hqu : q ≤ (13/46 : ℝ) := hsplit
          exact large_selected_greedy_t23_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (13/46 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t23_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (12/23 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t23_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t23_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t24_r3_all_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 100)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hgood : e+(1-(12/1 : ℝ))*q ≤ 0)
    (hq0 : (1/24 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (19/250 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 108 := by
  have hql : (1/24 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (23/24 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t24_r3_all_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t24_r3_all_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : q ≤ (31/192 : ℝ)
          · have hqu : q ≤ (31/192 : ℝ) := hsplit
            exact large_selected_greedy_t24_r3_all_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hql : (31/192 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t24_r3_all_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t24_r3_all_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t24_r3_all_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t24_r3_all_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t24_r3_all_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t24_r3_all_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t24_r3_all_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgood hgate hql hqu hzl hzu

theorem large_selected_greedy_t24_r3_all_bad1
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 24*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 102)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/24 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (19/250 : ℝ) ∨ (1/5 : ℝ) ≤ q ∨ q+e ≤ (22/25 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 110 := by
  have hql : (1/24 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1/1 : ℝ) := by linarith only [hmass,ha,ho0,hz0]
  have hzl : (0/1 : ℝ) ≤ z := by linarith only [hz0]
  have hzu : z ≤ (23/24 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t24_r3_all_cell_31 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t24_r3_all_cell_32 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_33 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_34 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_35 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_36 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_37 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_38 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_39 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_40 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t24_r3_all_cell_41 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_42 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_43 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_44 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_45 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_46 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_47 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      exact large_selected_greedy_t24_r3_all_cell_48 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t24_r3_all_cell_49 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (13/40 : ℝ)
    · have hzu : z ≤ (13/40 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          by_cases hsplit : z ≤ (13/80 : ℝ)
          · have hzu : z ≤ (13/80 : ℝ) := hsplit
            exact large_selected_greedy_t24_r3_all_cell_50 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
          · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_t24_r3_all_cell_51 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_52 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_53 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_54 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_55 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_56 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : z ≤ (5/6 : ℝ)
    · have hzu : z ≤ (5/6 : ℝ) := hsplit
      by_cases hsplit : q ≤ (25/48 : ℝ)
      · have hqu : q ≤ (25/48 : ℝ) := hsplit
        by_cases hsplit : q ≤ (9/32 : ℝ)
        · have hqu : q ≤ (9/32 : ℝ) := hsplit
          exact large_selected_greedy_t24_r3_all_cell_57 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
        · have hql : (9/32 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t24_r3_all_cell_58 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
      · have hql : (25/48 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t24_r3_all_cell_59 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu
    have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t24_r3_all_cell_60 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR hgate hql hqu hzl hzu

end TSP.Improvements20261105

namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_group_25_31
    (k q e z a o S I H g : ℝ)
    (hkmin : 25 ≤ k) (hkmax : k ≤ 31)
    (he0 : 0 ≤ e) (hem : e ≤ 31*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 4*(k+1))
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (hq0 : (1/31 : ℝ) ≤ q) (hz0 : 0 ≤ z) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 4*(k+3) := by
  have hql : (1/31 : ℝ) ≤ q := hq0
  have hqu : q ≤ (1:ℝ) := by linarith only [heq,he0]
  have hzl : (0:ℝ) ≤ z := hz0
  have hzu : z ≤ (1:ℝ) := by linarith only [hmass,ha,ho0,hq0]
  by_cases hsplit : z ≤ (13/40 : ℝ)
  · have hzu : z ≤ (13/40 : ℝ) := hsplit
    by_cases hsplit : q ≤ (16/31 : ℝ)
    · have hqu : q ≤ (16/31 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/62 : ℝ)
      · have hqu : q ≤ (17/62 : ℝ) := hsplit
        by_cases hsplit : z ≤ (13/80 : ℝ)
        · have hzu : z ≤ (13/80 : ℝ) := hsplit
          by_cases hsplit : q ≤ (19/124 : ℝ)
          · have hqu : q ≤ (19/124 : ℝ) := hsplit
            exact large_selected_greedy_group_25_31_cell_0 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
          · have hql : (19/124 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_group_25_31_cell_1 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
        · have hzl : (13/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
          by_cases hsplit : q ≤ (19/124 : ℝ)
          · have hqu : q ≤ (19/124 : ℝ) := hsplit
            by_cases hsplit : z ≤ (39/160 : ℝ)
            · have hzu : z ≤ (39/160 : ℝ) := hsplit
              exact large_selected_greedy_group_25_31_cell_2 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
            · have hzl : (39/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
              by_cases hsplit : q ≤ (23/248 : ℝ)
              · have hqu : q ≤ (23/248 : ℝ) := hsplit
                by_cases hsplit : z ≤ (91/320 : ℝ)
                · have hzu : z ≤ (91/320 : ℝ) := hsplit
                  exact large_selected_greedy_group_25_31_cell_3 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
                · have hzl : (91/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_group_25_31_cell_4 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
              · have hql : (23/248 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_group_25_31_cell_5 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
          · have hql : (19/124 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_group_25_31_cell_6 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
      · have hql : (17/62 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_group_25_31_cell_7 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
    · have hql : (16/31 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_group_25_31_cell_8 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
  have hzl : (13/40 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
  by_cases hsplit : z ≤ (1/2 : ℝ)
  · have hzu : z ≤ (1/2 : ℝ) := hsplit
    by_cases hsplit : q ≤ (16/31 : ℝ)
    · have hqu : q ≤ (16/31 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/62 : ℝ)
      · have hqu : q ≤ (17/62 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/124 : ℝ)
        · have hqu : q ≤ (19/124 : ℝ) := hsplit
          by_cases hsplit : z ≤ (33/80 : ℝ)
          · have hzu : z ≤ (33/80 : ℝ) := hsplit
            by_cases hsplit : q ≤ (23/248 : ℝ)
            · have hqu : q ≤ (23/248 : ℝ) := hsplit
              by_cases hsplit : z ≤ (59/160 : ℝ)
              · have hzu : z ≤ (59/160 : ℝ) := hsplit
                by_cases hsplit : q ≤ (1/16 : ℝ)
                · have hqu : q ≤ (1/16 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_group_25_31_cell_9 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_group_25_31_cell_10 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
                · have hql : (1/16 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (111/320 : ℝ)
                  · have hzu : z ≤ (111/320 : ℝ) := hsplit
                    exact large_selected_greedy_group_25_31_cell_11 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
                  · have hzl : (111/320 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_group_25_31_cell_12 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
              · have hzl : (59/160 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_group_25_31_cell_13 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
            · have hql : (23/248 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_group_25_31_cell_14 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
          · have hzl : (33/80 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            exact large_selected_greedy_group_25_31_cell_15 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
        · have hql : (19/124 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_group_25_31_cell_16 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
      · have hql : (17/62 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_group_25_31_cell_17 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
    · have hql : (16/31 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_group_25_31_cell_18 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
  have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
  by_cases hsplit : z ≤ (5/6 : ℝ)
  · have hzu : z ≤ (5/6 : ℝ) := hsplit
    by_cases hsplit : q ≤ (16/31 : ℝ)
    · have hqu : q ≤ (16/31 : ℝ) := hsplit
      by_cases hsplit : q ≤ (17/62 : ℝ)
      · have hqu : q ≤ (17/62 : ℝ) := hsplit
        exact large_selected_greedy_group_25_31_cell_19 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
      · have hql : (17/62 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_group_25_31_cell_20 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
    · have hql : (16/31 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_group_25_31_cell_21 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)
  have hzl : (5/6 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
  exact large_selected_greedy_group_25_31_cell_22 k q e z a o S I H g hkmin hkmax he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR (by simpa only [div_one] using hql) (by simpa only [div_one] using hqu) (by simpa only [div_one] using hzl) (by simpa only [div_one] using hzu)

end TSP.Improvements20261105
