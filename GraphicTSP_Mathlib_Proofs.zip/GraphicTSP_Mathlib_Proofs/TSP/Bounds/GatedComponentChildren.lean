import TSP.Improvements20261105.DFSLeafIncidence

/-! Empty child components and their chosen original DFS leaves, grouped
by the actual unique parent component. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def GatedDrops.componentEmptyChildren (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P) : Finset (a.EmptyLeaf d P) :=
  Finset.univ.filter (fun l => a.emptyLeafParent d hs hc P l = r)

noncomputable def GatedDrops.chosenLeaves (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P) : Finset V :=
  (a.componentEmptyChildren d hs hc P r).image (a.emptyLeafVertex d P)

theorem GatedDrops.chosenLeaves_card (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P) :
    (a.chosenLeaves d hs hc P r).card = (a.componentEmptyChildren d hs hc P r).card :=
  Finset.card_image_of_injective _ (a.emptyLeafVertex_injective d P)

theorem GatedDrops.chosenLeaves_are_leaves (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P) :
    AreDFSLeaves d (a.chosenLeaves d hs hc P r) := by
  intro v hv
  obtain ⟨l, _, rfl⟩ := Finset.mem_image.mp hv
  exact (a.emptyLeafVertex_spec d P l).2

theorem GatedDrops.chosenLeaves_heads_in (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P) (r : a.Component d P) :
    LeafHeadsIn d (a.chosenLeaves d hs hc P r) (a.componentHeads d P r) := by
  intro e he
  have hb := Finset.mem_filter.mp he
  obtain ⟨l, hl, htail⟩ := Finset.mem_image.mp hb.2
  have hp := (Finset.mem_filter.mp hl).2
  have hh := a.back_from_emptyLeaf d hs hc ha l ⟨e, hb.1⟩ htail.symm
  rw [hp] at hh
  exact hh

theorem GatedDrops.componentEmptyChildren_outside_internal (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.Component d P)
    (hr : r ∉ a.internalComponents d P) : a.componentEmptyChildren d hs hc P r = ∅ := by
  apply Finset.eq_empty_iff_forall_not_mem.mpr
  intro l hl
  have he := (Finset.mem_filter.mp hl).2
  exact hr (he ▸ a.emptyLeafParent_internal d hs hc P l)

theorem GatedDrops.empty_child_fiber_sum (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) :
    (∑ r : a.Component d P, (a.componentEmptyChildren d hs hc P r).card) =
      (a.emptyLeafComponents d P).card := by
  simp only [componentEmptyChildren, Finset.card_filter]
  rw [Finset.sum_comm]
  simp [GatedDrops.EmptyLeaf]

theorem GatedDrops.internal_empty_child_sum (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) :
    (∑ r ∈ a.internalComponents d P, (a.componentEmptyChildren d hs hc P r).card) =
      (a.emptyLeafComponents d P).card := by
  rw [← a.empty_child_fiber_sum d hs hc P]
  apply Finset.sum_subset (Finset.subset_univ _)
  intro r _ hr
  rw [a.componentEmptyChildren_outside_internal d hs hc P r hr]
  rfl

theorem GatedDrops.head_charge_fiber_sum (P : GatePlan d) (a : GatedDrops d)
    (q : d.tree.Child → ℝ) :
    (∑ r : a.Component d P, ∑ s ∈ a.componentHeads d P r, q s) =
      ∑ s ∈ a.selectedHeads d, q s := by
  simp only [componentHeads, Finset.sum_filter]
  rw [Finset.sum_comm]
  rw [selectedHeads, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro s _
  by_cases hs : a.head s = 1
  · let r₀ : a.Component d P := (expandedTree d).cutComponentMap (a.trueCuts d P) (.inr s)
    have hr₀ : (r₀ : FlowVertex d) = a.component d P (.inr s) := rfl
    rw [Finset.sum_eq_single r₀]
    · simp [hs, hr₀]
    · intro r _ hne
      have hn : a.component d P (.inr s) ≠ (r : FlowVertex d) := by
        intro he
        exact hne (Subtype.ext (he.symm.trans hr₀.symm))
      simp [hn]
    · simp
  · simp [hs]

end TSP.Improvements20261105
