import TSP.Improvements20261105.CanonicalProjectedAllLeafSharedBudget
import TSP.Improvements20261105.AllLeafCountCoverage
import TSP.Improvements20261105.CanonicalProjectedAllLeafCost
import TSP.Improvements20261105.NoPairLeafFamilyCost
import TSP.Improvements20261105.NoPairGuardAccounting
import TSP.Improvements20261105.SharedNoPairLeafReserves
import TSP.Improvements20261105.CanonicalClippedLeafCouponCost
import TSP.Improvements20261105.ProjectedPaidLeafCost
import TSP.Improvements20261105.ProjectedKLeafFamilyCost
import TSP.Improvements20261105.ProjectedMultiplePairLeafCost
import TSP.Improvements20261105.ProjectedLargeRemainingLeafFamilyCost
import TSP.Improvements20261105.ProjectedSolePairLeafFamilyCost
import TSP.Improvements20261105.EnlargedOneExtraBackLeafFamilyCost
import TSP.Improvements20261105.EnlargedTwoBackSingleLeafFamilyCost
import TSP.Improvements20261105.TwoOneBackLeafFamilyCost
import TSP.Improvements20261105.TwoOneBackLeafDisjoint
import TSP.Improvements20261105.SharedTwoHeadLeafError
import TSP.Improvements20261105.CanonicalOneExtraBackLeafCost
import TSP.Improvements20261105.TwoBackSingleLeafFamilyCost
import TSP.Improvements20261105.TwoBackSingleLeafDisjoint
import TSP.Improvements20261105.SharedTwoBackLeafError
import TSP.Improvements20261105.LeafProjectionConversion
import TSP.Improvements20261105.OneExtraBackLeafFamilyCost
import TSP.Improvements20261105.OneExtraBackLeafDisjoint
import TSP.Improvements20261105.SharedLeafError
import TSP.Improvements20261105.SolePairLeafFamilyCost
import TSP.Improvements20261105.SolePairLeafDisjoint

/-! The single-extra-head/two-back family is removed from the actual
global ledger. Every entry cut and original back budget is allocated
once. Geometric and erased-mass charges retain their explicit owners. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 2000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem canonical_no_unpaid_leaf_budget (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : (d).tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (S : Finset (d).tree.Child) (hscore : ScoreComparisons d x S)
    (T : Finset (d).tree.Child) (hTS : T ⊆ S)
    (hT : ∀ s ∈ T, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (b : (d).tree.Child → ℝ) (hbcap : ∀ s, b s ≤ 1)
    (hbout : ∀ s, P.kind s = .outsideGate → b s ≤ outsideBackMass d P (fun e => x e.1) s)
    (q : (d).tree.Child → ℝ) (hq : ∀ s, 0 ≤ q s)
    (hpack : ∀ s, edgeSum z ((d).backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s, ((d).backGroup s).card ≤ 3 → ∀ e ∈ (d).backGroup s, z e ≤ q s)
    (hn : 2 ≤ Fintype.card V)
    (hprojection : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hrootStar : (d).centers rootStar = (d).tree.root)
    (R : E ⊕ (d).StarIndex → ℝ)
    (Q : E ⊕ (d).StarIndex → ℝ) (hQ : Q ∈ projectedFrameworkTwo G (d).centers owner)
    (hrep : ∀ c, Q (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Q (.inl e) = 1-x e/2)
    (m : (d).StarIndex → ℝ) (hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ m i)
    (hm : ∀ i ∈ fixedZeroTerminalHeads d x, (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
      max (x ((d).treeEdge i.1)-zeroGuardCapacity d x Q i) 0) 0 ≤ m i)
    (hmprojected : ∀ i ∈ projectedZeroTerminalHeads d z,
      (15/88 : ℝ)*max (terminalSubtreeGuardValue d x i.1-
        max (x ((d).treeEdge i.1)-projectedZeroGuardCapacity d x z Q i) 0) 0 ≤ m i)
    (hguarded : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Q i)
    (hconn : FixedQConnectorValues d x hx hn hcap R)
    (hloss : ∀ i, edgeSum Q (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Q i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hmpositive : ∀ i ∈ fixedPositiveTerminalHeads d x,
      m i = (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1)
    (hconnectors : ∀ i : (d).StarIndex, R (.inr i) = Q (.inr i))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1) :
    let L := a.paidLeafRoots d P x
    let J := a.paidLeafHeads d P x
    let KJ := pairStarHeads d (a.KLeafPairs d P x z C)
    let ML := a.multiplePairLeafRoots d P x z C
    let MJ := pairStarHeads d (a.matchingPairsForRoots d P x z C ML)
    let LL := a.largeRemainingLeafRoots d P x z C
    let LJ := a.componentStarUnion d P LL
    let SL := a.solePairLeafRoots d P x z C
    let SJ := a.componentStarUnion d P SL
    let EL := a.oneExtraBackLeafRoots d P x z C
    let EJ := a.componentStarUnion d P EL
    let BL := a.twoBackSingleLeafRoots d P x z C
    let BJ := a.componentStarUnion d P BL
    let DL := a.twoBackTwoHeadLeafRoots d P x z C
    let DJ := a.componentStarUnion d P DL
    let NL := a.noPairLeafRoots d P x z C
    let NJ := a.componentStarUnion d P NL
    let U := projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x
    let J0 := a.componentStarUnion d P (a.zeroLeafRoots d P x)
    let cost := guardedNormalizedHeadCost d x z C owner rootStar R a
    48*a.value d P (fun _ => 0)+(∑ i : (d).StarIndex, cost i)-
      (704/5 : ℝ)*(∑ i ∈ U, m i) ≤
      (∑ s ∈ a.selectedHeads d,
        (24*(edgeSum z ((d).backGroup s)-gatedFreeBase d s)+refinedIncidenceCharge d x z S T s-
          24*accountedCoupon d P b s+24*couponResidual d P (fun e => x e.1) b s))+
      (-24*((a.selectedRootHeads d).card : ℝ))-
      (162/19)*(∑ r ∈ a.internalComponents d P, (a.incidenceEdgeCount d P z S r : ℝ))+
      (1204/5)*(edgeSum x Finset.univ-Fintype.card V)-12*Chapter11.totalOverage d x+
      (4*∑ i ∈ KJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ MJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ LJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ SJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ EJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ BJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ DJ, (((d).backGroup i.1).card : ℝ))+
      (4*∑ i ∈ NJ, (((d).backGroup i.1).card : ℝ))+
      (∑ i ∈ Finset.univ \ ((((((((J ∪ KJ) ∪ MJ) ∪ LJ) ∪ SJ) ∪ EJ) ∪ BJ) ∪ DJ) ∪ NJ), cost i)-
      (704/5 : ℝ)*(∑ i ∈ U \ (a.paidLeafGuardHeads d P x ∪ NJ.filter (fun i => i ∈ U)), m i) := by
  have hledger := canonical_projected_all_leaf_shared_budget G x z hs hconnected root hc
    x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan hx hcap hz hzx S hscore T hTS hT
    b hbcap hbout q hq hpack hsmall hn hprojection C owner ho rootStar hrootStar R Q hQ
    hrep hbacks m hm0 hm hmprojected hguarded hconn hloss hmpositive hconnectors hterminal
  have hcount := a.all_leaf_count_bound d P x z C
  have hcountR : ((a.headfulLeafComponents d P).card : ℝ) ≤
      (a.paidLeafRoots d P x).card+(a.KLeafRoots d P x z C).card+
      (a.multiplePairLeafRoots d P x z C).card+(a.largeRemainingLeafRoots d P x z C).card+
      (a.solePairLeafRoots d P x z C).card+(a.oneExtraBackLeafRoots d P x z C).card+
      (a.twoBackSingleLeafRoots d P x z C).card+(a.twoBackTwoHeadLeafRoots d P x z C).card+
      (a.noPairLeafRoots d P x z C).card+1 := by exact_mod_cast hcount
  dsimp only at hledger ⊢
  linarith only [hledger,hcountR]

end TSP.Improvements20261105
