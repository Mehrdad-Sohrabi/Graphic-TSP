import TSP.Improvements20261105.CanonicalUniformIncidence
import TSP.Improvements20261105.RefinedIncidenceCharge

/-! Safely remove critical floors in non-singleton canonical parents,
keeping the same previously fixed critical membership. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_refined_parent_incidence (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : r ∈ a.internalComponents d P)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : Finset d.tree.Child) (hscore : ScoreComparisons d x C)
    (R : Finset d.tree.Child) (hRC : R ⊆ C)
    (hR : ∀ s ∈ R, 2 ≤ (a.componentHeads d P (a.headComponent d P s)).card)
    (q : d.tree.Child → ℝ) (hq : ∀ s ∈ a.componentHeads d P r, 0 ≤ q s)
    (hpack : ∀ s ∈ a.componentHeads d P r, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s ∈ a.componentHeads d P r, (d.backGroup s).card ≤ 3 →
      ∀ e ∈ d.backGroup s, z e ≤ q s) :
    24 * (1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card) ≤
      (∑ s ∈ a.componentHeads d P r, refinedIncidenceCharge d x z C R s) -
      (162 / 19) * (G.internalEdges (headCenters d
        (retainedIncidenceHeads d z (a.componentHeads d P r) C))).card +
      48 * (∑ s ∈ a.componentHeads d P r, ownProjectionLoss d x z s) +
      (124 / 5) * a.outgoingDeficit d P (fun b => x b.1) r := by
  by_cases hhit : (a.componentHeads d P r ∩ R).Nonempty
  · obtain ⟨s, hsPair⟩ := hhit
    have hsH := (Finset.mem_inter.mp hsPair).1
    have hsR := (Finset.mem_inter.mp hsPair).2
    have hcard := hR s hsR
    rw [a.headComponent_eq_of_mem d P r s hsH] at hcard
    have hC : (a.componentHeads d P r ∩ C).Nonempty :=
      ⟨s, Finset.mem_inter.mpr ⟨hsH, hRC hsR⟩⟩
    have hi := canonical_critical_parent_bound d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
      r (a.componentHeads d P r ∩ C) Finset.inter_subset_left hC (Or.inr hcard)
      x z hx hcap hz hzx (hscore.restrict d Finset.inter_subset_right) q hq hpack hsmall
    have hsum := raw_mixed_sum_le_refined d x z (a.componentHeads d P r) C R
    have hloss := leafProjectionLoss_le_heads d x z hzx _ _ (a.chosenLeaves_heads_in d hs hc ha r)
    have hdef := a.outgoingDeficit_nonneg d P (fun b => x b.1) r
    simp only [retainedIncidenceHeads, if_pos hC]
    linarith
  · have he : (∑ s ∈ a.componentHeads d P r, refinedIncidenceCharge d x z C R s) =
        ∑ s ∈ a.componentHeads d P r, fixedIncidenceCharge d x z C s := by
      apply Finset.sum_congr rfl
      intro s hs
      exact refinedIncidenceCharge_outside d x z C R s
        (fun hr => hhit ⟨s, Finset.mem_inter.mpr ⟨hs, hr⟩⟩)
    rw [he]
    exact canonical_uniform_parent_incidence d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
      r hr x z hx hcap hz hzx C hscore q hq hpack hsmall

end TSP.Improvements20261105
