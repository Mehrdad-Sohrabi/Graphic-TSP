import TSP.Improvements20261105.ClassifiedResourceGraph
import TSP.Improvements20261105.SingletonLabels

/-! Couple the actual internal-resource matching with local block pairs.
The only local interface is the prescribed pair distribution, its support,
and its unchanged internal-edge marginals. Positive joint atoms have exactly
the same selected internal edge at both ends. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter05 Classical
open scoped BigOperators
variable {V E J : Type} [Fintype V] [Fintype E] [Fintype J]
  [DecidableEq V] [DecidableEq E] [DecidableEq J]

theorem classified_pair_resource_coupling {G : Graph V E} (d : DFSData G)
    (hsimple : G.IsSimple) {x : E → ℝ} (hx : ∀ e, 0 ≤ x e)
    (v : V → J → ℝ) (P : V → J → Finset E)
    (hv : ∀ u j, 0 ≤ v u j) (hvs : ∀ u, ∑ j, v u j = 1)
    (hP : ∀ u j, P u j ⊆ minorBoundary d x u)
    (hone : ∀ u j, ((P u j) ∩ internalResourceEdges d x).card ≤ 1)
    (hm : ∀ u e, e ∈ internalResourceEdges d x → e ∈ minorBoundary d x u →
      ∑ j, v u j * incidence (P u j) e = x e / 2) :
    ∃ (K : Type) (_ : Fintype K) (W : K → ℝ) (choice : K → V → J) (R : K → Finset E),
      (∀ k, 0 ≤ W k) ∧ (∑ k, W k = 1) ∧
      (∀ u j, ∑ k, W k * (if choice k u = j then 1 else 0) = v u j) ∧
      (∀ k, R k ⊆ internalResourceEdges d x ∧ IsBMatching G (fun _ => 1) (R k)) ∧
      (∀ k, 0 < W k → ∀ u,
        P u (choice k u) ∩ internalResourceEdges d x = R k ∩ minorBoundary d x u) := by
  classical
  obtain ⟨I, hi, w, S, hw, hs, hS, hSm⟩ := classified_resource_distribution d hsimple hx
  letI := hi
  let R := fun i => includeEdges (S i)
  let A := fun u i => R i ∩ minorBoundary d x u
  let B := fun u j => P u j ∩ internalResourceEdges d x
  have hRsub : ∀ i, R i ⊆ internalResourceEdges d x := fun i => includeEdges_subset (S i)
  have hRmatch : ∀ i, IsBMatching G (fun _ => 1) (R i) := by
    intro i u
    have hh := hS i u
    change (G.restrictTo (internalResourceEdges d x)).intDegree (S i) u ≤ 1 at hh
    rw [restrict_intDegree] at hh
    exact hh
  have hA : ∀ u i, (A u i).card ≤ 1 := by
    intro u i
    have hsub : A u i ⊆ R i ∩ G.cut {u} := by
      intro e he
      exact Finset.mem_inter.mpr ⟨(Finset.mem_inter.mp he).1,
        minorBoundary_subset_cut d x u (Finset.mem_inter.mp he).2⟩
    have hc := Finset.card_le_card hsub
    have hm := hRmatch i u
    change (R i ∩ G.cut {u}).card + 2 * (R i ∩ G.loops u).card ≤ 1 at hm
    omega
  have hRm : ∀ e, (∑ i, w i * incidence (R i) e) =
      if e ∈ internalResourceEdges d x then x e / 2 else 0 := by
    intro e
    by_cases he : e ∈ internalResourceEdges d x
    · rw [if_pos he]
      have hh := hSm ⟨e, he⟩
      have hinc : ∀ i, incidence (R i) e = incidence (S i) ⟨e, he⟩ := by
        intro i
        have hmem := mem_includeEdges (S i) ⟨e, he⟩
        change e ∈ R i ↔ (⟨e, he⟩ : internalResourceEdges d x) ∈ S i at hmem
        simp only [incidence, hmem]
      simp_rw [hinc]
      exact hh
    · rw [if_neg he]
      apply Finset.sum_eq_zero
      intro i _
      have hn : e ∉ R i := fun hi => he (hRsub i hi)
      simp [incidence, hn]
  have hAm : ∀ u e, (∑ i, w i * incidence (A u i) e) =
      if e ∈ internalResourceEdges d x ∧ e ∈ minorBoundary d x u then x e / 2 else 0 := by
    intro u e
    by_cases hb : e ∈ minorBoundary d x u
    · simpa only [A, incidence, Finset.mem_inter, hb, and_true] using hRm e
    · simp [A, incidence, hb]
  have hBm : ∀ u e, (∑ j, v u j * incidence (B u j) e) =
      if e ∈ internalResourceEdges d x ∧ e ∈ minorBoundary d x u then x e / 2 else 0 := by
    intro u e
    by_cases he : e ∈ internalResourceEdges d x
    · by_cases hb : e ∈ minorBoundary d x u
      · simpa only [B, incidence, Finset.mem_inter, he, and_true, hb, and_self, if_true] using hm u e he hb
      · have hn : ∀ j, e ∉ P u j := fun j hj => hb (hP u j hj)
        simp [B, incidence, hn, hb]
    · simp [B, incidence, he]
  have hl : ∀ u k, labelMass w (fun i => singletonLabel (A u i)) k =
      labelMass (v u) (fun j => singletonLabel (B u j)) k := by
    intro u
    apply singleton_label_masses_eq w (v u) (A u) (B u) (hA u) (hone u)
      (hs.trans (hvs u).symm)
    intro e
    rw [hAm, hBm]
  let f := fun u i => singletonLabel (A u i)
  let g := fun u j => singletonLabel (B u j)
  let W := simultaneousLabelWeight w v f g
  obtain ⟨hW, hWs, hbase, hlocal, hlabels⟩ := simultaneous_label_coupling w v f g hw hs hv hl
  refine ⟨I × (V → J), inferInstance, W, Prod.snd, fun k => R k.1,
    hW, hWs, hlocal, fun k => ⟨hRsub k.1, hRmatch k.1⟩, ?_⟩
  intro k hk u
  have hh := hlabels k hk u
  exact (singletonLabel_injective (A u k.1) (B u (k.2 u)) (hA u k.1) (hone u (k.2 u)) hh).symm

end TSP.Improvements20261105
