import TSP.Improvements20261105.LargeSelectedGreedyT5R3CapCells00
import TSP.Improvements20261105.LargeSelectedGreedyT5R3CapCells01
import TSP.Improvements20261105.LargeSelectedGreedyT5R3CapCells02
import TSP.Improvements20261105.LargeSelectedGreedyT5R3CapCells03
import TSP.Improvements20261105.UniformRampLinearEnvelope
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 3000000
set_option Elab.async false
set_option linter.unusedVariables false

theorem large_selected_greedy_t5_r3_cap_bad0
    (q e z a o S I H g : ℝ)
    (he0 : 0 ≤ e) (hem : e ≤ 5*q-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (ha : 1 ≤ a)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hmass : q+o+z+a=2) (hH0 : 0 ≤ H)
    (hsource : (415/2)*(e-o)-(704/5)+24*e+S+24*g ≤ 24)
    (hSall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → q ≤ U →
      S ≤ max (24*A*(1+e)) ((360/19)*(B*(1+e)-1/10)+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0 ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0 ≤ H)
    (htarget : a ≤ 3*z)
    (hq0 : (1/5 : ℝ) ≤ q) (hz0 : 0 ≤ z)
    (hgate : q ≤ (41/150 : ℝ) ∨ (211/500 : ℝ) ≤ q ∨ q+e ≤ (91/100 : ℝ))
 :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H-24*min z (1-z)-162/19 ≤ 32 := by
  have hql : (1/5 : ℝ) ≤ q := hq0
  have hqu : q ≤ (2/3 : ℝ) := by linarith only [hmass,ha,ho0,htarget]
  have hzl : (1/3 : ℝ) ≤ z := by linarith only [ha,htarget]
  have hzu : z ≤ (4/5 : ℝ) := by linarith only [hmass,ha,ho0,hq0]
  rcases hgate with hgate | hgate | hgate
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t5_r3_cap_cell_0 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t5_r3_cap_cell_1 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      exact large_selected_greedy_t5_r3_cap_cell_2 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    exact large_selected_greedy_t5_r3_cap_cell_3 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
  · by_cases hsplit : z ≤ (1/2 : ℝ)
    · have hzu : z ≤ (1/2 : ℝ) := hsplit
      by_cases hsplit : q ≤ (13/30 : ℝ)
      · have hqu : q ≤ (13/30 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/60 : ℝ)
        · have hqu : q ≤ (19/60 : ℝ) := hsplit
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            exact large_selected_greedy_t5_r3_cap_cell_4 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (31/120 : ℝ)
            · have hqu : q ≤ (31/120 : ℝ) := hsplit
              exact large_selected_greedy_t5_r3_cap_cell_5 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (31/120 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (23/80 : ℝ)
                · have hqu : q ≤ (23/80 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r3_cap_cell_6 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (23/80 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    exact large_selected_greedy_t5_r3_cap_cell_7 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t5_r3_cap_cell_8 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                exact large_selected_greedy_t5_r3_cap_cell_9 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (19/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          by_cases hsplit : z ≤ (5/12 : ℝ)
          · have hzu : z ≤ (5/12 : ℝ) := hsplit
            by_cases hsplit : q ≤ (3/8 : ℝ)
            · have hqu : q ≤ (3/8 : ℝ) := hsplit
              by_cases hsplit : z ≤ (3/8 : ℝ)
              · have hzu : z ≤ (3/8 : ℝ) := hsplit
                exact large_selected_greedy_t5_r3_cap_cell_10 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (3/8 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (83/240 : ℝ)
                · have hqu : q ≤ (83/240 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r3_cap_cell_11 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (83/240 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t5_r3_cap_cell_12 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t5_r3_cap_cell_13 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
          · have hzl : (5/12 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
            by_cases hsplit : q ≤ (3/8 : ℝ)
            · have hqu : q ≤ (3/8 : ℝ) := hsplit
              by_cases hsplit : z ≤ (11/24 : ℝ)
              · have hzu : z ≤ (11/24 : ℝ) := hsplit
                by_cases hsplit : q ≤ (83/240 : ℝ)
                · have hqu : q ≤ (83/240 : ℝ) := hsplit
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    by_cases hsplit : q ≤ (53/160 : ℝ)
                    · have hqu : q ≤ (53/160 : ℝ) := hsplit
                      by_cases hsplit : z ≤ (41/96 : ℝ)
                      · have hzu : z ≤ (41/96 : ℝ) := hsplit
                        by_cases hsplit : q ≤ (311/960 : ℝ)
                        · have hqu : q ≤ (311/960 : ℝ) := hsplit
                          exact large_selected_greedy_t5_r3_cap_cell_14 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                        · have hql : (311/960 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                          exact large_selected_greedy_t5_r3_cap_cell_15 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (41/96 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t5_r3_cap_cell_16 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (53/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      by_cases hsplit : z ≤ (41/96 : ℝ)
                      · have hzu : z ≤ (41/96 : ℝ) := hsplit
                        exact large_selected_greedy_t5_r3_cap_cell_17 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                      · have hzl : (41/96 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                        exact large_selected_greedy_t5_r3_cap_cell_18 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    by_cases hsplit : q ≤ (53/160 : ℝ)
                    · have hqu : q ≤ (53/160 : ℝ) := hsplit
                      exact large_selected_greedy_t5_r3_cap_cell_19 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                    · have hql : (53/160 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                      exact large_selected_greedy_t5_r3_cap_cell_20 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (83/240 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  by_cases hsplit : z ≤ (7/16 : ℝ)
                  · have hzu : z ≤ (7/16 : ℝ) := hsplit
                    exact large_selected_greedy_t5_r3_cap_cell_21 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                  · have hzl : (7/16 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                    exact large_selected_greedy_t5_r3_cap_cell_22 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
              · have hzl : (11/24 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
                by_cases hsplit : q ≤ (83/240 : ℝ)
                · have hqu : q ≤ (83/240 : ℝ) := hsplit
                  exact large_selected_greedy_t5_r3_cap_cell_23 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
                · have hql : (83/240 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
                  exact large_selected_greedy_t5_r3_cap_cell_24 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
            · have hql : (3/8 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
              exact large_selected_greedy_t5_r3_cap_cell_25 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hql : (13/30 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t5_r3_cap_cell_26 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    have hzl : (1/2 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
    by_cases hsplit : q ≤ (13/30 : ℝ)
    · have hqu : q ≤ (13/30 : ℝ) := hsplit
      by_cases hsplit : z ≤ (13/20 : ℝ)
      · have hzu : z ≤ (13/20 : ℝ) := hsplit
        by_cases hsplit : q ≤ (19/60 : ℝ)
        · have hqu : q ≤ (19/60 : ℝ) := hsplit
          exact large_selected_greedy_t5_r3_cap_cell_27 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
        · have hql : (19/60 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
          exact large_selected_greedy_t5_r3_cap_cell_28 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
      · have hzl : (13/20 : ℝ) ≤ z := (lt_of_not_ge hsplit).le
        exact large_selected_greedy_t5_r3_cap_cell_29 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu
    · have hql : (13/30 : ℝ) ≤ q := (lt_of_not_ge hsplit).le
      exact large_selected_greedy_t5_r3_cap_cell_30 q e z a o S I H g he0 hem heq ho0 hoe ha hg0 hghalf hgap hmass hH0 hsource hSall hIall hHL hHR htarget hgate hql hqu hzl hzu

end TSP.Improvements20261105
