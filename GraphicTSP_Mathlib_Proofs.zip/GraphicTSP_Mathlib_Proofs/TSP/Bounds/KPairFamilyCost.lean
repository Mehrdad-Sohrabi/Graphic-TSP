import TSP.Improvements20261105.ActualKPairCost

/-! Protected unmatched pairs pay one whole leaf charge using their
own original back counts, for the current P and simultaneous guarded Q. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_K_pair_family_cost
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s) -
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415 / 2) (704 / 5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (Qbase : E ⊕ (d).StarIndex → ℝ)
    (hrep : ∀ c, Qbase (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Qbase (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Qbase (starRepresentatives (d).stars i)-edgeSum Y (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ fixedZeroTerminalHeads d x then zeroGuardCapacity d x Qbase i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum Y (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (P : GatePlan d) (a : GatedDrops d) (ha : a.Admissible d P)
    (J : Finset ((d).StarIndex × (d).StarIndex)) (hJ : J ⊆ KUnmatchedStarPairs d x z C) :
    (∑ i ∈ pairStarHeads d J, guardedNormalizedHeadCost d x z C owner rootStar Y a i)+
      24*(J.card : ℝ) ≤ 4*∑ i ∈ pairStarHeads d J, (((d).backGroup i.1).card : ℝ) := by
  have hsum := Finset.sum_le_sum (fun p hp => scoredDFS_K_pair_normalized_cost G x z hs hc root
    hx hn hcap hm C owner ho rootStar hroot Y hY Qbase hrep hbacks hloss hterminal P a ha p (hJ hp))
  rw [KStarPair_family_sum d hs x z hx hn hcap hm C J hJ
    (fun i => guardedNormalizedHeadCost d x z C owner rootStar Y a i)]
  rw [KStarPair_family_sum d hs x z hx hn hcap hm C J hJ
    (fun i => (((d).backGroup i.1).card : ℝ))]
  simp only [Finset.sum_add_distrib,Finset.sum_const,nsmul_eq_mul,Finset.mul_sum] at hsum ⊢
  rw [← Finset.mul_sum,← Finset.mul_sum] at hsum
  linarith

end TSP.Improvements20261105
