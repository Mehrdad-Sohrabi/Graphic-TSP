import TSP.Improvements20261105.CurrentProjectedDeficitEstimates
import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)
variable (hs : G.IsSimple) (x z : E → ℝ) (hx : G.SubtourFeasible x)
variable (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
variable (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
  fixedRemoval d x (allFullOverrideTargets d x) s)
variable (C : ProjectedCoverWitness d x z (415/2) (704/5))
variable (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
variable (R : E ⊕ d.StarIndex → ℝ) (i : d.StarIndex)
variable (hR : (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
  -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)

include hs hx hn hcap hm hR in
theorem current_projected_even_positive_deficit (hnr : d.centers i ≠ d.tree.root)
    (hp : 1 < edgeSum z (d.backGroup i.1))
    (hu : i.1 ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hev : Even (G.intDegree d.treeEdges (d.centers i))) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        -(704/5)*(x (d.treeEdge i.1)+preliminaryQIncrease d x i.1) := by
  change d.tree.parent (i.1 : V) ≠ d.tree.root at hnr
  change Even (G.intDegree d.treeEdges (d.tree.parent (i.1 : V))) at hev
  have hb := current_positive_deficit_bound d hs x z hx hn hcap hm C owner rootStar R i hR hp
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  rw [max_eq_left (by linarith)] at he
  have hc := coveredPIncrease_deficit d hs x z hx hn hcap hm (415/2) (704/5)
    (by norm_num) (by norm_num) C i.1 hnr
  rw [C.unmatched_floor i.1 hu,fixedCoverFloor,if_neg hnr,if_pos hev,if_pos hp] at hc
  have hg := forcedCoverIncrease_ge_base d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C) i.1
  linarith only [hb,he,hc,hg]

end TSP.Improvements20261105
