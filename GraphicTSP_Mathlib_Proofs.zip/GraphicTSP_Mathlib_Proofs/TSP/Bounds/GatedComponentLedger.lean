import TSP.Improvements20261105.GatedInternalComponents
import TSP.Improvements20261105.JointCoordinateCompletion

/-! Exact component accounting for the unaugmented dual. Headful leaves
are distinguished using actual back groups, regardless of selection. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

abbrev GatedDrops.Component (P : GatePlan d) (a : GatedDrops d) :=
  (expandedTree d).CutComponent (a.trueCuts d P)

noncomputable def GatedDrops.actualComponentHeads (P : GatePlan d) (a : GatedDrops d) (r : FlowVertex d) :
    Finset d.tree.Child :=
  Finset.univ.filter (fun v => (d.backGroup v).Nonempty ∧ a.component d P (.inr v) = r)

noncomputable def GatedDrops.internalComponents (P : GatePlan d) (a : GatedDrops d) : Finset (a.Component d P) :=
  Finset.univ.filter (fun r => (a.componentOutgoingCuts d P r).Nonempty)

noncomputable def GatedDrops.emptyLeafComponents (P : GatePlan d) (a : GatedDrops d) : Finset (a.Component d P) :=
  Finset.univ.filter (fun r => ¬(a.componentOutgoingCuts d P r).Nonempty ∧ ¬(a.actualComponentHeads d P r).Nonempty)

noncomputable def GatedDrops.headfulLeafComponents (P : GatePlan d) (a : GatedDrops d) : Finset (a.Component d P) :=
  Finset.univ.filter (fun r => ¬(a.componentOutgoingCuts d P r).Nonempty ∧ (a.actualComponentHeads d P r).Nonempty)

noncomputable def GatedDrops.selectedHeads (a : GatedDrops d) : Finset d.tree.Child :=
  Finset.univ.filter (fun v => a.head v = 1)

noncomputable def GatedDrops.selectedRootHeads (a : GatedDrops d) : Finset d.tree.Child :=
  Finset.univ.filter (fun v => a.head v = 1 ∧ d.tree.parent v = d.tree.root)

theorem GatedDrops.component_partition_count (P : GatePlan d) (a : GatedDrops d) :
    (a.internalComponents d P).card + (a.emptyLeafComponents d P).card +
      (a.headfulLeafComponents d P).card = (a.trueCuts d P).card + 1 := by
  rw [← a.true_component_count d P]
  simp only [internalComponents, emptyLeafComponents, headfulLeafComponents,
    Finset.card_filter, ← Finset.sum_add_distrib]
  calc
    _ = ∑ _r : a.Component d P, (1 : ℕ) := by
      apply Finset.sum_congr rfl
      intro r _
      by_cases hi : (a.componentOutgoingCuts d P r).Nonempty <;>
        by_cases hh : (a.actualComponentHeads d P r).Nonempty <;> simp [hi, hh]
    _ = _ := by simp

theorem GatedDrops.base_head_price_count {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) :
    (∑ v : d.tree.Child, (gatedFreeBase d v : ℝ) * (a.head v : ℝ)) =
      ((a.selectedHeads d).card : ℝ) + ((a.selectedRootHeads d).card : ℝ) := by
  have hlocal (v : d.tree.Child) : (gatedFreeBase d v : ℝ) * (a.head v : ℝ) =
      (if a.head v = 1 then (1 : ℝ) else 0) +
      (if a.head v = 1 ∧ d.tree.parent v = d.tree.root then (1 : ℝ) else 0) := by
    rcases a.head_binary d ha v with hz | hz <;>
      by_cases hr : d.tree.parent v = d.tree.root <;> norm_num [gatedFreeBase, hz, hr]
  simp_rw [hlocal]
  rw [Finset.sum_add_distrib]
  simp [selectedHeads, selectedRootHeads]

theorem GatedDrops.component_dual_ledger (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P) :
    a.value d P (fun _ => 0) =
      ((a.internalComponents d P).card : ℝ) + ((a.emptyLeafComponents d P).card : ℝ) +
      ((a.headfulLeafComponents d P).card : ℝ) - 1 -
      ((a.selectedHeads d).card : ℝ) - ((a.selectedRootHeads d).card : ℝ) -
      ∑ v : d.tree.Child, (a.penalty d P v : ℝ) := by
  have hreward : (∑ v : d.tree.Child, (a.reward d P v : ℝ)) = ((a.trueCuts d P).card : ℝ) := by
    exact_mod_cast a.trueCuts_reward_card d hs hc ha
  have hcount : ((a.internalComponents d P).card : ℝ) + ((a.emptyLeafComponents d P).card : ℝ) +
      ((a.headfulLeafComponents d P).card : ℝ) = ((a.trueCuts d P).card : ℝ) + 1 := by
    exact_mod_cast a.component_partition_count d P
  simp only [GatedDrops.value, add_zero, Finset.sum_sub_distrib]
  rw [hreward, a.base_head_price_count d ha]
  linarith

theorem GatedDrops.selected_head_fiber_sum (P : GatePlan d) (a : GatedDrops d) :
    (∑ r : a.Component d P, (a.componentHeads d P r).card) = (a.selectedHeads d).card := by
  have hlocal (v : d.tree.Child) :
      (∑ r : a.Component d P, if a.head v = 1 ∧ a.component d P (.inr v) = (r : FlowVertex d) then (1 : ℕ) else 0) =
      if a.head v = 1 then 1 else 0 := by
    by_cases hv : a.head v = 1
    · let r₀ : a.Component d P := (expandedTree d).cutComponentMap (a.trueCuts d P) (.inr v)
      have hr₀ : (r₀ : FlowVertex d) = a.component d P (.inr v) := rfl
      rw [Finset.sum_eq_single r₀]
      · simp [hv, hr₀]
      · intro r _ hne
        have hn : a.component d P (.inr v) ≠ (r : FlowVertex d) := by
          intro he
          exact hne (Subtype.ext (he.symm.trans hr₀.symm))
        simp [hn]
      · simp
    · simp [hv]
  simp only [GatedDrops.componentHeads, Finset.card_filter]
  rw [Finset.sum_comm]
  simp_rw [hlocal]
  simp [selectedHeads]

end TSP.Improvements20261105
