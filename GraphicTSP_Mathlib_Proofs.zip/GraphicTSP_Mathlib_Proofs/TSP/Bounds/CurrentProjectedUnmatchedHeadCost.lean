import TSP.Improvements20261105.CurrentProjectedKZeroReceiver
import TSP.Improvements20261105.CurrentProjectedGuardedCoverCost
import TSP.Improvements20261105.KOriginOwnership

/-! The actual simultaneous construction retains a strictly negative
bound at a projected-zero receiver of an unmatched protected link.
Actual-zero and erased-positive receivers are both included. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_unmatched_unprotected_receiver_nonpositive (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (i : d.StarIndex) (hnr : d.centers i ≠ d.tree.root)
    (hu : i.1 ∉ matchingEndpoints id (unaryNext d) C.matching)
    (hnotK : i.1 ∉ (KUnmatchedOrigins d x z (415/2) (704/5) 60 C).image (unaryNext d)) :
    max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ 0 := by
  classical
  have hcov : C.cover i.1 ≤ 0 := by
    rw [C.unmatched_floor i.1 hu]
    exact fixedCoverFloor_nonpositive d hs x z hx hcap (704/5) (by norm_num) i.1
  have hd := current_projected_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar
    Y R hY hrep hbacks hloss hterminal hzero i hnr
  have hbase := current_projected_guarded_max_cover d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero i hnr
  by_cases hc : childCount d (d.centers i) = 1
  · let v : d.tree.Child := ⟨d.centers i,hnr⟩
    have hv : d.centers i = (v : V) := rfl
    have hcv : childCount d v = 1 := hc
    let H := fixedHForceTargets d x z (415/2) (704/5) C
    have hH := fixedHForceTargets_subset d x z (415/2) (704/5) C
    have hT : ∀ s ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d s := by
      intro s hsT
      obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hsT
      exact (Finset.mem_filter.mp hj).2.1
    by_cases hHv : v ∈ H
    · have hir : i ≠ rootStar := fun he => hnr (he ▸ hroot)
      have hh := terminal_H_forced_PQ_connector d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
        (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) C H hH (fixedPositiveTerminalChildren d x) hT
        owner ho rootStar R hR i hir v hv hcv hHv
      change pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
        (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤ _ at hh
      have hs0 : 0 ≤ targetForceSlack d x 24 4 v := le_max_right _ _
      have hm0 : max (C.cover i.1) (-targetForceSlack d x 24 4 v) ≤ 0 :=
        max_le hcov (neg_nonpos.mpr hs0)
      apply (sub_le_iff_le_add).mpr
      apply max_le <;> linarith
    · have hforce : forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H v =
          protectedCoverIncrease d x z (415/2) (704/5) 60 C v := by
        rw [forcedCoverIncrease,if_neg hHv]
      have hnext : unaryNext d v = i.1 := ((unaryNext_spec d v hcv).2 i.1 hv).symm
      by_cases heff : coveredPIncrease d x (415/2) (704/5) C.cover v <
          protectedCoverIncrease d x z (415/2) (704/5) 60 C v
      · have hp : ProtectedHead d x z (415/2) (704/5) C v := by
          by_contra h
          simpa [protectedCoverIncrease,h] using heff
        have hl : v ∈ projectionLinks d x := by
          by_contra hl
          have hb := (protectedCoverIncrease_bounds d hs x z hx hn hcap hm (415/2) (704/5) 60
            (by norm_num) (by norm_num) (by norm_num) (by norm_num) C v).2.2
          rw [coveredPIncrease,if_neg hp.1,if_neg hl] at heff
          linarith
        have hz : edgeSum z (d.backGroup i.1) ≤ 1 := by
          by_contra hh
          have he := fixed_projected_excess_eq d hs x z hx hn _ hm i.1
          have hpos : 0 < survivingExcess d x i.1 := by
            rw [← he]
            exact lt_max_of_lt_left (by linarith)
          apply hnotK
          apply Finset.mem_image.mpr
          refine ⟨v,Finset.mem_filter.mpr ⟨Finset.mem_univ _,heff,hcv,?_,?_⟩,hnext⟩
          · rwa [hnext]
          · rwa [hnext]
        have hh := current_projected_K_zero_receiver_max d hs x z hx hn hcap hm C owner ho rootStar hroot
          Y R hY hR hrep hbacks hloss hterminal hzero i v hv hl hp.2.2 hz
        have hg := (Finset.mem_filter.mp hl).2.2.2.2
        linarith
      · have hge := (protectedCoverIncrease_bounds d hs x z hx hn hcap hm (415/2) (704/5) 60
          (by norm_num) (by norm_num) (by norm_num) (by norm_num) C v).1
        have heq : protectedCoverIncrease d x z (415/2) (704/5) 60 C v =
            coveredPIncrease d x (415/2) (704/5) C.cover v := le_antisymm (le_of_not_gt heff) hge
        have hc0 : currentIncomingForceCharge d x z C i = 0 := by
          rw [currentIncomingForceCharge,dif_pos hnr,if_pos hc]
          change (415/2 : ℝ)*(forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H v-
            coveredPIncrease d x (415/2) (704/5) C.cover v) = 0
          rw [hforce,heq,sub_self,mul_zero]
        rw [hc0] at hbase
        linarith
  · have hc0 : currentIncomingForceCharge d x z C i = 0 := by
      rw [currentIncomingForceCharge,dif_pos hnr,if_neg hc]
    rw [hc0] at hbase
    linarith

end TSP.Improvements20261105
