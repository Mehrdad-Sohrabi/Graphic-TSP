import TSP.Improvements20261105.CurrentProjectedDeficitEstimates
import TSP.Improvements20261105.HighQZeroSourceScalar
import TSP.Improvements20261105.NoncriticalCountLoad
import TSP.Improvements20261105.ActualHighQLoads

/-! The projected-small-receiver source payment uses the actual scored
DFS, fixed projection and forced P/Q deficit. No finite certificate is assumed. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem actual_high_q_effective_source
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (rootStar : (d).StarIndex)
    (Y : E ⊕ (d).StarIndex → ℝ) (i : (d).StarIndex)
    (hY : ((d).stars i).card-1-edgeSum Y (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
      -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hprotected : ProtectedHead d x z (415/2) (704/5) C i.1)
    (hq : 1/2 ≤ x ((d).treeEdge i.1)) (ho : outgoingBackMass d x i.1 ≤ survivingExcess d x i.1)
    (eligible R : Finset (d).tree.Child) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1+
      24*(edgeSum z ((d).backGroup i.1)-1)+
      refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) R i.1-
      24*((1-x ((d).treeEdge i.1))+(1-x ((d).treeEdge i.1)-outgoingBackMass d x i.1)) ≤
        4*((((d).backGroup i.1).card : ℝ)) := by
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  have hpos : 1 < edgeSum z ((d).backGroup i.1) := by
    have hp := hprotected.2.1
    rw [← he] at hp
    have hh := (lt_max_iff.mp hp).resolve_right (lt_irrefl _)
    linarith
  rw [max_eq_left (by linarith)] at he
  have hg := scoredDFS_high_q_greedy G x hs hc root i.1 hq
  have htprod := positive_greedy_back_product d x hx hn i.1 hprotected.2.1 hg
  have ht : 2 ≤ ((d).backGroup i.1).card := by
    by_contra h
    have hcN : ((d).backGroup i.1).card ≤ 1 := by omega
    have hcR : ((((d).backGroup i.1).card : ℝ)) ≤ 1 := by exact_mod_cast hcN
    have hmul := mul_le_mul_of_nonneg_right hcR (hx.1 ((d).treeEdge i.1))
    linarith [hcap ((d).treeEdge i.1)]
  have hr1 := current_projected_protected_deficit d hs x z hx hn hcap hm C owner rootStar Y i hY hprotected
  rw [min_eq_right (by linarith)] at hr1
  have hr2 := current_projected_intrinsic_deficit d hs x z hx hn hcap hm C owner rootStar Y i hY hprotected.1 hpos ho
  have hload := scoredDFS_high_q_selected_load G x z hs hc root hx hn hcap hz hzx hm eligible R i.1 hq
  have hI := (refined_fixed_incidence_le_noncritical d x z eligible R i.1).trans
    (noncriticalIncidence_le_count d z i.1)
  have hE := (survivingExcess_bounds d hs hx hcap i.1).2
  have ho0 : 0 ≤ outgoingBackMass d x i.1 := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hh := high_q_zero_source_count_scalar ((d).backGroup i.1).card
    (survivingExcess d x i.1) (x ((d).treeEdge i.1)) (outgoingBackMass d x i.1)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) Y i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)
    (24*(edgeSum z ((d).backGroup i.1)-1)+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) R i.1)
    ht hE ho0 hr1 hr2 hload (by linarith)
  linarith only [hh]

end TSP.Improvements20261105
