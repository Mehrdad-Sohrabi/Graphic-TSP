import TSP.Improvements20261105.GatedDropCoordinates

/-! The path inequalities are sufficient as well as necessary: they
reconstruct a feasible potential on every arc of the actual network. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

structure GatedDrops.Admissible (P : GatePlan d) (a : GatedDrops d) : Prop where
  pref_nonneg : ∀ v, 0 ≤ a.pref v
  suffix_nonneg : ∀ v, 0 ≤ a.suffix v
  representative_nonneg : ∀ v, 0 ≤ a.representative v
  head_nonneg : ∀ v, 0 ≤ a.head v
  tail_nonneg : ∀ v, 0 ≤ a.tail v
  outside_nonneg : ∀ v, 0 ≤ a.outside v
  paid : ∀ v, a.head v + a.suffix v + (if P.IsReceiver d v then 0 else a.pref v) ≤ 1
  back : ∀ b : BackEdge d, a.pathCost d b + (a.tail (d.lower b.1) : ℝ) +
    (if P.OutsideBack d b then (a.outside (d.anchor b.1) : ℝ) else 0) ≤
      (a.head (d.anchor b.1) : ℝ)

theorem gatedDropsOf_admissible {P : GatePlan d} {p : GatedVertex d → ℤ}
    (hp : GatedDualFeasible d P p) : (gatedDropsOf d p).Admissible d P := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro v
    have hh := gated_dual_prefix d hp v
    change 0 ≤ gatedPrefixDrop d p v
    unfold gatedPrefixDrop
    omega
  · intro v
    have hh := gated_dual_suffix d hp v
    change 0 ≤ gatedSuffixDrop d p v
    unfold gatedSuffixDrop
    omega
  · intro v
    have hh := gated_dual_representative d hp v
    change 0 ≤ gatedRepresentativeDrop d p v
    unfold gatedRepresentativeDrop
    omega
  · intro v
    have hh := gated_head_selector_binary d P p hp v
    change 0 ≤ gatedHeadSelector d p v
    omega
  · intro v
    have hh := gated_dual_tail d hp v
    change 0 ≤ gatedTailDrop d p v
    unfold gatedTailDrop
    omega
  · intro v
    have hh := gated_dual_outside d hp v
    change 0 ≤ gatedOutsideDrop d p v
    unfold gatedOutsideDrop
    omega
  · intro v
    by_cases hv : P.IsReceiver d v
    · simpa [gatedDropsOf, hv] using gated_head_suffix_exclusive d hp v
    · have hh := gated_head_connector_exclusive d hp v hv
      have he := gated_split_drop_identity d p v
      simp only [gatedDropsOf, if_neg hv]
      omega
  · intro b
    rw [gatedDropsOf_pathCost]
    exact gated_back_path_constraint d hp b

theorem GatedDrops.potential_feasible (P : GatePlan d) (a : GatedDrops d)
    (ha : a.Admissible d P) : GatedDualFeasible d P (a.potential d P) := by
  intro e he
  rcases e with ((v | v) | b) | (v | ⟨v, k⟩)
  · have hh := ha.suffix_nonneg v
    simpa [gatedNetwork, gatedCost] using neg_nonpos.mpr hh
  · have hh := ha.representative_nonneg v
    simpa [gatedNetwork, gatedCost] using neg_nonpos.mpr hh
  · have hb := ha.back b
    rw [← a.potential_pathCost d P b, gated_tree_path_telescope] at hb
    simp only [potential_aux, potential_center, Int.cast_add] at hb
    by_cases ho : P.OutsideBack d b
    · rw [if_pos ho] at hb
      have hbi : a.center d (d.anchor b.1) + a.representative (d.anchor b.1) -
          a.center d (d.lower b.1) + a.tail (d.lower b.1) + a.outside (d.anchor b.1) ≤
          a.head (d.anchor b.1) := by exact_mod_cast hb
      simp only [gatedNetwork, gatedCost, Sum.elim_inl, Sum.elim_inr, if_pos ho,
        potential_outside, potential_tail, Nat.cast_zero]
      omega
    · rw [if_neg ho, add_zero] at hb
      have hbi : a.center d (d.anchor b.1) + a.representative (d.anchor b.1) -
          a.center d (d.lower b.1) + a.tail (d.lower b.1) ≤ a.head (d.anchor b.1) := by
        exact_mod_cast hb
      simp only [gatedNetwork, gatedCost, Sum.elim_inl, Sum.elim_inr, if_neg ho,
        potential_head, potential_tail, Nat.cast_zero]
      omega
  · have hh := ha.tail_nonneg v
    simpa [gatedNetwork, gatedCost] using neg_nonpos.mpr hh
  · have hpre := ha.pref_nonneg v
    have hhead := ha.head_nonneg v
    have hout := ha.outside_nonneg v
    have hpaid := ha.paid v
    have hpar := a.center_parent d v
    fin_cases k
    · simp only [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost,
        Sum.elim_inl, Sum.elim_inr, potential_gate, potential_center]
      norm_num
      omega
    · simp [gatedUpper] at he
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost] using neg_nonpos.mpr hhead
    · change a.potential d P (if P.IsReceiver d v then gatedGate d v else gatedCenter d (d.tree.parent v)) -
        a.potential d P (gatedHead d v) ≤ 1
      by_cases hv : P.IsReceiver d v
      · simp [hv] at hpaid
        simp only [if_pos hv, potential_gate, potential_head]
        omega
      · rw [if_neg hv] at hpaid
        simp only [if_neg hv, potential_center, potential_head]
        omega
    · simp [gatedUpper] at he
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost] using neg_nonpos.mpr hout
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, sub_nonpos] using
        le_max_left (a.center d v - a.tail v)
          (a.center d (P.receiver v) + a.representative (P.receiver v) + a.suffix (P.receiver v))
    · have hk : P.kind v = .sharedGate := by simpa [gatedUpper] using he
      simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedCost, hk, sub_nonpos] using
        le_max_right (a.center d v - a.tail v)
          (a.center d (P.receiver v) + a.representative (P.receiver v) + a.suffix (P.receiver v))

theorem GatedDrops.pathCost_nonneg {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) : 0 ≤ a.pathCost d b := by
  have hh := (gated_path_parts_nonnegative d (a.potential_feasible d P ha) b).1
  simpa using hh

theorem GatedDrops.head_binary {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (v : d.tree.Child) : a.head v = 0 ∨ a.head v = 1 := by
  simpa using gated_head_selector_binary d P (a.potential d P) (a.potential_feasible d P ha) v

end TSP.Improvements20261105
