import TSP.Improvements20261105.ColoredEdgeEndpoints

/-! Exact finite cover with arbitrary, possibly negative, vertex floors.
The matching is constructed and contains only positive shifted-weight edges. -/
namespace TSP.Improvements20261105
open Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem full_floor_cover (A B : E → V) (P : V → Prop)
    (hP : ∀ e, P (A e) ↔ ¬P (B e)) (floor : V → ℝ) (ell : E → ℝ) :
    ∃ M : Finset E, ∃ z : V → ℝ,
      (∀ e ∈ M, ∀ f ∈ M, ∀ a, (a = A e ∨ a = B e) → (a = A f ∨ a = B f) → e = f) ∧
      (∀ e ∈ M, 0 < ell e - floor (A e) - floor (B e)) ∧
      (∀ a, floor a ≤ z a) ∧
      (∀ e, ell e ≤ z (A e) + z (B e)) ∧
      (∑ a, z a) = (∑ a, floor a) + ∑ e ∈ M, (ell e - floor (A e) - floor (B e)) := by
  let w : E → ℝ := fun e => ell e - floor (A e) - floor (B e)
  obtain ⟨M, u, v, hl, hr, hw, hu, hv, hc, heq⟩ :=
    weighted_bipartite_positive_cover (coloredLeft A B P hP) (coloredRight A B P hP) w
  let price : V → ℝ := combinedColorPrice P u v
  let z : V → ℝ := fun a => floor a + price a
  have hn (a : V) : 0 ≤ price a := by
    dsimp [price, combinedColorPrice]
    split_ifs with h
    · exact hu _
    · exact hv _
  refine ⟨M, z, colored_matching_endpoints A B P hP M hl hr, hw, ?_, ?_, ?_⟩
  · intro a; dsimp [z]; exact le_add_of_nonneg_right (hn a)
  · intro e
    have hh := hc e
    rw [colored_endpoints_sum] at hh
    change ell e - floor (A e) - floor (B e) ≤ price (A e) + price (B e) at hh
    dsimp [z]
    linarith
  · change (∑ a, (floor a + combinedColorPrice P u v a)) = _
    rw [Finset.sum_add_distrib, combinedColorPrice_sum, heq]

end TSP.Improvements20261105
