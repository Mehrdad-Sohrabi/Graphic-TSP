import TSP.Improvements20261105.ScoredSourceFiniteContinuous
import TSP.Improvements20261105.GoodPartitionMassBound
import TSP.Improvements20261105.ScoredUniformNetLoad

/-! Continuous source estimates instantiated with the actual star weights,
fixed incidence charge and original unit-part capacities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_small_scored_source_load_uncouponed
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hsc : ScoredStar d x s) (hel : s ∈ eligible)
    (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hout : outgoingBackMass d x s ≤ survivingExcess d x s)
    (hcount : ((d).backGroup s).card ≤ 18)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      24*survivingExcess d x s+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  let n := ((d).backGroup s).card
  let M := starMaximum d x s
  let q := x ((d).treeEdge s)
  let u := min (outgoingBackMass d x s) (1-M)
  let a := edgeSum z ((d).backGroup s)
  let B := winningBenchmark d x s
  let I := refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s
  have hq0 : 0 ≤ q := hx.1 _
  have hqM : q ≤ M := le_finiteMaximum x ((d).mem_group s _ |>.mpr ((d).anchor_treeEdge s))
  have hM0 : 0 ≤ M := hq0.trans hqM
  have hMhi : M ≤ 43/100 := hsc.2.2.2.2.2.trans (ScoredParameters.upper_bounds _).2
  have ho0 : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  have hu0 : 0 ≤ u := le_min ho0 (by linarith)
  have huO : u ≤ outgoingBackMass d x s := min_le_left _ _
  have huM : u ≤ 1-M := min_le_right _ _
  have hBM : M ≤ B := scoredDFS_maximum_le_benchmark G x hs hc root hx.1 hcap s hsc
  have hBeq : B=q+ScoredParameters.coefficient n*u := rfl
  have hB0 : 0 ≤ B := hq0.trans (hqM.trans hBM)
  have hLam := ScoredParameters.coefficient_bounds n
  have hB1 : B ≤ 1 := by
    have hmu := mul_le_mul_of_nonneg_right hLam.2.le hu0
    rw [hBeq]
    linarith only [hqM,huM,hmu]
  have hN : 1 ≤ sourceScoreDenominator n := by
    unfold sourceScoreDenominator
    split_ifs <;> norm_num
  have hNR : 0 < (sourceScoreDenominator n : ℝ) := by exact_mod_cast hN
  obtain ⟨j,hj,hjlo,hjhi⟩ := exists_mass_interval (sourceScoreDenominator n)
    (1/(sourceScoreDenominator n : ℝ)) B hN (by positivity) hB0
    (by simpa [ne_of_gt hNR] using hB1)
  have hslo : (j : ℝ)/(sourceScoreDenominator n : ℝ) ≤ B := by simpa [div_eq_mul_inv] using hjlo
  have hshi : B ≤ ((j : ℝ)+1)/(sourceScoreDenominator n : ℝ) := by simpa [div_eq_mul_inv] using hjhi
  have hcapz (e : E) (he : e ∈ (d).backGroup s) : z e ≤ M :=
    (hzx e).trans (le_finiteMaximum x (Finset.mem_sdiff.mp he).1)
  have hmcount : a ≤ (n : ℝ)*M := by
    have hh := Finset.sum_le_sum (s := (d).backGroup s) hcapz
    simpa [edgeSum,a,n,M] using hh
  obtain ⟨k,hk,hka,hak⟩ := exists_mass_interval n M a (by have hh:=hsc.2.1; omega) hM0 (by linarith) hmcount
  have hraw1 := rawCriticalIncidence_packed_score d x z s M k (fun e _ => hz e) hcapz
  have hraw2 := rawCriticalIncidence_joint_linear d x z s (sourceScoreSlope n j) (by
    intro e he
    have hBz : z e ≤ B := (hcapz e he).trans hBM
    have hh := scored_source_finite_per_back n j hsc.2.1 hcount hj B (z e) (hz e) hBz hshi
    convert hh using 1 <;> norm_num [incidenceRamp,ScoredParameters.perBackPayment,ScoredParameters.massSlope] <;> rfl)
  have hraw3 : rawCriticalIncidence d x z s ≤
      (if n=7 then sourceScoreSecantSlope n j*a+(n : ℝ)*sourceScoreSecantOffset n j-(360/19)*(1/10)-96/19
       else sourceScoreSlope n j*a-(360/19)*(1/10)-96/19) := by
    by_cases ht : n=7
    · rw [if_pos ht]
      apply rawCriticalIncidence_joint_affine d x z s (sourceScoreSecantSlope n j) (sourceScoreSecantOffset n j)
      intro e he
      have hBz : z e ≤ B := (hcapz e he).trans hBM
      have hh := scored_source_7_per_back_affine j (by simpa [ht,sourceScoreDenominator] using hj)
        B (z e) (hz e) hBz (by simpa [ht,sourceScoreDenominator] using hshi)
      convert hh using 1 <;> norm_num [incidenceRamp,ScoredParameters.perBackPayment,ScoredParameters.massSlope,
        show ((d).backGroup s).card=7 from ht, ht,ScoredParameters.localMassSlope,ScoredParameters.upper,ScoredParameters.coefficient] <;> rfl
    · rw [if_neg ht]
      exact hraw2
  have hC := (refined_fixed_incidence_le_clipped d x z eligible T s hel).trans
    (max_le_max (le_min hraw1 (le_min hraw2 hraw3)) (le_refl (-(124/5 : ℝ)*(2-a))))
  have hNinc := (refined_fixed_incidence_le_noncritical d x z eligible T s).trans
    (noncritical_signed_packing_envelope d z s M k (fun e _ => hz e) hcapz)
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hgoodR : n%2=0 → bad=0 → a+q-1 ≤ ((n : ℝ)/2)*M := by
    intro hpar hb
    have hn2 : n=2*(n/2) := by omega
    have hh := unitPartCapacities_star_even_bound d hs x z hx.1 hz hzx htree s (hgood hpar hb)
      (n/2) hn2
    have hnR : (n : ℝ)=2*((n/2 : ℕ) : ℝ) := by exact_mod_cast hn2
    change q+a ≤ 1+((n/2 : ℕ) : ℝ)*M at hh
    rw [hnR]
    linarith only [hh]
  have hrow := scored_source_finite_continuous n j k bad hsc.2.1 hcount hj hk hbad M q u a I δ
    hsc.2.2.2.2.1 hsc.2.2.2.2.2 hq0 hqM hu0 (by simpa only [hBeq] using hBM)
    (by linarith only [huM]) hpositive.le hmcount (by change a+q ≤ 2; linarith only [hpack])
    (by change u ≤ a-1; linarith only [huO,hout,he]) hka hak
    (by simpa only [hBeq] using hslo) (by simpa only [hBeq] using hshi)
    hδ0 (hδ.trans (min_le_right _ _)) (by have hh:=hδ.trans (min_le_left _ _); change δ+q+a≤2; linarith only [hh,he])
    hgoodR hNinc (by simpa only [← hBeq] using hC)
  linarith only [hrow,huO,he]

theorem scoredDFS_small_scored_source_load
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hsc : ScoredStar d x s) (hel : s ∈ eligible)
    (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hout : outgoingBackMass d x s ≤ survivingExcess d x s)
    (hcount : ((d).backGroup s).card ≤ 18)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  have hu := scoredDFS_small_scored_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx htree hm eligible T s hsc hel hpositive hout hcount bad hbad hgood δ hδ0 hδ
  have hl := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun s => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz s) s
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  linarith only [hu,hl,he]

end TSP.Improvements20261105
