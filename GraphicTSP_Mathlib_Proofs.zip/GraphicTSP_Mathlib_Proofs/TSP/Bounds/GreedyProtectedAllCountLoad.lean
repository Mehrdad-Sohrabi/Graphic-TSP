import TSP.Improvements20261105.GreedyUniformLoadTools
import TSP.Improvements20261105.GreedyProtectedCount2Continuous
import TSP.Improvements20261105.GreedyProtectedCount3Continuous
import TSP.Improvements20261105.GreedyProtectedCount4Continuous
import TSP.Improvements20261105.GreedyProtectedCount5Continuous
import TSP.Improvements20261105.GreedyProtectedCount6Continuous
import TSP.Improvements20261105.GreedyProtectedCount7Continuous
import TSP.Improvements20261105.GreedyProtectedCount8Continuous
import TSP.Improvements20261105.GreedyProtectedCount9Continuous
import TSP.Improvements20261105.GreedyProtectedCount10Continuous
import TSP.Improvements20261105.GreedyProtectedCount11Continuous
import TSP.Improvements20261105.GreedyProtectedCount12Continuous
import TSP.Improvements20261105.GreedyProtectedCount13Continuous
import TSP.Improvements20261105.GreedyProtectedCount14Continuous
import TSP.Improvements20261105.GreedyProtectedCount15Continuous
import TSP.Improvements20261105.GreedyProtectedCount16Continuous

/-! The continuous packing cases cover every actual finite back set. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators

theorem greedy_protected_finite_new (t : ℕ) (q a : ℝ) (k : ℕ)
    (ht0 : 2 ≤ t) (ht1 : t ≤ 16) (hk : k<t)
    (hq0 : 0 ≤ q) (hqh : q ≤ 1/2) (ha : 1 ≤ a)
    (hpack : a+q ≤ 2) (hlo : (k : ℝ)*q ≤ a) (hhi : a ≤ ((k : ℝ)+1)*q)
    (hgate : 6 ≤ t → t ≤ 8 →
      q ≤ ScoredParameters.lower t ∨ ScoredParameters.upper t ≤ q ∨
        q+a ≤ 2-ScoredParameters.incomingThreshold t) :
    24*(a-1)+(360/19)*greedyMuEnvelope q a k+
      (96/19)*((100/57)*a-1)-(824/5)*q+24*min (2-q-a) (1/2) ≤ 4*(t : ℝ) := by
  interval_cases t
  · convert greedy_protected_2_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_3_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_4_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_5_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · have hg := hgate (by omega) (by omega)
    norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hg
    convert greedy_protected_6_continuous_new q a k hk hq0 hqh ha hpack hlo hhi (by norm_num; exact hg) using 1 <;> norm_num
  · have hg := hgate (by omega) (by omega)
    norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hg
    convert greedy_protected_7_continuous_new q a k hk hq0 hqh ha hpack hlo hhi (by norm_num; exact hg) using 1 <;> norm_num
  · have hg := hgate (by omega) (by omega)
    norm_num [ScoredParameters.lower,ScoredParameters.upper,ScoredParameters.incomingThreshold] at hg
    convert greedy_protected_8_continuous_new q a k hk hq0 hqh ha hpack hlo hhi (by norm_num; exact hg) using 1 <;> norm_num
  · convert greedy_protected_9_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_10_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_11_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_12_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_13_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_14_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_15_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num
  · convert greedy_protected_16_continuous_new q a k hk hq0 hqh ha hpack hlo hhi using 1 <;> norm_num

variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem greedy_protected_all_count_load (z : E → ℝ) (s : d.tree.Child) (q : ℝ)
    (hq : 0 ≤ q) (hq1 : q ≤ 1) (hz : ∀ e ∈ d.backGroup s, 0 ≤ z e)
    (hcap : ∀ e ∈ d.backGroup s, z e ≤ q) (ha : 1 < edgeSum z (d.backGroup s))
    (hpack : edgeSum z (d.backGroup s)+q ≤ 2)
    (hgate : 6 ≤ (d.backGroup s).card → (d.backGroup s).card ≤ 8 →
      q ≤ ScoredParameters.lower (d.backGroup s).card ∨ ScoredParameters.upper (d.backGroup s).card ≤ q ∨
        q+edgeSum z (d.backGroup s) ≤ 2-ScoredParameters.incomingThreshold (d.backGroup s).card) :
    24*(edgeSum z (d.backGroup s)-1)+noncriticalIncidence d z s-(824/5)*q+24*min (2-q-edgeSum z (d.backGroup s)) (1/2) ≤
      4*(d.backGroup s).card := by
  let a := edgeSum z (d.backGroup s)
  let t := (d.backGroup s).card
  have hcount : a ≤ (t : ℝ)*q := by
    have hh := Finset.sum_le_sum hcap
    simpa [a,t,edgeSum] using hh
  have ht : 2 ≤ t := by
    by_contra hn
    have hnR : (t : ℝ) ≤ 1 := by exact_mod_cast (show t≤1 by omega)
    have hh := mul_le_mul_of_nonneg_right hnR hq
    change 1<a at ha
    linarith only [ha,hcount,hh,hq1]
  have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
  have hglobal := greedy_uncouponed_uniform_cap d z s q hq hz hcap hpack
  have hres := min_le_right (2-q-edgeSum z (d.backGroup s)) (1/2 : ℝ)
  by_cases htail : 17 ≤ t
  · have htailR : (17 : ℝ) ≤ t := by exact_mod_cast htail
    change 24*(a-1)+noncriticalIncidence d z s-(824/5)*q+24*min (2-q-a) (1/2) ≤ 4*(t : ℝ)
    change 24*(a-1)+noncriticalIncidence d z s ≤ _ at hglobal
    change min (2-q-a) (1/2 : ℝ) ≤ 1/2 at hres
    linarith only [hglobal,hq,htailR,hres]
  by_cases hhigh : 1/2 ≤ q
  · have hglobal := high_q_noncritical_load d z s q hhigh hz hcap hpack
    change 24*(a-1)+noncriticalIncidence d z s-(824/5)*q+24*min (2-q-a) (1/2) ≤ 4*(t : ℝ)
    change 24*(a-1)+noncriticalIncidence d z s ≤ _ at hglobal
    change min (2-q-a) (1/2 : ℝ) ≤ 1/2 at hres
    linarith only [hglobal,hhigh,htR,hres]
  obtain ⟨k,hk,hlo,hhi⟩ := exists_mass_interval t q a (by omega) hq (by linarith) hcount
  have hnew := greedy_protected_finite_new t q a k ht (by omega) hk hq (le_of_not_ge hhigh)
    ha.le hpack hlo hhi hgate
  have hmu := greedy_mu_actual_envelope (d.backGroup s) z q k hz hcap
  have hmu' : signedStarIncidence d (9/20) z s ≤ greedyMuEnvelope q a k := by
    unfold signedStarIncidence starIncidenceRamp edgeSum
    change _ ≤ greedyMuEnvelope q (∑ e ∈ d.backGroup s, z e) k
    linarith only [hmu]
  have h1 := min_le_right (((d.backGroup s).card : ℝ)-1) (signedStarIncidence d (9/20) z s)
  have h2 := min_le_right (((d.backGroup s).card : ℝ)-1) ((100/57 : ℝ)*a-1)
  have hnewActual : 24*(a-1)+mixedNoncriticalIncidence d z s-(824/5)*q+24*min (2-q-a) (1/2) ≤ 4*(t : ℝ) := by
    unfold mixedNoncriticalIncidence
    change 24*(a-1)+((360/19)*min _ (signedStarIncidence d (9/20) z s)+
      (96/19)*min _ ((100/57)*a-1))-(824/5)*q+24*min (2-q-a) (1/2) ≤ _
    linarith only [hnew,hmu',h1,h2]
  have hold := greedy_protected_old_load d z s q hq hz hcap ha.le hpack
  unfold noncriticalIncidence
  rcases le_total (24*oldIncidence d z s) (mixedNoncriticalIncidence d z s) with hh | hh
  · rw [max_eq_right hh]
    exact hnewActual
  · rw [max_eq_left hh]
    exact hold

end TSP.Improvements20261105
