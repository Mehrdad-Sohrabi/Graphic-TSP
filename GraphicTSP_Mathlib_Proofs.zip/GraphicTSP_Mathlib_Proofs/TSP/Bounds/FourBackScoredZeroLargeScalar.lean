import TSP.Improvements20261105.FourBackNoncriticalBound

/-! A continuous paired inequality for a selected three-back source and
positive greedy target of arbitrary count. All rational cases are checked by Lean. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 6000000
set_option Elab.async false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

theorem four_back_scored_zerolarge_scalar
    (M q e z a o S I H g : ℝ) (hq : (1/4 : ℝ) ≤ q)
    (he0 : 0 ≤ e) (hem : e ≤ 4*M-1) (heq : e+q ≤ 1)
    (ho0 : 0 ≤ o) (hoe : o ≤ e) (hz0 : 0 ≤ z) (ha0 : 0 ≤ a) (ha : a ≤ 1) (hz1 : z ≤ 1)
    (hmass : q+o+z+a=2) (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hgap : g+q+e ≤ 1)
    (hS : S ≤ max (192*M-48) (144*M-684/19+(96/19)*((100/57)*(1+e)-1)))
    (hIall : ∀ U A B : ℝ, 0 ≤ A → 0 ≤ 2-A → (2-A)*U ≤ 1/2 →
      0 ≤ B → 0 ≤ 19/10-B → (19/10-B)*U ≤ 9/20 → z ≤ U →
      I ≤ max (24*A*a) ((360/19)*(B*a-1/10)+(96/19)*((100/57)*a-1)))
    
    (hMlo : (9/25 : ℝ) ≤ M) (hMhi : M ≤ 43/100) (hqM : q ≤ M)
    (hchoice : M ≤ q+(1/10)*o)
    (hC : S ≤ max (144*M-36+(96/19)*(1000/57)*(4*(q+(1/10)*o)-(1+e))-96/19)
      (-(124/5)*(1-e)))
    (hH0 : 0 ≤ H)
    (hHL : 13/40 ≤ z → (415/2)*(1-a)+(704/5)*(2-z-a)-max (24*min z (1-z)-4) 0-48*z ≤ H)
    (hHR : 13/40 ≤ z → (415/2)*(z-1)+(704/5)*(e+q)-max (24*min z (1-z)-4) 0-48*z ≤ H) :
    (415/2)*(e-o)-(704/5)+24*e+S+24*(a-1)+I+24*g-H≤ 28 := by
  by_cases hc0 : z ≤ (1/20 : ℝ)
  · have ht := hIall (1/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc0
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc0,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc0,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc0,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc0,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc0,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc0,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc0,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc0,hC,ht,hmass]
  by_cases hc1 : z ≤ (1/10 : ℝ)
  · have ht := hIall (1/10 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc1
    have hlo : (1/20 : ℝ) ≤ z := (lt_of_not_ge hc0).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc1,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc1,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc1,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc1,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc1,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc1,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc1,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc1,hC,ht,hmass]
  by_cases hc2 : z ≤ (3/20 : ℝ)
  · have ht := hIall (3/20 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc2
    have hlo : (1/10 : ℝ) ≤ z := (lt_of_not_ge hc1).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc2,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc2,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc2,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc2,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc2,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc2,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc2,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc2,hC,ht,hmass]
  by_cases hc3 : z ≤ (1/5 : ℝ)
  · have ht := hIall (1/5 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc3
    have hlo : (3/20 : ℝ) ≤ z := (lt_of_not_ge hc2).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc3,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc3,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc3,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc3,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc3,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc3,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc3,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc3,hC,ht,hmass]
  by_cases hc4 : z ≤ (9/38 : ℝ)
  · have ht := hIall (9/38 : ℝ) (0/1 : ℝ) (0/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc4
    have hlo : (1/5 : ℝ) ≤ z := (lt_of_not_ge hc3).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc4,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc4,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc4,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc4,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc4,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc4,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc4,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc4,hC,ht,hmass]
  by_cases hc5 : z ≤ (1/4 : ℝ)
  · have ht := hIall (1/4 : ℝ) (0/1 : ℝ) (1/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc5
    have hlo : (9/38 : ℝ) ≤ z := (lt_of_not_ge hc4).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc5,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc5,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc5,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc5,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc5,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc5,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc5,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc5,hC,ht,hmass]
  by_cases hc6 : z ≤ (3/10 : ℝ)
  · have ht := hIall (3/10 : ℝ) (1/3 : ℝ) (2/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc6
    have hlo : (1/4 : ℝ) ≤ z := (lt_of_not_ge hc5).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc6,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc6,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc6,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc6,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc6,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc6,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc6,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc6,hC,ht,hmass]
  by_cases hc7 : z ≤ (13/40 : ℝ)
  · have ht := hIall (13/40 : ℝ) (6/13 : ℝ) (67/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc7
    have hlo : (3/10 : ℝ) ≤ z := (lt_of_not_ge hc6).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc7,hS,hC,ht,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hH0,hc7,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc7,hS,hC,ht,hmass]
    · linarith only [heq,hMhi,ha,hgap,hH0,hc7,hS,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc7,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc7,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc7,hC,ht,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hH0,hc7,hC,ht,hmass]
  by_cases hc8 : z ≤ (7/20 : ℝ)
  · have ht := hIall (7/20 : ℝ) (4/7 : ℝ) (43/70 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc8
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc7]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith only [hc8] : z ≤ 1-z)] at hL hR
    rw [max_eq_left (by linarith only [hforce] : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (13/40 : ℝ) ≤ z := (lt_of_not_ge hc7).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hc8,hS,hC,ht,hL,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hc8,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc8,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc8,hS,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc8,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc8,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc8,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc8,hC,ht,hL,hmass]
  by_cases hc9 : z ≤ (2/5 : ℝ)
  · have ht := hIall (2/5 : ℝ) (3/4 : ℝ) (31/40 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc9
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc8]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith only [hc9] : z ≤ 1-z)] at hL hR
    rw [max_eq_left (by linarith only [hforce] : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (7/20 : ℝ) ≤ z := (lt_of_not_ge hc8).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hc9,hS,hC,ht,hL,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hc9,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc9,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc9,hS,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc9,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc9,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc9,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc9,hC,ht,hL,hmass]
  by_cases hc10 : z ≤ (9/20 : ℝ)
  · have ht := hIall (9/20 : ℝ) (8/9 : ℝ) (9/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc10
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc9]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith only [hc10] : z ≤ 1-z)] at hL hR
    rw [max_eq_left (by linarith only [hforce] : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (2/5 : ℝ) ≤ z := (lt_of_not_ge hc9).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hc10,hS,hC,ht,hL,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hc10,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc10,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc10,hS,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc10,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc10,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc10,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc10,hC,ht,hL,hmass]
  by_cases hc11 : z ≤ (1/2 : ℝ)
  · have ht := hIall (1/2 : ℝ) (1/1 : ℝ) (1/1 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc11
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc10]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_left (by linarith only [hc11] : z ≤ 1-z)] at hL hR
    rw [max_eq_left (by linarith only [hforce] : (0 : ℝ) ≤ 24*z-4)] at hL hR
    have hlo : (9/20 : ℝ) ≤ z := (lt_of_not_ge hc10).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [hMhi,ha,hg0,hgap,hc11,hS,hC,ht,hL,hmass]
    · linarith only [hMhi,ha,hg0,hgap,hc11,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc11,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc11,hS,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc11,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc11,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc11,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc11,hC,ht,hL,hmass]
  by_cases hc12 : z ≤ (11/20 : ℝ)
  · have ht := hIall (11/20 : ℝ) (12/11 : ℝ) (119/110 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc12
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc11]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc11] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc12] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (1/2 : ℝ) ≤ z := (lt_of_not_ge hc11).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hMhi,ha,hgap,hc12,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc12,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc12,hS,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,ha,hgap,hc12,hS,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc12,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc12,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc12,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ha,hg0,hgap,hc12,hC,ht,hL,hmass]
  by_cases hc13 : z ≤ (3/5 : ℝ)
  · have ht := hIall (3/5 : ℝ) (7/6 : ℝ) (23/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc13
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc12]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc12] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc13] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (11/20 : ℝ) ≤ z := (lt_of_not_ge hc12).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hMhi,hqM,ho0,ha,hgap,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,hqM,ho0,ha,hgap,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,hqM,ho0,ha,hgap,hC,ht,hL,hmass]
    · linarith only [heq,hMhi,hqM,ho0,ha,hgap,hC,ht,hL,hmass]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hC,ht,hR,hmass]
  by_cases hc14 : z ≤ (13/20 : ℝ)
  · have ht := hIall (13/20 : ℝ) (16/13 : ℝ) (157/130 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc14
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc13]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc13] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc14] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (3/5 : ℝ) ≤ z := (lt_of_not_ge hc13).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hlo,hC,ht,hR]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hlo,hC,ht,hR]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hlo,hC,ht,hR]
    · linarith only [hem,hchoice,ho0,ha,hg0,hgap,hlo,hC,ht,hR]
  by_cases hc15 : z ≤ (7/10 : ℝ)
  · have ht := hIall (7/10 : ℝ) (9/7 : ℝ) (44/35 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc15
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc14]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc14] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc15] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (13/20 : ℝ) ≤ z := (lt_of_not_ge hc14).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  by_cases hc16 : z ≤ (3/4 : ℝ)
  · have ht := hIall (3/4 : ℝ) (4/3 : ℝ) (13/10 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc16
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc15]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc15] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc16] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (7/10 : ℝ) ≤ z := (lt_of_not_ge hc15).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  by_cases hc17 : z ≤ (4/5 : ℝ)
  · have ht := hIall (4/5 : ℝ) (11/8 : ℝ) (107/80 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc17
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc16]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc16] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc17] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (3/4 : ℝ) ≤ z := (lt_of_not_ge hc16).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  by_cases hc18 : z ≤ (5/6 : ℝ)
  · have ht := hIall (5/6 : ℝ) (7/5 : ℝ) (34/25 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc18
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc17]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc17] : 1-z ≤ z)] at hL hR
    rw [max_eq_left (by linarith only [hc18] : (0 : ℝ) ≤ 24*(1-z)-4)] at hL hR
    have hlo : (4/5 : ℝ) ≤ z := (lt_of_not_ge hc17).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  by_cases hc19 : z ≤ (17/20 : ℝ)
  · have ht := hIall (17/20 : ℝ) (24/17 : ℝ) (233/170 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc19
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc18]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc18] : 1-z ≤ z)] at hL hR
    rw [max_eq_right (by linarith only [hc18] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
    have hlo : (5/6 : ℝ) ≤ z := (lt_of_not_ge hc18).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  by_cases hc20 : z ≤ (9/10 : ℝ)
  · have ht := hIall (9/10 : ℝ) (13/9 : ℝ) (7/5 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc20
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc19]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc19] : 1-z ≤ z)] at hL hR
    rw [max_eq_right (by linarith only [hc19] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
    have hlo : (17/20 : ℝ) ≤ z := (lt_of_not_ge hc19).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  by_cases hc21 : z ≤ (19/20 : ℝ)
  · have ht := hIall (19/20 : ℝ) (28/19 : ℝ) (271/190 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) hc21
    have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc20]
    have hL := hHL hforce
    have hR := hHR hforce
    rw [min_eq_right (by linarith only [hc20] : 1-z ≤ z)] at hL hR
    rw [max_eq_right (by linarith only [hc20] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
    have hlo : (9/10 : ℝ) ≤ z := (lt_of_not_ge hc20).le
    rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
    · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  have ht := hIall (1/1 : ℝ) (3/2 : ℝ) (29/20 : ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by simpa using hz1)
  have hforce : (13/40 : ℝ) ≤ z := by linarith only [hc21]
  have hL := hHL hforce
  have hR := hHR hforce
  rw [min_eq_right (by linarith only [hc21] : 1-z ≤ z)] at hL hR
  rw [max_eq_right (by linarith only [hc21] : 24*(1-z)-4 ≤ (0 : ℝ))] at hL hR
  have hlo : (19/20 : ℝ) ≤ z := (lt_of_not_ge hc21).le
  rcases le_max_iff.mp hC with hC | hC <;> rcases le_max_iff.mp hS with hS | hS <;> rcases le_max_iff.mp ht with ht | ht
  · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
  · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
  · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
  · linarith only [heq,hchoice,ho0,hgap,hlo,hC,ht,hL,hR,hmass]
  · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]
  · linarith only [hem,hchoice,ho0,hg0,hgap,hlo,hC,ht,hR,hmass]

end TSP.Improvements20261105
