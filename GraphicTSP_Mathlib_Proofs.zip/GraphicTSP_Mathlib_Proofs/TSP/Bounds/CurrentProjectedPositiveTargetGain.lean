import TSP.Improvements20261105.CurrentProjectedGuardedDeficits
import TSP.Improvements20261105.TerminalHGain
import TSP.Improvements20261105.ProjectedGuardedPositiveDeficits
import TSP.Improvements20261105.TerminalForcedDeficits

/-! Every nonroot head of the actual simultaneous construction retains
its fixed cover bound in the signed P/Q arm. Actual-zero and erased-positive
heads are proved by different valid inequalities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def positiveMatchingTargetGain (x z : E → ℝ) (s t : d.tree.Child) : ℝ :=
  if (13/40 : ℝ) ≤ x (d.treeEdge t) then max 0 (max
    ((704/5)*(x (d.treeEdge s)+outgoingBackMass d x s)-
      (415/2)*(edgeSum z (d.backGroup t)-1)-targetForceSlack d x 24 4 t)
    ((704/5)*survivingExcess d x s-((415/2)-(704/5))*(x (d.treeEdge s)+outgoingBackMass d x s)-
      (415/2)*(edgeSum z (d.backGroup t)-1)-targetForceSlack d x 24 4 t-(704/5)*outgoingBackMass d x s))
  else 0

theorem positiveMatchingTargetGain_nonnegative (x z : E → ℝ) (s t : d.tree.Child) :
    0 ≤ positiveMatchingTargetGain d x z s t := by
  unfold positiveMatchingTargetGain
  split_ifs
  · exact le_max_left _ _
  · exact le_rfl

theorem current_projected_positive_target_gain (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : d.StarIndex, edgeSum z (d.backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x (d.stars i)/2)
        ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
          -zeroQCredit d x Y i)
    (s : d.tree.Child) (hsM : s ∈ C.matching) (i : d.StarIndex)
    (hnext : unaryNext d s=i.1) (hpositive : 1 < edgeSum z (d.backGroup i.1)) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        C.cover i.1-positiveMatchingTargetGain d x z s i.1 := by
  have hnr : d.centers i ≠ d.tree.root := by
    change d.tree.parent i.1 ≠ d.tree.root
    rw [← hnext,projectionLinks_parent d x s (C.link_subset hsM)]
    exact s.2
  unfold positiveMatchingTargetGain
  split_ifs with hq
  · have hiH : i.1 ∈ fixedHForceTargets d x z (415/2) (704/5) C := by
      apply Finset.mem_filter.mpr
      exact ⟨Finset.mem_image.mpr ⟨s,hsM,hnext⟩,hq⟩
    exact terminal_forcedPQ_H_target_gain d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
      (fixedHForceTargets d x z (415/2) (704/5) C)
      (fixedHForceTargets_subset d x z (415/2) (704/5) C)
      (fixedPositiveTerminalChildren d x) owner rootStar R s hsM i hnext hiH
      (guarded_projected_positive_Q_deficit d x z Y R hrep hbacks hloss hterminal i hpositive)
  · rw [sub_zero]
    exact current_projected_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar
      Y R hY hrep hbacks hloss hterminal hzero i hnr

end TSP.Improvements20261105
