import TSP.Improvements20261105.GeneralPairPaymentInterface

/-! Close all global accounting and physical construction once the
explicit local pair payments have been proved. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x₀ x z : E → ℝ) (hs : G.IsSimple) (hconnected : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hconnected root

theorem GeneralPairPaymentContext.tsp_bound
    (K : GeneralPairPaymentContext G x₀ x z hs hconnected root)
    (hpairs : K.PairPayments G x₀ x z hs hconnected root) :
    (G.tsp : ℝ) ≤ (14524*edgeSum x Finset.univ-8166)/10481 := by
  have hn : 2 ≤ Fintype.card V := by have hh := K.hc.1; omega
  have heligible : ∀ s ∈ generalEligibleHeads d x, ScoredStar d x s :=
    fun _ hs => (Finset.mem_filter.mp hs).2
  have heligibleAll : ∀ s, ScoredStar d x s → s ∈ generalEligibleHeads d x :=
    fun s hs => Finset.mem_filter.mpr ⟨Finset.mem_univ s,hs⟩
  have hTS : generalRawCriticalHeads d x z K.a ⊆ fixedCriticalHeads d x z (generalEligibleHeads d x) :=
    Finset.filter_subset _ _
  have hT : ∀ s ∈ generalRawCriticalHeads d x z K.a,
      2 ≤ (K.a.componentHeads d (fixedGatePlan d x) (K.a.headComponent d (fixedGatePlan d x) s)).card :=
    fun _ hs => (Finset.mem_filter.mp hs).2
  have hm0 : ∀ i ∈ fixedZeroTerminalHeads d x, 0 ≤ K.m i := fun i hi =>
    K.hmU i (Finset.mem_union_left _ (fixedZeroTerminalHeads_subset_projected d x z K.hzx hi))
  have hm := original_zero_guard_payment_retained d x z K.hzx K.Q K.m K.hmprojected
  have hglobal := canonical_global_budget_of_pair_payments G x z hs hconnected root
    (generalEligibleHeads d x) K.hc x₀ K.hx₀ K.hpositive K.t K.ht K.f K.hf K.hb K.a K.ha K.hcan
    K.hx K.hcap K.hz K.hzx heligible heligibleAll (generalRawCriticalHeads d x z K.a) hTS hT hn
    K.hprojection K.C K.owner K.ho K.rootStar K.hrootStar K.R K.Q K.hQ K.hrep K.hbacks
    K.m hm0 hm K.hmprojected K.hguarded K.hconn K.hloss K.hmpositive K.hconnectors K.hterminal
    K.hdom K.hmU hpairs
  have hover := Chapter11.totalOverage_nonneg d x
  have hslack : (0 : ℝ) ≤ ((degreeSlackVertices G x₀).card : ℝ) := Nat.cast_nonneg _
  have hrole : 48*K.a.value d (fixedGatePlan d x) (fun _ => 0)+
      (∑ i : (d).StarIndex, guardedNormalizedHeadCost d x z K.C K.owner K.rootStar K.R K.a i)-
      (704/5)*(∑ i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x, K.m i) ≤
      (415/2 : ℝ)+4*((Fintype.card V : ℝ)-3)+(1204/5)*(edgeSum x Finset.univ-Fintype.card V) := by
    linarith only [hglobal,hover,hslack]
  have hinter : 0 ≤ ∑ i ∈ projectedZeroTerminalHeads d z ∩ fixedPositiveTerminalHeads d x, K.m i :=
    Finset.sum_nonneg (fun i hi => K.hmU i (Finset.mem_union_left _ (Finset.mem_inter.mp hi).1))
  have hunion : (∑ i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x, K.m i)+
      (∑ i ∈ projectedZeroTerminalHeads d z ∩ fixedPositiveTerminalHeads d x, K.m i)=
      (∑ i ∈ projectedZeroTerminalHeads d z, K.m i)+(∑ i ∈ fixedPositiveTerminalHeads d x, K.m i) :=
    Finset.sum_union_inter
  have hRN : edgeSum K.R (nonremovableRepresentatives (d).stars) ≤
      edgeSum x (Finset.univ \ removableEdges (d).stars)/2-
        (∑ i ∈ projectedZeroTerminalHeads d z ∪ fixedPositiveTerminalHeads d x, K.m i) := by
    linarith only [K.hsave,hunion,hinter]
  exact physical_tsp_bound_of_role_budget d hs K.hc x z K.hx hn K.hcap K.hprojection K.C
    K.owner K.ho K.rootStar K.hrootStar K.R K.Z K.a _ K.hR K.hZ hRN K.hZN K.hcost hrole

end TSP.Improvements20261105
