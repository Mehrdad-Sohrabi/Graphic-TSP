import TSP.Improvements20261105.ScoredSourcePacking

/-! Exact real-weight greedy source row, count 7. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 10000000

theorem greedy_source_7_continuous (k : ℕ) (hk : k < 7)
    (q a I g : ℝ) (hq0 : 0 ≤ q) (hq1 : q ≤ 1)
    (ha : 1 ≤ a) (hcount : a ≤ 7*q) (hpack : a+q ≤ 2)
    (hka : (k : ℝ)*q ≤ a) (hak : a ≤ ((k : ℝ)+1)*q)
    (hg0 : 0 ≤ g) (hghalf : g ≤ 1/2) (hggap : g+q+a ≤ 2)
    (hgate : q ≤ (19/100) ∨ (46/125) ≤ q ∨ q+a ≤ 2-(9/100))
    (hN : I ≤ 24*greedyOldEnvelope q a k ∨
      I ≤ (360/19)*packedSignedMu q a k+(96/19)*((100/57)*a-1)) :
    (415/2)*(a-1)-(704/5)+24*(a-1+g)+I ≤ 32 := by
  rcases hgate with hg | hg | hg <;>
  rcases hN with hN | hN <;>
    interval_cases k <;>
    norm_num only [greedyOldEnvelope,packedOldRamp,packedSignedMu,Nat.cast_ofNat,Nat.cast_zero,zero_mul,one_mul] at hN hka hak <;>
    simp only [max_def] at hN <;> split_ifs at hN <;> linarith

end TSP.Improvements20261105
