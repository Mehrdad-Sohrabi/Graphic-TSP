import TSP.Improvements20261105.ClassifiedResourceGraph

/-! Assemble one original edge set from compatible local block selections.
Every minor block sees exactly its prescribed local set. Edges meeting no
minor block can be selected independently. -/
namespace TSP.Improvements20261105
open Graph Chapter05 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

noncomputable def blockSelection {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (P : V → Finset E) (N : Finset E) : Finset E :=
  Finset.univ.filter (fun e =>
    if e ∈ minorBoundary d x (G.src e) then e ∈ P (G.src e)
    else if e ∈ minorBoundary d x (G.dst e) then e ∈ P (G.dst e) else e ∈ N)

theorem blockSelection_source {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (P : V → Finset E) (N : Finset E) (e : E) (he : e ∈ minorBoundary d x (G.src e)) :
    e ∈ blockSelection d x P N ↔ e ∈ P (G.src e) := by
  simp [blockSelection, he]

theorem blockSelection_target {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (P : V → Finset E) (N : Finset E)
    (hcoherent : ∀ e ∈ internalResourceEdges d x, e ∈ P (G.src e) ↔ e ∈ P (G.dst e))
    (e : E) (he : e ∈ minorBoundary d x (G.dst e)) :
    e ∈ blockSelection d x P N ↔ e ∈ P (G.dst e) := by
  by_cases hs : e ∈ minorBoundary d x (G.src e)
  · rw [blockSelection_source d x P N e hs]
    exact hcoherent e (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hs, he⟩)
  · simp [blockSelection, hs, he]

theorem blockSelection_at_minor {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (P : V → Finset E) (N : Finset E)
    (hcoherent : ∀ e ∈ internalResourceEdges d x, e ∈ P (G.src e) ↔ e ∈ P (G.dst e))
    (u : V) (e : E) (he : e ∈ minorBoundary d x u) :
    e ∈ blockSelection d x P N ↔ e ∈ P u := by
  have hi := (loopless_incident_iff_cut G hsimple.1 u e).mpr (minorBoundary_subset_cut d x u he)
  rcases hi with hs | ht
  · simpa [hs] using blockSelection_source d x P N e (by simpa [hs] using he)
  · simpa [ht] using blockSelection_target d x P N hcoherent e (by simpa [ht] using he)

theorem blockSelection_boundary {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    (x : E → ℝ) (P : V → Finset E) (N : Finset E)
    (hP : ∀ u, P u ⊆ minorBoundary d x u)
    (hcoherent : ∀ e ∈ internalResourceEdges d x, e ∈ P (G.src e) ↔ e ∈ P (G.dst e))
    (u : V) : blockSelection d x P N ∩ minorBoundary d x u = P u := by
  ext e
  by_cases he : e ∈ minorBoundary d x u
  · simp only [Finset.mem_inter, he, and_true]
    exact blockSelection_at_minor d hsimple x P N hcoherent u e he
  · have hp : e ∉ P u := fun hp => he (hP u hp)
    simp [he, hp]

theorem resource_agreement_implies_coherence {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (P : V → Finset E) (R : Finset E)
    (hag : ∀ u, P u ∩ internalResourceEdges d x = R ∩ minorBoundary d x u) :
    ∀ e ∈ internalResourceEdges d x, e ∈ P (G.src e) ↔ e ∈ P (G.dst e) := by
  intro e he
  have hb := (Finset.mem_filter.mp he).2
  have hs := Finset.ext_iff.mp (hag (G.src e)) e
  have ht := Finset.ext_iff.mp (hag (G.dst e)) e
  simp only [Finset.mem_inter, he, hb.1, hb.2, and_true] at hs ht
  exact hs.trans ht.symm

end TSP.Improvements20261105
