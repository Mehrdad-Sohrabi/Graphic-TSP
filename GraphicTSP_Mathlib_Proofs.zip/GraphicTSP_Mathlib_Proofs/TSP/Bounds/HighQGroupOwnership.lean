import TSP.Improvements20261105.HighQSuccessorClassification

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def HighQGroupOwner (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s : d.tree.Child) : Prop :=
  2 ≤ childCount d (d.tree.parent s) ∧ s ∈ projectionLinks d x ∧
    s ∉ matchingEndpoints id (unaryNext d) C.matching

noncomputable def highQGroupChildren (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s : d.tree.Child) : Finset d.tree.Child :=
  {s, unaryNext d s} ∪ if unaryNext d s ∈ C.matching then {unaryNext d (unaryNext d s)} else ∅

noncomputable def highQGroupStars (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s : d.tree.Child) : Finset d.StarIndex :=
  Finset.univ.filter (fun i => i.1 ∈ highQGroupChildren d x z C s)

theorem mem_highQGroupChildren (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s u : d.tree.Child) :
    u ∈ highQGroupChildren d x z C s ↔
      u=s ∨ u=unaryNext d s ∨ (unaryNext d s ∈ C.matching ∧ u=unaryNext d (unaryNext d s)) := by
  by_cases h : unaryNext d s ∈ C.matching <;> simp [highQGroupChildren, h, or_assoc]

theorem highQGroup_nonorigin_unary_center (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s u : d.tree.Child)
    (hs : HighQGroupOwner d x z C s) (hu : u ∈ highQGroupChildren d x z C s) (hne : u≠s) :
    childCount d (d.tree.parent u)=1 := by
  rcases (mem_highQGroupChildren d x z C s u).mp hu with he | he | ⟨hm,he⟩
  · exact (hne he).elim
  · rw [he, projectionLinks_parent d x s hs.2.1]
    exact (Finset.mem_filter.mp hs.2.1).2.2.2.1
  · have hl := C.link_subset hm
    rw [he, projectionLinks_parent d x (unaryNext d s) hl]
    exact (Finset.mem_filter.mp hl).2.2.2.1

theorem highQGroup_target_shape (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s u : d.tree.Child)
    (hs : HighQGroupOwner d x z C s) (hu : u ∈ highQGroupChildren d x z C s) (hne : u≠s)
    (ht : u ∈ C.matching.image (unaryNext d)) :
    unaryNext d s ∈ C.matching ∧ u=unaryNext d (unaryNext d s) := by
  rcases (mem_highQGroupChildren d x z C s u).mp hu with he | he | hh
  · exact (hne he).elim
  · exact (unmatched_successor_not_matching_target d x z C s hs.2.1 hs.2.2 (he ▸ ht)).elim
  · exact hh

theorem highQGroup_nontarget_shape (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s u : d.tree.Child)
    (hu : u ∈ highQGroupChildren d x z C s) (hne : u≠s)
    (ht : u ∉ C.matching.image (unaryNext d)) : u=unaryNext d s := by
  rcases (mem_highQGroupChildren d x z C s u).mp hu with he | he | ⟨hm,he⟩
  · exact (hne he).elim
  · exact he
  · exact (ht (Finset.mem_image.mpr ⟨unaryNext d s, hm, he.symm⟩)).elim

theorem highQGroupChildren_disjoint (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s t : d.tree.Child)
    (hs : HighQGroupOwner d x z C s) (ht : HighQGroupOwner d x z C t) (hne : s≠t) :
    Disjoint (highQGroupChildren d x z C s) (highQGroupChildren d x z C t) := by
  apply Finset.disjoint_left.mpr
  intro u hus hut
  have hneS : u≠s := by
    intro he
    subst u
    have hc := highQGroup_nonorigin_unary_center d x z C t s ht hut hne
    have hb := hs.1
    omega
  have hneT : u≠t := by
    intro he
    subst u
    have hc := highQGroup_nonorigin_unary_center d x z C s t hs hus hne.symm
    have hb := ht.1
    omega
  apply hne
  by_cases htarget : u ∈ C.matching.image (unaryNext d)
  · obtain ⟨hms, hes⟩ := highQGroup_target_shape d x z C s u hs hus hneS htarget
    obtain ⟨hmt, het⟩ := highQGroup_target_shape d x z C t u ht hut hneT htarget
    have hnext := unaryNext_injective_on_projectionLinks d x (unaryNext d s) (unaryNext d t)
      (C.link_subset hms) (C.link_subset hmt) (hes.symm.trans het)
    exact unaryNext_injective_on_projectionLinks d x s t hs.2.1 ht.2.1 hnext
  · have hes := highQGroup_nontarget_shape d x z C s u hus hneS htarget
    have het := highQGroup_nontarget_shape d x z C t u hut hneT htarget
    exact unaryNext_injective_on_projectionLinks d x s t hs.2.1 ht.2.1 (hes.symm.trans het)

theorem highQGroupStars_disjoint (x z : E → ℝ)
    (C : ProjectedCoverWitness d x z (415/2) (704/5)) (s t : d.tree.Child)
    (hs : HighQGroupOwner d x z C s) (ht : HighQGroupOwner d x z C t) (hne : s≠t) :
    Disjoint (highQGroupStars d x z C s) (highQGroupStars d x z C t) := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  exact Finset.disjoint_left.mp (highQGroupChildren_disjoint d x z C s t hs ht hne)
    (Finset.mem_filter.mp hi).2 (Finset.mem_filter.mp hj).2

end TSP.Improvements20261105
