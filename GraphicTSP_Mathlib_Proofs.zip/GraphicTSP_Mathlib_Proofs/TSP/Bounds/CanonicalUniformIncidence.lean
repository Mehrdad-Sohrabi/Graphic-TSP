import TSP.Improvements20261105.CanonicalOldIncidence
import TSP.Improvements20261105.FixedIncidenceCharge

/-! A single parent inequality on the actual canonical components,
including the clipped singleton exception and all noncritical parents. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_uniform_parent_incidence (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (x₀ : E → ℝ) (hx₀ : x₀ ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x₀ e)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (r : a.Component d P) (hr : r ∈ a.internalComponents d P)
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : Finset d.tree.Child) (hscore : ScoreComparisons d x C)
    (q : d.tree.Child → ℝ) (hq : ∀ s ∈ a.componentHeads d P r, 0 ≤ q s)
    (hpack : ∀ s ∈ a.componentHeads d P r, edgeSum z (d.backGroup s) ≤ 2 - q s)
    (hsmall : ∀ s ∈ a.componentHeads d P r, (d.backGroup s).card ≤ 3 →
      ∀ e ∈ d.backGroup s, z e ≤ q s) :
    24 * (1 + ((a.componentEmptyChildren d hs hc P r).card : ℝ) - (a.componentHeads d P r).card) ≤
      (∑ s ∈ a.componentHeads d P r, fixedIncidenceCharge d x z C s) -
      (162 / 19) * (G.internalEdges (headCenters d
        (retainedIncidenceHeads d z (a.componentHeads d P r) C))).card +
      48 * (∑ s ∈ a.componentHeads d P r, ownProjectionLoss d x z s) +
      (124 / 5) * a.outgoingDeficit d P (fun b => x b.1) r := by
  have hdef := a.outgoingDeficit_nonneg d P (fun b => x b.1) r
  by_cases hC : ((a.componentHeads d P r) ∩ C).Nonempty
  · by_cases hnonex : 0 < (a.componentEmptyChildren d hs hc P r).card ∨
        2 ≤ (a.componentHeads d P r).card
    · have hi := canonical_critical_parent_bound d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
        r ((a.componentHeads d P r) ∩ C) Finset.inter_subset_left hC hnonex
        x z hx hcap hz hzx (hscore.restrict d Finset.inter_subset_right) q hq hpack hsmall
      have hsum :
          (∑ s ∈ (a.componentHeads d P r) ∩ C, rawCriticalIncidence d x z s) +
          (∑ s ∈ a.componentHeads d P r \ ((a.componentHeads d P r) ∩ C), mixedNoncriticalIncidence d z s) ≤
          ∑ s ∈ a.componentHeads d P r, fixedIncidenceCharge d x z C s := by
        rw [fixedIncidenceCharge_sum]
        exact add_le_add (Finset.sum_le_sum (fun s _ => le_max_left _ _))
          (Finset.sum_le_sum (fun s _ => le_max_right _ _))
      have hloss := leafProjectionLoss_le_heads d x z hzx _ _ (a.chosenLeaves_heads_in d hs hc ha r)
      simp only [retainedIncidenceHeads, if_pos hC]
      linarith
    · have hhpos := Finset.card_pos.mpr (hC.mono Finset.inter_subset_left)
      have hH : (a.componentHeads d P r).card = 1 := by omega
      have hK : (a.componentEmptyChildren d hs hc P r).card = 0 := by omega
      obtain ⟨s, hHs⟩ := Finset.card_eq_one.mp hH
      have hsC : s ∈ C := by
        obtain ⟨u, hu⟩ := hC
        have hh := Finset.mem_inter.mp hu
        rw [hHs, Finset.mem_singleton] at hh
        exact hh.1 ▸ hh.2
      have hpay := canonical_singleton_clipped_payment d hs hc P hP t ht f hf hb a ha hcan
        r s hHs x z hx.1 hzx
      rw [hHs, hK, retainedIncidenceHeads_singleton d z s C hsC,
        singleton_center_edges_zero d hs s, Finset.sum_singleton, Finset.sum_singleton]
      simp only [fixedIncidenceCharge, if_pos hsC, ownProjectionLoss] at *
      norm_num at *
      exact hpay
  · have hi := canonical_old_parent_incidence d hs hc x₀ hx₀ hpositive P hP t ht f hf hb a ha hcan
      r hr x z hx hcap hz hzx q hq hpack hsmall
    have hsum : 24 * (∑ s ∈ a.componentHeads d P r, oldIncidence d z s) ≤
        ∑ s ∈ a.componentHeads d P r, fixedIncidenceCharge d x z C s := by
      rw [fixedIncidenceCharge_sum_noncritical d x z _ C hC, Finset.mul_sum]
      exact Finset.sum_le_sum (fun s _ => le_max_left _ _)
    have he : (0 : ℝ) ≤ (G.internalEdges (headCenters d
        (a.componentHeads d P r \ countExcluded d (1 / 2) z (a.componentHeads d P r) ∅))).card :=
      Nat.cast_nonneg _
    simp only [retainedIncidenceHeads, if_neg hC]
    linarith

end TSP.Improvements20261105
