import TSP.Improvements20261105.CanonicalHeadSize

/-! A selected head cannot have all its dependencies deleted for at most
its base free price. Canonical head minimization makes this strict. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem canonical_selected_head_deletion_cost (P : GatePlan d) (hP : P.RespectsTree d)
    (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v) (f : GatedArc d → ℝ)
    (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P)
    (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (s : d.tree.Child) (hsel : a.head s = 1) :
    (gatedFreeBase d s : ℝ) <
      a.deletionCost d (a.eraseBackDependencies d (ownBackEdges d s) {s}) := by
  by_contra hbad
  have hcost : a.deletionCost d (a.eraseBackDependencies d (ownBackEdges d s) {s}) ≤ (gatedFreeBase d s : ℝ) :=
    le_of_not_gt hbad
  let B := ownBackEdges d s
  let S : Finset d.tree.Child := {s}
  let q := a.eraseBackDependencies d B S
  have hown : ∀ b : BackEdge d, d.anchor b.1 ∈ S → b ∈ B := by
    intro b hb
    simpa [S, B, ownBackEdges] using hb
  have hq := a.eraseBackDependencies_admissible d ha B S hown
  have hm := a.eraseBackDependencies_mono d ha B S
  have hrep : ∀ v, q.head v ≠ 0 → a.representative v ≤ q.representative v := by
    intro v hv
    by_cases hactive : (d.backGroup v).Nonempty
    · have hz := gated_optimal_active_representative_zero d P t ht f hf hb
        (a.potential d P) hcan.1.1 hcan.1.2 v hactive
      simp only [GatedDrops.potential_representative] at hz
      rw [hz]
      exact hq.representative_nonneg v
    · have hz := gated_optimal_inactive_head_zero d P hP t ht f hf hb
        (a.potential d P) hcan.1.1 hcan.1.2 v hactive
      simp only [GatedDrops.potential_headSelector] at hz
      have hmono := hm.2.2.2.1 v
      have hn := hq.head_nonneg v
      change q.head v ≤ a.head v at hmono
      change 0 ≤ q.head v at hn
      exact (hv (by omega)).elim
  have hout : ∀ v, q.head v ≠ 0 → a.outside v ≤ q.outside v := by
    intro v hv
    have hn : v ∉ S := by
      intro h
      exact hv (by simp [q, GatedDrops.eraseBackDependencies, h])
    simp [q, GatedDrops.eraseBackDependencies, hn]
  have hgain : (∑ v : d.tree.Child, ((gatedFreeBase d v : ℝ) + t v) *
      ((a.head v - q.head v : ℤ) : ℝ)) = (gatedFreeBase d s : ℝ) + t s := by
    rw [Finset.sum_eq_single s]
    · simp [q, S, GatedDrops.eraseBackDependencies, hsel]
    · intro v _ hv
      simp [q, S, GatedDrops.eraseBackDependencies, hv]
    · simp
  have hv := GatedDrops.exchange_value_bound d hP t ha hq hm.1 hm.2.1 hm.2.2.1
    hm.2.2.2.2.1 hm.2.2.2.1 hrep hout
  change a.value d P t + _ - a.deletionCost d q ≤ q.value d P t at hv
  rw [hgain] at hv
  have hbetter : a.value d P t ≤ q.value d P t := by linarith [ht s]
  exact canonical_drops_no_head_deletion d P hP t f hf hb a q ha hq hcan
    hm.1 hm.2.1 hm.2.2.1 hm.2.2.2.1 hbetter s hsel
      (by simp [q, S, GatedDrops.eraseBackDependencies])

end TSP.Improvements20261105
