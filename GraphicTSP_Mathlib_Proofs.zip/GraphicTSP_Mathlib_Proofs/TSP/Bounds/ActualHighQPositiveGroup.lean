import TSP.Improvements20261105.ActualHighQZeroGroup
import TSP.Improvements20261105.HighQGroupScalars
import TSP.Improvements20261105.TerminalProtectedOriginCharge

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem actual_high_q_positive_group
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option (d).StarIndex) (ho : ValidOwner (d).stars owner)
    (rootStar : (d).StarIndex) (hroot : (d).centers rootStar = (d).tree.root)
    (Y R : E ⊕ (d).StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hR : FixedQConnectorValues d x hx hn hcap R)
    (hrep : ∀ c, Y (.inl ((d).treeEdge c)) = x ((d).treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ (d).backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives (d).stars i)-edgeSum R (starRepresentatives (d).stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      ((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2 ≤
        -x ((d).treeEdge i.1)-preliminaryQIncrease d x i.1)
    (hzero : ∀ i : (d).StarIndex, edgeSum z ((d).backGroup i.1) ≤ 1 →
      max (R (.inr i)-edgeSum x ((d).stars i)/2)
        (((d).stars i).card-1-edgeSum R (starRepresentatives (d).stars i)-edgeSum x ((d).stars i)/2) ≤
          -zeroQCredit d x Y i)
    (eligible T : Finset (d).tree.Child) (i j : (d).StarIndex)
    (hi : HighQGroupOwner d x z C i.1) (hq : 1/2 ≤ x ((d).treeEdge i.1))
    (hp : (d).centers j=(i.1:V)) (hposj : 1 < edgeSum z ((d).backGroup j.1))
    (huj : j.1 ∉ matchingEndpoints id (unaryNext d) C.matching)
    (ns nw : ℤ) (hns : ns=0 ∨ ns=1) (hnw : nw=0 ∨ nw=1) :
    (jointHeadTerm
      (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i) (ns:ℝ)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1)+
      (ns:ℝ)*canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) i.1+
    (jointHeadTerm
      (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)
      (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j) (nw:ℝ)-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) j.1)+
      (nw:ℝ)*canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) j.1 ≤
      4*((((d).backGroup i.1).card:ℝ)+(((d).backGroup j.1).card:ℝ)) := by
  have hl := (Finset.mem_filter.mp hi.2.1).2
  have hprotected : ProtectedHead d x z (415/2) (704/5) C i.1 := ⟨hl.1,hl.2.1,hi.2.2⟩
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm i.1
  have hposi : 1 < edgeSum z ((d).backGroup i.1) := by
    have hh := hl.2.1
    rw [← he] at hh
    have h := (lt_max_iff.mp hh).resolve_right (lt_irrefl _)
    linarith
  have hdefi := guarded_projected_positive_Q_deficit d x z Y R hrep hbacks hloss hterminal i hposi
  have hdefj := guarded_projected_positive_Q_deficit d x z Y R hrep hbacks hloss hterminal j hposj
  have hsourcedef := current_projected_protected_deficit d hs x z hx hn hcap hm C owner rootStar R i hdefi hprotected
  rw [min_eq_right (by linarith)] at hsourcedef
  have hsource0 := current_projected_branch_source_max d hs x z hx hn hcap hm C owner ho rootStar hroot
    Y R hY hR hrep hbacks hloss hterminal hzero i hi
  have hnrj : (d).centers j ≠ (d).tree.root := by rw [hp]; exact i.1.2
  have hej := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm j.1
  have hsurvj : 0 < survivingExcess d x j.1 := by rw [← hej]; exact lt_max_of_lt_left (by linarith)
  have hterminalfree : ∀ c ∈ fixedPositiveTerminalChildren d x, HeadFreeBelow d c := by
    intro c hc
    obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hc
    exact (Finset.mem_filter.mp hv).2.1
  have hreceiver0 := terminal_forcedPQ_K_receiver_owned_charge d hs x z hx hn hcap hm
    (415/2) (704/5) 60 24 4 (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) C
    (fixedHForceTargets d x z (415/2) (704/5) C) (fixedHForceTargets_subset d x z (415/2) (704/5) C)
    (fixedPositiveTerminalChildren d x) hterminalfree owner ho rootStar hroot R hR j i.1 hp hl.2.2.1
    hsurvj huj hi.2.2 hdefj
  rw [min_eq_right (by linarith)] at hreceiver0
  have hdeg := tree_degree_eq d ((d).centers j)
  rw [if_neg hnrj,hp,hl.2.2.1] at hdeg
  have hev : Even (G.intDegree (d).treeEdges ((d).tree.parent j.1)) := by
    change Even (G.intDegree (d).treeEdges ((d).centers j))
    rw [hp,hdeg]
    norm_num
  have hcover := unmatched_positive_even_cover d hs x z hx hn hm (415/2) (704/5) C j.1 hnrj hsurvj hev huj
  have hreceiverdef := current_projected_guarded_deficit_cover d hs x z hx hn hcap hm C owner rootStar
    Y R hY hrep hbacks hloss hterminal hzero j hnrj
  rw [hcover] at hreceiverdef
  have heta := (preliminaryQIncrease_bounds d hs hx hcap j.1).1
  have hloadSi := scoredDFS_high_q_selected_load G x z hs hc root hx hn hcap hz hzx hm eligible T i.1 hq
  have hloadWi := scoredDFS_high_parent_receiver_load G x z hs hc root hx hn hcap hz hzx hm eligible T j.1 i.1 hp hq hposj
  have hcoupon := projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz
  have hloadS := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z) hcoupon i.1
  have hloadW := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z) hcoupon j.1
  have hprodS := positive_greedy_back_product d x hx hn i.1 hl.2.1 (scoredDFS_high_q_greedy G x hs hc root i.1 hq)
  have hprodW := positive_greedy_back_product d x hx hn j.1 hsurvj (scoredDFS_high_parent_greedy G x hs hc root j.1 i.1 hp hq)
  have hcount : (2:ℝ) ≤ (((d).backGroup i.1).card:ℝ) := by
    have hh : 2 ≤ ((d).backGroup i.1).card := by
      by_contra h
      have hn1 : ((d).backGroup i.1).card ≤ 1 := by omega
      have hr1 : (((d).backGroup i.1).card:ℝ) ≤ 1 := by exact_mod_cast hn1
      have hm := mul_le_mul_of_nonneg_right hr1 (hx.1 ((d).treeEdge i.1))
      linarith [hcap ((d).treeEdge i.1)]
    exact_mod_cast hh
  have hfin := high_q_positive_group_scalar (((d).backGroup i.1).card:ℝ) (((d).backGroup j.1).card:ℝ)
    (x ((d).treeEdge j.1)) (1-x ((d).treeEdge i.1)) ns nw hns hnw
    (by linarith [hcap ((d).treeEdge i.1)]) (by linarith) hcount (Nat.cast_nonneg _) (hx.1 _) hprodW.le
  change max (pqConnectorArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j)
    (pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R j) ≤ _ at hreceiver0
  rcases hns with rfl | rfl <;> rcases hnw with rfl | rfl <;>
    norm_num only [Int.cast_zero,Int.cast_one,jointHeadTerm,zero_mul,one_mul,sub_zero,sub_self,zero_add,add_zero] at hfin ⊢ <;>
    linarith only [hsourcedef,hsource0,hreceiver0,hreceiverdef,heta,hloadSi,hloadWi,hloadS,hloadW,hfin]

end TSP.Improvements20261105
