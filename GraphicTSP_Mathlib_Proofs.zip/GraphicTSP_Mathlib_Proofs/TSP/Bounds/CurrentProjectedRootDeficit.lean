import TSP.Improvements20261105.FixedProjectionPacking
import TSP.Improvements20261105.ProjectedTerminalFamily
import TSP.Improvements20261105.CurrentProjectedGuardedDeficits

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem current_projected_root_deficit (hs : G.IsSimple) (x z : E → ℝ)
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (rootStar : d.StarIndex)
    (Y R : E ⊕ d.StarIndex → ℝ) (hY : FixedQConnectorValues d x hx hn hcap Y)
    (hrep : ∀ c, Y (.inl (d.treeEdge c)) = x (d.treeEdge c)/2+
      fixedQIncrease d x (fixedPositiveTerminalChildren d x) c)
    (hbacks : ∀ e ∈ d.backEdges, Y (.inl e) = 1-x e/2)
    (hloss : ∀ i, edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*(if i ∈ projectedZeroTerminalHeads d z then projectedZeroGuardCapacity d x z Y i else 0)+
      2*(if i ∈ fixedPositiveTerminalHeads d x then (15/88 : ℝ)*terminalSubtreeGuardValue d x i.1 else 0))
    (hterminal : ∀ i ∈ fixedPositiveTerminalHeads d x,
      (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
        -x (d.treeEdge i.1)-preliminaryQIncrease d x i.1)
    (i : d.StarIndex) (hroot : d.centers i = d.tree.root) :
    pqDeficitArm d x (415/2) (704/5) (currentGuardedP d x z C owner rootStar) R i-
      (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
        (415/2 : ℝ)-(3003/10)*x (d.treeEdge i.1) := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  let delta := terminalPIncrease d x (fixedPositiveTerminalChildren d x)
    (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H j.1)
  have hpd := generalP_deficit d owner rootStar x delta i
  rw [extendNonrootRepairs_root d delta i.1 hroot] at hpd
  have hmass := hm i.1
  have hrem : fixedRemoval d x (allFullOverrideTargets d x) i.1 ≤
      fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 := le_max_right _ _
  have hnot : i ∉ fixedPositiveTerminalHeads d x := by
    intro hh
    exact (Finset.mem_filter.mp hh).2.2.2 hroot
  have hcredit := zeroQCredit_bounds d x hx Y i
    (sub_nonpos.mp (fixedQ_connector_nonpositive d hs x hx hn hcap Y hY i))
  have hcapzero : projectedZeroGuardCapacity d x z Y i ≤ x (d.treeEdge i.1) := by
    unfold projectedZeroGuardCapacity
    split_ifs
    · exact (min_le_left _ _).trans (by linarith only [hcredit.1])
    · linarith only [hcredit.1]
  have hl := hloss i
  rw [if_neg hnot,mul_zero,add_zero] at hl
  have hlbound : edgeSum Y (starRepresentatives d.stars i)-edgeSum R (starRepresentatives d.stars i) ≤
      (15/44 : ℝ)*x (d.treeEdge i.1) := by
    by_cases ht : i ∈ projectedZeroTerminalHeads d z
    · rw [if_pos ht] at hl
      linarith only [hl,hcapzero]
    · rw [if_neg ht,mul_zero] at hl
      have hq0 := hx.1 (d.treeEdge i.1)
      linarith only [hl,hq0]
  have hbase := raisedQ_deficit d x (fixedQIncrease d x (fixedPositiveTerminalChildren d x)) Y hrep hbacks i
  have heta0 : 0 ≤ fixedQIncrease d x (fixedPositiveTerminalChildren d x) i.1 := by
    unfold fixedQIncrease
    split_ifs
    · linarith only [hcap (d.treeEdge i.1)]
    · exact (preliminaryQIncrease_bounds d hs hx hcap i.1).1
  have hqd : (d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2 ≤
      -(29/44 : ℝ)*x (d.treeEdge i.1) := by linarith only [hbase,hlbound,heta0]
  change pqDeficitArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i-_ ≤ _
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm i.1
  unfold pqDeficitArm
  linarith only [hpd,hqd,hmass,hrem,hpack]

end TSP.Improvements20261105
