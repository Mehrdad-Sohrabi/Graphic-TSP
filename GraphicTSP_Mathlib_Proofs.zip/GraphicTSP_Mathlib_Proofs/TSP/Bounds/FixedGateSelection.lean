import TSP.Improvements20261105.GatedGadgets
import TSP.Chapter11.BundledCuts

/-! Select every bypass type and receiver from the actual DFS children,
before a circulation selector is chosen. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def headedChildren (s : d.tree.Child) : Finset d.tree.Child :=
  (Chapter11.childSet d s).filter (fun r => (d.backGroup r).Nonempty)

noncomputable def headlessChildren (s : d.tree.Child) : Finset d.tree.Child :=
  (Chapter11.childSet d s).filter (fun r => ¬(d.backGroup r).Nonempty)

noncomputable def childOwnMass (x : E → ℝ) (s r : d.tree.Child) : ℝ :=
  edgeSum x ((d.backGroup s).filter (fun e => d.tree.Ancestor r (d.lower e)))

noncomputable def minimumHeadedChild (x : E → ℝ) (s : d.tree.Child) : d.tree.Child :=
  if h : (headedChildren d s).Nonempty then
    Classical.choose (Finset.exists_min_image (headedChildren d s) (childOwnMass d x s) h)
  else s

theorem minimumHeadedChild_spec (x : E → ℝ) (s : d.tree.Child) (h : (headedChildren d s).Nonempty) :
    minimumHeadedChild d x s ∈ headedChildren d s ∧
      ∀ r ∈ headedChildren d s, childOwnMass d x s (minimumHeadedChild d x s) ≤ childOwnMass d x s r := by
  rw [minimumHeadedChild, dif_pos h]
  exact Classical.choose_spec (Finset.exists_min_image (headedChildren d s) (childOwnMass d x s) h)

noncomputable def fixedBypassKind (s : d.tree.Child) : BypassKind :=
  if d.tree.parent s = d.tree.root then .disabled
  else if (Chapter11.childSet d s).card ≤ 1 then .outgoing
  else if 2 ≤ (headlessChildren d s).card then .twoDirections
  else if (headedChildren d s).Nonempty then
    if (headlessChildren d s).Nonempty then .sharedGate else .outsideGate
  else .outgoing

noncomputable def fixedGatePlan (x : E → ℝ) : GatePlan d where
  kind := fixedBypassKind d
  receiver := minimumHeadedChild d x

theorem fixedGatePlan_use_headed (x : E → ℝ) (s : d.tree.Child)
    (h : (fixedGatePlan d x).UsesGate d s) : (headedChildren d s).Nonempty := by
  simp only [GatePlan.UsesGate, fixedGatePlan, fixedBypassKind] at h
  split_ifs at h <;> simp_all

theorem fixedGatePlan_tree (x : E → ℝ) : (fixedGatePlan d x).RespectsTree d := by
  intro s hs
  have hm := (minimumHeadedChild_spec d x s (fixedGatePlan_use_headed d x s hs)).1
  exact (Finset.mem_filter.mp (Finset.mem_filter.mp hm).1).2

theorem fixedGatePlan_root (x : E → ℝ) (s : d.tree.Child) (hs : d.tree.parent s = d.tree.root) :
    (fixedGatePlan d x).kind s = .disabled := by simp [fixedGatePlan, fixedBypassKind, hs]

theorem fixedGatePlan_two (x : E → ℝ) (s : d.tree.Child)
    (hs : (fixedGatePlan d x).kind s = .twoDirections) :
    ∃ c₁ c₂ : d.tree.Child, c₁ ≠ c₂ ∧ d.tree.parent c₁ = (s : V) ∧
      d.tree.parent c₂ = (s : V) ∧ ¬(d.backGroup c₁).Nonempty ∧ ¬(d.backGroup c₂).Nonempty := by
  have hn : 2 ≤ (headlessChildren d s).card := by
    simp only [fixedGatePlan, fixedBypassKind] at hs
    split_ifs at hs <;> simp_all
  obtain ⟨c₁, hc₁, c₂, hc₂, hne⟩ := Finset.one_lt_card.mp (show 1 < (headlessChildren d s).card by omega)
  have h1 := Finset.mem_filter.mp hc₁
  have h2 := Finset.mem_filter.mp hc₂
  exact ⟨c₁, c₂, hne, (Finset.mem_filter.mp h1.1).2, (Finset.mem_filter.mp h2.1).2, h1.2, h2.2⟩

theorem fixedGatePlan_shared (x : E → ℝ) (s : d.tree.Child)
    (hs : (fixedGatePlan d x).kind s = .sharedGate) :
    ∃ c : d.tree.Child, c ≠ (fixedGatePlan d x).receiver s ∧
      d.tree.parent c = (s : V) ∧ ¬(d.backGroup c).Nonempty := by
  have hn : (headlessChildren d s).Nonempty := by
    simp only [fixedGatePlan, fixedBypassKind] at hs
    split_ifs at hs <;> simp_all
  have hm := (minimumHeadedChild_spec d x s (fixedGatePlan_use_headed d x s (Or.inl hs))).1
  obtain ⟨c, hc⟩ := hn
  have hh := Finset.mem_filter.mp hc
  refine ⟨c, ?_, (Finset.mem_filter.mp hh.1).2, hh.2⟩
  intro he
  apply hh.2
  rw [he]
  exact (Finset.mem_filter.mp hm).2

theorem fixedGatePlan_valid (x : E → ℝ) : (fixedGatePlan d x).ValidGadgets d where
  tree := fixedGatePlan_tree d x
  root := fixedGatePlan_root d x
  two := fixedGatePlan_two d x
  shared := fixedGatePlan_shared d x

end TSP.Improvements20261105
