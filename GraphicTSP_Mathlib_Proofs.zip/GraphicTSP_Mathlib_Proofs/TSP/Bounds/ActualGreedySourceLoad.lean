import TSP.Improvements20261105.GreedySourceFiniteContinuous
import TSP.Improvements20261105.GoodPartitionMassBound
import TSP.Improvements20261105.ScoredUniformNetLoad
import TSP.Improvements20261105.ActualGreedyGateComplement

/-! The greedy source row follows from actual back-edge maxima and the
actual gate complement; good labels use genuine unit-part capacities. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
set_option maxHeartbeats 4000000
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable (G : Graph V E) (x z : E → ℝ) (hs : G.IsSimple) (hc : G.Connected) (root : V)
local notation "d" => scoredDFS G x hs hc root

theorem scoredDFS_small_greedy_source_load_uncouponed
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hnr : (d).tree.parent s ≠ (d).tree.root) (hsc : ¬ScoredStar d x s)
    (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hcount : ((d).backGroup s).card ≤ 19)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      24*survivingExcess d x s+refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  let n := ((d).backGroup s).card
  let q := x ((d).treeEdge s)
  let a := edgeSum z ((d).backGroup s)
  let I := refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s
  have hq0 : 0 ≤ q := hx.1 _
  have hq1 : q ≤ 1 := hcap _
  have hM := scoredDFS_unscored_maximum G x hs hc root s hsc
  have hcapz (e : E) (he : e ∈ (d).backGroup s) : z e ≤ q :=
    (hzx e).trans (scoredDFS_not_scored_greedy G x hs hc root s hsc e he)
  have hmcount : a ≤ (n : ℝ)*q := by
    have hh := Finset.sum_le_sum (s := (d).backGroup s) hcapz
    simpa [edgeSum,a,n] using hh
  have hn2 : 2 ≤ n := by
    by_contra hh
    have hn1 : (n : ℝ) ≤ 1 := by exact_mod_cast (show n≤1 by omega)
    have hh := mul_le_mul_of_nonneg_right hn1 hq0
    change 1<a at hpositive
    nlinarith only [hmcount,hh,hpositive,hq1]
  obtain ⟨k,hk,hka,hak⟩ := exists_mass_interval n q a (by omega) hq0 (by linarith) hmcount
  have hNinc := (refined_fixed_incidence_le_noncritical d x z eligible T s).trans
    (noncritical_signed_packing_envelope d z s q k (fun e _ => hz e) hcapz)
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  have hpack := fixed_projection_star_pack d hs hx hcap hn (allFullOverrideTargets d x) hm s
  have hgoodR : n%2=0 → bad=0 → a+q-1 ≤ ((n : ℝ)/2)*q := by
    intro hpar hb
    have hn2 : n=2*(n/2) := by omega
    have hh := unitPartCapacities_star_even_bound d hs x z hx.1 hz hzx htree s (hgood hpar hb)
      (n/2) hn2
    rw [hM] at hh
    have hnR : (n : ℝ)=2*((n/2 : ℕ) : ℝ) := by exact_mod_cast hn2
    change q+a ≤ 1+((n/2 : ℕ) : ℝ)*q at hh
    rw [hnR]
    linarith only [hh]
  have hgate : 4≤n → n≤25 → q ≤ ScoredParameters.lower n ∨
      ScoredParameters.upper n ≤ q ∨ q+a ≤ 2-ScoredParameters.incomingThreshold n := by
    intro hlo hhi
    exact scoredDFS_positive_greedy_gate_complement G x z hs hc root hx hn hm s hnr hsc hpositive hlo hhi
  have hrow := greedy_source_finite_continuous n k bad hn2 hcount hk hbad q a I δ hq0 hq1
    hpositive.le hmcount (by change a+q ≤ 2; linarith only [hpack]) hka hak
    hδ0 (hδ.trans (min_le_right _ _)) (by have hh:=hδ.trans (min_le_left _ _); change δ+q+a≤2; linarith only [hh,he])
    hgoodR hgate hNinc
  have ho0 : 0 ≤ outgoingBackMass d x s := Finset.sum_nonneg (fun e _ => hx.1 e)
  linarith only [hrow,ho0,he]

theorem scoredDFS_small_greedy_source_load
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (htree : ∀ s, z ((d).treeEdge s)=x ((d).treeEdge s))
    (hm : ∀ s, edgeSum z ((d).backGroup s) = edgeSum x ((d).backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (eligible T : Finset (d).tree.Child) (s : (d).tree.Child)
    (hnr : (d).tree.parent s ≠ (d).tree.root) (hsc : ¬ScoredStar d x s)
    (hpositive : 1 < edgeSum z ((d).backGroup s))
    (hcount : ((d).backGroup s).card ≤ 19)
    (bad : ℕ) (hbad : bad ≤ 1)
    (hgood : ((d).backGroup s).card%2=0 → bad=0 → UnitPartCapacities G z ((d).tree.parent s))
    (δ : ℝ) (hδ0 : 0 ≤ δ)
    (hδ : δ ≤ min (1-x ((d).treeEdge s)-survivingExcess d x s) (1/2)) :
    (415/2 : ℝ)*(survivingExcess d x s-outgoingBackMass d x s)-(704/5)+
      canonicalHeadLoad d (fixedGatePlan d x) x z (fixedCriticalHeads d x z eligible) T
        (projectedOutgoingCoupon d x z) s+24*δ ≤
      4*((((d).backGroup s).card : ℝ)+1)+2*(bad : ℝ) := by
  have hu := scoredDFS_small_greedy_source_load_uncouponed G x z hs hc root hx hn hcap hz hzx htree hm eligible T s hnr hsc hpositive hcount bad hbad hgood δ hδ0 hδ
  have hl := canonicalHeadLoad_le_uncouponed d (fixedGatePlan d x) x z hx.1
    (fixedCriticalHeads d x z eligible) T (projectedOutgoingCoupon d x z)
    (fun s => projectedOutgoingCoupon_nonneg d x z hx.1 hcap hz s) s
  have he := fixed_projected_excess_eq d hs x z hx hn (allFullOverrideTargets d x) hm s
  rw [max_eq_left (by linarith)] at he
  linarith only [hu,hl,he]

end TSP.Improvements20261105
