import TSP.Improvements20261105.SourceRegionBackBudget

/-! A region inside an actual leaf with no actual head centers cannot
have an outgoing back edge. Thus every back crossing its boundary has
its tail inside the region, as needed for disjoint-boundary accounting. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.head_free_region_back_tail (P : GatePlan d) (a : GatedDrops d)
    (r : FlowVertex d) (hout : a.componentOutgoingCuts d P r = ∅)
    (A : Finset V) (hinside : A ⊆ a.originalComponentVertices d P r)
    (hcenters : ∀ i ∈ a.actualComponentStars d P r, d.centers i ∉ A)
    (e : E) (he : e ∈ G.cut A ∩ d.backEdges) : d.lower e ∈ A := by
  have hcut : (d.upper e ∈ A ∧ d.lower e ∉ A) ∨ (d.lower e ∈ A ∧ d.upper e ∉ A) := by
    have hc := (Finset.mem_inter.mp he).1
    rcases d.oriented e with hor | hor
    · simpa only [Graph.cut,Finset.mem_filter,Finset.mem_univ,true_and,hor.1,hor.2] using hc
    · simpa only [Graph.cut,Finset.mem_filter,Finset.mem_univ,true_and,hor.1,hor.2,or_comm] using hc
  rcases hcut with hup | hlo
  · have hupper := (Finset.mem_filter.mp (hinside hup.1)).2
    have hanc : (expandedTree d).Ancestor (.inl (d.upper e)) (.inr (d.anchor e)) := by
      rw [← (d.anchor_spec e).1]
      exact Relation.ReflTransGen.single (expanded_auxiliary_parent_step d (d.anchor e))
    have hcomp := a.leaf_descendant_same d P r hout (.inl (d.upper e)) (.inr (d.anchor e)) hupper hanc
    let b : BackEdge d := ⟨e,(Finset.mem_inter.mp he).2⟩
    let i : d.StarIndex := ⟨d.anchor e,own_back_anchor_active d b⟩
    have hi : i ∈ a.actualComponentStars d P r := Finset.mem_filter.mpr ⟨Finset.mem_univ _,hcomp⟩
    have hcenter : d.centers i = d.upper e := (d.anchor_spec e).1
    exact False.elim (hcenters i hi (hcenter.symm ▸ hup.1))
  · exact hlo.1

end TSP.Improvements20261105
