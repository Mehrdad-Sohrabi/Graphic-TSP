import TSP.Improvements20261105.ZeroComponentPBounds
import TSP.Improvements20261105.GuardedPQZConstruction
import TSP.Improvements20261105.ZeroLeafEntryPayment

/-! The actual terminal-repaired P and guarded Q retain every zero-only
component credit after the common P projection charge is set aside. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Manuscript20261020 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem jointHeadTerm_le_max (C W nu : ℝ) (hn : 0 ≤ nu) :
    jointHeadTerm C W nu ≤ max C W := by
  rw [jointHeadTerm_identity]
  exact sub_le_self _ (mul_nonneg (sub_nonneg.mpr (le_max_right _ _)) hn)

theorem GatedDrops.currentGuardedP_zero_component_credit (hs : G.IsSimple)
    (P : GatePlan d) (hP : P.RespectsTree d) (t : d.tree.Child → ℝ) (ht : ∀ v, 0 ≤ t v)
    (f : GatedArc d → ℝ) (hf : Chapter06.Balanced (gatedNetwork d P) f)
    (hb : RealFlowBounds (gatedLower d P) (gatedAugmentedUpper d P t) f)
    (a : GatedDrops d) (ha : a.Admissible d P) (hcan : CanonicalGatedFor d P t f (a.potential d P))
    (x z : E → ℝ) (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (hm : ∀ s, edgeSum z (d.backGroup s) = edgeSum x (d.backGroup s)-
      fixedRemoval d x (allFullOverrideTargets d x) s)
    (C : ProjectedCoverWitness d x z (415/2) (704/5))
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (Y R : E ⊕ d.StarIndex → ℝ)
    (r : FlowVertex d) (hr : r ≠ .inl d.tree.root)
    (hzero : ∀ c ∈ a.actualComponentHeads d P r, edgeSum x (d.backGroup c) ≤ 1)
    (i : d.StarIndex) (hi : i ∈ a.actualComponentStars d P r)
    (hQ : max (R (.inr i)-edgeSum x (d.stars i)/2)
      ((d.stars i).card-1-edgeSum R (starRepresentatives d.stars i)-edgeSum x (d.stars i)/2) ≤
        -zeroQCredit d x Y i) :
    let A := currentGuardedP d x z C owner rootStar
    jointHeadTerm (pqConnectorArm d x (415/2) (704/5) A R i)
      (pqDeficitArm d x (415/2) (704/5) A R i) (a.head i.1 : ℝ) -
        (415/2 : ℝ)*fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 ≤
      -(704/5 : ℝ)*zeroQCredit d x Y i := by
  let H := fixedHForceTargets d x z (415/2) (704/5) C
  let T := fixedPositiveTerminalChildren d x
  let delta : d.StarIndex → ℝ := terminalPIncrease d x T
    (fun j => forcedCoverIncrease d x z (415/2) (704/5) 60 24 4 C H j.1)
  have hd : AdmissibleAdjustment d x delta := by
    apply terminalPIncrease_admissible d hs x hx hn hcap
    exact forcedCoverIncrease_admissible d hs x z hx hn hcap hm (415/2) (704/5) 60 24 4
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
      (by norm_num) (by norm_num) C H (fixedHForceTargets_subset d x z (415/2) (704/5) C)
  have hz : ∀ j : d.StarIndex, a.component d P (.inr j.1) = r → delta j = 0 := by
    intro j hj
    exact a.zero_component_terminal_repair_zero d hs P hP t ht f hf hb ha hcan x z hx hn
      (415/2) (704/5) 60 24 4 C H T (fixedHForceTargets_subset d x z (415/2) (704/5) C) r hzero j hj
  have hcomp := (Finset.mem_filter.mp hi).2
  have hnr := a.nonroot_component_head_center d P r hr i hcomp
  have hir : i ≠ rootStar := fun h => hnr (h ▸ hroot)
  have hback := hzero i.1 (Finset.mem_filter.mpr ⟨Finset.mem_univ _, i.2, hcomp⟩)
  have hp := a.zero_component_P_connector d hs P hP t ht f hf hb ha hcan x hx hcap r delta hd hz
    owner ho rootStar i hir hnr hcomp
  have hcost := zero_component_PQ_credit d x delta hd owner rootStar Y R (415/2) (704/5)
    (by norm_num) (by norm_num) i hnr hback hp hQ
  have hterm := jointHeadTerm_le_max
    (pqConnectorArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i)
    (pqDeficitArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i)
    (a.head i.1) (by exact_mod_cast ha.head_nonneg i.1)
  have hcharge : starTau d x i ≤ fixedProjectionCharge d x (allFullOverrideTargets d x) i.1 :=
    starTau_le_fixedProjectionCharge d hs x (allFullOverrideTargets d x) i
  change jointHeadTerm
    (pqConnectorArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i)
    (pqDeficitArm d x (415/2) (704/5) (generalPoint d owner rootStar x delta) R i)
    (a.head i.1 : ℝ) - _ ≤ _
  linarith

end TSP.Improvements20261105
