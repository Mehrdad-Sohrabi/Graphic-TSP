import TSP.Improvements20261105.GatedComponentMass
import TSP.Improvements20261105.RootedCutLeaves

/-! Choose actual original DFS leaves in empty true-cut components.
Every back from a chosen leaf goes to a selected head in its unique
parent component. No incidence or tour inequality is assumed. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.leaf_component_original_leaf (P : GatePlan d) (a : GatedDrops d)
    (r : a.Component d P) (hout : a.componentOutgoingCuts d P r = ∅) :
    ∃ v : V, a.component d P (.inl v) = r ∧ ∀ c : d.tree.Child, d.tree.parent c ≠ v := by
  obtain ⟨w, hw, hleaf⟩ := (expandedTree d).leaf_component_contains_leaf
    (a.trueCuts d P) r hout
  cases w with
  | inl v =>
    refine ⟨v, hw, ?_⟩
    intro c hc
    apply hleaf (expandedConnectorChild d c)
    change Sum.inl (d.tree.parent c) = Sum.inl v
    exact congrArg Sum.inl hc
  | inr v =>
    exact (hleaf (expandedRepresentativeChild d v) (expanded_original_parent_step d v).2).elim

abbrev GatedDrops.EmptyLeaf (P : GatePlan d) (a : GatedDrops d) :=
  {r : a.Component d P // r ∈ a.emptyLeafComponents d P}

theorem GatedDrops.emptyLeaf_no_outgoing (P : GatePlan d) (a : GatedDrops d)
    (r : a.EmptyLeaf d P) : a.componentOutgoingCuts d P r.1 = ∅ :=
  Finset.not_nonempty_iff_eq_empty.mp (Finset.mem_filter.mp r.2).2.1

theorem GatedDrops.emptyLeaf_no_heads (P : GatePlan d) (a : GatedDrops d)
    (r : a.EmptyLeaf d P) : a.actualComponentHeads d P r.1 = ∅ :=
  Finset.not_nonempty_iff_eq_empty.mp (Finset.mem_filter.mp r.2).2.2

noncomputable def GatedDrops.emptyLeafVertex (P : GatePlan d) (a : GatedDrops d)
    (r : a.EmptyLeaf d P) : V :=
  Classical.choose (a.leaf_component_original_leaf d P r.1 (a.emptyLeaf_no_outgoing d P r))

theorem GatedDrops.emptyLeafVertex_spec (P : GatePlan d) (a : GatedDrops d)
    (r : a.EmptyLeaf d P) :
    a.component d P (.inl (a.emptyLeafVertex d P r)) = r.1 ∧
      ∀ c : d.tree.Child, d.tree.parent c ≠ a.emptyLeafVertex d P r :=
  Classical.choose_spec (a.leaf_component_original_leaf d P r.1 (a.emptyLeaf_no_outgoing d P r))

theorem GatedDrops.emptyLeafVertex_injective (P : GatePlan d) (a : GatedDrops d) :
    Function.Injective (a.emptyLeafVertex d P) := by
  intro r s he
  apply Subtype.ext
  apply Subtype.ext
  exact (a.emptyLeafVertex_spec d P r).1.symm.trans
    ((congrArg (fun v => a.component d P (.inl v)) he).trans (a.emptyLeafVertex_spec d P s).1)

theorem GatedDrops.root_component_has_head (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) :
    (a.actualComponentHeads d P (.inl d.tree.root)).Nonempty := by
  obtain ⟨v, hv⟩ := root_child_exists d hc
  have hg := root_group_nonempty d hs hc v hv
  have hz : a.trueRoleWeight d P (.inl v) = 0 := by simp [trueRoleWeight, hv]
  have hh := a.component_uncut_connector d P v hz
  rw [hv] at hh
  have hr : a.component d P (.inl d.tree.root) = .inl d.tree.root :=
    (expandedTree d).cutComponentRoot_root (a.trueCuts d P)
  refine ⟨v, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hg, hh.trans hr⟩⟩

theorem GatedDrops.emptyLeaf_not_root (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.EmptyLeaf d P) :
    (r.1 : FlowVertex d) ≠ (expandedTree d).root := by
  intro he
  have hh := a.root_component_has_head d hs hc P
  have hz := a.emptyLeaf_no_heads d P r
  rw [he] at hz
  change a.actualComponentHeads d P (.inl d.tree.root) = ∅ at hz
  rw [hz] at hh
  exact Finset.not_nonempty_empty hh

noncomputable def GatedDrops.emptyLeafEnteringCut (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.EmptyLeaf d P) : (expandedTree d).Child :=
  (expandedTree d).enteringCut (a.trueCuts d P) r.1 (a.emptyLeaf_not_root d hs hc P r)

noncomputable def GatedDrops.emptyLeafParent (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.EmptyLeaf d P) : a.Component d P :=
  (expandedTree d).cutComponentMap (a.trueCuts d P)
    ((expandedTree d).parent (a.emptyLeafEnteringCut d hs hc P r))

theorem GatedDrops.back_from_emptyLeaf (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P)
    (r : a.EmptyLeaf d P) (b : BackEdge d) (htail : d.lower b.1 = a.emptyLeafVertex d P r) :
    d.anchor b.1 ∈ a.componentHeads d P (a.emptyLeafParent d hs hc P r) := by
  have htailcomp : a.component d P (.inl (d.lower b.1)) = r.1 := by
    rw [htail]
    exact (a.emptyLeafVertex_spec d P r).1
  have hg : (d.backGroup (d.anchor b.1)).Nonempty :=
    ⟨b.1, (d.mem_backGroup_iff _ _).mpr ⟨b.2, (d.anchor_spec b.1).1.symm, (d.anchor_spec b.1).2⟩⟩
  have hne : a.component d P (.inr (d.anchor b.1)) ≠ a.component d P (.inl (d.lower b.1)) := by
    intro he
    have hm : d.anchor b.1 ∈ a.actualComponentHeads d P r.1 :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, hg, he.trans htailcomp⟩
    rw [a.emptyLeaf_no_heads d P r] at hm
    exact Finset.not_mem_empty _ hm
  have hn : (a.backPathCuts d P b).Nonempty :=
    Finset.nonempty_iff_ne_empty.mpr (fun hz => hne ((a.backPathCuts_empty_iff_same d ha b).mp hz))
  have hcard : (a.backPathCuts d P b).card = 1 := by
    have hlo := Finset.card_pos.mpr hn
    have hhi := a.backPathCuts_card_le_one d ha b
    omega
  obtain ⟨w, hw, hbefore, hafter⟩ := (expandedTree d).cutsOnPath_card_one_decomposition (a.trueCuts d P) hcard
  have hwr : (expandedTree d).cutComponentRoot (a.trueCuts d P) w = r.1 :=
    ((expandedTree d).cutComponentRoot_cut (a.trueCuts d P) w hw).trans
      (hafter.symm.trans htailcomp)
  have hwe : w = a.emptyLeafEnteringCut d hs hc P r :=
    (expandedTree d).enteringCut_unique (a.trueCuts d P) r.1
      (a.emptyLeaf_not_root d hs hc P r) w hw hwr
  refine (a.mem_componentHeads d P _ _).mpr ⟨a.crossing_back_selected d ha b hn, ?_⟩
  change a.component d P (.inr (d.anchor b.1)) =
    a.component d P ((expandedTree d).parent (a.emptyLeafEnteringCut d hs hc P r))
  rw [← hwe]
  exact hbefore.symm

theorem GatedDrops.emptyLeafParent_internal (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    (P : GatePlan d) (a : GatedDrops d) (r : a.EmptyLeaf d P) :
    a.emptyLeafParent d hs hc P r ∈ a.internalComponents d P := by
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_univ _, a.emptyLeafEnteringCut d hs hc P r, ?_⟩
  apply Finset.mem_filter.mpr
  exact ⟨(expandedTree d).enteringCut_mem (a.trueCuts d P) r.1
    (a.emptyLeaf_not_root d hs hc P r), rfl⟩

end TSP.Improvements20261105
