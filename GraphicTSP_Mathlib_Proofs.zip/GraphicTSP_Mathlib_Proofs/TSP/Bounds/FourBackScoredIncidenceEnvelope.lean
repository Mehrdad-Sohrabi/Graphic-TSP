import TSP.Improvements20261105.ScoredSourcePacking

namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [LinearOrder E]
variable {G : Graph V E} (d : DFSData G)

theorem four_back_scored_incidence_envelope (x z : E → ℝ)
    (hz : ∀ e, 0 ≤ z e) (hzx : ∀ e, z e ≤ x e)
    (eligible T : Finset d.tree.Child) (s : d.tree.Child)
    (hcount : (d.backGroup s).card=4) (hsc : ScoredStar d x s) (hel : s ∈ eligible) :
    refinedIncidenceCharge d x z (fixedCriticalHeads d x z eligible) T s ≤
      max (144*starMaximum d x s-36+(96/19)*(1000/57)*
        (4*(x (d.treeEdge s)+(1/10)*outgoingBackMass d x s)-edgeSum z (d.backGroup s))-96/19)
        (-(124/5)*(2-edgeSum z (d.backGroup s))) := by
  let M := starMaximum d x s
  have hMlo : (9/25 : ℝ) ≤ M := by simpa [ScoredParameters.lower,hcount] using hsc.2.2.2.2.1
  have hcapS (e : E) (he : e ∈ d.backGroup s) : z e ≤ M :=
    (hzx e).trans (le_finiteMaximum x (Finset.mem_sdiff.mp he).1)
  have hmass : edgeSum z (d.backGroup s) ≤ 4*M := by
    have hh := Finset.sum_le_sum (s := d.backGroup s) hcapS
    simpa only [Finset.sum_const,nsmul_eq_mul,hcount,Nat.cast_ofNat] using hh
  have hraw := rawCriticalIncidence_packed_score d x z s M 4 (fun e _ => hz e) hcapS
  have hpackMu : packedSignedMu M (edgeSum z (d.backGroup s)) 4=(38/5)*M-19/10 := by
    rw [packedSignedMu,if_neg (by linarith only [hMlo] : ¬M ≤ 9/38)]
    norm_num only [Nat.cast_ofNat]
    rw [max_eq_right (by linarith only [hmass] : (19/10)*(edgeSum z (d.backGroup s)-4*M)-9/20 ≤ 0)]
    ring
  rw [hpackMu,hcount] at hraw
  norm_num [Nat.cast_ofNat,ScoredParameters.localMassSlope,ScoredParameters.upper,ScoredParameters.coefficient] at hraw
  have hB : winningBenchmark d x s ≤ x (d.treeEdge s)+(1/10)*outgoingBackMass d x s := by
    unfold winningBenchmark ScoredParameters.benchmark
    rw [hcount]
    norm_num [ScoredParameters.coefficient]
  have hraw' : rawCriticalIncidence d x z s ≤ 144*M-36+(96/19)*(1000/57)*
      (4*(x (d.treeEdge s)+(1/10)*outgoingBackMass d x s)-edgeSum z (d.backGroup s))-96/19 := by
    linarith only [hraw,hB]
  exact (refined_fixed_incidence_le_clipped d x z eligible T s hel).trans
    (max_le_max hraw' (le_refl _))

end TSP.Improvements20261105
