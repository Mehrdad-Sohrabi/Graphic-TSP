import TSP.Improvements20261105.InducedCutRank

/-! Every induced subgraph of a positive extreme subtour support has
at most 2|W|-3 edges for |W| >= 2. Extremality is required only of the
original vector, never of a subsequently capped or projected vector. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

theorem restrictedCutFamily_card_bound (W : Finset V) (r : W) (hW : 2 ≤ W.card)
    (F : Finset (Finset V)) (hF : LaminarFamily F) (hr : ∀ U ∈ F, r.1 ∉ U) :
    (restrictedCutFamily W F).card ≤ 2 * W.card - 3 := by
  apply (laminar_family_card_bound r (by simpa using hW) _
    (restrictedCutFamily_laminar W F hF) ?_ ?_).trans (by simp)
  · intro U hU
    exact Finset.nonempty_iff_ne_empty.mpr (Finset.mem_erase.mp hU).1
  · intro U hU
    obtain ⟨Z, hZ, rfl⟩ := Finset.mem_image.mp (Finset.mem_of_mem_erase hU)
    simpa using hr Z hZ

theorem extreme_induced_support_sparsity (G : Graph V E) {x : E → ℝ}
    (hx : x ∈ G.subtourPolytope.extremePoints ℝ) (hpositive : ∀ e, 0 < x e)
    (W : Finset V) (hW : 2 ≤ W.card) :
    (G.internalEdges W).card ≤ 2 * W.card - 3 := by
  obtain ⟨r, hr⟩ := Finset.card_pos.mp (show 0 < W.card by omega)
  have hempty : LaminarFamily (∅ : Finset (Finset V)) := by intro A hA; simp at hA
  obtain ⟨F, _, hlam, htight, hspan⟩ := exists_laminar_tight_span_extension G hx.1 hpositive r
    ∅ hempty (by intro A hA; simp at hA)
  have hfull : ∀ A, edgeSum x (G.cut A) = 2 → incidence (G.cut A) ∈ tightCutSpan G F := by
    intro A hA
    by_cases ha : r ∈ A
    · have hh := hspan Aᶜ (tight_shore_of_avoids G x r Aᶜ (by simpa using ha)
        (by simpa only [cut_complement] using hA))
      simpa only [cut_complement] using hh
    · exact hspan A (tight_shore_of_avoids G x r A ha hA)
  have hrows := spanning_cut_rows_injective G hx hpositive F hfull
  exact (induced_edge_card_le_family G W F hrows).trans
    (restrictedCutFamily_card_bound W ⟨r, hr⟩ hW F hlam (fun A hA => (htight A hA).2.1))

end TSP.Improvements20261105
