import TSP.Improvements20261105.GatedDualGeometry

/-! A shift on the original descendant subtree, including its entering
head, removes an active representative drop. The only incoming unlimited
arcs of the shifted shore are that representative and its reverse-head arc. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def descendantBit (s : d.tree.Child) (v : V) : ℤ :=
  if d.tree.Ancestor s v then 1 else 0

theorem descendantBit_mono (s : d.tree.Child) {u v : V} (h : d.tree.Ancestor u v) :
    descendantBit d s u ≤ descendantBit d s v := by
  unfold descendantBit
  split_ifs with hu hv hv
  · omega
  · exact (hv (h.trans hu)).elim
  · omega
  · omega

theorem descendantBit_child_difference (s v : d.tree.Child) :
    descendantBit d s v - descendantBit d s (d.tree.parent v) = if v = s then 1 else 0 := by
  by_cases hvs : v = s
  · subst v
    have hn : ¬d.tree.Ancestor s (d.tree.parent s) := by
      intro h
      have hh := d.tree.ancestor_depth_le h
      have hd := d.tree.parent_depth s s.2
      omega
    simp [descendantBit, hn, show d.tree.Ancestor s s from .refl]
  · have hne : (v : V) ≠ s := fun h => hvs (Subtype.ext h)
    have he : d.tree.Ancestor s v ↔ d.tree.Ancestor s (d.tree.parent v) := by
      constructor
      · exact fun h => d.tree.ancestor_parent_of_ne h hne
      · intro h
        exact (Relation.ReflTransGen.single ⟨v.2, rfl⟩).trans h
    simp [descendantBit, hvs, he]

noncomputable def gatedRepresentativeSide (s : d.tree.Child) : GatedVertex d → ℤ
  | .inl (.inl v) => descendantBit d s v
  | .inl (.inr v) => descendantBit d s (d.tree.parent v)
  | .inr (.inl v) => descendantBit d s v
  | .inr (.inr (v, k)) =>
      if k = 1 then descendantBit d s (d.tree.parent v) else descendantBit d s v

theorem gatedRepresentativeSide_bypass (P : GatePlan d) (hP : P.RespectsTree d)
    (s v : d.tree.Child) :
    gatedRepresentativeSide d s (gatedBypassTarget d P v) =
      gatedRepresentativeSide d s (gatedBypassSource d P v) := by
  cases hv : P.kind v <;>
    simp [gatedBypassTarget, gatedBypassSource, hv, gatedRepresentativeSide]
  rw [hP v (Or.inr hv)]

theorem gatedRepresentativeSide_incoming (P : GatePlan d) (hP : P.RespectsTree d)
    (s : d.tree.Child) (a : GatedArc d) :
    gatedRepresentativeSide d s ((gatedNetwork d P).dst a) -
      gatedRepresentativeSide d s ((gatedNetwork d P).src a) ≤
      if a = gatedRepArc d s ∨ a = gatedReverseArc d s then 1 else 0 := by
  rcases a with ((v | v) | b) | (v | ⟨v, k⟩)
  · simp [gatedNetwork, gatedRepresentativeSide]
  · simpa [gatedNetwork, gatedRepresentativeSide] using
      le_of_eq (descendantBit_child_difference d s v)
  · have hh := descendantBit_mono d s (d.anchor_spec b.1).2
    by_cases ho : P.OutsideBack d b <;>
      simpa [gatedNetwork, gatedRepresentativeSide, ho, sub_nonpos] using hh
  · simp [gatedNetwork, gatedRepresentativeSide]
  · fin_cases k
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide]
    · have hh := descendantBit_mono d s
        (show d.tree.Ancestor (d.tree.parent v) v from .single ⟨v.2, rfl⟩)
      simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide, sub_nonpos] using hh
    · simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide] using
        le_of_eq (descendantBit_child_difference d s v)
    · have hh := descendantBit_mono d s
        (show d.tree.Ancestor (d.tree.parent v) v from .single ⟨v.2, rfl⟩)
      by_cases ho : P.IsReceiver d v <;>
        simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide,
          ho, sub_nonpos] using hh
    · have hh := gatedRepresentativeSide_bypass d P hP s v
      simpa [gatedNetwork, gatedExtraSrc, gatedExtraDst, hh] using sub_nonpos.mpr (le_of_eq hh)
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide]
    · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide]
    · by_cases hv : P.kind v = .sharedGate
      · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide,
          hv, hP v (Or.inl hv)]
      · simp [gatedNetwork, gatedExtraSrc, gatedExtraDst, gatedRepresentativeSide, hv]

noncomputable def raiseRepresentativeSubtree (p : GatedVertex d → ℤ)
    (s : d.tree.Child) (δ : ℤ) (w : GatedVertex d) : ℤ :=
  p w + δ * gatedRepresentativeSide d s w

theorem raiseRepresentativeSubtree_feasible (P : GatePlan d) (hP : P.RespectsTree d)
    (p : GatedVertex d → ℤ) (hp : GatedDualFeasible d P p)
    (s : d.tree.Child) (δ : ℤ) (hδ : 0 ≤ δ)
    (hr : δ ≤ gatedRepresentativeDrop d p s) (hh : δ ≤ gatedHeadSelector d p s) :
    GatedDualFeasible d P (raiseRepresentativeSubtree d p s δ) := by
  intro a ha
  have ho := hp a ha
  have hb := gatedRepresentativeSide_incoming d P hP s a
  by_cases he : a = gatedRepArc d s ∨ a = gatedReverseArc d s
  · rcases he with rfl | rfl
    · have hs : gatedRepresentativeSide d s (gatedCenter d s) -
          gatedRepresentativeSide d s (gatedAux d s) = 1 := by
        simpa [gatedRepresentativeSide] using descendantBit_child_difference d s s
      simp only [raiseRepresentativeSubtree, gatedNetwork, gatedCost,
        Sum.elim_inl, Sum.elim_inr, Nat.cast_zero]
      dsimp [gatedRepresentativeDrop] at hr
      nlinarith
    · have hs : gatedRepresentativeSide d s (gatedHead d s) -
          gatedRepresentativeSide d s (gatedAux d s) = 1 := by
        simpa [gatedRepresentativeSide] using descendantBit_child_difference d s s
      simp only [raiseRepresentativeSubtree, gatedNetwork, gatedExtraSrc,
        gatedExtraDst, gatedCost, Sum.elim_inl, Sum.elim_inr]
      norm_num [show (2 : Fin 8) ≠ 3 by decide]
      dsimp [gatedHeadSelector] at hh
      nlinarith
  · rw [if_neg he] at hb
    dsimp only [raiseRepresentativeSubtree]
    nlinarith

end TSP.Improvements20261105
