import TSP.Improvements20261105.BinaryClipping
import TSP.Chapter10.LPRepairCost
import TSP.Chapter04.FrameworkTwo

/-! The binary Z construction yields an actual graphic-TSP cost row.
The charge keeps connector deficiency and head overflow together. -/
namespace TSP.Improvements20261105
open Graph Chapter02 Chapter03 Chapter04 Chapter05 Chapter06 Chapter08 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

noncomputable def binaryHeadCharge (B : Finset E) (R : Finset d.tree.Child)
    (v : d.tree.Child) : ℝ :=
  max (if SelectedForeignCover d B v then 0 else 1)
    (((B ∩ d.backGroup v).card : ℝ) - (if v ∈ R then 1 else 0) - 1)

theorem binary_tree_lower (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (v : d.tree.Child) :
    1 / 3 + (2 / 3) * (if v ∈ R then (1 : ℝ) else 0) ≤
      binaryNonloopPoint d B R (Sum.inl (d.treeEdge v)) := by
  change _ ≤ expandedBinaryPoint d B R (Sum.inl (d.treeEdge v))
  rw [expandedBinaryPoint_tree d B hB]
  split_ifs <;> norm_num at * <;> tauto

theorem binary_back_sum (B : Finset E) (R : Finset d.tree.Child) (v : d.tree.Child) :
    (∑ b ∈ d.backGroup v, binaryNonloopPoint d B R (Sum.inl b)) =
      ((d.backGroup v).card : ℝ) - (2 / 3) * (B ∩ d.backGroup v).card := by
  have heq : ∀ b ∈ d.backGroup v, binaryNonloopPoint d B R (Sum.inl b) =
      1 - (2 / 3) * (if b ∈ B then (1 : ℝ) else 0) := by
    intro b hb
    change expandedBinaryPoint d B R (Sum.inl b) = _
    rw [expandedBinaryPoint_back d B R b ((d.mem_backGroup_iff v b).mp hb).1]
    split_ifs <;> norm_num
  rw [Finset.sum_congr rfl heq, Finset.sum_sub_distrib, ← Finset.mul_sum]
  have hi : (∑ b ∈ d.backGroup v, if b ∈ B then (1 : ℝ) else 0) = (B ∩ d.backGroup v).card := by
    rw [← Finset.sum_filter]
    simp [Finset.filter_mem_eq_inter, Finset.inter_comm]
  rw [hi]
  simp

theorem binary_star_sum_lower (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (i : d.StarIndex) :
    ((d.backGroup i.1).card : ℝ) + 1 / 3 + (2 / 3) * (if i.1 ∈ R then (1 : ℝ) else 0) -
      (2 / 3) * (B ∩ d.backGroup i.1).card ≤
      edgeSum (binaryNonloopPoint d B R) (starRepresentatives d.stars i) := by
  unfold edgeSum starRepresentatives
  rw [Finset.sum_map]
  change _ ≤ ∑ b ∈ d.group i.1, binaryNonloopPoint d B R (Sum.inl b)
  rw [d.group_eq_insert_backGroup, Finset.sum_insert (by simp [DFSData.backGroup]), binary_back_sum]
  have hh := binary_tree_lower d B hB R i.1
  linarith

theorem binary_star_cost_le (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (i : d.StarIndex) :
    max (binaryNonloopPoint d B R (Sum.inr i))
      ((d.stars i).card - 1 - edgeSum (binaryNonloopPoint d B R) (starRepresentatives d.stars i)) ≤
      1 / 3 + (2 / 3) * binaryHeadCharge d B R i.1 := by
  have hs := binary_star_sum_lower d B hB R i
  have hc : binaryNonloopPoint d B R (Sum.inr i) =
      if SelectedForeignCover d B i.1 then 1 / 3 else 1 :=
    expandedBinaryPoint_connector d B hB R i.1
  have hleft := le_max_left (if SelectedForeignCover d B i.1 then (0 : ℝ) else 1)
    (((B ∩ d.backGroup i.1).card : ℝ) - (if i.1 ∈ R then 1 else 0) - 1)
  have hright := le_max_right (if SelectedForeignCover d B i.1 then (0 : ℝ) else 1)
    (((B ∩ d.backGroup i.1).card : ℝ) - (if i.1 ∈ R then 1 else 0) - 1)
  change _ ≤ 1 / 3 + (2 / 3) * max _ _
  apply max_le
  · rw [hc]
    split_ifs at hleft ⊢ <;> linarith
  · change ((d.group i.1).card : ℝ) - 1 - _ ≤ _
    rw [group_card, Nat.cast_add, Nat.cast_one]
    linarith

theorem binary_root_cost_le (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (i : d.StarIndex) (hi : d.centers i = d.tree.root)
    (hroot : i.1 ∉ R) :
    max (binaryNonloopPoint d B R (Sum.inr i))
      ((d.stars i).card - 1 - edgeSum (binaryNonloopPoint d B R) (starRepresentatives d.stars i)) ≤
      1 + (2 / 3) * max (((B ∩ d.backGroup i.1).card : ℝ) - 2) 0 := by
  have hs := binary_star_sum_lower d B hB R i
  rw [if_neg hroot] at hs
  have hc : binaryNonloopPoint d B R (Sum.inr i) = 1 :=
    expandedBinaryPoint_root_connector d B hB R i.1 hi
  have h₁ := le_max_left (((B ∩ d.backGroup i.1).card : ℝ) - 2) 0
  have h₂ := le_max_right (((B ∩ d.backGroup i.1).card : ℝ) - 2) 0
  apply max_le
  · rw [hc]
    linarith
  · change ((d.group i.1).card : ℝ) - 1 - _ ≤ _
    rw [group_card, Nat.cast_add, Nat.cast_one]
    linarith

theorem binary_nonremovable_sum (B : Finset E) (hB : B ⊆ d.backEdges)
    (R : Finset d.tree.Child) (hown : ∀ v ∈ R, 2 ≤ (B ∩ d.backGroup v).card)
    (hcover : ∀ v : d.tree.Child, ¬(d.backGroup v).Nonempty → SelectedTreeCover d B v) :
    edgeSum (binaryNonloopPoint d B R) (nonremovableRepresentatives d.stars) =
      ((Finset.univ \ removableEdges d.stars).card : ℝ) / 3 := by
  have hvalue : ∀ e ∈ Finset.univ \ removableEdges d.stars,
      binaryNonloopPoint d B R (Sum.inl e) = 1 / 3 := by
    intro e he
    rw [d.nonremovable_eq_inactive_treeEdges] at he
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp he
    have hi := (Finset.mem_filter.mp hv).2
    have hr : v ∉ R := by
      intro hvr
      have hh := hown v hvr
      have hem : d.backGroup v = ∅ := Finset.not_nonempty_iff_eq_empty.mp hi
      simp [hem] at hh
    change expandedBinaryPoint d B R (Sum.inl (d.treeEdge v)) = _
    rw [expandedBinaryPoint_tree d B hB R v, if_pos ⟨hcover v hi, hr⟩]
  unfold edgeSum nonremovableRepresentatives
  rw [Finset.sum_map]
  simp only [Function.Embedding.inl_apply]
  rw [Finset.sum_congr rfl hvalue]
  simp [div_eq_mul_inv]

theorem binary_Z_tsp_bound (hsimple : G.IsSimple) (hconn : IsTwoVertexConnected G)
    (owner : E → Option d.StarIndex) (ho : ValidOwner d.stars owner)
    (B : Finset E) (hB : B ⊆ d.backEdges) (R : Finset d.tree.Child)
    (hown : ∀ v ∈ R, 2 ≤ (B ∩ d.backGroup v).card)
    (hwitness : ∀ v ∈ R, OriginalBypassWitness d B v)
    (hcover : ∀ v : d.tree.Child, ¬(d.backGroup v).Nonempty → SelectedTreeCover d B v)
    (rootStar : d.StarIndex) (hroot : d.centers rootStar = d.tree.root)
    (hrootR : rootStar.1 ∉ R) :
    (G.tsp : ℝ) ≤ (4 * Fintype.card V - 2) / 3 + (2 / 3) *
      (max (((B ∩ d.backGroup rootStar.1).card : ℝ) - 2) 0 +
        ∑ i ∈ Finset.univ.erase rootStar, binaryHeadCharge d B R i.1) := by
  let y := binaryNonloopPoint d B R
  have hy := binaryNonloopPoint_feasible d hsimple owner ho B hB R hown hwitness
  have hcost := frameworkTwo_tsp_bound G d.stars d.centers owner hsimple d.dfs_removable_system ho
    (completeRewardLoops_feasible edmondsJohnson_proved G d.stars d.centers owner hsimple
      d.dfs_removable_system ho hy)
  change (G.tsp : ℝ) ≤ certificate d.stars (completeRewardLoops d.stars y) at hcost
  rw [dfs_completed_certificate, binary_nonremovable_sum d B hB R hown hcover] at hcost
  let cost := fun i : d.StarIndex => max (y (Sum.inr i))
    ((d.stars i).card - 1 - edgeSum y (starRepresentatives d.stars i))
  have hl := Finset.sum_le_sum (s := Finset.univ.erase rootStar)
    (fun i _ => binary_star_cost_le d B hB R i)
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_const, nsmul_eq_mul] at hl
  have hr := binary_root_cost_le d B hB R rootStar hroot hrootR
  have hsplit := Finset.sum_erase_add (Finset.univ : Finset d.StarIndex) cost (Finset.mem_univ rootStar)
  have hcount := stars_plus_nonremovable d
  have he := Finset.card_erase_add_one (Finset.mem_univ rootStar)
  have hn := hconn.1
  have hnat : (Finset.univ \ removableEdges d.stars).card +
      (Finset.univ.erase rootStar).card + 2 = Fintype.card V := by
    simp only [Finset.card_univ] at he
    omega
  have hreal : ((Finset.univ \ removableEdges d.stars).card : ℝ) +
      (Finset.univ.erase rootStar).card + 2 = Fintype.card V := by exact_mod_cast hnat
  dsimp [cost, y] at hsplit hcost
  linarith

end TSP.Improvements20261105
