import TSP.Improvements20261105.GatedComponentPruning

/-! A component pruning can delete rewarded tree cuts only on the
outgoing boundary of that same component. -/
namespace TSP.Improvements20261105
set_option autoImplicit false
open Graph Chapter05 Chapter06 Chapter10 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]
variable {G : Graph V E} (d : DFSData G)

theorem GatedDrops.eraseBackDependencies_uncrossed_weight (P : GatePlan d) (a : GatedDrops d)
    (B : Finset (BackEdge d)) (S : Finset d.tree.Child) (w : (expandedTree d).Child)
    (hn : ¬∃ b ∈ B, onExpandedBackPath d b w) :
    (a.eraseBackDependencies d B S).trueCutWeight d P w = a.trueCutWeight d P w := by
  obtain ⟨u, rfl⟩ := (expandedTreeRoles d).surjective w
  cases u with
  | inl v =>
    have hcov : ¬backsCoverConnector d B v := by
      rintro ⟨b, hb, hp⟩
      exact hn ⟨b, hb, (expanded_connector_back_path d b v).mpr hp⟩
    change (a.eraseBackDependencies d B S).trueCutWeight d P (expandedConnectorChild d v) =
      a.trueCutWeight d P (expandedConnectorChild d v)
    simp [GatedDrops.trueRoleWeight, GatedDrops.eraseBackDependencies, hcov]
  | inr v =>
    have hcov : ¬backsCoverRepresentative d B v := by
      rintro ⟨b, hb, hp⟩
      exact hn ⟨b, hb, (expanded_representative_back_path d b v).mpr hp⟩
    change (a.eraseBackDependencies d B S).trueCutWeight d P (expandedRepresentativeChild d v) =
      a.trueCutWeight d P (expandedRepresentativeChild d v)
    simp [GatedDrops.trueRoleWeight, GatedDrops.eraseBackDependencies, hcov]

theorem GatedDrops.parent_component_of_back_cut {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (b : BackEdge d) (w : (expandedTree d).Child)
    (hw : w ∈ a.backPathCuts d P b) :
    a.component d P ((expandedTree d).parent w) = a.component d P (.inr (d.anchor b.1)) := by
  have hcard : (a.backPathCuts d P b).card = 1 := by
    have hlo := Finset.card_pos.mpr ⟨w, hw⟩
    have hhi := a.backPathCuts_card_le_one d ha b
    omega
  obtain ⟨c, hc⟩ := Finset.card_eq_one.mp hcard
  have he : w = c := by simpa [hc] using hw
  subst c
  have hu : ∀ z, z ∈ a.backPathCuts d P b → z = w := by
    intro z hz
    simpa [hc] using hz
  exact (expandedTree d).cutsOnPath_unique_before (a.trueCuts d P) w hw hu

theorem GatedDrops.pruneComponent_cut_subset {P : GatePlan d} {a : GatedDrops d}
    (ha : a.Admissible d P) (r : FlowVertex d) :
    a.trueCuts d P ⊆ (a.pruneComponent d P r).trueCuts d P ∪ a.componentOutgoingCuts d P r := by
  intro w hw
  by_cases hkeep : w ∈ (a.pruneComponent d P r).trueCuts d P
  · exact Finset.mem_union_left _ hkeep
  · apply Finset.mem_union_right
    have hcover : ∃ b ∈ a.componentBacks d P r, onExpandedBackPath d b w := by
      by_contra hn
      have he := a.eraseBackDependencies_uncrossed_weight d P
        (a.componentBacks d P r) (a.componentHeads d P r) w hn
      apply hkeep
      have hpos : 0 < a.trueCutWeight d P w := (Finset.mem_filter.mp hw).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, by
        change 0 < (a.eraseBackDependencies d _ _).trueCutWeight d P w
        rwa [he]⟩
    obtain ⟨b, hb, hpath⟩ := hcover
    have hanchor := (a.mem_componentHeads d P r (d.anchor b.1)).mp
      ((a.mem_componentBacks d P r b).mp hb)
    have hmem : w ∈ a.backPathCuts d P b := Finset.mem_filter.mpr ⟨hw, hpath⟩
    exact Finset.mem_filter.mpr ⟨hw, (a.parent_component_of_back_cut d ha b w hmem).trans hanchor.2⟩

theorem GatedDrops.pruneComponent_reward_loss (hs : G.IsSimple) (hc : IsTwoVertexConnected G)
    {P : GatePlan d} {a : GatedDrops d} (ha : a.Admissible d P) (r : FlowVertex d) :
    (∑ v : d.tree.Child, (a.reward d P v : ℝ)) -
      (∑ v : d.tree.Child, ((a.pruneComponent d P r).reward d P v : ℝ)) ≤
      ((a.componentOutgoingCuts d P r).card : ℝ) := by
  have hcard : (a.trueCuts d P).card ≤ ((a.pruneComponent d P r).trueCuts d P).card +
      (a.componentOutgoingCuts d P r).card :=
    (Finset.card_le_card (a.pruneComponent_cut_subset d ha r)).trans (Finset.card_union_le _ _)
  have hA : (∑ v : d.tree.Child, (a.reward d P v : ℝ)) = ((a.trueCuts d P).card : ℝ) := by
    exact_mod_cast a.trueCuts_reward_card d hs hc ha
  have hB : (∑ v : d.tree.Child, ((a.pruneComponent d P r).reward d P v : ℝ)) =
      (((a.pruneComponent d P r).trueCuts d P).card : ℝ) := by
    exact_mod_cast (a.pruneComponent d P r).trueCuts_reward_card d hs hc (a.pruneComponent_admissible d ha r)
  rw [hA, hB]
  have hR : ((a.trueCuts d P).card : ℝ) ≤ (((a.pruneComponent d P r).trueCuts d P).card : ℝ) +
      ((a.componentOutgoingCuts d P r).card : ℝ) := by exact_mod_cast hcard
  linarith

end TSP.Improvements20261105
