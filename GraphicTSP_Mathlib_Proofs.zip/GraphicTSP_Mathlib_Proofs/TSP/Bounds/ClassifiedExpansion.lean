import TSP.Improvements20261105.ClassifiedResourceGraph
import TSP.Improvements20261105.StarExpansionRoutes

/-! The classified partial expansion of the actual DFS graph. Only stars
at classified centers are split. The main auxiliary is the unique heavy
star; all unclassified original vertices remain major. -/
namespace TSP.Improvements20261105
open Graph Chapter03 Chapter05 Classical
open scoped BigOperators
variable {V E : Type} [Fintype V] [Fintype E] [DecidableEq V] [DecidableEq E]

abbrev ClassifiedStarIndex {G : Graph V E} (d : DFSData G) (x : E → ℝ) :=
  {i : d.StarIndex // ClassifiedCenter d x (d.centers i)}

noncomputable instance classifiedStarIndexFintype {G : Graph V E} (d : DFSData G) (x : E → ℝ) :
    Fintype (ClassifiedStarIndex d x) := Fintype.ofFinite _

noncomputable def partialStars {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (i : ClassifiedStarIndex d x) : Finset E := d.stars i.1

def partialCenter {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (i : ClassifiedStarIndex d x) : V := d.centers i.1

theorem partialStars_disjoint {G : Graph V E} (d : DFSData G) (x : E → ℝ)
    (i j : ClassifiedStarIndex d x) (hne : i ≠ j) :
    Disjoint (partialStars d x i) (partialStars d x j) := by
  apply d.groups_disjoint
  intro hh
  exact hne (Subtype.ext (Subtype.ext hh))

noncomputable def partialOwner {G : Graph V E} (d : DFSData G) (x : E → ℝ) :
    E → Option (ClassifiedStarIndex d x) :=
  Classical.choose (exists_validOwner (partialStars d x) (partialStars_disjoint d x))

theorem partialOwner_valid {G : Graph V E} (d : DFSData G) (x : E → ℝ) :
    ValidOwner (partialStars d x) (partialOwner d x) :=
  Classical.choose_spec (exists_validOwner (partialStars d x) (partialStars_disjoint d x))

noncomputable def partialMain {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (u : V) : Option (ClassifiedStarIndex d x) :=
  if hu : ClassifiedCenter d x u then
    some ⟨classifiedStar d hx hn hcap u hu, by
      change ClassifiedCenter d x (d.tree.parent (classifiedHead d x u hu))
      simpa only [(classifiedHead_spec d x u hu).1] using hu⟩
  else none

theorem partialMain_center {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (u : V) (i : ClassifiedStarIndex d x) (hi : partialMain d hx hn hcap u = some i) :
    partialCenter d x i = u := by
  unfold partialMain at hi
  split_ifs at hi with hu
  · have heq := Option.some.inj hi
    rw [← heq]
    exact (classifiedHead_spec d x u hu).1

theorem partialMain_head {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : ClassifiedStarIndex d x) :
    partialMain d hx hn hcap (partialCenter d x i) = some i ↔
      i.1.1 = classifiedHead d x (partialCenter d x i) i.2 := by
  have hu : ClassifiedCenter d x (partialCenter d x i) := i.2
  rw [partialMain, dif_pos hu]
  constructor
  · intro heq
    exact (congrArg (fun j : ClassifiedStarIndex d x => j.1.1) (Option.some.inj heq)).symm
  · intro heq
    congr 1
    apply Subtype.ext
    apply Subtype.ext
    exact heq.symm

noncomputable def classifiedExpansion {G : Graph V E} (d : DFSData G) (x : E → ℝ) :
    Graph (V ⊕ ClassifiedStarIndex d x) (E ⊕ ClassifiedStarIndex d x) :=
  auxiliaryGraph G (partialCenter d x) (partialOwner d x)

noncomputable def classifiedMajor {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) :
    V → V ⊕ ClassifiedStarIndex d x := expansionMajor (partialMain d hx hn hcap)

noncomputable def classifiedCapacity {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) :
    (E ⊕ ClassifiedStarIndex d x) → ℝ :=
  routedCapacity x (expansionRoute G (partialCenter d x) (partialOwner d x) (partialMain d hx hn hcap))

theorem classified_representative_capacity {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1) (e : E) :
    classifiedCapacity d hx hn hcap (Sum.inl e) = x e :=
  expansion_representative_capacity G _ _ _ x e

theorem classified_anchor_capacity {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : ClassifiedStarIndex d x) :
    classifiedCapacity d hx hn hcap (Sum.inr i) =
      if partialMain d hx hn hcap (partialCenter d x i) = some i
      then edgeSum x (minorBoundary d x (partialCenter d x i)) else edgeSum x (partialStars d x i) := by
  by_cases hi : partialMain d hx hn hcap (partialCenter d x i) = some i
  · rw [if_pos hi]
    have hc := expansion_main_capacity G hsimple.1 (partialStars d x) (partialCenter d x)
      (partialOwner d x) (partialOwner_valid d x) (partialMain d hx hn hcap) x i hi
    change classifiedCapacity d hx hn hcap (Sum.inr i) = _ at hc
    have hu : ClassifiedCenter d x (partialCenter d x i) := i.2
    rw [hc, minorBoundary, dif_pos hu]
    have hh := (partialMain_head d hx hn hcap i).mp hi
    change edgeSum x (G.cut {partialCenter d x i} \ d.group i.1.1) = _
    rw [hh]
  · rw [if_neg hi]
    exact expansion_light_capacity G (partialStars d x) (partialCenter d x) (partialOwner d x)
      (partialOwner_valid d x) (partialMain d hx hn hcap) x i hi

theorem classified_anchor_capacity_bounds {G : Graph V E} (d : DFSData G) (hsimple : G.IsSimple)
    {x : E → ℝ} (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (i : ClassifiedStarIndex d x) :
    0 ≤ classifiedCapacity d hx hn hcap (Sum.inr i) ∧ classifiedCapacity d hx hn hcap (Sum.inr i) < 1 := by
  rw [classified_anchor_capacity d hsimple hx hn hcap i]
  split_ifs with hi
  · exact ⟨Finset.sum_nonneg (fun e _ => hx.1 e), minorBoundary_mass_lt_one d hsimple x _⟩
  · refine ⟨Finset.sum_nonneg (fun e _ => hx.1 e), ?_⟩
    exact light_group_mass_lt_one d hsimple hx.1 (partialCenter d x i) i.2 i.1.1 rfl
      (fun hh => hi ((partialMain_head d hx hn hcap i).mpr hh))

/-- Every cut separating actual major vertices has capacity at least two.
The capacity identities above identify this with the manuscript's shield. -/
theorem classified_major_cut_shield {G : Graph V E} (d : DFSData G) {x : E → ℝ}
    (hx : G.SubtourFeasible x) (hn : 2 ≤ Fintype.card V) (hcap : ∀ e, x e ≤ 1)
    (U : Finset (V ⊕ ClassifiedStarIndex d x))
    (hl : ∃ u, classifiedMajor d hx hn hcap u ∈ U)
    (hr : ∃ u, classifiedMajor d hx hn hcap u ∉ U) :
    2 ≤ edgeSum (classifiedCapacity d hx hn hcap) ((classifiedExpansion d x).cut U) :=
  expansion_major_cut_capacity G (partialCenter d x) (partialOwner d x) (partialMain d hx hn hcap)
    (partialMain_center d hx hn hcap) hx U hl hr

end TSP.Improvements20261105
